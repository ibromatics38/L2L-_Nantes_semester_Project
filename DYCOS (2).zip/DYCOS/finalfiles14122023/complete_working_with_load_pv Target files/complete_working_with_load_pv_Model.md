Model complete_working_with_load_pv


REM LUT solver inputs...
rtds_write 0x01000000 0x00000000