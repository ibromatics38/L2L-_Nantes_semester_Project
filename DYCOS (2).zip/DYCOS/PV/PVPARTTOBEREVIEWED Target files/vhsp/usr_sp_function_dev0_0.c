// generated using template: cop_main.template---------------------------------------------
/******************************************************************************************
**
**  Module Name: cop_main.c
**  NOTE: Automatically generated file. DO NOT MODIFY!
**  Description:
**            Main file
**
******************************************************************************************/
// generated using template: arm/custom_include.template-----------------------------------


#ifdef __cplusplus
#include <limits>

extern "C" {
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <stdint.h>
#include <complex.h>

// x86 libraries:
#include "../include/sp_functions_dev0.h"


#ifdef __cplusplus
}
#endif


// ----------------------------------------------------------------------------------------                // generated using template:generic_macros.template-----------------------------------------
/*********************** Macros (Inline Functions) Definitions ***************************/

// ----------------------------------------------------------------------------------------

#ifndef MAX
#define MAX(value, limit) (((value) > (limit)) ? (value) : (limit))
#endif
#ifndef MIN
#define MIN(value, limit) (((value) < (limit)) ? (value) : (limit))
#endif

// generated using template: VirtualHIL/custom_defines.template----------------------------

typedef unsigned char X_UnInt8;
typedef char X_Int8;
typedef signed short X_Int16;
typedef unsigned short X_UnInt16;
typedef int X_Int32;
typedef unsigned int X_UnInt32;
typedef unsigned int uint;
typedef double real;

// ----------------------------------------------------------------------------------------
// generated using template: custom_consts.template----------------------------------------

// arithmetic constants
#define C_SQRT_2                    1.4142135623730950488016887242097f
#define C_SQRT_3                    1.7320508075688772935274463415059f
#define C_PI                        3.1415926535897932384626433832795f
#define C_E                         2.7182818284590452353602874713527f
#define C_2PI                       6.283185307179586476925286766559f

//@cmp.def.start
//component defines





















































































































































































































//@cmp.def.end


//-----------------------------------------------------------------------------------------
// generated using template: common_variables.template-------------------------------------
// true global variables



//@cmp.var.start
// variables
double _pv_plant_control_grid_follow_constant1__out = 0.0;
double _pv_plant_control_grid_follow_constant2__out = 0.0;
double _pv_plant_control_grid_follow_constant3__out = 1.0;
double _pv_plant_control_grid_follow_controlsignal_calculation_damp__out = 0.0;
double _pv_plant_control_grid_follow_controlsignal_calculation_limit3__out;
double _pv_plant_control_grid_follow_edge_detection1_unit_delay1__out;
double _pv_plant_control_grid_follow_limit_pqref_unit_delay1__out;
double _pv_plant_control_grid_follow_limit_pqref_unit_delay2__out;
double _pv_plant_control_grid_follow_pv_area_m2__out = 5556.0;
double _pv_plant_control_grid_follow_power_meas_gain4__out;
double _pv_plant_control_grid_follow_power_meas_gain5__out;
double _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_s_and_pf__P;
double _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_s_and_pf__Q;


double _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_s_and_pf__S;
double _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_s_and_pf__pf;
double _pv_plant_control_pll_constant1__out = 0.0;
double _pv_plant_control_pll_pll_pid_integrator1__out;
double _pv_plant_control_pll_pll_pid_integrator2__out;
double _pv_plant_control_pll_pll_unit_delay1__out;
double _pv_plant_control_pll_pll_to_hz__out;
double _pv_plant_control_duty_cycle_zsm_constant1__out = 0.5;
double _pv_plant_control_duty_cycle_zsm_constant2__out = 1.0;
double _pv_plant_control_duty_cycle_zsm_constant3__out = 1.0;
double _pv_plant_control_duty_cycle_zsm_constant4__out = 1.0;
double _pv_plant_control_duty_cycle_o_ref__out = 0.0;
double _pv_plant_ia_ia1__out;
double _pv_plant_ib_ia1__out;
double _pv_plant_ic_ia1__out;
double _pv_plant_vdc__out = 1000.0;
double _pv_plant_va_va1__out;
double _pv_plant_vb_va1__out;
double _pv_plant_vc_va1__out;
double _pv_plant_vdc_va1__out;
double _pv_in_connect__out;
double _pv_in_enable__out;
double _pv_in_irradiation__out;
double _pv_in_q_mode__out;
double _pv_in_q_ref__out;
double _pv_in_v_ref__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_gain5__out;
double _pv_plant_control_grid_follow_power_meas_gain6__out;
double _pv_plant_control_pll_gain1__out;
double _pv_plant_control_duty_cycle_zsm_limit1__out;
double _pv_plant_control_grid_follow_current_abc_to_dq_abc_to_dq1_abc_to_alpha_beta__alpha;
double _pv_plant_control_grid_follow_current_abc_to_dq_abc_to_dq1_abc_to_alpha_beta__beta;
double _pv_plant_control_grid_follow_current_abc_to_dq_abc_to_dq1_abc_to_alpha_beta__gamma;
double _pv_plant_control_grid_follow_gain3__out;
double _pv_in_bus_join1__out[6];
double _pv_plant_control_duty_cycle_zsm_sum2__out;
double _pv_plant_control_duty_cycle_zsm_sum8__out;
double _pv_plant_control_grid_follow_current_abc_to_dq_abc_to_dq1_alpha_beta_to_dq__d;
double _pv_plant_control_grid_follow_current_abc_to_dq_abc_to_dq1_alpha_beta_to_dq__q;
double _pv_plant_control_grid_follow_current_abc_to_dq_abc_to_dq1_alpha_beta_to_dq__k1;
double _pv_plant_control_grid_follow_current_abc_to_dq_abc_to_dq1_alpha_beta_to_dq__k2;
double _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__b_coeff[2] = {0.0006279239944363413, 0.0006279239944364523};
double _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__a_coeff[2] = {1.0, -0.9987441520111273};
double _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__a_sum;
double _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__b_sum;
double _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__delay_line_in;
double _pv_plant_input_bus_split2__out;
double _pv_plant_input_bus_split2__out1;
double _pv_plant_input_bus_split2__out2;
double _pv_plant_input_bus_split2__out3;
double _pv_plant_input_bus_split2__out4;
double _pv_plant_input_bus_split2__out5;
double _pv_plant_control_grid_follow_current_abc_to_dq_gain1__out;
double _pv_plant_control_grid_follow_current_abc_to_dq_gain2__out;
double _pv_plant_control_grid_follow_edge_detection1_relational_operator1__out;
double _pv_plant_control_grid_follow_gain2__out;
double _pv_plant_control_grid_follow_gain4__out;
double _pv_plant_control_grid_follow_logical_operator1__out;
double _pv_plant_control_grid_follow_product2__out;
float _pv_plant_control_grid_follow_qmode__tmp;

double _pv_plant_control_grid_follow_delay__in;


double _pv_plant_control_grid_follow_delay__out;
double _pv_plant_control_pll_signal_switch1__out;
double _pv_plant_control_pll_signal_switch2__out;
double _pv_plant_control_pll_signal_switch3__out;

double _pv_plant_delay__in;


double _pv_plant_delay__out;
float _pv_plant_enable__tmp;
double _pv_plant_control_grid_follow_controlsignal_calculation_gain2__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_product5__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_gain1__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_product6__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_integrator1__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_integrator1__out;
double _pv_plant_control_grid_follow_pi_vt_integrator1__out;
double _pv_plant_control_grid_follow_pv_eff__out;
double _pv_plant_control_grid_follow_logical_operator2__out;
double _pv_plant_control_pll_pll_abc_to_dq_abc_to_alpha_beta__alpha;
double _pv_plant_control_pll_pll_abc_to_dq_abc_to_alpha_beta__beta;
double _pv_plant_control_pll_pll_abc_to_dq_abc_to_alpha_beta__gamma;
double _pv_plant_logical_operator1__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_product2__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_product1__out;
double _pv_plant_control_grid_follow_to_pu__out;
double _pv_plant_control_grid_follow_signal_switch3__out;
double _pv_plant_control_pll_pll_abc_to_dq_alpha_beta_to_dq__d;
double _pv_plant_control_pll_pll_abc_to_dq_alpha_beta_to_dq__q;
double _pv_plant_control_pll_pll_abc_to_dq_alpha_beta_to_dq__k1;
double _pv_plant_control_pll_pll_abc_to_dq_alpha_beta_to_dq__k2;
float _pv_plant_on__tmp;
double _pv_plant_control_grid_follow_signal_switch2__out;
double _pv_plant_control_pll_pll_abc_to_dq_lpf_d__out;
double _pv_plant_control_pll_pll_abc_to_dq_lpf_d__previous_filtered_value;
double _pv_plant_control_pll_pll_abc_to_dq_lpf_q__out;
double _pv_plant_control_pll_pll_abc_to_dq_lpf_q__previous_filtered_value;
double _pv_plant_control_pll_gain4__out;
double _pv_plant_control_pll_gain3__out;
double _pv_plant_control_pll_pll_normalize__in1;
double _pv_plant_control_pll_pll_normalize__in2;


double _pv_plant_control_pll_pll_normalize__in2_pu;
double _pv_plant_control_pll_pll_normalize__pk;
double _pv_plant_control_grid_follow_controlsignal_calculation_sum5__out;
double _pv_plant_control_grid_follow_current_ref_product4__out;
double _pv_plant_control_grid_follow_current_ref_product5__out;
double _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_product1__out;
double _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_product3__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_sum6__out;
double _pv_plant_control_grid_follow_current_ref_product3__out;
double _pv_plant_control_grid_follow_current_ref_product6__out;
double _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_product2__out;
double _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_product4__out;
double _pv_plant_control_pll_gain5__out;
double _pv_plant_control_pll_pll_pid_kd__out;
double _pv_plant_control_pll_pll_pid_ki__out;
double _pv_plant_control_pll_pll_pid_kp__out;
double _pv_plant_output_bus_join1__out[14];
double _pv_plant_control_grid_follow_current_ref_sum3__out;
double _pv_plant_control_grid_follow_current_ref_sum4__out;
double _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_sum1__out;
double _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_sum2__out;
double _pv_plant_control_grid_follow_current_ref_product7__out;
double _pv_plant_control_grid_follow_signal_switch4__out;
double _pv_plant_control_pll_pll_pid_sum8__out;
double _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__out;
double _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__b_coeff[2] = {0.0006279239944363413, 0.0006279239944364523};
double _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__a_coeff[2] = {1.0, -0.9987441520111273};
double _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__a_sum;
double _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__b_sum;
double _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__delay_line_in;
double _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__out;
double _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__b_coeff[2] = {0.0006279239944363413, 0.0006279239944364523};
double _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__a_coeff[2] = {1.0, -0.9987441520111273};
double _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__a_sum;
double _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__b_sum;
double _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__delay_line_in;
double _pv_plant_control_grid_follow_current_ref_limit3__out;
double _pv_plant_control_grid_follow_sum1__out;
double _pv_plant_control_pll_pll_pid_gain1__out;
double _pv_plant_control_grid_follow_current_ref_product1__out;
double _pv_plant_control_grid_follow_current_ref_product2__out;
double _pv_plant_control_grid_follow_pi_vt_ki__out;
double _pv_plant_control_grid_follow_pi_vt_kp__out;
double _pv_plant_control_pll_pll_pid_sum5__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_sum2__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_sum1__out;
double _pv_plant_control_grid_follow_pi_vt_sum5__out;
double _pv_plant_control_pll_pll_pid_limit1__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_ki__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_kp__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_ki__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_kp__out;
double _pv_plant_control_grid_follow_pi_vt_limit1__out;
double _pv_plant_control_pll_pll_pid_sum6__out;
double _pv_plant_control_pll_pll_rate_limiter1__out;

double _pv_plant_control_pll_pll_integrator__in;


double _pv_plant_control_pll_pll_integrator__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_sum5__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_sum5__out;
double _pv_plant_control_grid_follow_pi_vt_sum6__out;
double _pv_plant_control_grid_follow_signal_switch1__out;
double _pv_plant_control_pll_pll_pid_kb__out;
double _pv_plant_control_pll_pll_lpf_lpf__out;
double _pv_plant_control_pll_pll_lpf_lpf__b_coeff[1] = {0.0009869600294464265};
double _pv_plant_control_pll_pll_lpf_lpf__a_coeff[3] = {1.0, -1.95557788912, 0.9565648491494463};
double _pv_plant_control_pll_pll_lpf_lpf__a_sum;
double _pv_plant_control_pll_pll_lpf_lpf__b_sum;
double _pv_plant_control_pll_pll_lpf_lpf__delay_line_in;
double _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_limit1__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_limit1__out;
double _pv_plant_control_grid_follow_pi_vt_kb__out;
double _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Pref;
double _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Qref;
double _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Smax;


double _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__P;
double _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q;
double _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__S;
double _pv_plant_control_pll_pll_pid_sum7__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_sum6__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_sum7__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_sum6__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_sum3__out;
double _pv_plant_control_grid_follow_pi_vt_sum7__out;
double _pv_plant_control_grid_follow_limit_pqref_p_rate_limit__out;
double _pv_plant_control_grid_follow_limit_pqref_q_rate_limit__out;
double _pv_plant_control_grid_follow_limit_pqref_s_rate_limit__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_kb__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_product7__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_kb__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_product8__out;

double _pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__Pref;
double _pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__Qref;
double _pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__Sref;


double _pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__P;
double _pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__Q;
double _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_sum7__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_gain11__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_sum7__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_gain10__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_sum9__out;
double _pv_plant_control_grid_follow_controlsignal_calculation_sum8__out;
double _pv_plant_control_duty_cycle_limit3__out;
double _pv_plant_control_duty_cycle_limit2__out;
double _pv_plant_control_duty_cycle_dq_to_abc1_dq_to_alpha_beta__alpha;
double _pv_plant_control_duty_cycle_dq_to_abc1_dq_to_alpha_beta__beta;
double _pv_plant_control_duty_cycle_dq_to_abc1_dq_to_alpha_beta__k1;
double _pv_plant_control_duty_cycle_dq_to_abc1_dq_to_alpha_beta__k2;
double _pv_plant_control_duty_cycle_dq_to_abc1_alpha_beta_to_abc__A;
double _pv_plant_control_duty_cycle_dq_to_abc1_alpha_beta_to_abc__B;
double _pv_plant_control_duty_cycle_dq_to_abc1_alpha_beta_to_abc__C;
double _pv_plant_control_duty_cycle_zsm_min_max1__out;
double _pv_plant_control_duty_cycle_zsm_min_max2__out;
double _pv_plant_control_duty_cycle_zsm_product2__out;
double _pv_plant_control_duty_cycle_zsm_sum1__out;
double _pv_plant_control_duty_cycle_zsm_product1__out;
double _pv_plant_control_duty_cycle_zsm_sum3__out;
double _pv_plant_control_duty_cycle_zsm_sum5__out;
double _pv_plant_control_duty_cycle_zsm_sum6__out;
double _pv_plant_control_duty_cycle_zsm_sum7__out;
X_UnInt32 _pv_plant_3ph_inverter_1_phase_a_pwm_modulator__channels[1] = {0};
double _pv_plant_3ph_inverter_1_phase_a_pwm_modulator__limited_in[1];
X_UnInt32 _pv_plant_3ph_inverter_1_phase_a_pwm_modulator__update_mask;
X_UnInt32 _pv_plant_3ph_inverter_1_phase_a_pwm_modulator__sig_dir[1];

X_UnInt32 _pv_plant_3ph_inverter_1_phase_b_pwm_modulator__channels[1] = {1};
double _pv_plant_3ph_inverter_1_phase_b_pwm_modulator__limited_in[1];
X_UnInt32 _pv_plant_3ph_inverter_1_phase_b_pwm_modulator__update_mask;
X_UnInt32 _pv_plant_3ph_inverter_1_phase_b_pwm_modulator__sig_dir[1];

X_UnInt32 _pv_plant_3ph_inverter_1_phase_c_pwm_modulator__channels[1] = {2};
double _pv_plant_3ph_inverter_1_phase_c_pwm_modulator__limited_in[1];
X_UnInt32 _pv_plant_3ph_inverter_1_phase_c_pwm_modulator__update_mask;
X_UnInt32 _pv_plant_3ph_inverter_1_phase_c_pwm_modulator__sig_dir[1];

//@cmp.var.end

//@cmp.svar.start
// state variables
double _pv_plant_control_grid_follow_edge_detection1_unit_delay1__state;
double _pv_plant_control_grid_follow_limit_pqref_unit_delay1__state;
double _pv_plant_control_grid_follow_limit_pqref_unit_delay2__state;
double _pv_plant_control_pll_pll_pid_integrator1__state;
double _pv_plant_control_pll_pll_pid_integrator2__state;
double _pv_plant_control_pll_pll_unit_delay1__state;
double _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__states[1];
double _pv_plant_control_grid_follow_delay__counter;
double _pv_plant_delay__counter;
double _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_integrator1__state;
double _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_integrator1__reset_state;
double _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_integrator1__state;
double _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_integrator1__reset_state;
double _pv_plant_control_grid_follow_pi_vt_integrator1__state;
double _pv_plant_control_grid_follow_pi_vt_integrator1__reset_state;
double _pv_plant_control_pll_pll_abc_to_dq_lpf_d__filtered_value;
double _pv_plant_control_pll_pll_abc_to_dq_lpf_d__previous_in;
double _pv_plant_control_pll_pll_abc_to_dq_lpf_q__filtered_value;
double _pv_plant_control_pll_pll_abc_to_dq_lpf_q__previous_in;
double _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__states[1];
double _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__states[1];
double _pv_plant_control_pll_pll_rate_limiter1__state;
X_Int32 _pv_plant_control_pll_pll_rate_limiter1__first_step;
double _pv_plant_control_pll_pll_lpf_lpf__states[2];
double _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__signQ;
double _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__signP;
double _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Sref;
double _pv_plant_control_grid_follow_limit_pqref_p_rate_limit__state;
X_Int32 _pv_plant_control_grid_follow_limit_pqref_p_rate_limit__first_step;
double _pv_plant_control_grid_follow_limit_pqref_q_rate_limit__state;
X_Int32 _pv_plant_control_grid_follow_limit_pqref_q_rate_limit__first_step;
double _pv_plant_control_grid_follow_limit_pqref_s_rate_limit__state;
X_Int32 _pv_plant_control_grid_follow_limit_pqref_s_rate_limit__first_step;
double _pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__S_PQref;
//@cmp.svar.end

//
// Tunable parameters
//
static struct Tunable_params {
} __attribute__((__packed__)) tunable_params;

void *tunable_params_dev0_cpu0_ptr = &tunable_params;

// Dll function pointers
#if defined(_WIN64)
#else
// Define handles for loading dlls
#endif








// generated using template: virtual_hil/custom_functions.template---------------------------------
void ReInit_user_sp_cpu0_dev0() {
#if DEBUG_MODE
    printf("\n\rReInitTimer");
#endif
    //@cmp.init.block.start
    _pv_plant_control_grid_follow_edge_detection1_unit_delay1__state = 0.0;
    _pv_plant_control_grid_follow_limit_pqref_unit_delay1__state = 0.0;
    _pv_plant_control_grid_follow_limit_pqref_unit_delay2__state = 0.0;
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_s_and_pf__P = 0;
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_s_and_pf__Q = 0;
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_s_and_pf__S = 0;
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_s_and_pf__pf = 0;
    _pv_plant_control_pll_pll_pid_integrator1__state = 376.99111843;
    _pv_plant_control_pll_pll_pid_integrator2__state = 0.0;
    _pv_plant_control_pll_pll_unit_delay1__state = 0.0;
    HIL_OutAO(0x4000, 0.0f);
    HIL_OutAO(0x4003, 0.0f);
    HIL_OutAO(0x4005, 0.0f);
    HIL_OutAO(0x4010, 0.0f);
    HIL_OutAO(0x4012, 0.0f);
    HIL_OutAO(0x4014, 0.0f);
    HIL_OutFloat(137101312, 0.0);
    HIL_OutAO(0x4007, 0.0f);
    HIL_OutAO(0x4011, 0.0f);
    X_UnInt32 _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__i;
    for (_pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__i = 0; _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__i < 1; _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__i++) {
        _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__states[_pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__i] = 0;
    }
    _pv_plant_control_grid_follow_delay__out = 0;
    _pv_plant_control_grid_follow_delay__counter = 0;
    HIL_OutAO(0x400f, 0.0f);
    _pv_plant_delay__out = 0;
    _pv_plant_delay__counter = 0;
    HIL_OutAO(0x400d, 0.0f);
    HIL_OutAO(0x400e, 0.0f);
    _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_integrator1__state = 0.0;
    _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_integrator1__reset_state = 2;
    _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_integrator1__state = 0.0;
    _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_integrator1__reset_state = 2;
    _pv_plant_control_grid_follow_pi_vt_integrator1__state = 0.0;
    _pv_plant_control_grid_follow_pi_vt_integrator1__reset_state = 2;
    _pv_plant_control_pll_pll_abc_to_dq_lpf_d__filtered_value = 0.0 / (1 - 1.0 * 62.83185307 * 0.0002 );
    _pv_plant_control_pll_pll_abc_to_dq_lpf_d__previous_in = 0x0;
    _pv_plant_control_pll_pll_abc_to_dq_lpf_q__filtered_value = 0.0 / (1 - 1.0 * 62.83185307 * 0.0002 );
    _pv_plant_control_pll_pll_abc_to_dq_lpf_q__previous_in = 0x0;
    HIL_OutAO(0x4004, 0.0f);
    _pv_plant_control_pll_pll_normalize__pk = 0;
    HIL_OutAO(0x400a, 0.0f);
    HIL_OutAO(0x400b, 0.0f);
    HIL_OutAO(0x4013, 0.0f);
    HIL_OutAO(0x400c, 0.0f);
    HIL_OutAO(0x401e, 0.0f);
    HIL_OutAO(0x401f, 0.0f);
    HIL_OutAO(0x4020, 0.0f);
    HIL_OutAO(0x4021, 0.0f);
    HIL_OutAO(0x4022, 0.0f);
    HIL_OutAO(0x4023, 0.0f);
    HIL_OutAO(0x4024, 0.0f);
    HIL_OutAO(0x4025, 0.0f);
    HIL_OutAO(0x4026, 0.0f);
    HIL_OutAO(0x4027, 0.0f);
    HIL_OutAO(0x4028, 0.0f);
    HIL_OutAO(0x4029, 0.0f);
    HIL_OutAO(0x402a, 0.0f);
    HIL_OutAO(0x402b, 0.0f);
    X_UnInt32 _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__i;
    for (_pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__i = 0; _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__i < 1; _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__i++) {
        _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__states[_pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__i] = 0;
    }
    X_UnInt32 _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__i;
    for (_pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__i = 0; _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__i < 1; _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__i++) {
        _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__states[_pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__i] = 0;
    }
    HIL_OutAO(0x4002, 0.0f);
    HIL_OutAO(0x4001, 0.0f);
    _pv_plant_control_pll_pll_rate_limiter1__state = 0;
    _pv_plant_control_pll_pll_rate_limiter1__first_step = 1;
    _pv_plant_control_pll_pll_integrator__out = 0;
    X_UnInt32 _pv_plant_control_pll_pll_lpf_lpf__i;
    for (_pv_plant_control_pll_pll_lpf_lpf__i = 0; _pv_plant_control_pll_pll_lpf_lpf__i < 2; _pv_plant_control_pll_pll_lpf_lpf__i++) {
        _pv_plant_control_pll_pll_lpf_lpf__states[_pv_plant_control_pll_pll_lpf_lpf__i] = 0;
    }
    _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Sref = 0;
    HIL_OutAO(0x4006, 0.0f);
    _pv_plant_control_grid_follow_limit_pqref_p_rate_limit__state = 0;
    _pv_plant_control_grid_follow_limit_pqref_p_rate_limit__first_step = 1;
    _pv_plant_control_grid_follow_limit_pqref_q_rate_limit__state = 0;
    _pv_plant_control_grid_follow_limit_pqref_q_rate_limit__first_step = 1;
    _pv_plant_control_grid_follow_limit_pqref_s_rate_limit__state = 0;
    _pv_plant_control_grid_follow_limit_pqref_s_rate_limit__first_step = 1;
    _pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__S_PQref = 0;
    HIL_OutAO(0x4009, 0.0f);
    HIL_OutAO(0x4008, 0.0f);
    HIL_OutAO(0x401d, 0.0f);
    HIL_OutAO(0x401c, 0.0f);
    HIL_OutAO(0x4015, 0.0f);
    HIL_OutAO(0x4016, 0.0f);
    HIL_OutAO(0x4017, 0.0f);
    HIL_OutAO(0x401b, 0.0f);
    _pv_plant_3ph_inverter_1_phase_a_pwm_modulator__update_mask = 1;
    HIL_OutInt32(0x2000080 + _pv_plant_3ph_inverter_1_phase_a_pwm_modulator__channels[0], 20000);// divide by 2 is already implemented in hw
    HIL_OutInt32(0x20000c0 + _pv_plant_3ph_inverter_1_phase_a_pwm_modulator__channels[0], 400);
    HIL_OutInt32(0x20001c0 + _pv_plant_3ph_inverter_1_phase_a_pwm_modulator__channels[0], 0);
    HIL_OutInt32(0x2000200 + _pv_plant_3ph_inverter_1_phase_a_pwm_modulator__channels[0], 0);
    HIL_OutInt32(0x2000240 + _pv_plant_3ph_inverter_1_phase_a_pwm_modulator__channels[0], 0);
    HIL_OutInt32(0x2000300 + _pv_plant_3ph_inverter_1_phase_a_pwm_modulator__channels[0], 1);
    HIL_OutInt32(0x2000140, _pv_plant_3ph_inverter_1_phase_a_pwm_modulator__update_mask);
    HIL_OutAO(0x4018, 0.0f);
    _pv_plant_3ph_inverter_1_phase_b_pwm_modulator__update_mask = 2;
    HIL_OutInt32(0x2000080 + _pv_plant_3ph_inverter_1_phase_b_pwm_modulator__channels[0], 20000);// divide by 2 is already implemented in hw
    HIL_OutInt32(0x20000c0 + _pv_plant_3ph_inverter_1_phase_b_pwm_modulator__channels[0], 400);
    HIL_OutInt32(0x20001c0 + _pv_plant_3ph_inverter_1_phase_b_pwm_modulator__channels[0], 0);
    HIL_OutInt32(0x2000200 + _pv_plant_3ph_inverter_1_phase_b_pwm_modulator__channels[0], 0);
    HIL_OutInt32(0x2000240 + _pv_plant_3ph_inverter_1_phase_b_pwm_modulator__channels[0], 0);
    HIL_OutInt32(0x2000300 + _pv_plant_3ph_inverter_1_phase_b_pwm_modulator__channels[0], 1);
    HIL_OutInt32(0x2000140, _pv_plant_3ph_inverter_1_phase_b_pwm_modulator__update_mask);
    HIL_OutAO(0x4019, 0.0f);
    _pv_plant_3ph_inverter_1_phase_c_pwm_modulator__update_mask = 4;
    HIL_OutInt32(0x2000080 + _pv_plant_3ph_inverter_1_phase_c_pwm_modulator__channels[0], 20000);// divide by 2 is already implemented in hw
    HIL_OutInt32(0x20000c0 + _pv_plant_3ph_inverter_1_phase_c_pwm_modulator__channels[0], 400);
    HIL_OutInt32(0x20001c0 + _pv_plant_3ph_inverter_1_phase_c_pwm_modulator__channels[0], 0);
    HIL_OutInt32(0x2000200 + _pv_plant_3ph_inverter_1_phase_c_pwm_modulator__channels[0], 0);
    HIL_OutInt32(0x2000240 + _pv_plant_3ph_inverter_1_phase_c_pwm_modulator__channels[0], 0);
    HIL_OutInt32(0x2000300 + _pv_plant_3ph_inverter_1_phase_c_pwm_modulator__channels[0], 1);
    HIL_OutInt32(0x2000140, _pv_plant_3ph_inverter_1_phase_c_pwm_modulator__update_mask);
    HIL_OutAO(0x401a, 0.0f);
    //@cmp.init.block.end
}


// Dll function pointers and dll reload function
#if defined(_WIN64)
// Define method for reloading dll functions
void ReloadDllFunctions_user_sp_cpu0_dev0(void) {
    // Load each library and setup function pointers
}

void FreeDllFunctions_user_sp_cpu0_dev0(void) {
}

#else
// Define method for reloading dll functions
void ReloadDllFunctions_user_sp_cpu0_dev0(void) {
    // Load each library and setup function pointers
}

void FreeDllFunctions_user_sp_cpu0_dev0(void) {
}
#endif

void load_fmi_libraries_user_sp_cpu0_dev0(void) {
#if defined(_WIN64)
#else
#endif
}


void ReInit_sp_scope_user_sp_cpu0_dev0() {
    // initialise SP Scope buffer pointer
}
// generated using template: common_timer_counter_handler.template-------------------------

/*****************************************************************************************/
/**
* This function is the handler which performs processing for the timer counter.
* It is called from an interrupt context such that the amount of processing
* performed should be minimized.  It is called when the timer counter expires
* if interrupts are enabled.
*
*
* @param    None
*
* @return   None
*
* @note     None
*
*****************************************************************************************/

void TimerCounterHandler_0_user_sp_cpu0_dev0() {
#if DEBUG_MODE
    printf("\n\rTimerCounterHandler_0");
#endif
    //////////////////////////////////////////////////////////////////////////
    // Set tunable parameters
    //////////////////////////////////////////////////////////////////////////
    // Generated from the component: PV_Plant.Control.Grid_follow.Constant1
    // Generated from the component: PV_Plant.Control.Grid_follow.Constant2
    // Generated from the component: PV_Plant.Control.Grid_follow.Constant3
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.Damp
    // Generated from the component: PV_Plant.Control.Grid_follow.PV_Area_m2
    // Generated from the component: PV_Plant.Control.PLL.Constant1
    // Generated from the component: PV_Plant.Control.duty_cycle.ZSM.Constant1
    // Generated from the component: PV_Plant.Control.duty_cycle.ZSM.Constant2
    // Generated from the component: PV_Plant.Control.duty_cycle.ZSM.Constant3
    // Generated from the component: PV_Plant.Control.duty_cycle.ZSM.Constant4
    // Generated from the component: PV_Plant.Control.duty_cycle.o_ref
    // Generated from the component: PV_Plant.VDC
//////////////////////////////////////////////////////////////////////////
    // Output block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.out.block.start
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.Limit3
    _pv_plant_control_grid_follow_controlsignal_calculation_limit3__out = MAX(_pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__out, 0.01);
    // Generated from the component: PV_Plant.Control.Grid_follow.Edge Detection1.Unit Delay1
    _pv_plant_control_grid_follow_edge_detection1_unit_delay1__out = _pv_plant_control_grid_follow_edge_detection1_unit_delay1__state;
    // Generated from the component: PV_Plant.Control.Grid_follow.Limit_PQref.Unit Delay1
    _pv_plant_control_grid_follow_limit_pqref_unit_delay1__out = _pv_plant_control_grid_follow_limit_pqref_unit_delay1__state;
    // Generated from the component: PV_Plant.Control.Grid_follow.Limit_PQref.Unit Delay2
    _pv_plant_control_grid_follow_limit_pqref_unit_delay2__out = _pv_plant_control_grid_follow_limit_pqref_unit_delay2__state;
    // Generated from the component: PV_Plant.Control.Grid_follow.Power_Meas.Gain4
    _pv_plant_control_grid_follow_power_meas_gain4__out = 5000000.0 * _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.Power_Meas.Gain5
    _pv_plant_control_grid_follow_power_meas_gain5__out = 5000000.0 * _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.Power_Meas.Power_Meas_DQpu.S_and_pf
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_s_and_pf__P = _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__out;
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_s_and_pf__Q = _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__out;
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_s_and_pf__S = sqrt(_pv_plant_control_grid_follow_power_meas_power_meas_dqpu_s_and_pf__P * _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_s_and_pf__P + _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_s_and_pf__Q * _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_s_and_pf__Q);
    if (_pv_plant_control_grid_follow_power_meas_power_meas_dqpu_s_and_pf__S > 0) {
        _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_s_and_pf__pf = _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_s_and_pf__P / _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_s_and_pf__S;
    }
    else {
        _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_s_and_pf__pf = 0;
    }
    // Generated from the component: PV_Plant.Control.PLL.PLL.PID.Integrator1
    _pv_plant_control_pll_pll_pid_integrator1__out = _pv_plant_control_pll_pll_pid_integrator1__state;
    // Generated from the component: PV_Plant.Control.PLL.PLL.PID.Integrator2
    _pv_plant_control_pll_pll_pid_integrator2__out = _pv_plant_control_pll_pll_pid_integrator2__state;
    // Generated from the component: PV_Plant.Control.PLL.PLL.Unit Delay1
    _pv_plant_control_pll_pll_unit_delay1__out = _pv_plant_control_pll_pll_unit_delay1__state;
    // Generated from the component: PV_Plant.Control.PLL.PLL.to_Hz
    _pv_plant_control_pll_pll_to_hz__out = 0.15915494309189535 * _pv_plant_control_pll_pll_lpf_lpf__out;
    // Generated from the component: PV_Plant.Ia.Ia1
    _pv_plant_ia_ia1__out = (HIL_InFloat(0xc80000 + 0x13));
    // Generated from the component: PV_Plant.Ib.Ia1
    _pv_plant_ib_ia1__out = (HIL_InFloat(0xc80000 + 0x17));
    // Generated from the component: PV_Plant.Ic.Ia1
    _pv_plant_ic_ia1__out = (HIL_InFloat(0xc80000 + 0x18));
    // Generated from the component: PV_Plant.Va.Va1
    _pv_plant_va_va1__out = (HIL_InFloat(0xc80000 + 0x9));
    // Generated from the component: PV_Plant.Vb.Va1
    _pv_plant_vb_va1__out = (HIL_InFloat(0xc80000 + 0xf));
    // Generated from the component: PV_Plant.Vc.Va1
    _pv_plant_vc_va1__out = (HIL_InFloat(0xc80000 + 0x11));
    // Generated from the component: PV_Plant.Vdc.Va1
    _pv_plant_vdc_va1__out = (HIL_InFloat(0xc80000 + 0x12));
    // Generated from the component: PV_in.Connect
    _pv_in_connect__out = XIo_InFloat(0x55000100);
    // Generated from the component: PV_in.Enable
    _pv_in_enable__out = XIo_InFloat(0x55000104);
    // Generated from the component: PV_in.Irradiation
    _pv_in_irradiation__out = XIo_InFloat(0x55000108);
    // Generated from the component: PV_in.Q_mode
    _pv_in_q_mode__out = XIo_InFloat(0x5500010c);
    // Generated from the component: PV_in.Q_ref
    _pv_in_q_ref__out = XIo_InFloat(0x55000110);
    // Generated from the component: PV_in.V_ref
    _pv_in_v_ref__out = XIo_InFloat(0x55000114);
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.Gain5
    _pv_plant_control_grid_follow_controlsignal_calculation_gain5__out = 0.5 * _pv_plant_control_grid_follow_controlsignal_calculation_limit3__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.Vdc
    HIL_OutAO(0x4000, (float)_pv_plant_control_grid_follow_controlsignal_calculation_limit3__out);
    // Generated from the component: PV_Plant.Control.Grid_follow.P
    HIL_OutAO(0x4003, (float)_pv_plant_control_grid_follow_power_meas_gain4__out);
    // Generated from the component: PV_Plant.Control.Grid_follow.Q
    HIL_OutAO(0x4005, (float)_pv_plant_control_grid_follow_power_meas_gain5__out);
    // Generated from the component: PV_Plant.Control.Grid_follow.Power_Meas.Gain6
    _pv_plant_control_grid_follow_power_meas_gain6__out = 5000000.0 * _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_s_and_pf__S;
    // Generated from the component: PV_Plant.Control.Grid_follow.pf
    HIL_OutAO(0x4010, (float)_pv_plant_control_grid_follow_power_meas_power_meas_dqpu_s_and_pf__pf);
    // Generated from the component: PV_Plant.Control.Grid_follow.wt_pll
    HIL_OutAO(0x4012, (float)_pv_plant_control_pll_pll_unit_delay1__out);
    // Generated from the component: PV_Plant.Control.PLL.Gain1
    _pv_plant_control_pll_gain1__out = 0.016666666666666666 * _pv_plant_control_pll_pll_to_hz__out;
    // Generated from the component: PV_Plant.Control.PLL.f_meas
    HIL_OutAO(0x4014, (float)_pv_plant_control_pll_pll_to_hz__out);
    // Generated from the component: PV_Plant.Control.duty_cycle.ZSM.Limit1
    _pv_plant_control_duty_cycle_zsm_limit1__out = MIN(MAX(_pv_plant_control_duty_cycle_zsm_constant1__out, 0.0), 1.0);
    // Generated from the component: PV_Plant.Control.Grid_follow.Current_abc_to_dq.abc to dq1.abc to alpha beta
    _pv_plant_control_grid_follow_current_abc_to_dq_abc_to_dq1_abc_to_alpha_beta__alpha = (2.0 * _pv_plant_ia_ia1__out - _pv_plant_ib_ia1__out - _pv_plant_ic_ia1__out) * 0.3333333333333333;
    _pv_plant_control_grid_follow_current_abc_to_dq_abc_to_dq1_abc_to_alpha_beta__beta = (_pv_plant_ib_ia1__out - _pv_plant_ic_ia1__out) * 0.5773502691896258;
    _pv_plant_control_grid_follow_current_abc_to_dq_abc_to_dq1_abc_to_alpha_beta__gamma = (_pv_plant_ia_ia1__out + _pv_plant_ib_ia1__out + _pv_plant_ic_ia1__out) * 0.3333333333333333;
    // Generated from the component: PV_Plant.Vs2.Vs1
    HIL_OutFloat(137101312, (float) _pv_plant_vdc__out);
    // Generated from the component: PV_Plant.Control.Grid_follow.Gain3
    _pv_plant_control_grid_follow_gain3__out = 0.001 * _pv_plant_vdc_va1__out;
    // Generated from the component: PV_in.Bus Join1
    _pv_in_bus_join1__out[0] = _pv_in_connect__out;
    _pv_in_bus_join1__out[1] = _pv_in_enable__out;
    _pv_in_bus_join1__out[2] = _pv_in_irradiation__out;
    _pv_in_bus_join1__out[3] = _pv_in_v_ref__out;
    _pv_in_bus_join1__out[4] = _pv_in_q_mode__out;
    _pv_in_bus_join1__out[5] = _pv_in_q_ref__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.S
    HIL_OutAO(0x4007, (float)_pv_plant_control_grid_follow_power_meas_gain6__out);
    // Generated from the component: PV_Plant.Control.Grid_follow.w_pu
    HIL_OutAO(0x4011, (float)_pv_plant_control_pll_gain1__out);
    // Generated from the component: PV_Plant.Control.duty_cycle.ZSM.Sum2
    _pv_plant_control_duty_cycle_zsm_sum2__out =  - _pv_plant_control_duty_cycle_zsm_limit1__out + _pv_plant_control_duty_cycle_zsm_constant3__out;
    // Generated from the component: PV_Plant.Control.duty_cycle.ZSM.Sum8
    _pv_plant_control_duty_cycle_zsm_sum8__out =  - _pv_plant_control_duty_cycle_zsm_limit1__out + _pv_plant_control_duty_cycle_zsm_constant4__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.Current_abc_to_dq.Termination1
    // Generated from the component: PV_Plant.Control.Grid_follow.Current_abc_to_dq.abc to dq1.alpha beta to dq
    _pv_plant_control_grid_follow_current_abc_to_dq_abc_to_dq1_alpha_beta_to_dq__k1 = cos(_pv_plant_control_pll_pll_unit_delay1__out);
    _pv_plant_control_grid_follow_current_abc_to_dq_abc_to_dq1_alpha_beta_to_dq__k2 = sin(_pv_plant_control_pll_pll_unit_delay1__out);
    _pv_plant_control_grid_follow_current_abc_to_dq_abc_to_dq1_alpha_beta_to_dq__d = _pv_plant_control_grid_follow_current_abc_to_dq_abc_to_dq1_alpha_beta_to_dq__k2 * _pv_plant_control_grid_follow_current_abc_to_dq_abc_to_dq1_abc_to_alpha_beta__alpha - _pv_plant_control_grid_follow_current_abc_to_dq_abc_to_dq1_alpha_beta_to_dq__k1 * _pv_plant_control_grid_follow_current_abc_to_dq_abc_to_dq1_abc_to_alpha_beta__beta;
    _pv_plant_control_grid_follow_current_abc_to_dq_abc_to_dq1_alpha_beta_to_dq__q = _pv_plant_control_grid_follow_current_abc_to_dq_abc_to_dq1_alpha_beta_to_dq__k1 * _pv_plant_control_grid_follow_current_abc_to_dq_abc_to_dq1_abc_to_alpha_beta__alpha + _pv_plant_control_grid_follow_current_abc_to_dq_abc_to_dq1_alpha_beta_to_dq__k2 * _pv_plant_control_grid_follow_current_abc_to_dq_abc_to_dq1_abc_to_alpha_beta__beta;
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.LPF_dc
    X_UnInt32 _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__i;
    _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__a_sum = 0.0f;
    _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__b_sum = 0.0f;
    _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__delay_line_in = 0.0f;
    for (_pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__i = 0; _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__i < 1; _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__i++) {
        _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__b_sum += _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__b_coeff[_pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__i + 1] * _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__states[_pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__i];
    }
    _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__a_sum += _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__states[0] * _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__a_coeff[1];
    _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__delay_line_in = _pv_plant_control_grid_follow_gain3__out - _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__a_sum;
    _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__b_sum += _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__b_coeff[0] * _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__delay_line_in;
    _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__out = _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__b_sum;
    // Generated from the component: PV_Plant.Input.Bus Split2
    _pv_plant_input_bus_split2__out = _pv_in_bus_join1__out[0];
    _pv_plant_input_bus_split2__out1 = _pv_in_bus_join1__out[1];
    _pv_plant_input_bus_split2__out2 = _pv_in_bus_join1__out[2];
    _pv_plant_input_bus_split2__out3 = _pv_in_bus_join1__out[3];
    _pv_plant_input_bus_split2__out4 = _pv_in_bus_join1__out[4];
    _pv_plant_input_bus_split2__out5 = _pv_in_bus_join1__out[5];
    // Generated from the component: PV_Plant.Control.Grid_follow.Current_abc_to_dq.Gain1
    _pv_plant_control_grid_follow_current_abc_to_dq_gain1__out = 0.00011757550765359254 * _pv_plant_control_grid_follow_current_abc_to_dq_abc_to_dq1_alpha_beta_to_dq__d;
    // Generated from the component: PV_Plant.Control.Grid_follow.Current_abc_to_dq.Gain2
    _pv_plant_control_grid_follow_current_abc_to_dq_gain2__out = 0.00011757550765359254 * _pv_plant_control_grid_follow_current_abc_to_dq_abc_to_dq1_alpha_beta_to_dq__q;
    // Generated from the component: PV_Plant.Control.Grid_follow.Edge Detection1.Relational operator1
    _pv_plant_control_grid_follow_edge_detection1_relational_operator1__out = (_pv_plant_input_bus_split2__out1 != _pv_plant_control_grid_follow_edge_detection1_unit_delay1__out) ? 1 : 0;
    // Generated from the component: PV_Plant.Control.Grid_follow.Gain2
    _pv_plant_control_grid_follow_gain2__out = 0.0002 * _pv_plant_input_bus_split2__out5;
    // Generated from the component: PV_Plant.Control.Grid_follow.Gain4
    _pv_plant_control_grid_follow_gain4__out = 0.0020833333333333333 * _pv_plant_input_bus_split2__out3;
    // Generated from the component: PV_Plant.Control.Grid_follow.Logical operator1
    _pv_plant_control_grid_follow_logical_operator1__out = !_pv_plant_input_bus_split2__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.Product2
    _pv_plant_control_grid_follow_product2__out = (_pv_plant_input_bus_split2__out2 * _pv_plant_control_grid_follow_pv_area_m2__out);
    // Generated from the component: PV_Plant.Control.Grid_follow.Qmode
    HIL_OutInt32(0xf00400, _pv_plant_input_bus_split2__out4 != 0x0);
    // Generated from the component: PV_Plant.Control.Grid_follow.delay
    _pv_plant_control_grid_follow_delay__in = _pv_plant_input_bus_split2__out;
    if (_pv_plant_control_grid_follow_delay__out == 0) {
        if (_pv_plant_control_grid_follow_delay__in > 0.5) {
            _pv_plant_control_grid_follow_delay__counter += 0.0002;
            if (_pv_plant_control_grid_follow_delay__counter > 0.125) {
                _pv_plant_control_grid_follow_delay__out = 1;
            }
        }
        else {
            _pv_plant_control_grid_follow_delay__counter -= _pv_plant_control_grid_follow_delay__counter;
            _pv_plant_control_grid_follow_delay__out = 0;
        }
    }
    else {
        _pv_plant_control_grid_follow_delay__counter = 0;
        if (_pv_plant_control_grid_follow_delay__in <= 0.5) {
            _pv_plant_control_grid_follow_delay__out = 0;
        }
    }
    // Generated from the component: PV_Plant.Control.Grid_follow.irr_in
    HIL_OutAO(0x400f, (float)_pv_plant_input_bus_split2__out2);
    // Generated from the component: PV_Plant.Control.PLL.Signal switch1
    _pv_plant_control_pll_signal_switch1__out = (_pv_plant_input_bus_split2__out > 0.5f) ? _pv_plant_va_va1__out : _pv_plant_control_pll_constant1__out;
    // Generated from the component: PV_Plant.Control.PLL.Signal switch2
    _pv_plant_control_pll_signal_switch2__out = (_pv_plant_input_bus_split2__out > 0.5f) ? _pv_plant_vb_va1__out : _pv_plant_control_pll_constant1__out;
    // Generated from the component: PV_Plant.Control.PLL.Signal switch3
    _pv_plant_control_pll_signal_switch3__out = (_pv_plant_input_bus_split2__out > 0.5f) ? _pv_plant_vc_va1__out : _pv_plant_control_pll_constant1__out;
    // Generated from the component: PV_Plant.S1.CTC_Wrapper
    if (_pv_plant_input_bus_split2__out == 0x0) {
        HIL_OutInt32(0x8240480, 0x0);
    }
    else {
        HIL_OutInt32(0x8240480, 0x1);
    }
    // Generated from the component: PV_Plant.delay
    _pv_plant_delay__in = _pv_plant_input_bus_split2__out;
    if (_pv_plant_delay__out == 0) {
        if (_pv_plant_delay__in > 0.5) {
            _pv_plant_delay__counter += 0.0002;
            if (_pv_plant_delay__counter > 0.125) {
                _pv_plant_delay__out = 1;
            }
        }
        else {
            _pv_plant_delay__counter -= _pv_plant_delay__counter;
            _pv_plant_delay__out = 0;
        }
    }
    else {
        _pv_plant_delay__counter = 0;
        if (_pv_plant_delay__in <= 0.5) {
            _pv_plant_delay__out = 0;
        }
    }
    // Generated from the component: PV_Plant.enable
    HIL_OutInt32(0xf00402, _pv_plant_input_bus_split2__out1 != 0x0);
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.Gain2
    _pv_plant_control_grid_follow_controlsignal_calculation_gain2__out = 0.07418903776375772 * _pv_plant_control_grid_follow_current_abc_to_dq_gain1__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.Product5
    _pv_plant_control_grid_follow_controlsignal_calculation_product5__out = (_pv_plant_control_grid_follow_current_abc_to_dq_gain1__out * _pv_plant_control_grid_follow_controlsignal_calculation_damp__out);
    // Generated from the component: PV_Plant.Control.Grid_follow.id
    HIL_OutAO(0x400d, (float)_pv_plant_control_grid_follow_current_abc_to_dq_gain1__out);
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.Gain1
    _pv_plant_control_grid_follow_controlsignal_calculation_gain1__out = 0.07418903776375772 * _pv_plant_control_grid_follow_current_abc_to_dq_gain2__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.Product6
    _pv_plant_control_grid_follow_controlsignal_calculation_product6__out = (_pv_plant_control_grid_follow_controlsignal_calculation_damp__out * _pv_plant_control_grid_follow_current_abc_to_dq_gain2__out);
    // Generated from the component: PV_Plant.Control.Grid_follow.iq
    HIL_OutAO(0x400e, (float)_pv_plant_control_grid_follow_current_abc_to_dq_gain2__out);
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.PI_d.Integrator1
    if (((_pv_plant_control_grid_follow_edge_detection1_relational_operator1__out > 0.0) && (_pv_plant_control_grid_follow_controlsignal_calculation_pi_d_integrator1__reset_state <= 0)) || ((_pv_plant_control_grid_follow_edge_detection1_relational_operator1__out <= 0.0) && (_pv_plant_control_grid_follow_controlsignal_calculation_pi_d_integrator1__reset_state == 1))) {
        _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_integrator1__state = 0.0;
    }
    _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_integrator1__out = _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_integrator1__state;
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.PI_q.Integrator1
    if (((_pv_plant_control_grid_follow_edge_detection1_relational_operator1__out > 0.0) && (_pv_plant_control_grid_follow_controlsignal_calculation_pi_q_integrator1__reset_state <= 0)) || ((_pv_plant_control_grid_follow_edge_detection1_relational_operator1__out <= 0.0) && (_pv_plant_control_grid_follow_controlsignal_calculation_pi_q_integrator1__reset_state == 1))) {
        _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_integrator1__state = 0.0;
    }
    _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_integrator1__out = _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_integrator1__state;
    // Generated from the component: PV_Plant.Control.Grid_follow.PI_Vt.Integrator1
    if (((_pv_plant_control_grid_follow_logical_operator1__out > 0.0) && (_pv_plant_control_grid_follow_pi_vt_integrator1__reset_state <= 0)) || ((_pv_plant_control_grid_follow_logical_operator1__out <= 0.0) && (_pv_plant_control_grid_follow_pi_vt_integrator1__reset_state == 1))) {
        _pv_plant_control_grid_follow_pi_vt_integrator1__state = 0.0;
    }
    _pv_plant_control_grid_follow_pi_vt_integrator1__out = _pv_plant_control_grid_follow_pi_vt_integrator1__state;
    // Generated from the component: PV_Plant.Control.Grid_follow.PV_eff
    _pv_plant_control_grid_follow_pv_eff__out = 0.2 * _pv_plant_control_grid_follow_product2__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.Logical operator2
    _pv_plant_control_grid_follow_logical_operator2__out = _pv_plant_control_grid_follow_delay__out && _pv_plant_input_bus_split2__out1 ;
    // Generated from the component: PV_Plant.Control.PLL.PLL.abc to dq.abc to alpha beta
    _pv_plant_control_pll_pll_abc_to_dq_abc_to_alpha_beta__alpha = (2.0 * _pv_plant_control_pll_signal_switch1__out - _pv_plant_control_pll_signal_switch2__out - _pv_plant_control_pll_signal_switch3__out) * 0.3333333333333333;
    _pv_plant_control_pll_pll_abc_to_dq_abc_to_alpha_beta__beta = (_pv_plant_control_pll_signal_switch2__out - _pv_plant_control_pll_signal_switch3__out) * 0.5773502691896258;
    _pv_plant_control_pll_pll_abc_to_dq_abc_to_alpha_beta__gamma = (_pv_plant_control_pll_signal_switch1__out + _pv_plant_control_pll_signal_switch2__out + _pv_plant_control_pll_signal_switch3__out) * 0.3333333333333333;
    // Generated from the component: PV_Plant.Logical operator1
    _pv_plant_logical_operator1__out = _pv_plant_input_bus_split2__out1 && _pv_plant_delay__out ;
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.Product2
    _pv_plant_control_grid_follow_controlsignal_calculation_product2__out = (_pv_plant_control_pll_gain1__out * _pv_plant_control_grid_follow_controlsignal_calculation_gain2__out);
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.Product1
    _pv_plant_control_grid_follow_controlsignal_calculation_product1__out = (_pv_plant_control_pll_gain1__out * _pv_plant_control_grid_follow_controlsignal_calculation_gain1__out);
    // Generated from the component: PV_Plant.Control.Grid_follow.to_pu
    _pv_plant_control_grid_follow_to_pu__out = 2e-07 * _pv_plant_control_grid_follow_pv_eff__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.Signal switch3
    _pv_plant_control_grid_follow_signal_switch3__out = (_pv_plant_control_grid_follow_logical_operator2__out > 0.5f) ? _pv_plant_control_grid_follow_gain2__out : _pv_plant_control_grid_follow_constant2__out;
    // Generated from the component: PV_Plant.Control.PLL.PLL.abc to dq.alpha beta to dq
    _pv_plant_control_pll_pll_abc_to_dq_alpha_beta_to_dq__k1 = cos(_pv_plant_control_pll_pll_unit_delay1__out);
    _pv_plant_control_pll_pll_abc_to_dq_alpha_beta_to_dq__k2 = sin(_pv_plant_control_pll_pll_unit_delay1__out);
    _pv_plant_control_pll_pll_abc_to_dq_alpha_beta_to_dq__d = _pv_plant_control_pll_pll_abc_to_dq_alpha_beta_to_dq__k2 * _pv_plant_control_pll_pll_abc_to_dq_abc_to_alpha_beta__alpha - _pv_plant_control_pll_pll_abc_to_dq_alpha_beta_to_dq__k1 * _pv_plant_control_pll_pll_abc_to_dq_abc_to_alpha_beta__beta;
    _pv_plant_control_pll_pll_abc_to_dq_alpha_beta_to_dq__q = _pv_plant_control_pll_pll_abc_to_dq_alpha_beta_to_dq__k1 * _pv_plant_control_pll_pll_abc_to_dq_abc_to_alpha_beta__alpha + _pv_plant_control_pll_pll_abc_to_dq_alpha_beta_to_dq__k2 * _pv_plant_control_pll_pll_abc_to_dq_abc_to_alpha_beta__beta;
    // Generated from the component: PV_Plant.Control.PLL.PLL.term_zero
    // Generated from the component: PV_Plant.3ph_inverter 1.Phase A.IGBT Leg global gds ovs.termination1
    // Generated from the component: PV_Plant.3ph_inverter 1.Phase B.IGBT Leg global gds ovs.termination1
    // Generated from the component: PV_Plant.3ph_inverter 1.Phase C.IGBT Leg global gds ovs.termination1
    // Generated from the component: PV_Plant.On
    HIL_OutInt32(0xf00401, _pv_plant_logical_operator1__out != 0x0);
    // Generated from the component: PV_Plant.Control.Grid_follow.Signal switch2
    _pv_plant_control_grid_follow_signal_switch2__out = (_pv_plant_control_grid_follow_logical_operator2__out > 0.5f) ? _pv_plant_control_grid_follow_to_pu__out : _pv_plant_control_grid_follow_constant1__out;
    // Generated from the component: PV_Plant.Control.PLL.PLL.abc to dq.LPF_d
    _pv_plant_control_pll_pll_abc_to_dq_lpf_d__previous_filtered_value = _pv_plant_control_pll_pll_abc_to_dq_lpf_d__filtered_value;
    _pv_plant_control_pll_pll_abc_to_dq_lpf_d__filtered_value = _pv_plant_control_pll_pll_abc_to_dq_lpf_d__previous_in * (1.0 * 62.83185307 * 0.0002) + _pv_plant_control_pll_pll_abc_to_dq_lpf_d__previous_filtered_value * (1 - 1.0 * 62.83185307 * 0.0002 );
    _pv_plant_control_pll_pll_abc_to_dq_lpf_d__out = _pv_plant_control_pll_pll_abc_to_dq_lpf_d__filtered_value;
    _pv_plant_control_pll_pll_abc_to_dq_lpf_d__previous_in = _pv_plant_control_pll_pll_abc_to_dq_alpha_beta_to_dq__d;
    // Generated from the component: PV_Plant.Control.PLL.PLL.abc to dq.LPF_q
    _pv_plant_control_pll_pll_abc_to_dq_lpf_q__previous_filtered_value = _pv_plant_control_pll_pll_abc_to_dq_lpf_q__filtered_value;
    _pv_plant_control_pll_pll_abc_to_dq_lpf_q__filtered_value = _pv_plant_control_pll_pll_abc_to_dq_lpf_q__previous_in * (1.0 * 62.83185307 * 0.0002) + _pv_plant_control_pll_pll_abc_to_dq_lpf_q__previous_filtered_value * (1 - 1.0 * 62.83185307 * 0.0002 );
    _pv_plant_control_pll_pll_abc_to_dq_lpf_q__out = _pv_plant_control_pll_pll_abc_to_dq_lpf_q__filtered_value;
    _pv_plant_control_pll_pll_abc_to_dq_lpf_q__previous_in = _pv_plant_control_pll_pll_abc_to_dq_alpha_beta_to_dq__q;
    // Generated from the component: PV_Plant.Control.Grid_follow.Pref
    HIL_OutAO(0x4004, (float)_pv_plant_control_grid_follow_signal_switch2__out);
    // Generated from the component: PV_Plant.Control.PLL.Gain4
    _pv_plant_control_pll_gain4__out = 0.002551551815399144 * _pv_plant_control_pll_pll_abc_to_dq_lpf_d__out;
    // Generated from the component: PV_Plant.Control.PLL.Gain3
    _pv_plant_control_pll_gain3__out = 0.002551551815399144 * _pv_plant_control_pll_pll_abc_to_dq_lpf_q__out;
    // Generated from the component: PV_Plant.Control.PLL.PLL.normalize
    _pv_plant_control_pll_pll_normalize__in1 = _pv_plant_control_pll_pll_abc_to_dq_lpf_d__out;
    _pv_plant_control_pll_pll_normalize__in2 = _pv_plant_control_pll_pll_abc_to_dq_lpf_q__out;
    _pv_plant_control_pll_pll_normalize__pk = (powf(_pv_plant_control_pll_pll_normalize__in1, 2.0) + powf(_pv_plant_control_pll_pll_normalize__in2, 2.0));
    _pv_plant_control_pll_pll_normalize__pk = sqrt(_pv_plant_control_pll_pll_normalize__pk);
    if (_pv_plant_control_pll_pll_normalize__pk < 0.1) {
        _pv_plant_control_pll_pll_normalize__in2_pu = _pv_plant_control_pll_pll_normalize__in2 / 0.1;
    }
    else {
        _pv_plant_control_pll_pll_normalize__in2_pu = _pv_plant_control_pll_pll_normalize__in2 / _pv_plant_control_pll_pll_normalize__pk;
    }
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.Sum5
    _pv_plant_control_grid_follow_controlsignal_calculation_sum5__out = _pv_plant_control_pll_gain4__out - _pv_plant_control_grid_follow_controlsignal_calculation_product1__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.Current_ref.Product4
    _pv_plant_control_grid_follow_current_ref_product4__out = (_pv_plant_control_pll_gain4__out * _pv_plant_control_grid_follow_limit_pqref_unit_delay2__out);
    // Generated from the component: PV_Plant.Control.Grid_follow.Current_ref.Product5
    _pv_plant_control_grid_follow_current_ref_product5__out = (_pv_plant_control_grid_follow_limit_pqref_unit_delay1__out * _pv_plant_control_pll_gain4__out);
    // Generated from the component: PV_Plant.Control.Grid_follow.Power_Meas.Power_Meas_DQpu.Product1
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_product1__out = (_pv_plant_control_pll_gain4__out * _pv_plant_control_grid_follow_current_abc_to_dq_gain1__out);
    // Generated from the component: PV_Plant.Control.Grid_follow.Power_Meas.Power_Meas_DQpu.Product3
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_product3__out = (_pv_plant_control_pll_gain4__out * _pv_plant_control_grid_follow_current_abc_to_dq_gain2__out);
    // Generated from the component: PV_Plant.Control.Grid_follow.Vd
    HIL_OutAO(0x400a, (float)_pv_plant_control_pll_gain4__out);
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.Sum6
    _pv_plant_control_grid_follow_controlsignal_calculation_sum6__out = _pv_plant_control_pll_gain3__out + _pv_plant_control_grid_follow_controlsignal_calculation_product2__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.Current_ref.Product3
    _pv_plant_control_grid_follow_current_ref_product3__out = (_pv_plant_control_pll_gain3__out * _pv_plant_control_grid_follow_limit_pqref_unit_delay1__out);
    // Generated from the component: PV_Plant.Control.Grid_follow.Current_ref.Product6
    _pv_plant_control_grid_follow_current_ref_product6__out = (_pv_plant_control_grid_follow_limit_pqref_unit_delay2__out * _pv_plant_control_pll_gain3__out);
    // Generated from the component: PV_Plant.Control.Grid_follow.Power_Meas.Power_Meas_DQpu.Product2
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_product2__out = (_pv_plant_control_pll_gain3__out * _pv_plant_control_grid_follow_current_abc_to_dq_gain2__out);
    // Generated from the component: PV_Plant.Control.Grid_follow.Power_Meas.Power_Meas_DQpu.Product4
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_product4__out = (_pv_plant_control_pll_gain3__out * _pv_plant_control_grid_follow_current_abc_to_dq_gain1__out);
    // Generated from the component: PV_Plant.Control.Grid_follow.Vq
    HIL_OutAO(0x400b, (float)_pv_plant_control_pll_gain3__out);
    // Generated from the component: PV_Plant.Control.PLL.Gain5
    _pv_plant_control_pll_gain5__out = 0.002551551815399144 * _pv_plant_control_pll_pll_normalize__pk;
    // Generated from the component: PV_Plant.Control.PLL.PLL.PID.Kd
    _pv_plant_control_pll_pll_pid_kd__out = 1.0 * _pv_plant_control_pll_pll_normalize__in2_pu;
    // Generated from the component: PV_Plant.Control.PLL.PLL.PID.Ki
    _pv_plant_control_pll_pll_pid_ki__out = 3200.0 * _pv_plant_control_pll_pll_normalize__in2_pu;
    // Generated from the component: PV_Plant.Control.PLL.PLL.PID.Kp
    _pv_plant_control_pll_pll_pid_kp__out = 100.0 * _pv_plant_control_pll_pll_normalize__in2_pu;
    // Generated from the component: PV_Plant.Control.PLL.Vt_meas
    HIL_OutAO(0x4013, (float)_pv_plant_control_pll_pll_normalize__pk);
    // Generated from the component: PV_Plant.Output.Bus Join1
    _pv_plant_output_bus_join1__out[0] = _pv_plant_input_bus_split2__out;
    _pv_plant_output_bus_join1__out[1] = _pv_plant_logical_operator1__out;
    _pv_plant_output_bus_join1__out[2] = _pv_plant_va_va1__out;
    _pv_plant_output_bus_join1__out[3] = _pv_plant_vb_va1__out;
    _pv_plant_output_bus_join1__out[4] = _pv_plant_vc_va1__out;
    _pv_plant_output_bus_join1__out[5] = _pv_plant_control_pll_pll_normalize__pk;
    _pv_plant_output_bus_join1__out[6] = _pv_plant_ia_ia1__out;
    _pv_plant_output_bus_join1__out[7] = _pv_plant_ib_ia1__out;
    _pv_plant_output_bus_join1__out[8] = _pv_plant_ic_ia1__out;
    _pv_plant_output_bus_join1__out[9] = _pv_plant_control_pll_pll_to_hz__out;
    _pv_plant_output_bus_join1__out[10] = _pv_plant_control_grid_follow_power_meas_gain4__out;
    _pv_plant_output_bus_join1__out[11] = _pv_plant_control_grid_follow_power_meas_gain5__out;
    _pv_plant_output_bus_join1__out[12] = _pv_plant_control_grid_follow_power_meas_gain6__out;
    _pv_plant_output_bus_join1__out[13] = _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_s_and_pf__pf;
    // Generated from the component: PV_Plant.Control.Grid_follow.Current_ref.Sum3
    _pv_plant_control_grid_follow_current_ref_sum3__out = _pv_plant_control_grid_follow_current_ref_product3__out - _pv_plant_control_grid_follow_current_ref_product4__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.Current_ref.Sum4
    _pv_plant_control_grid_follow_current_ref_sum4__out = _pv_plant_control_grid_follow_current_ref_product5__out + _pv_plant_control_grid_follow_current_ref_product6__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.Power_Meas.Power_Meas_DQpu.Sum1
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_sum1__out = _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_product1__out + _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_product2__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.Power_Meas.Power_Meas_DQpu.Sum2
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_sum2__out = _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_product4__out - _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_product3__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.Current_ref.Product7
    _pv_plant_control_grid_follow_current_ref_product7__out = (_pv_plant_control_pll_gain5__out * _pv_plant_control_pll_gain5__out);
    // Generated from the component: PV_Plant.Control.Grid_follow.Signal switch4
    _pv_plant_control_grid_follow_signal_switch4__out = (_pv_plant_control_grid_follow_logical_operator2__out > 0.5f) ? _pv_plant_control_grid_follow_gain4__out : _pv_plant_control_pll_gain5__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.Vt_pu
    HIL_OutAO(0x400c, (float)_pv_plant_control_pll_gain5__out);
    // Generated from the component: PV_Plant.Control.PLL.PLL.PID.Sum8
    _pv_plant_control_pll_pll_pid_sum8__out = _pv_plant_control_pll_pll_pid_kd__out - _pv_plant_control_pll_pll_pid_integrator2__out;
    // Generated from the component: PV_out.Out
    HIL_OutAO(0x401e, (float)_pv_plant_output_bus_join1__out[0]);
    HIL_OutAO(0x401f, (float)_pv_plant_output_bus_join1__out[1]);
    HIL_OutAO(0x4020, (float)_pv_plant_output_bus_join1__out[2]);
    HIL_OutAO(0x4021, (float)_pv_plant_output_bus_join1__out[3]);
    HIL_OutAO(0x4022, (float)_pv_plant_output_bus_join1__out[4]);
    HIL_OutAO(0x4023, (float)_pv_plant_output_bus_join1__out[5]);
    HIL_OutAO(0x4024, (float)_pv_plant_output_bus_join1__out[6]);
    HIL_OutAO(0x4025, (float)_pv_plant_output_bus_join1__out[7]);
    HIL_OutAO(0x4026, (float)_pv_plant_output_bus_join1__out[8]);
    HIL_OutAO(0x4027, (float)_pv_plant_output_bus_join1__out[9]);
    HIL_OutAO(0x4028, (float)_pv_plant_output_bus_join1__out[10]);
    HIL_OutAO(0x4029, (float)_pv_plant_output_bus_join1__out[11]);
    HIL_OutAO(0x402a, (float)_pv_plant_output_bus_join1__out[12]);
    HIL_OutAO(0x402b, (float)_pv_plant_output_bus_join1__out[13]);
    // Generated from the component: PV_Plant.Control.Grid_follow.Power_Meas.Power_Meas_DQpu.LPF_P
    X_UnInt32 _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__i;
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__a_sum = 0.0f;
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__b_sum = 0.0f;
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__delay_line_in = 0.0f;
    for (_pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__i = 0; _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__i < 1; _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__i++) {
        _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__b_sum += _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__b_coeff[_pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__i + 1] * _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__states[_pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__i];
    }
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__a_sum += _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__states[0] * _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__a_coeff[1];
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__delay_line_in = _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_sum1__out - _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__a_sum;
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__b_sum += _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__b_coeff[0] * _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__delay_line_in;
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__out = _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__b_sum;
    // Generated from the component: PV_Plant.Control.Grid_follow.Power_Meas.Power_Meas_DQpu.LPF_Q
    X_UnInt32 _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__i;
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__a_sum = 0.0f;
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__b_sum = 0.0f;
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__delay_line_in = 0.0f;
    for (_pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__i = 0; _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__i < 1; _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__i++) {
        _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__b_sum += _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__b_coeff[_pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__i + 1] * _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__states[_pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__i];
    }
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__a_sum += _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__states[0] * _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__a_coeff[1];
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__delay_line_in = _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_sum2__out - _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__a_sum;
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__b_sum += _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__b_coeff[0] * _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__delay_line_in;
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__out = _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__b_sum;
    // Generated from the component: PV_Plant.Control.Grid_follow.Current_ref.Limit3
    _pv_plant_control_grid_follow_current_ref_limit3__out = MAX(_pv_plant_control_grid_follow_current_ref_product7__out, 0.01);
    // Generated from the component: PV_Plant.Control.Grid_follow.Sum1
    _pv_plant_control_grid_follow_sum1__out = _pv_plant_control_grid_follow_signal_switch4__out - _pv_plant_control_pll_gain5__out;
    // Generated from the component: PV_Plant.Control.PLL.PLL.PID.Gain1
    _pv_plant_control_pll_pll_pid_gain1__out = 714.2857 * _pv_plant_control_pll_pll_pid_sum8__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.Current_ref.Product1
    _pv_plant_control_grid_follow_current_ref_product1__out = (_pv_plant_control_grid_follow_current_ref_sum3__out) * 1.0 / (_pv_plant_control_grid_follow_current_ref_limit3__out);
    // Generated from the component: PV_Plant.Control.Grid_follow.Current_ref.Product2
    _pv_plant_control_grid_follow_current_ref_product2__out = (_pv_plant_control_grid_follow_current_ref_sum4__out) * 1.0 / (_pv_plant_control_grid_follow_current_ref_limit3__out);
    // Generated from the component: PV_Plant.Control.Grid_follow.PI_Vt.Ki
    _pv_plant_control_grid_follow_pi_vt_ki__out = 3.0 * _pv_plant_control_grid_follow_sum1__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.PI_Vt.Kp
    _pv_plant_control_grid_follow_pi_vt_kp__out = 3.75 * _pv_plant_control_grid_follow_sum1__out;
    // Generated from the component: PV_Plant.Control.PLL.PLL.PID.Sum5
    _pv_plant_control_pll_pll_pid_sum5__out = _pv_plant_control_pll_pll_pid_kp__out + _pv_plant_control_pll_pll_pid_gain1__out + _pv_plant_control_pll_pll_pid_integrator1__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.Sum2
    _pv_plant_control_grid_follow_controlsignal_calculation_sum2__out =  - _pv_plant_control_grid_follow_current_abc_to_dq_gain2__out + _pv_plant_control_grid_follow_current_ref_product1__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.Iq_ref
    HIL_OutAO(0x4002, (float)_pv_plant_control_grid_follow_current_ref_product1__out);
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.Sum1
    _pv_plant_control_grid_follow_controlsignal_calculation_sum1__out =  - _pv_plant_control_grid_follow_current_abc_to_dq_gain1__out + _pv_plant_control_grid_follow_current_ref_product2__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.Id_ref
    HIL_OutAO(0x4001, (float)_pv_plant_control_grid_follow_current_ref_product2__out);
    // Generated from the component: PV_Plant.Control.Grid_follow.PI_Vt.Sum5
    _pv_plant_control_grid_follow_pi_vt_sum5__out = _pv_plant_control_grid_follow_pi_vt_kp__out + _pv_plant_control_grid_follow_pi_vt_integrator1__out;
    // Generated from the component: PV_Plant.Control.PLL.PLL.PID.Limit1
    _pv_plant_control_pll_pll_pid_limit1__out = MIN(MAX(_pv_plant_control_pll_pll_pid_sum5__out, 0.0), 527.7875658030853);
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.PI_q.Ki
    _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_ki__out = 30.0 * _pv_plant_control_grid_follow_controlsignal_calculation_sum2__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.PI_q.Kp
    _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_kp__out = 0.75 * _pv_plant_control_grid_follow_controlsignal_calculation_sum2__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.PI_d.Ki
    _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_ki__out = 30.0 * _pv_plant_control_grid_follow_controlsignal_calculation_sum1__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.PI_d.Kp
    _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_kp__out = 0.75 * _pv_plant_control_grid_follow_controlsignal_calculation_sum1__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.PI_Vt.Limit1
    _pv_plant_control_grid_follow_pi_vt_limit1__out = MIN(MAX(_pv_plant_control_grid_follow_pi_vt_sum5__out, -4.0), 4.0);
    // Generated from the component: PV_Plant.Control.PLL.PLL.PID.Sum6
    _pv_plant_control_pll_pll_pid_sum6__out =  - _pv_plant_control_pll_pll_pid_sum5__out + _pv_plant_control_pll_pll_pid_limit1__out;
    // Generated from the component: PV_Plant.Control.PLL.PLL.Rate Limiter1
    if (_pv_plant_control_pll_pll_rate_limiter1__first_step) {
        _pv_plant_control_pll_pll_rate_limiter1__out = _pv_plant_control_pll_pll_pid_limit1__out;
        _pv_plant_control_pll_pll_rate_limiter1__state = _pv_plant_control_pll_pll_pid_limit1__out;
    } else {
        _pv_plant_control_pll_pll_rate_limiter1__out = _pv_plant_control_pll_pll_pid_limit1__out;
        if (_pv_plant_control_pll_pll_pid_limit1__out - _pv_plant_control_pll_pll_rate_limiter1__state > 0.3769911184307752)
            _pv_plant_control_pll_pll_rate_limiter1__out = _pv_plant_control_pll_pll_rate_limiter1__state + (0.3769911184307752);
        if (_pv_plant_control_pll_pll_pid_limit1__out - _pv_plant_control_pll_pll_rate_limiter1__state < -0.3769911184307752)
            _pv_plant_control_pll_pll_rate_limiter1__out = _pv_plant_control_pll_pll_rate_limiter1__state + (-0.3769911184307752);
    }
    // Generated from the component: PV_Plant.Control.PLL.PLL.integrator
    _pv_plant_control_pll_pll_integrator__in = _pv_plant_control_pll_pll_pid_limit1__out;
    _pv_plant_control_pll_pll_integrator__out += 0.0002 * _pv_plant_control_pll_pll_integrator__in;
    if (_pv_plant_control_pll_pll_integrator__in >= 0.0) {
        if (_pv_plant_control_pll_pll_integrator__out >= 6.283185307179586) {
            _pv_plant_control_pll_pll_integrator__out -= 6.283185307179586;
        }
    }
    else {
        if (_pv_plant_control_pll_pll_integrator__out <= -6.283185307179586) {
            _pv_plant_control_pll_pll_integrator__out += 6.283185307179586;
        }
    }
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.PI_q.Sum5
    _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_sum5__out = _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_kp__out + _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_integrator1__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.PI_d.Sum5
    _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_sum5__out = _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_kp__out + _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_integrator1__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.PI_Vt.Sum6
    _pv_plant_control_grid_follow_pi_vt_sum6__out =  - _pv_plant_control_grid_follow_pi_vt_sum5__out + _pv_plant_control_grid_follow_pi_vt_limit1__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.Signal switch1
    _pv_plant_control_grid_follow_signal_switch1__out = (_pv_plant_input_bus_split2__out4 > 0.5f) ? _pv_plant_control_grid_follow_signal_switch3__out : _pv_plant_control_grid_follow_pi_vt_limit1__out;
    // Generated from the component: PV_Plant.Control.PLL.PLL.PID.Kb
    _pv_plant_control_pll_pll_pid_kb__out = 1.0 * _pv_plant_control_pll_pll_pid_sum6__out;
    // Generated from the component: PV_Plant.Control.PLL.PLL.LPF.LPF
    X_UnInt32 _pv_plant_control_pll_pll_lpf_lpf__i;
    _pv_plant_control_pll_pll_lpf_lpf__a_sum = 0.0f;
    _pv_plant_control_pll_pll_lpf_lpf__b_sum = 0.0f;
    _pv_plant_control_pll_pll_lpf_lpf__delay_line_in = 0.0f;
    for (_pv_plant_control_pll_pll_lpf_lpf__i = 0; _pv_plant_control_pll_pll_lpf_lpf__i < 1; _pv_plant_control_pll_pll_lpf_lpf__i++) {
        _pv_plant_control_pll_pll_lpf_lpf__b_sum += _pv_plant_control_pll_pll_lpf_lpf__b_coeff[_pv_plant_control_pll_pll_lpf_lpf__i] * _pv_plant_control_pll_pll_lpf_lpf__states[_pv_plant_control_pll_pll_lpf_lpf__i + 1];
    }
    for (_pv_plant_control_pll_pll_lpf_lpf__i = 1; _pv_plant_control_pll_pll_lpf_lpf__i > 0; _pv_plant_control_pll_pll_lpf_lpf__i--) {
        _pv_plant_control_pll_pll_lpf_lpf__a_sum += _pv_plant_control_pll_pll_lpf_lpf__a_coeff[_pv_plant_control_pll_pll_lpf_lpf__i + 1] * _pv_plant_control_pll_pll_lpf_lpf__states[_pv_plant_control_pll_pll_lpf_lpf__i];
    }
    _pv_plant_control_pll_pll_lpf_lpf__a_sum += _pv_plant_control_pll_pll_lpf_lpf__states[0] * _pv_plant_control_pll_pll_lpf_lpf__a_coeff[1];
    _pv_plant_control_pll_pll_lpf_lpf__delay_line_in = _pv_plant_control_pll_pll_rate_limiter1__out - _pv_plant_control_pll_pll_lpf_lpf__a_sum;
    _pv_plant_control_pll_pll_lpf_lpf__out = _pv_plant_control_pll_pll_lpf_lpf__b_sum;
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.PI_q.Limit1
    _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_limit1__out = MIN(MAX(_pv_plant_control_grid_follow_controlsignal_calculation_pi_q_sum5__out, -10.0), 10.0);
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.PI_d.Limit1
    _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_limit1__out = MIN(MAX(_pv_plant_control_grid_follow_controlsignal_calculation_pi_d_sum5__out, -10.0), 10.0);
    // Generated from the component: PV_Plant.Control.Grid_follow.PI_Vt.Kb
    _pv_plant_control_grid_follow_pi_vt_kb__out = 1000.0 * _pv_plant_control_grid_follow_pi_vt_sum6__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.Limit_PQref.priority_PQlim.PQ limiting with priority
    _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Pref = _pv_plant_control_grid_follow_signal_switch2__out;
    _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Qref = _pv_plant_control_grid_follow_signal_switch1__out;
    _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Smax = _pv_plant_control_grid_follow_constant3__out;
    _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Sref = sqrt(_pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Pref * _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Pref + _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Qref * _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Qref);
    if (_pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Qref >= 0)_pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__signQ = 1;
    else _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__signQ = -1;
    if (_pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Pref >= 0)_pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__signP = 1;
    else _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__signP = -1;
    if (_pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Sref <= _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Smax) {
        _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__S = _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Sref;
        _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__P = _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Pref;
        _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q = _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Qref;
    }
    else {
        _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__S = _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Smax;
        if (1.0 == 1) {
            if (fabs(_pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Pref) > _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Smax) {
                _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__P = _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__signP * _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Smax;
                _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q = 0;
            }
            else {
                _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__P = _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Pref;
                _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q = _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__signQ * sqrt(_pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Smax * _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Smax - _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Pref * _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Pref);
            }
        }
        else if (1.0 == 2) {
            if (fabs(_pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Qref) > _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Smax) {
                _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q = _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__signQ * _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Smax;
                _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__P = 0;
            }
            else {
                _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q = _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Qref;
                _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__P = _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__signP * sqrt(_pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Smax * _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Smax - _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Qref * _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Qref);
            }
        }
        else {
            _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__P = (_pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Pref / _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Sref) * _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Smax;
            _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q = (_pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Qref / _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Sref) * _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Smax;
        }
    }
    // Generated from the component: PV_Plant.Control.Grid_follow.Qref
    HIL_OutAO(0x4006, (float)_pv_plant_control_grid_follow_signal_switch1__out);
    // Generated from the component: PV_Plant.Control.PLL.PLL.PID.Sum7
    _pv_plant_control_pll_pll_pid_sum7__out = _pv_plant_control_pll_pll_pid_ki__out + _pv_plant_control_pll_pll_pid_kb__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.PI_q.Sum6
    _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_sum6__out =  - _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_sum5__out + _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_limit1__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.Sum7
    _pv_plant_control_grid_follow_controlsignal_calculation_sum7__out = _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_limit1__out + _pv_plant_control_grid_follow_controlsignal_calculation_sum6__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.PI_d.Sum6
    _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_sum6__out =  - _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_sum5__out + _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_limit1__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.Sum3
    _pv_plant_control_grid_follow_controlsignal_calculation_sum3__out = _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_limit1__out + _pv_plant_control_grid_follow_controlsignal_calculation_sum5__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.PI_Vt.Sum7
    _pv_plant_control_grid_follow_pi_vt_sum7__out = _pv_plant_control_grid_follow_pi_vt_ki__out + _pv_plant_control_grid_follow_pi_vt_kb__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.Limit_PQref.P rate limit
    if (_pv_plant_control_grid_follow_limit_pqref_p_rate_limit__first_step) {
        _pv_plant_control_grid_follow_limit_pqref_p_rate_limit__out = _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__P;
        _pv_plant_control_grid_follow_limit_pqref_p_rate_limit__state = _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__P;
    } else {
        _pv_plant_control_grid_follow_limit_pqref_p_rate_limit__out = _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__P;
        if (_pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__P - _pv_plant_control_grid_follow_limit_pqref_p_rate_limit__state > 0.001)
            _pv_plant_control_grid_follow_limit_pqref_p_rate_limit__out = _pv_plant_control_grid_follow_limit_pqref_p_rate_limit__state + (0.001);
        if (_pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__P - _pv_plant_control_grid_follow_limit_pqref_p_rate_limit__state < -0.001)
            _pv_plant_control_grid_follow_limit_pqref_p_rate_limit__out = _pv_plant_control_grid_follow_limit_pqref_p_rate_limit__state + (-0.001);
    }
    // Generated from the component: PV_Plant.Control.Grid_follow.Limit_PQref.Q rate limit
    if (_pv_plant_control_grid_follow_limit_pqref_q_rate_limit__first_step) {
        _pv_plant_control_grid_follow_limit_pqref_q_rate_limit__out = _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q;
        _pv_plant_control_grid_follow_limit_pqref_q_rate_limit__state = _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q;
    } else {
        _pv_plant_control_grid_follow_limit_pqref_q_rate_limit__out = _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q;
        if (_pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q - _pv_plant_control_grid_follow_limit_pqref_q_rate_limit__state > 0.001)
            _pv_plant_control_grid_follow_limit_pqref_q_rate_limit__out = _pv_plant_control_grid_follow_limit_pqref_q_rate_limit__state + (0.001);
        if (_pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q - _pv_plant_control_grid_follow_limit_pqref_q_rate_limit__state < -0.001)
            _pv_plant_control_grid_follow_limit_pqref_q_rate_limit__out = _pv_plant_control_grid_follow_limit_pqref_q_rate_limit__state + (-0.001);
    }
    // Generated from the component: PV_Plant.Control.Grid_follow.Limit_PQref.S rate limit
    if (_pv_plant_control_grid_follow_limit_pqref_s_rate_limit__first_step) {
        _pv_plant_control_grid_follow_limit_pqref_s_rate_limit__out = _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__S;
        _pv_plant_control_grid_follow_limit_pqref_s_rate_limit__state = _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__S;
    } else {
        _pv_plant_control_grid_follow_limit_pqref_s_rate_limit__out = _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__S;
        if (_pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__S - _pv_plant_control_grid_follow_limit_pqref_s_rate_limit__state > 0.001)
            _pv_plant_control_grid_follow_limit_pqref_s_rate_limit__out = _pv_plant_control_grid_follow_limit_pqref_s_rate_limit__state + (0.001);
        if (_pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__S - _pv_plant_control_grid_follow_limit_pqref_s_rate_limit__state < -0.001)
            _pv_plant_control_grid_follow_limit_pqref_s_rate_limit__out = _pv_plant_control_grid_follow_limit_pqref_s_rate_limit__state + (-0.001);
    }
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.PI_q.Kb
    _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_kb__out = 1.0 * _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_sum6__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.Product7
    _pv_plant_control_grid_follow_controlsignal_calculation_product7__out = (_pv_plant_control_grid_follow_controlsignal_calculation_sum7__out) * 1.0 / (_pv_plant_control_grid_follow_controlsignal_calculation_gain5__out);
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.PI_d.Kb
    _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_kb__out = 1.0 * _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_sum6__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.Product8
    _pv_plant_control_grid_follow_controlsignal_calculation_product8__out = (_pv_plant_control_grid_follow_controlsignal_calculation_sum3__out) * 1.0 / (_pv_plant_control_grid_follow_controlsignal_calculation_gain5__out);
    // Generated from the component: PV_Plant.Control.Grid_follow.Limit_PQref.limS_overPQ.S limiting over PQ
    _pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__Pref = _pv_plant_control_grid_follow_limit_pqref_p_rate_limit__out;
    _pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__Qref = _pv_plant_control_grid_follow_limit_pqref_q_rate_limit__out;
    _pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__Sref = _pv_plant_control_grid_follow_limit_pqref_s_rate_limit__out;
    _pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__S_PQref = sqrt(_pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__Pref * _pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__Pref + _pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__Qref * _pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__Qref);
    if (_pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__S_PQref > _pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__Sref) {
        _pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__P = (_pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__Pref / _pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__S_PQref) * _pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__Sref;
        _pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__Q = (_pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__Qref / _pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__S_PQref) * _pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__Sref;
    }
    else {
        _pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__P = _pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__Pref;
        _pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__Q = _pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__Qref;
    }
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.PI_q.Sum7
    _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_sum7__out = _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_ki__out + _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_kb__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.Gain11
    _pv_plant_control_grid_follow_controlsignal_calculation_gain11__out = 0.3919183588453085 * _pv_plant_control_grid_follow_controlsignal_calculation_product7__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.PI_d.Sum7
    _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_sum7__out = _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_ki__out + _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_kb__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.Gain10
    _pv_plant_control_grid_follow_controlsignal_calculation_gain10__out = 0.3919183588453085 * _pv_plant_control_grid_follow_controlsignal_calculation_product8__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.Sum9
    _pv_plant_control_grid_follow_controlsignal_calculation_sum9__out = _pv_plant_control_grid_follow_controlsignal_calculation_product6__out + _pv_plant_control_grid_follow_controlsignal_calculation_gain11__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.Sum8
    _pv_plant_control_grid_follow_controlsignal_calculation_sum8__out = _pv_plant_control_grid_follow_controlsignal_calculation_gain10__out + _pv_plant_control_grid_follow_controlsignal_calculation_product5__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.Uq_c
    HIL_OutAO(0x4009, (float)_pv_plant_control_grid_follow_controlsignal_calculation_sum9__out);
    // Generated from the component: PV_Plant.Control.duty_cycle.Limit3
    _pv_plant_control_duty_cycle_limit3__out = MIN(MAX(_pv_plant_control_grid_follow_controlsignal_calculation_sum9__out, -1.1546), 1.1546);
    // Generated from the component: PV_Plant.Control.Grid_follow.Ud_c
    HIL_OutAO(0x4008, (float)_pv_plant_control_grid_follow_controlsignal_calculation_sum8__out);
    // Generated from the component: PV_Plant.Control.duty_cycle.Limit2
    _pv_plant_control_duty_cycle_limit2__out = MIN(MAX(_pv_plant_control_grid_follow_controlsignal_calculation_sum8__out, -1.1546), 1.1546);
    // Generated from the component: PV_Plant.Control.duty_cycle.m_q
    HIL_OutAO(0x401d, (float)_pv_plant_control_duty_cycle_limit3__out);
    // Generated from the component: PV_Plant.Control.duty_cycle.dq to abc1.dq to alpha beta
    _pv_plant_control_duty_cycle_dq_to_abc1_dq_to_alpha_beta__k1 = cos(_pv_plant_control_pll_pll_unit_delay1__out);
    _pv_plant_control_duty_cycle_dq_to_abc1_dq_to_alpha_beta__k2 = sin(_pv_plant_control_pll_pll_unit_delay1__out);
    _pv_plant_control_duty_cycle_dq_to_abc1_dq_to_alpha_beta__alpha = _pv_plant_control_duty_cycle_dq_to_abc1_dq_to_alpha_beta__k2 * _pv_plant_control_duty_cycle_limit2__out + _pv_plant_control_duty_cycle_dq_to_abc1_dq_to_alpha_beta__k1 * _pv_plant_control_duty_cycle_limit3__out;
    _pv_plant_control_duty_cycle_dq_to_abc1_dq_to_alpha_beta__beta = _pv_plant_control_duty_cycle_dq_to_abc1_dq_to_alpha_beta__k2 * _pv_plant_control_duty_cycle_limit3__out - _pv_plant_control_duty_cycle_dq_to_abc1_dq_to_alpha_beta__k1 * _pv_plant_control_duty_cycle_limit2__out;
    // Generated from the component: PV_Plant.Control.duty_cycle.m_d
    HIL_OutAO(0x401c, (float)_pv_plant_control_duty_cycle_limit2__out);
    // Generated from the component: PV_Plant.Control.duty_cycle.dq to abc1.alpha beta to abc
    _pv_plant_control_duty_cycle_dq_to_abc1_alpha_beta_to_abc__A = 1 * _pv_plant_control_duty_cycle_o_ref__out;
    _pv_plant_control_duty_cycle_dq_to_abc1_alpha_beta_to_abc__B = _pv_plant_control_duty_cycle_dq_to_abc1_alpha_beta_to_abc__A - 0.5 * _pv_plant_control_duty_cycle_dq_to_abc1_dq_to_alpha_beta__alpha;
    _pv_plant_control_duty_cycle_dq_to_abc1_alpha_beta_to_abc__C = _pv_plant_control_duty_cycle_dq_to_abc1_alpha_beta_to_abc__B - 0.8660254037844386 * _pv_plant_control_duty_cycle_dq_to_abc1_dq_to_alpha_beta__beta;
    _pv_plant_control_duty_cycle_dq_to_abc1_alpha_beta_to_abc__B += 0.8660254037844386 * _pv_plant_control_duty_cycle_dq_to_abc1_dq_to_alpha_beta__beta;
    _pv_plant_control_duty_cycle_dq_to_abc1_alpha_beta_to_abc__A += 1 * _pv_plant_control_duty_cycle_dq_to_abc1_dq_to_alpha_beta__alpha;
    // Generated from the component: PV_Plant.Control.duty_cycle.Da
    HIL_OutAO(0x4015, (float)_pv_plant_control_duty_cycle_dq_to_abc1_alpha_beta_to_abc__A);
    // Generated from the component: PV_Plant.Control.duty_cycle.Db
    HIL_OutAO(0x4016, (float)_pv_plant_control_duty_cycle_dq_to_abc1_alpha_beta_to_abc__B);
    // Generated from the component: PV_Plant.Control.duty_cycle.Dc
    HIL_OutAO(0x4017, (float)_pv_plant_control_duty_cycle_dq_to_abc1_alpha_beta_to_abc__C);
    // Generated from the component: PV_Plant.Control.duty_cycle.ZSM.Min Max1
    _pv_plant_control_duty_cycle_zsm_min_max1__out = MIN(MIN(_pv_plant_control_duty_cycle_dq_to_abc1_alpha_beta_to_abc__A, _pv_plant_control_duty_cycle_dq_to_abc1_alpha_beta_to_abc__B), _pv_plant_control_duty_cycle_dq_to_abc1_alpha_beta_to_abc__C);
    // Generated from the component: PV_Plant.Control.duty_cycle.ZSM.Min Max2
    _pv_plant_control_duty_cycle_zsm_min_max2__out = MAX(MAX(_pv_plant_control_duty_cycle_dq_to_abc1_alpha_beta_to_abc__A, _pv_plant_control_duty_cycle_dq_to_abc1_alpha_beta_to_abc__B), _pv_plant_control_duty_cycle_dq_to_abc1_alpha_beta_to_abc__C);
    // Generated from the component: PV_Plant.Control.duty_cycle.ZSM.Product2
    _pv_plant_control_duty_cycle_zsm_product2__out = (_pv_plant_control_duty_cycle_zsm_sum2__out * _pv_plant_control_duty_cycle_zsm_min_max1__out);
    // Generated from the component: PV_Plant.Control.duty_cycle.ZSM.Sum1
    _pv_plant_control_duty_cycle_zsm_sum1__out =  - _pv_plant_control_duty_cycle_zsm_min_max2__out + _pv_plant_control_duty_cycle_zsm_constant2__out;
    // Generated from the component: PV_Plant.Control.duty_cycle.ZSM.Product1
    _pv_plant_control_duty_cycle_zsm_product1__out = (_pv_plant_control_duty_cycle_zsm_limit1__out * _pv_plant_control_duty_cycle_zsm_sum1__out);
    // Generated from the component: PV_Plant.Control.duty_cycle.ZSM.Sum3
    _pv_plant_control_duty_cycle_zsm_sum3__out =  - _pv_plant_control_duty_cycle_zsm_sum8__out - _pv_plant_control_duty_cycle_zsm_product2__out + _pv_plant_control_duty_cycle_zsm_product1__out;
    // Generated from the component: PV_Plant.Control.duty_cycle.ZSM.Sum5
    _pv_plant_control_duty_cycle_zsm_sum5__out = _pv_plant_control_duty_cycle_dq_to_abc1_alpha_beta_to_abc__A + _pv_plant_control_duty_cycle_zsm_sum3__out;
    // Generated from the component: PV_Plant.Control.duty_cycle.ZSM.Sum6
    _pv_plant_control_duty_cycle_zsm_sum6__out = _pv_plant_control_duty_cycle_dq_to_abc1_alpha_beta_to_abc__B + _pv_plant_control_duty_cycle_zsm_sum3__out;
    // Generated from the component: PV_Plant.Control.duty_cycle.ZSM.Sum7
    _pv_plant_control_duty_cycle_zsm_sum7__out = _pv_plant_control_duty_cycle_dq_to_abc1_alpha_beta_to_abc__C + _pv_plant_control_duty_cycle_zsm_sum3__out;
    // Generated from the component: PV_Plant.Control.duty_cycle.ZSM.Z0
    HIL_OutAO(0x401b, (float)_pv_plant_control_duty_cycle_zsm_sum3__out);
    // Generated from the component: PV_Plant.3ph_inverter 1.Phase A.PWM_Modulator
    _pv_plant_3ph_inverter_1_phase_a_pwm_modulator__limited_in[0] = MIN(MAX(_pv_plant_control_duty_cycle_zsm_sum5__out, -1.0), 1.0);
    HIL_OutInt32(0x2000040 + _pv_plant_3ph_inverter_1_phase_a_pwm_modulator__channels[0], ((unsigned)((_pv_plant_3ph_inverter_1_phase_a_pwm_modulator__limited_in[0] - (-1.0)) * 10000.0)));
    if (_pv_plant_logical_operator1__out == 0x0) {
        // pwm_modulator_en
        HIL_OutInt32(0x2000000 + _pv_plant_3ph_inverter_1_phase_a_pwm_modulator__channels[0], 0x0);
    }
    else {
        // pwm_modulator_en
        HIL_OutInt32(0x2000000 + _pv_plant_3ph_inverter_1_phase_a_pwm_modulator__channels[0], 0x1);
    }
    HIL_OutInt32(0x2000140, _pv_plant_3ph_inverter_1_phase_a_pwm_modulator__update_mask);
    // Generated from the component: PV_Plant.Control.duty_cycle.Dz_A
    HIL_OutAO(0x4018, (float)_pv_plant_control_duty_cycle_zsm_sum5__out);
    // Generated from the component: PV_Plant.3ph_inverter 1.Phase B.PWM_Modulator
    _pv_plant_3ph_inverter_1_phase_b_pwm_modulator__limited_in[0] = MIN(MAX(_pv_plant_control_duty_cycle_zsm_sum6__out, -1.0), 1.0);
    HIL_OutInt32(0x2000040 + _pv_plant_3ph_inverter_1_phase_b_pwm_modulator__channels[0], ((unsigned)((_pv_plant_3ph_inverter_1_phase_b_pwm_modulator__limited_in[0] - (-1.0)) * 10000.0)));
    if (_pv_plant_logical_operator1__out == 0x0) {
        // pwm_modulator_en
        HIL_OutInt32(0x2000000 + _pv_plant_3ph_inverter_1_phase_b_pwm_modulator__channels[0], 0x0);
    }
    else {
        // pwm_modulator_en
        HIL_OutInt32(0x2000000 + _pv_plant_3ph_inverter_1_phase_b_pwm_modulator__channels[0], 0x1);
    }
    HIL_OutInt32(0x2000140, _pv_plant_3ph_inverter_1_phase_b_pwm_modulator__update_mask);
    // Generated from the component: PV_Plant.Control.duty_cycle.Dz_B
    HIL_OutAO(0x4019, (float)_pv_plant_control_duty_cycle_zsm_sum6__out);
    // Generated from the component: PV_Plant.3ph_inverter 1.Phase C.PWM_Modulator
    _pv_plant_3ph_inverter_1_phase_c_pwm_modulator__limited_in[0] = MIN(MAX(_pv_plant_control_duty_cycle_zsm_sum7__out, -1.0), 1.0);
    HIL_OutInt32(0x2000040 + _pv_plant_3ph_inverter_1_phase_c_pwm_modulator__channels[0], ((unsigned)((_pv_plant_3ph_inverter_1_phase_c_pwm_modulator__limited_in[0] - (-1.0)) * 10000.0)));
    if (_pv_plant_logical_operator1__out == 0x0) {
        // pwm_modulator_en
        HIL_OutInt32(0x2000000 + _pv_plant_3ph_inverter_1_phase_c_pwm_modulator__channels[0], 0x0);
    }
    else {
        // pwm_modulator_en
        HIL_OutInt32(0x2000000 + _pv_plant_3ph_inverter_1_phase_c_pwm_modulator__channels[0], 0x1);
    }
    HIL_OutInt32(0x2000140, _pv_plant_3ph_inverter_1_phase_c_pwm_modulator__update_mask);
    // Generated from the component: PV_Plant.Control.duty_cycle.Dz_C
    HIL_OutAO(0x401a, (float)_pv_plant_control_duty_cycle_zsm_sum7__out);
//@cmp.out.block.end
    //////////////////////////////////////////////////////////////////////////
    // Update block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.update.block.start
    // Generated from the component: PV_Plant.Control.Grid_follow.Edge Detection1.Unit Delay1
    _pv_plant_control_grid_follow_edge_detection1_unit_delay1__state = _pv_plant_input_bus_split2__out1;
    // Generated from the component: PV_Plant.Control.Grid_follow.Limit_PQref.Unit Delay1
    _pv_plant_control_grid_follow_limit_pqref_unit_delay1__state = _pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__P;
    // Generated from the component: PV_Plant.Control.Grid_follow.Limit_PQref.Unit Delay2
    _pv_plant_control_grid_follow_limit_pqref_unit_delay2__state = _pv_plant_control_grid_follow_limit_pqref_lims_overpq_s_limiting_over_pq__Q;
    // Generated from the component: PV_Plant.Control.Grid_follow.Power_Meas.Power_Meas_DQpu.S_and_pf
    // Generated from the component: PV_Plant.Control.PLL.PLL.PID.Integrator1
    _pv_plant_control_pll_pll_pid_integrator1__state += _pv_plant_control_pll_pll_pid_sum7__out * 0.0002;
    // Generated from the component: PV_Plant.Control.PLL.PLL.PID.Integrator2
    _pv_plant_control_pll_pll_pid_integrator2__state += _pv_plant_control_pll_pll_pid_gain1__out * 0.0002;
    // Generated from the component: PV_Plant.Control.PLL.PLL.Unit Delay1
    _pv_plant_control_pll_pll_unit_delay1__state = _pv_plant_control_pll_pll_integrator__out;
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.LPF_dc
    _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__states[0] = _pv_plant_control_grid_follow_controlsignal_calculation_lpf_dc__delay_line_in;
    // Generated from the component: PV_Plant.Control.Grid_follow.delay
    // Generated from the component: PV_Plant.delay
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.PI_d.Integrator1
    _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_integrator1__state += _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_sum7__out * 0.0002;
    if (_pv_plant_control_grid_follow_edge_detection1_relational_operator1__out > 0)
        _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_integrator1__reset_state = 1;
    else if (_pv_plant_control_grid_follow_edge_detection1_relational_operator1__out < 0)
        _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_integrator1__reset_state = -1;
    else
        _pv_plant_control_grid_follow_controlsignal_calculation_pi_d_integrator1__reset_state = 0;
    // Generated from the component: PV_Plant.Control.Grid_follow.ControlSignal_Calculation.PI_q.Integrator1
    _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_integrator1__state += _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_sum7__out * 0.0002;
    if (_pv_plant_control_grid_follow_edge_detection1_relational_operator1__out > 0)
        _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_integrator1__reset_state = 1;
    else if (_pv_plant_control_grid_follow_edge_detection1_relational_operator1__out < 0)
        _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_integrator1__reset_state = -1;
    else
        _pv_plant_control_grid_follow_controlsignal_calculation_pi_q_integrator1__reset_state = 0;
    // Generated from the component: PV_Plant.Control.Grid_follow.PI_Vt.Integrator1
    _pv_plant_control_grid_follow_pi_vt_integrator1__state += _pv_plant_control_grid_follow_pi_vt_sum7__out * 0.0002;
    if (_pv_plant_control_grid_follow_logical_operator1__out > 0)
        _pv_plant_control_grid_follow_pi_vt_integrator1__reset_state = 1;
    else if (_pv_plant_control_grid_follow_logical_operator1__out < 0)
        _pv_plant_control_grid_follow_pi_vt_integrator1__reset_state = -1;
    else
        _pv_plant_control_grid_follow_pi_vt_integrator1__reset_state = 0;
    // Generated from the component: PV_Plant.Control.PLL.PLL.normalize
    // Generated from the component: PV_Plant.Control.Grid_follow.Power_Meas.Power_Meas_DQpu.LPF_P
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__states[0] = _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_p__delay_line_in;
    // Generated from the component: PV_Plant.Control.Grid_follow.Power_Meas.Power_Meas_DQpu.LPF_Q
    _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__states[0] = _pv_plant_control_grid_follow_power_meas_power_meas_dqpu_lpf_q__delay_line_in;
    // Generated from the component: PV_Plant.Control.PLL.PLL.Rate Limiter1
    if (_pv_plant_control_pll_pll_pid_limit1__out - _pv_plant_control_pll_pll_rate_limiter1__state > 0.3769911184307752)
        _pv_plant_control_pll_pll_rate_limiter1__state += (0.3769911184307752);
    else  if (_pv_plant_control_pll_pll_pid_limit1__out - _pv_plant_control_pll_pll_rate_limiter1__state < -0.3769911184307752)
        _pv_plant_control_pll_pll_rate_limiter1__state += (-0.3769911184307752);
    else
        _pv_plant_control_pll_pll_rate_limiter1__state = _pv_plant_control_pll_pll_pid_limit1__out;
    _pv_plant_control_pll_pll_rate_limiter1__first_step = 0;
    // Generated from the component: PV_Plant.Control.PLL.PLL.integrator
    // Generated from the component: PV_Plant.Control.PLL.PLL.LPF.LPF
    for (_pv_plant_control_pll_pll_lpf_lpf__i = 1; _pv_plant_control_pll_pll_lpf_lpf__i > 0; _pv_plant_control_pll_pll_lpf_lpf__i--) {
        _pv_plant_control_pll_pll_lpf_lpf__states[_pv_plant_control_pll_pll_lpf_lpf__i] = _pv_plant_control_pll_pll_lpf_lpf__states[_pv_plant_control_pll_pll_lpf_lpf__i - 1];
    }
    _pv_plant_control_pll_pll_lpf_lpf__states[0] = _pv_plant_control_pll_pll_lpf_lpf__delay_line_in;
    // Generated from the component: PV_Plant.Control.Grid_follow.Limit_PQref.priority_PQlim.PQ limiting with priority
    // Generated from the component: PV_Plant.Control.Grid_follow.Limit_PQref.P rate limit
    if (_pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__P - _pv_plant_control_grid_follow_limit_pqref_p_rate_limit__state > 0.001)
        _pv_plant_control_grid_follow_limit_pqref_p_rate_limit__state += (0.001);
    else  if (_pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__P - _pv_plant_control_grid_follow_limit_pqref_p_rate_limit__state < -0.001)
        _pv_plant_control_grid_follow_limit_pqref_p_rate_limit__state += (-0.001);
    else
        _pv_plant_control_grid_follow_limit_pqref_p_rate_limit__state = _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__P;
    _pv_plant_control_grid_follow_limit_pqref_p_rate_limit__first_step = 0;
    // Generated from the component: PV_Plant.Control.Grid_follow.Limit_PQref.Q rate limit
    if (_pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q - _pv_plant_control_grid_follow_limit_pqref_q_rate_limit__state > 0.001)
        _pv_plant_control_grid_follow_limit_pqref_q_rate_limit__state += (0.001);
    else  if (_pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q - _pv_plant_control_grid_follow_limit_pqref_q_rate_limit__state < -0.001)
        _pv_plant_control_grid_follow_limit_pqref_q_rate_limit__state += (-0.001);
    else
        _pv_plant_control_grid_follow_limit_pqref_q_rate_limit__state = _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q;
    _pv_plant_control_grid_follow_limit_pqref_q_rate_limit__first_step = 0;
    // Generated from the component: PV_Plant.Control.Grid_follow.Limit_PQref.S rate limit
    if (_pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__S - _pv_plant_control_grid_follow_limit_pqref_s_rate_limit__state > 0.001)
        _pv_plant_control_grid_follow_limit_pqref_s_rate_limit__state += (0.001);
    else  if (_pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__S - _pv_plant_control_grid_follow_limit_pqref_s_rate_limit__state < -0.001)
        _pv_plant_control_grid_follow_limit_pqref_s_rate_limit__state += (-0.001);
    else
        _pv_plant_control_grid_follow_limit_pqref_s_rate_limit__state = _pv_plant_control_grid_follow_limit_pqref_priority_pqlim_pq_limiting_with_priority__S;
    _pv_plant_control_grid_follow_limit_pqref_s_rate_limit__first_step = 0;
    // Generated from the component: PV_Plant.Control.Grid_follow.Limit_PQref.limS_overPQ.S limiting over PQ
    //@cmp.update.block.end
}
// ----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------