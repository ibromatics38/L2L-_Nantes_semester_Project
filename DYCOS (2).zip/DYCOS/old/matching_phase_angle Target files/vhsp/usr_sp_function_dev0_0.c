// generated using template: cop_main.template---------------------------------------------
/******************************************************************************************
**
**  Module Name: cop_main.c
**  NOTE: Automatically generated file. DO NOT MODIFY!
**  Description:
**            Main file
**
******************************************************************************************/
// generated using template: arm/custom_include.template-----------------------------------


#ifdef __cplusplus
#include <limits>

extern "C" {
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <stdint.h>
#include <complex.h>

// x86 libraries:
#include "../include/sp_functions_dev0.h"


#ifdef __cplusplus
}
#endif


// ----------------------------------------------------------------------------------------                // generated using template:generic_macros.template-----------------------------------------
/*********************** Macros (Inline Functions) Definitions ***************************/

// ----------------------------------------------------------------------------------------

#ifndef MAX
#define MAX(value, limit) (((value) > (limit)) ? (value) : (limit))
#endif
#ifndef MIN
#define MIN(value, limit) (((value) < (limit)) ? (value) : (limit))
#endif

// generated using template: VirtualHIL/custom_defines.template----------------------------

typedef unsigned char X_UnInt8;
typedef char X_Int8;
typedef signed short X_Int16;
typedef unsigned short X_UnInt16;
typedef int X_Int32;
typedef unsigned int X_UnInt32;
typedef unsigned int uint;
typedef double real;

// ----------------------------------------------------------------------------------------
// generated using template: custom_consts.template----------------------------------------

// arithmetic constants
#define C_SQRT_2                    1.4142135623730950488016887242097f
#define C_SQRT_3                    1.7320508075688772935274463415059f
#define C_PI                        3.1415926535897932384626433832795f
#define C_E                         2.7182818284590452353602874713527f
#define C_2PI                       6.283185307179586476925286766559f

//@cmp.def.start
//component defines







































































































































































































































//@cmp.def.end


//-----------------------------------------------------------------------------------------
// generated using template: common_variables.template-------------------------------------
// true global variables



//@cmp.var.start
// variables
double _three_phase_meter1_ia_ia1__out;
double _three_phase_meter1_ib_ia1__out;
double _three_phase_meter1_ic_ia1__out;
double _three_phase_meter1_pll_pid_integrator1__out;
double _three_phase_meter1_pll_pid_integrator2__out;
double _three_phase_meter1_pll_unit_delay1__out;
double _three_phase_meter1_pll_to_hz__out;
double _three_phase_meter1_vab_va1__out;
double _three_phase_meter1_van_va1__out;
double _three_phase_meter1_vbc_va1__out;
double _three_phase_meter1_vbn_va1__out;
double _three_phase_meter1_vca_va1__out;
double _three_phase_meter1_vcn_va1__out;
double _three_phase_meter1_zero__out = 0.0;
double _three_phase_meter2_ia_ia1__out;
double _three_phase_meter2_ib_ia1__out;
double _three_phase_meter2_ic_ia1__out;
double _three_phase_meter2_pll_pid_integrator1__out;
double _three_phase_meter2_pll_pid_integrator2__out;
double _three_phase_meter2_pll_unit_delay1__out;
double _three_phase_meter2_pll_to_hz__out;
double _three_phase_meter2_van_va1__out;
double _three_phase_meter2_vbn_va1__out;
double _three_phase_meter2_vcn_va1__out;
double _three_phase_meter2_zero__out = 0.0;
double _three_phase_meter3_ia_ia1__out;
double _three_phase_meter3_ib_ia1__out;
double _three_phase_meter3_ic_ia1__out;
double _three_phase_meter3_pll_pid_integrator1__out;
double _three_phase_meter3_pll_pid_integrator2__out;
double _three_phase_meter3_pll_unit_delay1__out;
double _three_phase_meter3_pll_to_hz__out;
double _three_phase_meter3_van_va1__out;
double _three_phase_meter3_vbn_va1__out;
double _three_phase_meter3_vcn_va1__out;
double _three_phase_meter3_zero__out = 0.0;
double _three_phase_meter1_pll_sin__out;

double _three_phase_meter1_meassm_mode_and_dfract__Freq;


double _three_phase_meter1_meassm_mode_and_dfract__dFract;
X_Int32 _three_phase_meter1_meassm_mode_and_dfract__mode;
X_Int32 _three_phase_meter1_meassm_mode_and_dfract__submode;
double _three_phase_meter1_pll_abc_to_dq_abc_to_alpha_beta__alpha;
double _three_phase_meter1_pll_abc_to_dq_abc_to_alpha_beta__beta;
double _three_phase_meter1_pll_abc_to_dq_abc_to_alpha_beta__gamma;
double _three_phase_meter2_pll_sin__out;

double _three_phase_meter2_meassm_mode_and_dfract__Freq;


double _three_phase_meter2_meassm_mode_and_dfract__dFract;
X_Int32 _three_phase_meter2_meassm_mode_and_dfract__mode;
X_Int32 _three_phase_meter2_meassm_mode_and_dfract__submode;
double _three_phase_meter2_pll_abc_to_dq_abc_to_alpha_beta__alpha;
double _three_phase_meter2_pll_abc_to_dq_abc_to_alpha_beta__beta;
double _three_phase_meter2_pll_abc_to_dq_abc_to_alpha_beta__gamma;
double _three_phase_meter3_pll_sin__out;

double _three_phase_meter3_meassm_mode_and_dfract__Freq;


double _three_phase_meter3_meassm_mode_and_dfract__dFract;
X_Int32 _three_phase_meter3_meassm_mode_and_dfract__mode;
X_Int32 _three_phase_meter3_meassm_mode_and_dfract__submode;
double _three_phase_meter3_pll_abc_to_dq_abc_to_alpha_beta__alpha;
double _three_phase_meter3_pll_abc_to_dq_abc_to_alpha_beta__beta;
double _three_phase_meter3_pll_abc_to_dq_abc_to_alpha_beta__gamma;

double _three_phase_meter1_i_rms_calc_rms__IN1;
double _three_phase_meter1_i_rms_calc_rms__IN2;
double _three_phase_meter1_i_rms_calc_rms__IN3;
double _three_phase_meter1_i_rms_calc_rms__dFract;
X_Int32 _three_phase_meter1_i_rms_calc_rms__mode;


double _three_phase_meter1_i_rms_calc_rms__RMS1;
double _three_phase_meter1_i_rms_calc_rms__RMS2;
double _three_phase_meter1_i_rms_calc_rms__RMS3;

double _three_phase_meter1_vln_rms_calc_rms__IN1;
double _three_phase_meter1_vln_rms_calc_rms__IN2;
double _three_phase_meter1_vln_rms_calc_rms__IN3;
double _three_phase_meter1_vln_rms_calc_rms__dFract;
X_Int32 _three_phase_meter1_vln_rms_calc_rms__mode;


double _three_phase_meter1_vln_rms_calc_rms__RMS1;
double _three_phase_meter1_vln_rms_calc_rms__RMS2;
double _three_phase_meter1_vln_rms_calc_rms__RMS3;
double _three_phase_meter1_pll_abc_to_dq_alpha_beta_to_dq__d;
double _three_phase_meter1_pll_abc_to_dq_alpha_beta_to_dq__q;
double _three_phase_meter1_pll_abc_to_dq_alpha_beta_to_dq__k1;
double _three_phase_meter1_pll_abc_to_dq_alpha_beta_to_dq__k2;

double _three_phase_meter2_i_rms_calc_rms__IN1;
double _three_phase_meter2_i_rms_calc_rms__IN2;
double _three_phase_meter2_i_rms_calc_rms__IN3;
double _three_phase_meter2_i_rms_calc_rms__dFract;
X_Int32 _three_phase_meter2_i_rms_calc_rms__mode;


double _three_phase_meter2_i_rms_calc_rms__RMS1;
double _three_phase_meter2_i_rms_calc_rms__RMS2;
double _three_phase_meter2_i_rms_calc_rms__RMS3;

double _three_phase_meter2_vln_rms_calc_rms__IN1;
double _three_phase_meter2_vln_rms_calc_rms__IN2;
double _three_phase_meter2_vln_rms_calc_rms__IN3;
double _three_phase_meter2_vln_rms_calc_rms__dFract;
X_Int32 _three_phase_meter2_vln_rms_calc_rms__mode;


double _three_phase_meter2_vln_rms_calc_rms__RMS1;
double _three_phase_meter2_vln_rms_calc_rms__RMS2;
double _three_phase_meter2_vln_rms_calc_rms__RMS3;
double _three_phase_meter2_pll_abc_to_dq_alpha_beta_to_dq__d;
double _three_phase_meter2_pll_abc_to_dq_alpha_beta_to_dq__q;
double _three_phase_meter2_pll_abc_to_dq_alpha_beta_to_dq__k1;
double _three_phase_meter2_pll_abc_to_dq_alpha_beta_to_dq__k2;

double _three_phase_meter3_i_rms_calc_rms__IN1;
double _three_phase_meter3_i_rms_calc_rms__IN2;
double _three_phase_meter3_i_rms_calc_rms__IN3;
double _three_phase_meter3_i_rms_calc_rms__dFract;
X_Int32 _three_phase_meter3_i_rms_calc_rms__mode;


double _three_phase_meter3_i_rms_calc_rms__RMS1;
double _three_phase_meter3_i_rms_calc_rms__RMS2;
double _three_phase_meter3_i_rms_calc_rms__RMS3;

double _three_phase_meter3_vln_rms_calc_rms__IN1;
double _three_phase_meter3_vln_rms_calc_rms__IN2;
double _three_phase_meter3_vln_rms_calc_rms__IN3;
double _three_phase_meter3_vln_rms_calc_rms__dFract;
X_Int32 _three_phase_meter3_vln_rms_calc_rms__mode;


double _three_phase_meter3_vln_rms_calc_rms__RMS1;
double _three_phase_meter3_vln_rms_calc_rms__RMS2;
double _three_phase_meter3_vln_rms_calc_rms__RMS3;
double _three_phase_meter3_pll_abc_to_dq_alpha_beta_to_dq__d;
double _three_phase_meter3_pll_abc_to_dq_alpha_beta_to_dq__q;
double _three_phase_meter3_pll_abc_to_dq_alpha_beta_to_dq__k1;
double _three_phase_meter3_pll_abc_to_dq_alpha_beta_to_dq__k2;

double _three_phase_meter1_power_meter_power__Ia;
double _three_phase_meter1_power_meter_power__Ib;
double _three_phase_meter1_power_meter_power__Ic;
double _three_phase_meter1_power_meter_power__IrmsA;
double _three_phase_meter1_power_meter_power__IrmsB;
double _three_phase_meter1_power_meter_power__IrmsC;
double _three_phase_meter1_power_meter_power__Va;
double _three_phase_meter1_power_meter_power__Vb;
double _three_phase_meter1_power_meter_power__Vc;
double _three_phase_meter1_power_meter_power__VrmsA;
double _three_phase_meter1_power_meter_power__VrmsB;
double _three_phase_meter1_power_meter_power__VrmsC;
double _three_phase_meter1_power_meter_power__dFract;
X_Int32 _three_phase_meter1_power_meter_power__mode;
X_Int32 _three_phase_meter1_power_meter_power__submode;


double _three_phase_meter1_power_meter_power__P;
double _three_phase_meter1_power_meter_power__PF;
double _three_phase_meter1_power_meter_power__PFa;
double _three_phase_meter1_power_meter_power__PFb;
double _three_phase_meter1_power_meter_power__PFc;
double _three_phase_meter1_power_meter_power__Pa;
double _three_phase_meter1_power_meter_power__Pb;
double _three_phase_meter1_power_meter_power__Pc;
double _three_phase_meter1_power_meter_power__Q;
double _three_phase_meter1_power_meter_power__Qa;
double _three_phase_meter1_power_meter_power__Qb;
double _three_phase_meter1_power_meter_power__Qc;
double _three_phase_meter1_power_meter_power__S;
double _three_phase_meter1_power_meter_power__Sa;
double _three_phase_meter1_power_meter_power__Sb;
double _three_phase_meter1_power_meter_power__Sc;
double _three_phase_meter1_pll_abc_to_dq_lpf_d__out;
double _three_phase_meter1_pll_abc_to_dq_lpf_d__previous_filtered_value;
double _three_phase_meter1_pll_abc_to_dq_lpf_q__out;
double _three_phase_meter1_pll_abc_to_dq_lpf_q__previous_filtered_value;
double _three_phase_meter2_power_meter_power__Ia;
double _three_phase_meter2_power_meter_power__Ib;
double _three_phase_meter2_power_meter_power__Ic;
double _three_phase_meter2_power_meter_power__IrmsA;
double _three_phase_meter2_power_meter_power__IrmsB;
double _three_phase_meter2_power_meter_power__IrmsC;
double _three_phase_meter2_power_meter_power__Va;
double _three_phase_meter2_power_meter_power__Vb;
double _three_phase_meter2_power_meter_power__Vc;
double _three_phase_meter2_power_meter_power__VrmsA;
double _three_phase_meter2_power_meter_power__VrmsB;
double _three_phase_meter2_power_meter_power__VrmsC;
double _three_phase_meter2_power_meter_power__dFract;
X_Int32 _three_phase_meter2_power_meter_power__mode;
X_Int32 _three_phase_meter2_power_meter_power__submode;


double _three_phase_meter2_power_meter_power__P;
double _three_phase_meter2_power_meter_power__PF;
double _three_phase_meter2_power_meter_power__PFa;
double _three_phase_meter2_power_meter_power__PFb;
double _three_phase_meter2_power_meter_power__PFc;
double _three_phase_meter2_power_meter_power__Pa;
double _three_phase_meter2_power_meter_power__Pb;
double _three_phase_meter2_power_meter_power__Pc;
double _three_phase_meter2_power_meter_power__Q;
double _three_phase_meter2_power_meter_power__Qa;
double _three_phase_meter2_power_meter_power__Qb;
double _three_phase_meter2_power_meter_power__Qc;
double _three_phase_meter2_power_meter_power__S;
double _three_phase_meter2_power_meter_power__Sa;
double _three_phase_meter2_power_meter_power__Sb;
double _three_phase_meter2_power_meter_power__Sc;
double _three_phase_meter2_pll_abc_to_dq_lpf_d__out;
double _three_phase_meter2_pll_abc_to_dq_lpf_d__previous_filtered_value;
double _three_phase_meter2_pll_abc_to_dq_lpf_q__out;
double _three_phase_meter2_pll_abc_to_dq_lpf_q__previous_filtered_value;
double _three_phase_meter3_power_meter_power__Ia;
double _three_phase_meter3_power_meter_power__Ib;
double _three_phase_meter3_power_meter_power__Ic;
double _three_phase_meter3_power_meter_power__IrmsA;
double _three_phase_meter3_power_meter_power__IrmsB;
double _three_phase_meter3_power_meter_power__IrmsC;
double _three_phase_meter3_power_meter_power__Va;
double _three_phase_meter3_power_meter_power__Vb;
double _three_phase_meter3_power_meter_power__Vc;
double _three_phase_meter3_power_meter_power__VrmsA;
double _three_phase_meter3_power_meter_power__VrmsB;
double _three_phase_meter3_power_meter_power__VrmsC;
double _three_phase_meter3_power_meter_power__dFract;
X_Int32 _three_phase_meter3_power_meter_power__mode;
X_Int32 _three_phase_meter3_power_meter_power__submode;


double _three_phase_meter3_power_meter_power__P;
double _three_phase_meter3_power_meter_power__PF;
double _three_phase_meter3_power_meter_power__PFa;
double _three_phase_meter3_power_meter_power__PFb;
double _three_phase_meter3_power_meter_power__PFc;
double _three_phase_meter3_power_meter_power__Pa;
double _three_phase_meter3_power_meter_power__Pb;
double _three_phase_meter3_power_meter_power__Pc;
double _three_phase_meter3_power_meter_power__Q;
double _three_phase_meter3_power_meter_power__Qa;
double _three_phase_meter3_power_meter_power__Qb;
double _three_phase_meter3_power_meter_power__Qc;
double _three_phase_meter3_power_meter_power__S;
double _three_phase_meter3_power_meter_power__Sa;
double _three_phase_meter3_power_meter_power__Sb;
double _three_phase_meter3_power_meter_power__Sc;
double _three_phase_meter3_pll_abc_to_dq_lpf_d__out;
double _three_phase_meter3_pll_abc_to_dq_lpf_d__previous_filtered_value;
double _three_phase_meter3_pll_abc_to_dq_lpf_q__out;
double _three_phase_meter3_pll_abc_to_dq_lpf_q__previous_filtered_value;
double _three_phase_meter1_extra_output_bus__out[12];
double _three_phase_meter1_output_bus__out[30];

double _three_phase_meter1_pll_normalize__in1;
double _three_phase_meter1_pll_normalize__in2;


double _three_phase_meter1_pll_normalize__in2_pu;
double _three_phase_meter1_pll_normalize__pk;
double _three_phase_meter2_extra_output_bus__out[12];
double _three_phase_meter2_output_bus__out[30];

double _three_phase_meter2_pll_normalize__in1;
double _three_phase_meter2_pll_normalize__in2;


double _three_phase_meter2_pll_normalize__in2_pu;
double _three_phase_meter2_pll_normalize__pk;
double _three_phase_meter3_extra_output_bus__out[12];
double _three_phase_meter3_output_bus__out[30];

double _three_phase_meter3_pll_normalize__in1;
double _three_phase_meter3_pll_normalize__in2;


double _three_phase_meter3_pll_normalize__in2_pu;
double _three_phase_meter3_pll_normalize__pk;
double _three_phase_meter1_pll_pid_kd__out;
double _three_phase_meter1_pll_pid_ki__out;
double _three_phase_meter1_pll_pid_kp__out;
double _three_phase_meter2_pll_pid_kd__out;
double _three_phase_meter2_pll_pid_ki__out;
double _three_phase_meter2_pll_pid_kp__out;
double _three_phase_meter3_pll_pid_kd__out;
double _three_phase_meter3_pll_pid_ki__out;
double _three_phase_meter3_pll_pid_kp__out;
double _three_phase_meter1_pll_pid_sum8__out;
double _three_phase_meter2_pll_pid_sum8__out;
double _three_phase_meter3_pll_pid_sum8__out;
double _three_phase_meter1_pll_pid_gain1__out;
double _three_phase_meter2_pll_pid_gain1__out;
double _three_phase_meter3_pll_pid_gain1__out;
double _three_phase_meter1_pll_pid_sum5__out;
double _three_phase_meter2_pll_pid_sum5__out;
double _three_phase_meter3_pll_pid_sum5__out;
double _three_phase_meter1_pll_pid_limit1__out;
double _three_phase_meter2_pll_pid_limit1__out;
double _three_phase_meter3_pll_pid_limit1__out;
double _three_phase_meter1_pll_pid_sum6__out;
double _three_phase_meter1_pll_rate_limiter1__out;

double _three_phase_meter1_pll_integrator__in;


double _three_phase_meter1_pll_integrator__out;
double _three_phase_meter2_pll_pid_sum6__out;
double _three_phase_meter2_pll_rate_limiter1__out;

double _three_phase_meter2_pll_integrator__in;


double _three_phase_meter2_pll_integrator__out;
double _three_phase_meter3_pll_pid_sum6__out;
double _three_phase_meter3_pll_rate_limiter1__out;

double _three_phase_meter3_pll_integrator__in;


double _three_phase_meter3_pll_integrator__out;
double _three_phase_meter1_pll_pid_kb__out;
double _three_phase_meter1_pll_lpf_lpf__out;
double _three_phase_meter1_pll_lpf_lpf__b_coeff[2] = {2.220446049250313e-16, 0.0002467400073613568};
double _three_phase_meter1_pll_lpf_lpf__a_coeff[3] = {1.0, -1.97778894456, 0.9780356845673617};
double _three_phase_meter1_pll_lpf_lpf__a_sum;
double _three_phase_meter1_pll_lpf_lpf__b_sum;
double _three_phase_meter1_pll_lpf_lpf__delay_line_in;
double _three_phase_meter2_pll_pid_kb__out;
double _three_phase_meter2_pll_lpf_lpf__out;
double _three_phase_meter2_pll_lpf_lpf__b_coeff[2] = {2.220446049250313e-16, 0.0002467400073613568};
double _three_phase_meter2_pll_lpf_lpf__a_coeff[3] = {1.0, -1.97778894456, 0.9780356845673617};
double _three_phase_meter2_pll_lpf_lpf__a_sum;
double _three_phase_meter2_pll_lpf_lpf__b_sum;
double _three_phase_meter2_pll_lpf_lpf__delay_line_in;
double _three_phase_meter3_pll_pid_kb__out;
double _three_phase_meter3_pll_lpf_lpf__out;
double _three_phase_meter3_pll_lpf_lpf__b_coeff[2] = {2.220446049250313e-16, 0.0002467400073613568};
double _three_phase_meter3_pll_lpf_lpf__a_coeff[3] = {1.0, -1.97778894456, 0.9780356845673617};
double _three_phase_meter3_pll_lpf_lpf__a_sum;
double _three_phase_meter3_pll_lpf_lpf__b_sum;
double _three_phase_meter3_pll_lpf_lpf__delay_line_in;
double _three_phase_meter1_pll_pid_sum7__out;
double _three_phase_meter2_pll_pid_sum7__out;
double _three_phase_meter3_pll_pid_sum7__out;
//@cmp.var.end

//@cmp.svar.start
// state variables
double _three_phase_meter1_pll_pid_integrator1__state;
double _three_phase_meter1_pll_pid_integrator2__state;
double _three_phase_meter1_pll_unit_delay1__state;
double _three_phase_meter2_pll_pid_integrator1__state;
double _three_phase_meter2_pll_pid_integrator2__state;
double _three_phase_meter2_pll_unit_delay1__state;
double _three_phase_meter3_pll_pid_integrator1__state;
double _three_phase_meter3_pll_pid_integrator2__state;
double _three_phase_meter3_pll_unit_delay1__state;
double _three_phase_meter1_meassm_mode_and_dfract__Tfract;
double _three_phase_meter1_meassm_mode_and_dfract__freqAbs;
double _three_phase_meter1_meassm_mode_and_dfract__fMax;
X_Int32 _three_phase_meter1_meassm_mode_and_dfract__reset;
X_Int32 _three_phase_meter1_meassm_mode_and_dfract__cycle_counter;
double _three_phase_meter2_meassm_mode_and_dfract__Tfract;
double _three_phase_meter2_meassm_mode_and_dfract__freqAbs;
double _three_phase_meter2_meassm_mode_and_dfract__fMax;
X_Int32 _three_phase_meter2_meassm_mode_and_dfract__reset;
X_Int32 _three_phase_meter2_meassm_mode_and_dfract__cycle_counter;
double _three_phase_meter3_meassm_mode_and_dfract__Tfract;
double _three_phase_meter3_meassm_mode_and_dfract__freqAbs;
double _three_phase_meter3_meassm_mode_and_dfract__fMax;
X_Int32 _three_phase_meter3_meassm_mode_and_dfract__reset;
X_Int32 _three_phase_meter3_meassm_mode_and_dfract__cycle_counter;
double _three_phase_meter1_i_rms_calc_rms__rmsSum1;
double _three_phase_meter1_i_rms_calc_rms__rmsSum2;
double _three_phase_meter1_i_rms_calc_rms__rmsSum3;
double _three_phase_meter1_vln_rms_calc_rms__rmsSum1;
double _three_phase_meter1_vln_rms_calc_rms__rmsSum2;
double _three_phase_meter1_vln_rms_calc_rms__rmsSum3;
double _three_phase_meter2_i_rms_calc_rms__rmsSum1;
double _three_phase_meter2_i_rms_calc_rms__rmsSum2;
double _three_phase_meter2_i_rms_calc_rms__rmsSum3;
double _three_phase_meter2_vln_rms_calc_rms__rmsSum1;
double _three_phase_meter2_vln_rms_calc_rms__rmsSum2;
double _three_phase_meter2_vln_rms_calc_rms__rmsSum3;
double _three_phase_meter3_i_rms_calc_rms__rmsSum1;
double _three_phase_meter3_i_rms_calc_rms__rmsSum2;
double _three_phase_meter3_i_rms_calc_rms__rmsSum3;
double _three_phase_meter3_vln_rms_calc_rms__rmsSum1;
double _three_phase_meter3_vln_rms_calc_rms__rmsSum2;
double _three_phase_meter3_vln_rms_calc_rms__rmsSum3;
double _three_phase_meter1_power_meter_power__PsumA;
double _three_phase_meter1_power_meter_power__PsumB;
double _three_phase_meter1_power_meter_power__PsumC;
double _three_phase_meter1_power_meter_power__VevenSumA;
double _three_phase_meter1_power_meter_power__VevenSumB;
double _three_phase_meter1_power_meter_power__VevenSumC;
double _three_phase_meter1_power_meter_power__VoddSumA;
double _three_phase_meter1_power_meter_power__VoddSumB;
double _three_phase_meter1_power_meter_power__VoddSumC;
double _three_phase_meter1_power_meter_power__IevenSumA;
double _three_phase_meter1_power_meter_power__IevenSumB;
double _three_phase_meter1_power_meter_power__IevenSumC;
double _three_phase_meter1_power_meter_power__IoddSumA;
double _three_phase_meter1_power_meter_power__IoddSumB;
double _three_phase_meter1_power_meter_power__IoddSumC;
double _three_phase_meter1_pll_abc_to_dq_lpf_d__filtered_value;
double _three_phase_meter1_pll_abc_to_dq_lpf_d__previous_in;
double _three_phase_meter1_pll_abc_to_dq_lpf_q__filtered_value;
double _three_phase_meter1_pll_abc_to_dq_lpf_q__previous_in;
double _three_phase_meter2_power_meter_power__PsumA;
double _three_phase_meter2_power_meter_power__PsumB;
double _three_phase_meter2_power_meter_power__PsumC;
double _three_phase_meter2_power_meter_power__VevenSumA;
double _three_phase_meter2_power_meter_power__VevenSumB;
double _three_phase_meter2_power_meter_power__VevenSumC;
double _three_phase_meter2_power_meter_power__VoddSumA;
double _three_phase_meter2_power_meter_power__VoddSumB;
double _three_phase_meter2_power_meter_power__VoddSumC;
double _three_phase_meter2_power_meter_power__IevenSumA;
double _three_phase_meter2_power_meter_power__IevenSumB;
double _three_phase_meter2_power_meter_power__IevenSumC;
double _three_phase_meter2_power_meter_power__IoddSumA;
double _three_phase_meter2_power_meter_power__IoddSumB;
double _three_phase_meter2_power_meter_power__IoddSumC;
double _three_phase_meter2_pll_abc_to_dq_lpf_d__filtered_value;
double _three_phase_meter2_pll_abc_to_dq_lpf_d__previous_in;
double _three_phase_meter2_pll_abc_to_dq_lpf_q__filtered_value;
double _three_phase_meter2_pll_abc_to_dq_lpf_q__previous_in;
double _three_phase_meter3_power_meter_power__PsumA;
double _three_phase_meter3_power_meter_power__PsumB;
double _three_phase_meter3_power_meter_power__PsumC;
double _three_phase_meter3_power_meter_power__VevenSumA;
double _three_phase_meter3_power_meter_power__VevenSumB;
double _three_phase_meter3_power_meter_power__VevenSumC;
double _three_phase_meter3_power_meter_power__VoddSumA;
double _three_phase_meter3_power_meter_power__VoddSumB;
double _three_phase_meter3_power_meter_power__VoddSumC;
double _three_phase_meter3_power_meter_power__IevenSumA;
double _three_phase_meter3_power_meter_power__IevenSumB;
double _three_phase_meter3_power_meter_power__IevenSumC;
double _three_phase_meter3_power_meter_power__IoddSumA;
double _three_phase_meter3_power_meter_power__IoddSumB;
double _three_phase_meter3_power_meter_power__IoddSumC;
double _three_phase_meter3_pll_abc_to_dq_lpf_d__filtered_value;
double _three_phase_meter3_pll_abc_to_dq_lpf_d__previous_in;
double _three_phase_meter3_pll_abc_to_dq_lpf_q__filtered_value;
double _three_phase_meter3_pll_abc_to_dq_lpf_q__previous_in;
double _three_phase_meter1_pll_rate_limiter1__state;
X_Int32 _three_phase_meter1_pll_rate_limiter1__first_step;
double _three_phase_meter2_pll_rate_limiter1__state;
X_Int32 _three_phase_meter2_pll_rate_limiter1__first_step;
double _three_phase_meter3_pll_rate_limiter1__state;
X_Int32 _three_phase_meter3_pll_rate_limiter1__first_step;
double _three_phase_meter1_pll_lpf_lpf__states[2];
double _three_phase_meter2_pll_lpf_lpf__states[2];
double _three_phase_meter3_pll_lpf_lpf__states[2];
//@cmp.svar.end

//
// Tunable parameters
//
static struct Tunable_params {
} __attribute__((__packed__)) tunable_params;

void *tunable_params_dev0_cpu0_ptr = &tunable_params;

// Dll function pointers
#if defined(_WIN64)
#else
// Define handles for loading dlls
#endif








// generated using template: virtual_hil/custom_functions.template---------------------------------
void ReInit_user_sp_cpu0_dev0() {
#if DEBUG_MODE
    printf("\n\rReInitTimer");
#endif
    //@cmp.init.block.start
    _three_phase_meter1_pll_pid_integrator1__state = 376.99111843;
    _three_phase_meter1_pll_pid_integrator2__state = 0.0;
    _three_phase_meter1_pll_unit_delay1__state = 0.0;
    _three_phase_meter2_pll_pid_integrator1__state = 376.99111843;
    _three_phase_meter2_pll_pid_integrator2__state = 0.0;
    _three_phase_meter2_pll_unit_delay1__state = 0.0;
    _three_phase_meter3_pll_pid_integrator1__state = 376.99111843;
    _three_phase_meter3_pll_pid_integrator2__state = 0.0;
    _three_phase_meter3_pll_unit_delay1__state = 0.0;
    HIL_OutAO(0x4000, 0.0f);
    _three_phase_meter1_meassm_mode_and_dfract__dFract = 0;
    _three_phase_meter1_meassm_mode_and_dfract__fMax = 1.0 / 0.0001;
    _three_phase_meter1_meassm_mode_and_dfract__cycle_counter = 0;
    _three_phase_meter1_meassm_mode_and_dfract__reset = 1;
    HIL_OutAO(0x4017, 0.0f);
    _three_phase_meter2_meassm_mode_and_dfract__dFract = 0;
    _three_phase_meter2_meassm_mode_and_dfract__fMax = 1.0 / 0.0001;
    _three_phase_meter2_meassm_mode_and_dfract__cycle_counter = 0;
    _three_phase_meter2_meassm_mode_and_dfract__reset = 1;
    HIL_OutAO(0x402e, 0.0f);
    _three_phase_meter3_meassm_mode_and_dfract__dFract = 0;
    _three_phase_meter3_meassm_mode_and_dfract__fMax = 1.0 / 0.0001;
    _three_phase_meter3_meassm_mode_and_dfract__cycle_counter = 0;
    _three_phase_meter3_meassm_mode_and_dfract__reset = 1;
    _three_phase_meter1_i_rms_calc_rms__mode = 1;
    _three_phase_meter1_vln_rms_calc_rms__mode = 1;
    _three_phase_meter2_i_rms_calc_rms__mode = 1;
    _three_phase_meter2_vln_rms_calc_rms__mode = 1;
    _three_phase_meter3_i_rms_calc_rms__mode = 1;
    _three_phase_meter3_vln_rms_calc_rms__mode = 1;
    HIL_OutAO(0x4001, 0.0f);
    HIL_OutAO(0x4002, 0.0f);
    HIL_OutAO(0x4003, 0.0f);
    _three_phase_meter1_power_meter_power__mode = 1;
    HIL_OutAO(0x4014, 0.0f);
    HIL_OutAO(0x4015, 0.0f);
    HIL_OutAO(0x4016, 0.0f);
    _three_phase_meter1_pll_abc_to_dq_lpf_d__filtered_value = 0.0 / (1 - 1.0 * 62.83185307 * 0.0001 );
    _three_phase_meter1_pll_abc_to_dq_lpf_d__previous_in = 0x0;
    _three_phase_meter1_pll_abc_to_dq_lpf_q__filtered_value = 0.0 / (1 - 1.0 * 62.83185307 * 0.0001 );
    _three_phase_meter1_pll_abc_to_dq_lpf_q__previous_in = 0x0;
    HIL_OutAO(0x4018, 0.0f);
    HIL_OutAO(0x4019, 0.0f);
    HIL_OutAO(0x401a, 0.0f);
    _three_phase_meter2_power_meter_power__mode = 1;
    HIL_OutAO(0x402b, 0.0f);
    HIL_OutAO(0x402c, 0.0f);
    HIL_OutAO(0x402d, 0.0f);
    _three_phase_meter2_pll_abc_to_dq_lpf_d__filtered_value = 0.0 / (1 - 1.0 * 62.83185307 * 0.0001 );
    _three_phase_meter2_pll_abc_to_dq_lpf_d__previous_in = 0x0;
    _three_phase_meter2_pll_abc_to_dq_lpf_q__filtered_value = 0.0 / (1 - 1.0 * 62.83185307 * 0.0001 );
    _three_phase_meter2_pll_abc_to_dq_lpf_q__previous_in = 0x0;
    HIL_OutAO(0x402f, 0.0f);
    HIL_OutAO(0x4030, 0.0f);
    HIL_OutAO(0x4031, 0.0f);
    _three_phase_meter3_power_meter_power__mode = 1;
    HIL_OutAO(0x4042, 0.0f);
    HIL_OutAO(0x4043, 0.0f);
    HIL_OutAO(0x4044, 0.0f);
    _three_phase_meter3_pll_abc_to_dq_lpf_d__filtered_value = 0.0 / (1 - 1.0 * 62.83185307 * 0.0001 );
    _three_phase_meter3_pll_abc_to_dq_lpf_d__previous_in = 0x0;
    _three_phase_meter3_pll_abc_to_dq_lpf_q__filtered_value = 0.0 / (1 - 1.0 * 62.83185307 * 0.0001 );
    _three_phase_meter3_pll_abc_to_dq_lpf_q__previous_in = 0x0;
    HIL_OutAO(0x4004, 0.0f);
    HIL_OutAO(0x4005, 0.0f);
    HIL_OutAO(0x4006, 0.0f);
    HIL_OutAO(0x4007, 0.0f);
    HIL_OutAO(0x4008, 0.0f);
    HIL_OutAO(0x4009, 0.0f);
    HIL_OutAO(0x400a, 0.0f);
    HIL_OutAO(0x400b, 0.0f);
    HIL_OutAO(0x400c, 0.0f);
    HIL_OutAO(0x400d, 0.0f);
    HIL_OutAO(0x400e, 0.0f);
    HIL_OutAO(0x400f, 0.0f);
    HIL_OutAO(0x4010, 0.0f);
    HIL_OutAO(0x4011, 0.0f);
    HIL_OutAO(0x4012, 0.0f);
    HIL_OutAO(0x4013, 0.0f);
    _three_phase_meter1_pll_normalize__pk = 0;
    HIL_OutAO(0x401b, 0.0f);
    HIL_OutAO(0x401c, 0.0f);
    HIL_OutAO(0x401d, 0.0f);
    HIL_OutAO(0x401e, 0.0f);
    HIL_OutAO(0x401f, 0.0f);
    HIL_OutAO(0x4020, 0.0f);
    HIL_OutAO(0x4021, 0.0f);
    HIL_OutAO(0x4022, 0.0f);
    HIL_OutAO(0x4023, 0.0f);
    HIL_OutAO(0x4024, 0.0f);
    HIL_OutAO(0x4025, 0.0f);
    HIL_OutAO(0x4026, 0.0f);
    HIL_OutAO(0x4027, 0.0f);
    HIL_OutAO(0x4028, 0.0f);
    HIL_OutAO(0x4029, 0.0f);
    HIL_OutAO(0x402a, 0.0f);
    _three_phase_meter2_pll_normalize__pk = 0;
    HIL_OutAO(0x4032, 0.0f);
    HIL_OutAO(0x4033, 0.0f);
    HIL_OutAO(0x4034, 0.0f);
    HIL_OutAO(0x4035, 0.0f);
    HIL_OutAO(0x4036, 0.0f);
    HIL_OutAO(0x4037, 0.0f);
    HIL_OutAO(0x4038, 0.0f);
    HIL_OutAO(0x4039, 0.0f);
    HIL_OutAO(0x403a, 0.0f);
    HIL_OutAO(0x403b, 0.0f);
    HIL_OutAO(0x403c, 0.0f);
    HIL_OutAO(0x403d, 0.0f);
    HIL_OutAO(0x403e, 0.0f);
    HIL_OutAO(0x403f, 0.0f);
    HIL_OutAO(0x4040, 0.0f);
    HIL_OutAO(0x4041, 0.0f);
    _three_phase_meter3_pll_normalize__pk = 0;
    _three_phase_meter1_pll_rate_limiter1__state = 0;
    _three_phase_meter1_pll_rate_limiter1__first_step = 1;
    _three_phase_meter1_pll_integrator__out = 0;
    _three_phase_meter2_pll_rate_limiter1__state = 0;
    _three_phase_meter2_pll_rate_limiter1__first_step = 1;
    _three_phase_meter2_pll_integrator__out = 0;
    _three_phase_meter3_pll_rate_limiter1__state = 0;
    _three_phase_meter3_pll_rate_limiter1__first_step = 1;
    _three_phase_meter3_pll_integrator__out = 0;
    X_UnInt32 _three_phase_meter1_pll_lpf_lpf__i;
    for (_three_phase_meter1_pll_lpf_lpf__i = 0; _three_phase_meter1_pll_lpf_lpf__i < 2; _three_phase_meter1_pll_lpf_lpf__i++) {
        _three_phase_meter1_pll_lpf_lpf__states[_three_phase_meter1_pll_lpf_lpf__i] = 0;
    }
    X_UnInt32 _three_phase_meter2_pll_lpf_lpf__i;
    for (_three_phase_meter2_pll_lpf_lpf__i = 0; _three_phase_meter2_pll_lpf_lpf__i < 2; _three_phase_meter2_pll_lpf_lpf__i++) {
        _three_phase_meter2_pll_lpf_lpf__states[_three_phase_meter2_pll_lpf_lpf__i] = 0;
    }
    X_UnInt32 _three_phase_meter3_pll_lpf_lpf__i;
    for (_three_phase_meter3_pll_lpf_lpf__i = 0; _three_phase_meter3_pll_lpf_lpf__i < 2; _three_phase_meter3_pll_lpf_lpf__i++) {
        _three_phase_meter3_pll_lpf_lpf__states[_three_phase_meter3_pll_lpf_lpf__i] = 0;
    }
    //@cmp.init.block.end
}


// Dll function pointers and dll reload function
#if defined(_WIN64)
// Define method for reloading dll functions
void ReloadDllFunctions_user_sp_cpu0_dev0(void) {
    // Load each library and setup function pointers
}

void FreeDllFunctions_user_sp_cpu0_dev0(void) {
}

#else
// Define method for reloading dll functions
void ReloadDllFunctions_user_sp_cpu0_dev0(void) {
    // Load each library and setup function pointers
}

void FreeDllFunctions_user_sp_cpu0_dev0(void) {
}
#endif

void load_fmi_libraries_user_sp_cpu0_dev0(void) {
#if defined(_WIN64)
#else
#endif
}


void ReInit_sp_scope_user_sp_cpu0_dev0() {
    // initialise SP Scope buffer pointer
}
// generated using template: common_timer_counter_handler.template-------------------------

/*****************************************************************************************/
/**
* This function is the handler which performs processing for the timer counter.
* It is called from an interrupt context such that the amount of processing
* performed should be minimized.  It is called when the timer counter expires
* if interrupts are enabled.
*
*
* @param    None
*
* @return   None
*
* @note     None
*
*****************************************************************************************/

void TimerCounterHandler_0_user_sp_cpu0_dev0() {
#if DEBUG_MODE
    printf("\n\rTimerCounterHandler_0");
#endif
    //////////////////////////////////////////////////////////////////////////
    // Set tunable parameters
    //////////////////////////////////////////////////////////////////////////
    // Generated from the component: Three-phase Meter1.zero
    // Generated from the component: Three-phase Meter2.zero
    // Generated from the component: Three-phase Meter3.zero
//////////////////////////////////////////////////////////////////////////
    // Output block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.out.block.start
    // Generated from the component: Three-phase Meter1.IA.Ia1
    _three_phase_meter1_ia_ia1__out = (HIL_InFloat(0xc80000 + 0x51));
    // Generated from the component: Three-phase Meter1.IB.Ia1
    _three_phase_meter1_ib_ia1__out = (HIL_InFloat(0xc80000 + 0x52));
    // Generated from the component: Three-phase Meter1.IC.Ia1
    _three_phase_meter1_ic_ia1__out = (HIL_InFloat(0xc80000 + 0x53));
    // Generated from the component: Three-phase Meter1.PLL.PID.Integrator1
    _three_phase_meter1_pll_pid_integrator1__out = _three_phase_meter1_pll_pid_integrator1__state;
    // Generated from the component: Three-phase Meter1.PLL.PID.Integrator2
    _three_phase_meter1_pll_pid_integrator2__out = _three_phase_meter1_pll_pid_integrator2__state;
    // Generated from the component: Three-phase Meter1.PLL.Unit Delay1
    _three_phase_meter1_pll_unit_delay1__out = _three_phase_meter1_pll_unit_delay1__state;
    // Generated from the component: Three-phase Meter1.PLL.to_Hz
    _three_phase_meter1_pll_to_hz__out = 0.15915494309189535 * _three_phase_meter1_pll_lpf_lpf__out;
    // Generated from the component: Three-phase Meter1.VAB.Va1
    _three_phase_meter1_vab_va1__out = (HIL_InFloat(0xc80000 + 0x39));
    // Generated from the component: Three-phase Meter1.VAn.Va1
    _three_phase_meter1_van_va1__out = (HIL_InFloat(0xc80000 + 0x3a));
    // Generated from the component: Three-phase Meter1.VBC.Va1
    _three_phase_meter1_vbc_va1__out = (HIL_InFloat(0xc80000 + 0x3b));
    // Generated from the component: Three-phase Meter1.VBn.Va1
    _three_phase_meter1_vbn_va1__out = (HIL_InFloat(0xc80000 + 0x3c));
    // Generated from the component: Three-phase Meter1.VCA.Va1
    _three_phase_meter1_vca_va1__out = (HIL_InFloat(0xc80000 + 0x3d));
    // Generated from the component: Three-phase Meter1.VCn.Va1
    _three_phase_meter1_vcn_va1__out = (HIL_InFloat(0xc80000 + 0x3e));
    // Generated from the component: Three-phase Meter2.IA.Ia1
    _three_phase_meter2_ia_ia1__out = (HIL_InFloat(0xc80000 + 0x54));
    // Generated from the component: Three-phase Meter2.IB.Ia1
    _three_phase_meter2_ib_ia1__out = (HIL_InFloat(0xc80000 + 0x55));
    // Generated from the component: Three-phase Meter2.IC.Ia1
    _three_phase_meter2_ic_ia1__out = (HIL_InFloat(0xc80000 + 0x56));
    // Generated from the component: Three-phase Meter2.PLL.PID.Integrator1
    _three_phase_meter2_pll_pid_integrator1__out = _three_phase_meter2_pll_pid_integrator1__state;
    // Generated from the component: Three-phase Meter2.PLL.PID.Integrator2
    _three_phase_meter2_pll_pid_integrator2__out = _three_phase_meter2_pll_pid_integrator2__state;
    // Generated from the component: Three-phase Meter2.PLL.Unit Delay1
    _three_phase_meter2_pll_unit_delay1__out = _three_phase_meter2_pll_unit_delay1__state;
    // Generated from the component: Three-phase Meter2.PLL.to_Hz
    _three_phase_meter2_pll_to_hz__out = 0.15915494309189535 * _three_phase_meter2_pll_lpf_lpf__out;
    // Generated from the component: Three-phase Meter2.VAn.Va1
    _three_phase_meter2_van_va1__out = (HIL_InFloat(0xc80000 + 0x3f));
    // Generated from the component: Three-phase Meter2.VBn.Va1
    _three_phase_meter2_vbn_va1__out = (HIL_InFloat(0xc80000 + 0x40));
    // Generated from the component: Three-phase Meter2.VCn.Va1
    _three_phase_meter2_vcn_va1__out = (HIL_InFloat(0xc80000 + 0x41));
    // Generated from the component: Three-phase Meter3.IA.Ia1
    _three_phase_meter3_ia_ia1__out = (HIL_InFloat(0xc80000 + 0x57));
    // Generated from the component: Three-phase Meter3.IB.Ia1
    _three_phase_meter3_ib_ia1__out = (HIL_InFloat(0xc80000 + 0x58));
    // Generated from the component: Three-phase Meter3.IC.Ia1
    _three_phase_meter3_ic_ia1__out = (HIL_InFloat(0xc80000 + 0x59));
    // Generated from the component: Three-phase Meter3.PLL.PID.Integrator1
    _three_phase_meter3_pll_pid_integrator1__out = _three_phase_meter3_pll_pid_integrator1__state;
    // Generated from the component: Three-phase Meter3.PLL.PID.Integrator2
    _three_phase_meter3_pll_pid_integrator2__out = _three_phase_meter3_pll_pid_integrator2__state;
    // Generated from the component: Three-phase Meter3.PLL.Unit Delay1
    _three_phase_meter3_pll_unit_delay1__out = _three_phase_meter3_pll_unit_delay1__state;
    // Generated from the component: Three-phase Meter3.PLL.to_Hz
    _three_phase_meter3_pll_to_hz__out = 0.15915494309189535 * _three_phase_meter3_pll_lpf_lpf__out;
    // Generated from the component: Three-phase Meter3.VAn.Va1
    _three_phase_meter3_van_va1__out = (HIL_InFloat(0xc80000 + 0x42));
    // Generated from the component: Three-phase Meter3.VBn.Va1
    _three_phase_meter3_vbn_va1__out = (HIL_InFloat(0xc80000 + 0x43));
    // Generated from the component: Three-phase Meter3.VCn.Va1
    _three_phase_meter3_vcn_va1__out = (HIL_InFloat(0xc80000 + 0x44));
    // Generated from the component: Three-phase Meter1.PLL.sin
    _three_phase_meter1_pll_sin__out = sin(_three_phase_meter1_pll_unit_delay1__out);
    // Generated from the component: Three-phase Meter1.TRMwt
    // Generated from the component: Three-phase Meter1.Freq
    HIL_OutAO(0x4000, (float)_three_phase_meter1_pll_to_hz__out);
    // Generated from the component: Three-phase Meter1.measSM.mode_and_dFract
    _three_phase_meter1_meassm_mode_and_dfract__Freq = _three_phase_meter1_pll_to_hz__out;
    _three_phase_meter1_meassm_mode_and_dfract__freqAbs = fabs(_three_phase_meter1_meassm_mode_and_dfract__Freq);
    if (_three_phase_meter1_meassm_mode_and_dfract__reset == 1) {
        _three_phase_meter1_meassm_mode_and_dfract__mode = 1;
        _three_phase_meter1_meassm_mode_and_dfract__Tfract = 0.0;
        _three_phase_meter1_meassm_mode_and_dfract__cycle_counter = 0;
        _three_phase_meter1_meassm_mode_and_dfract__reset = 0;
    }
    else if (_three_phase_meter1_meassm_mode_and_dfract__freqAbs < 1.0) {
        _three_phase_meter1_meassm_mode_and_dfract__mode = 2;
        if (_three_phase_meter1_meassm_mode_and_dfract__Tfract > 0.0) {
            _three_phase_meter1_meassm_mode_and_dfract__reset = 1;
        }
    }
    else if ((_three_phase_meter1_meassm_mode_and_dfract__Tfract < 1.0) && (_three_phase_meter1_meassm_mode_and_dfract__freqAbs < _three_phase_meter1_meassm_mode_and_dfract__fMax)) {
        _three_phase_meter1_meassm_mode_and_dfract__dFract = 0.0001 * _three_phase_meter1_meassm_mode_and_dfract__freqAbs;
        _three_phase_meter1_meassm_mode_and_dfract__Tfract += _three_phase_meter1_meassm_mode_and_dfract__dFract;
        if (_three_phase_meter1_meassm_mode_and_dfract__Tfract >= 1.0) {
            _three_phase_meter1_meassm_mode_and_dfract__cycle_counter += 1;
            if (_three_phase_meter1_meassm_mode_and_dfract__cycle_counter >= 1) {
                _three_phase_meter1_meassm_mode_and_dfract__dFract = 1.0 - (_three_phase_meter1_meassm_mode_and_dfract__Tfract - _three_phase_meter1_meassm_mode_and_dfract__dFract);
            }
            else {
                _three_phase_meter1_meassm_mode_and_dfract__Tfract -= 1.0;
            }
        }
        _three_phase_meter1_meassm_mode_and_dfract__dFract /= 1;
        _three_phase_meter1_meassm_mode_and_dfract__mode = 3;
        if (_three_phase_meter1_meassm_mode_and_dfract__Tfract < 0.25) {
            _three_phase_meter1_meassm_mode_and_dfract__submode = 1;
        }
        else if (_three_phase_meter1_meassm_mode_and_dfract__Tfract < 0.5) {
            _three_phase_meter1_meassm_mode_and_dfract__submode = 2;
        }
        else if (_three_phase_meter1_meassm_mode_and_dfract__Tfract < 0.75) {
            _three_phase_meter1_meassm_mode_and_dfract__submode = 3;
        }
        else {
            _three_phase_meter1_meassm_mode_and_dfract__submode = 4;
        }
    }
    else if (_three_phase_meter1_meassm_mode_and_dfract__Tfract >= 1.0) {
        _three_phase_meter1_meassm_mode_and_dfract__mode = 4;
        _three_phase_meter1_meassm_mode_and_dfract__reset = 1;
    }
    else {
        _three_phase_meter1_meassm_mode_and_dfract__mode = 5;
        _three_phase_meter1_meassm_mode_and_dfract__reset = 1;
    }
    // Generated from the component: Three-phase Meter1.PLL.abc to dq.abc to alpha beta
    _three_phase_meter1_pll_abc_to_dq_abc_to_alpha_beta__alpha = (2.0 * _three_phase_meter1_van_va1__out - _three_phase_meter1_vbn_va1__out - _three_phase_meter1_vcn_va1__out) * 0.3333333333333333;
    _three_phase_meter1_pll_abc_to_dq_abc_to_alpha_beta__beta = (_three_phase_meter1_vbn_va1__out - _three_phase_meter1_vcn_va1__out) * 0.5773502691896258;
    _three_phase_meter1_pll_abc_to_dq_abc_to_alpha_beta__gamma = (_three_phase_meter1_van_va1__out + _three_phase_meter1_vbn_va1__out + _three_phase_meter1_vcn_va1__out) * 0.3333333333333333;
    // Generated from the component: Three-phase Meter1.IN
    // Generated from the component: Three-phase Meter1.IN_RMS
    // Generated from the component: Three-phase Meter1.I_RMS
    // Generated from the component: Three-phase Meter1.VAB_RMS
    // Generated from the component: Three-phase Meter1.VBC_RMS
    // Generated from the component: Three-phase Meter1.VCA_RMS
    // Generated from the component: Three-phase Meter1.VLL_RMS
    // Generated from the component: Three-phase Meter1.VLn_RMS
    // Generated from the component: Three-phase Meter1.VN
    // Generated from the component: Three-phase Meter1.VN_RMS
    // Generated from the component: Three-phase Meter2.PLL.sin
    _three_phase_meter2_pll_sin__out = sin(_three_phase_meter2_pll_unit_delay1__out);
    // Generated from the component: Three-phase Meter2.TRMwt
    // Generated from the component: Three-phase Meter2.Freq
    HIL_OutAO(0x4017, (float)_three_phase_meter2_pll_to_hz__out);
    // Generated from the component: Three-phase Meter2.measSM.mode_and_dFract
    _three_phase_meter2_meassm_mode_and_dfract__Freq = _three_phase_meter2_pll_to_hz__out;
    _three_phase_meter2_meassm_mode_and_dfract__freqAbs = fabs(_three_phase_meter2_meassm_mode_and_dfract__Freq);
    if (_three_phase_meter2_meassm_mode_and_dfract__reset == 1) {
        _three_phase_meter2_meassm_mode_and_dfract__mode = 1;
        _three_phase_meter2_meassm_mode_and_dfract__Tfract = 0.0;
        _three_phase_meter2_meassm_mode_and_dfract__cycle_counter = 0;
        _three_phase_meter2_meassm_mode_and_dfract__reset = 0;
    }
    else if (_three_phase_meter2_meassm_mode_and_dfract__freqAbs < 1.0) {
        _three_phase_meter2_meassm_mode_and_dfract__mode = 2;
        if (_three_phase_meter2_meassm_mode_and_dfract__Tfract > 0.0) {
            _three_phase_meter2_meassm_mode_and_dfract__reset = 1;
        }
    }
    else if ((_three_phase_meter2_meassm_mode_and_dfract__Tfract < 1.0) && (_three_phase_meter2_meassm_mode_and_dfract__freqAbs < _three_phase_meter2_meassm_mode_and_dfract__fMax)) {
        _three_phase_meter2_meassm_mode_and_dfract__dFract = 0.0001 * _three_phase_meter2_meassm_mode_and_dfract__freqAbs;
        _three_phase_meter2_meassm_mode_and_dfract__Tfract += _three_phase_meter2_meassm_mode_and_dfract__dFract;
        if (_three_phase_meter2_meassm_mode_and_dfract__Tfract >= 1.0) {
            _three_phase_meter2_meassm_mode_and_dfract__cycle_counter += 1;
            if (_three_phase_meter2_meassm_mode_and_dfract__cycle_counter >= 1) {
                _three_phase_meter2_meassm_mode_and_dfract__dFract = 1.0 - (_three_phase_meter2_meassm_mode_and_dfract__Tfract - _three_phase_meter2_meassm_mode_and_dfract__dFract);
            }
            else {
                _three_phase_meter2_meassm_mode_and_dfract__Tfract -= 1.0;
            }
        }
        _three_phase_meter2_meassm_mode_and_dfract__dFract /= 1;
        _three_phase_meter2_meassm_mode_and_dfract__mode = 3;
        if (_three_phase_meter2_meassm_mode_and_dfract__Tfract < 0.25) {
            _three_phase_meter2_meassm_mode_and_dfract__submode = 1;
        }
        else if (_three_phase_meter2_meassm_mode_and_dfract__Tfract < 0.5) {
            _three_phase_meter2_meassm_mode_and_dfract__submode = 2;
        }
        else if (_three_phase_meter2_meassm_mode_and_dfract__Tfract < 0.75) {
            _three_phase_meter2_meassm_mode_and_dfract__submode = 3;
        }
        else {
            _three_phase_meter2_meassm_mode_and_dfract__submode = 4;
        }
    }
    else if (_three_phase_meter2_meassm_mode_and_dfract__Tfract >= 1.0) {
        _three_phase_meter2_meassm_mode_and_dfract__mode = 4;
        _three_phase_meter2_meassm_mode_and_dfract__reset = 1;
    }
    else {
        _three_phase_meter2_meassm_mode_and_dfract__mode = 5;
        _three_phase_meter2_meassm_mode_and_dfract__reset = 1;
    }
    // Generated from the component: Three-phase Meter2.PLL.abc to dq.abc to alpha beta
    _three_phase_meter2_pll_abc_to_dq_abc_to_alpha_beta__alpha = (2.0 * _three_phase_meter2_van_va1__out - _three_phase_meter2_vbn_va1__out - _three_phase_meter2_vcn_va1__out) * 0.3333333333333333;
    _three_phase_meter2_pll_abc_to_dq_abc_to_alpha_beta__beta = (_three_phase_meter2_vbn_va1__out - _three_phase_meter2_vcn_va1__out) * 0.5773502691896258;
    _three_phase_meter2_pll_abc_to_dq_abc_to_alpha_beta__gamma = (_three_phase_meter2_van_va1__out + _three_phase_meter2_vbn_va1__out + _three_phase_meter2_vcn_va1__out) * 0.3333333333333333;
    // Generated from the component: Three-phase Meter2.IN
    // Generated from the component: Three-phase Meter2.IN_RMS
    // Generated from the component: Three-phase Meter2.I_RMS
    // Generated from the component: Three-phase Meter2.VAB_RMS
    // Generated from the component: Three-phase Meter2.VBC_RMS
    // Generated from the component: Three-phase Meter2.VCA_RMS
    // Generated from the component: Three-phase Meter2.VLL_RMS
    // Generated from the component: Three-phase Meter2.VLn_RMS
    // Generated from the component: Three-phase Meter2.VN
    // Generated from the component: Three-phase Meter2.VN_RMS
    // Generated from the component: Three-phase Meter3.PLL.sin
    _three_phase_meter3_pll_sin__out = sin(_three_phase_meter3_pll_unit_delay1__out);
    // Generated from the component: Three-phase Meter3.TRMwt
    // Generated from the component: Three-phase Meter3.Freq
    HIL_OutAO(0x402e, (float)_three_phase_meter3_pll_to_hz__out);
    // Generated from the component: Three-phase Meter3.measSM.mode_and_dFract
    _three_phase_meter3_meassm_mode_and_dfract__Freq = _three_phase_meter3_pll_to_hz__out;
    _three_phase_meter3_meassm_mode_and_dfract__freqAbs = fabs(_three_phase_meter3_meassm_mode_and_dfract__Freq);
    if (_three_phase_meter3_meassm_mode_and_dfract__reset == 1) {
        _three_phase_meter3_meassm_mode_and_dfract__mode = 1;
        _three_phase_meter3_meassm_mode_and_dfract__Tfract = 0.0;
        _three_phase_meter3_meassm_mode_and_dfract__cycle_counter = 0;
        _three_phase_meter3_meassm_mode_and_dfract__reset = 0;
    }
    else if (_three_phase_meter3_meassm_mode_and_dfract__freqAbs < 1.0) {
        _three_phase_meter3_meassm_mode_and_dfract__mode = 2;
        if (_three_phase_meter3_meassm_mode_and_dfract__Tfract > 0.0) {
            _three_phase_meter3_meassm_mode_and_dfract__reset = 1;
        }
    }
    else if ((_three_phase_meter3_meassm_mode_and_dfract__Tfract < 1.0) && (_three_phase_meter3_meassm_mode_and_dfract__freqAbs < _three_phase_meter3_meassm_mode_and_dfract__fMax)) {
        _three_phase_meter3_meassm_mode_and_dfract__dFract = 0.0001 * _three_phase_meter3_meassm_mode_and_dfract__freqAbs;
        _three_phase_meter3_meassm_mode_and_dfract__Tfract += _three_phase_meter3_meassm_mode_and_dfract__dFract;
        if (_three_phase_meter3_meassm_mode_and_dfract__Tfract >= 1.0) {
            _three_phase_meter3_meassm_mode_and_dfract__cycle_counter += 1;
            if (_three_phase_meter3_meassm_mode_and_dfract__cycle_counter >= 1) {
                _three_phase_meter3_meassm_mode_and_dfract__dFract = 1.0 - (_three_phase_meter3_meassm_mode_and_dfract__Tfract - _three_phase_meter3_meassm_mode_and_dfract__dFract);
            }
            else {
                _three_phase_meter3_meassm_mode_and_dfract__Tfract -= 1.0;
            }
        }
        _three_phase_meter3_meassm_mode_and_dfract__dFract /= 1;
        _three_phase_meter3_meassm_mode_and_dfract__mode = 3;
        if (_three_phase_meter3_meassm_mode_and_dfract__Tfract < 0.25) {
            _three_phase_meter3_meassm_mode_and_dfract__submode = 1;
        }
        else if (_three_phase_meter3_meassm_mode_and_dfract__Tfract < 0.5) {
            _three_phase_meter3_meassm_mode_and_dfract__submode = 2;
        }
        else if (_three_phase_meter3_meassm_mode_and_dfract__Tfract < 0.75) {
            _three_phase_meter3_meassm_mode_and_dfract__submode = 3;
        }
        else {
            _three_phase_meter3_meassm_mode_and_dfract__submode = 4;
        }
    }
    else if (_three_phase_meter3_meassm_mode_and_dfract__Tfract >= 1.0) {
        _three_phase_meter3_meassm_mode_and_dfract__mode = 4;
        _three_phase_meter3_meassm_mode_and_dfract__reset = 1;
    }
    else {
        _three_phase_meter3_meassm_mode_and_dfract__mode = 5;
        _three_phase_meter3_meassm_mode_and_dfract__reset = 1;
    }
    // Generated from the component: Three-phase Meter3.PLL.abc to dq.abc to alpha beta
    _three_phase_meter3_pll_abc_to_dq_abc_to_alpha_beta__alpha = (2.0 * _three_phase_meter3_van_va1__out - _three_phase_meter3_vbn_va1__out - _three_phase_meter3_vcn_va1__out) * 0.3333333333333333;
    _three_phase_meter3_pll_abc_to_dq_abc_to_alpha_beta__beta = (_three_phase_meter3_vbn_va1__out - _three_phase_meter3_vcn_va1__out) * 0.5773502691896258;
    _three_phase_meter3_pll_abc_to_dq_abc_to_alpha_beta__gamma = (_three_phase_meter3_van_va1__out + _three_phase_meter3_vbn_va1__out + _three_phase_meter3_vcn_va1__out) * 0.3333333333333333;
    // Generated from the component: Three-phase Meter3.IN
    // Generated from the component: Three-phase Meter3.IN_RMS
    // Generated from the component: Three-phase Meter3.I_RMS
    // Generated from the component: Three-phase Meter3.VAB_RMS
    // Generated from the component: Three-phase Meter3.VBC_RMS
    // Generated from the component: Three-phase Meter3.VCA_RMS
    // Generated from the component: Three-phase Meter3.VLL_RMS
    // Generated from the component: Three-phase Meter3.VLn_RMS
    // Generated from the component: Three-phase Meter3.VN
    // Generated from the component: Three-phase Meter3.VN_RMS
    // Generated from the component: Three-phase Meter1.TRMsin
    // Generated from the component: Three-phase Meter1.I_RMS_calc.RMS
    _three_phase_meter1_i_rms_calc_rms__IN1 = _three_phase_meter1_ia_ia1__out;
    _three_phase_meter1_i_rms_calc_rms__IN2 = _three_phase_meter1_ib_ia1__out;
    _three_phase_meter1_i_rms_calc_rms__IN3 = _three_phase_meter1_ic_ia1__out;
    _three_phase_meter1_i_rms_calc_rms__dFract = _three_phase_meter1_meassm_mode_and_dfract__dFract;
    _three_phase_meter1_i_rms_calc_rms__mode = _three_phase_meter1_meassm_mode_and_dfract__mode;
    switch (_three_phase_meter1_i_rms_calc_rms__mode) {
    case 1:
        _three_phase_meter1_i_rms_calc_rms__rmsSum1 = 0.0;
        _three_phase_meter1_i_rms_calc_rms__rmsSum2 = 0.0;
        _three_phase_meter1_i_rms_calc_rms__rmsSum3 = 0.0;
        break ;
    case 2:
        _three_phase_meter1_i_rms_calc_rms__RMS1 = _three_phase_meter1_i_rms_calc_rms__IN1;
        _three_phase_meter1_i_rms_calc_rms__RMS2 = _three_phase_meter1_i_rms_calc_rms__IN2;
        _three_phase_meter1_i_rms_calc_rms__RMS3 = _three_phase_meter1_i_rms_calc_rms__IN3;
        break ;
    case 3:
        _three_phase_meter1_i_rms_calc_rms__rmsSum1 += _three_phase_meter1_i_rms_calc_rms__dFract * (_three_phase_meter1_i_rms_calc_rms__IN1 * _three_phase_meter1_i_rms_calc_rms__IN1);
        _three_phase_meter1_i_rms_calc_rms__rmsSum2 += _three_phase_meter1_i_rms_calc_rms__dFract * (_three_phase_meter1_i_rms_calc_rms__IN2 * _three_phase_meter1_i_rms_calc_rms__IN2);
        _three_phase_meter1_i_rms_calc_rms__rmsSum3 += _three_phase_meter1_i_rms_calc_rms__dFract * (_three_phase_meter1_i_rms_calc_rms__IN3 * _three_phase_meter1_i_rms_calc_rms__IN3);
        break ;
    case 4:
        _three_phase_meter1_i_rms_calc_rms__RMS1 = sqrt(_three_phase_meter1_i_rms_calc_rms__rmsSum1);
        _three_phase_meter1_i_rms_calc_rms__RMS2 = sqrt(_three_phase_meter1_i_rms_calc_rms__rmsSum2);
        _three_phase_meter1_i_rms_calc_rms__RMS3 = sqrt(_three_phase_meter1_i_rms_calc_rms__rmsSum3);
        break ;
    case 5:
        _three_phase_meter1_i_rms_calc_rms__RMS1 = fabs(_three_phase_meter1_i_rms_calc_rms__IN1);
        _three_phase_meter1_i_rms_calc_rms__RMS2 = fabs(_three_phase_meter1_i_rms_calc_rms__IN2);
        _three_phase_meter1_i_rms_calc_rms__RMS3 = fabs(_three_phase_meter1_i_rms_calc_rms__IN3);
        break ;
    }
    // Generated from the component: Three-phase Meter1.VLn_RMS_calc.RMS
    _three_phase_meter1_vln_rms_calc_rms__IN1 = _three_phase_meter1_van_va1__out;
    _three_phase_meter1_vln_rms_calc_rms__IN2 = _three_phase_meter1_vbn_va1__out;
    _three_phase_meter1_vln_rms_calc_rms__IN3 = _three_phase_meter1_vcn_va1__out;
    _three_phase_meter1_vln_rms_calc_rms__dFract = _three_phase_meter1_meassm_mode_and_dfract__dFract;
    _three_phase_meter1_vln_rms_calc_rms__mode = _three_phase_meter1_meassm_mode_and_dfract__mode;
    switch (_three_phase_meter1_vln_rms_calc_rms__mode) {
    case 1:
        _three_phase_meter1_vln_rms_calc_rms__rmsSum1 = 0.0;
        _three_phase_meter1_vln_rms_calc_rms__rmsSum2 = 0.0;
        _three_phase_meter1_vln_rms_calc_rms__rmsSum3 = 0.0;
        break ;
    case 2:
        _three_phase_meter1_vln_rms_calc_rms__RMS1 = _three_phase_meter1_vln_rms_calc_rms__IN1;
        _three_phase_meter1_vln_rms_calc_rms__RMS2 = _three_phase_meter1_vln_rms_calc_rms__IN2;
        _three_phase_meter1_vln_rms_calc_rms__RMS3 = _three_phase_meter1_vln_rms_calc_rms__IN3;
        break ;
    case 3:
        _three_phase_meter1_vln_rms_calc_rms__rmsSum1 += _three_phase_meter1_vln_rms_calc_rms__dFract * (_three_phase_meter1_vln_rms_calc_rms__IN1 * _three_phase_meter1_vln_rms_calc_rms__IN1);
        _three_phase_meter1_vln_rms_calc_rms__rmsSum2 += _three_phase_meter1_vln_rms_calc_rms__dFract * (_three_phase_meter1_vln_rms_calc_rms__IN2 * _three_phase_meter1_vln_rms_calc_rms__IN2);
        _three_phase_meter1_vln_rms_calc_rms__rmsSum3 += _three_phase_meter1_vln_rms_calc_rms__dFract * (_three_phase_meter1_vln_rms_calc_rms__IN3 * _three_phase_meter1_vln_rms_calc_rms__IN3);
        break ;
    case 4:
        _three_phase_meter1_vln_rms_calc_rms__RMS1 = sqrt(_three_phase_meter1_vln_rms_calc_rms__rmsSum1);
        _three_phase_meter1_vln_rms_calc_rms__RMS2 = sqrt(_three_phase_meter1_vln_rms_calc_rms__rmsSum2);
        _three_phase_meter1_vln_rms_calc_rms__RMS3 = sqrt(_three_phase_meter1_vln_rms_calc_rms__rmsSum3);
        break ;
    case 5:
        _three_phase_meter1_vln_rms_calc_rms__RMS1 = fabs(_three_phase_meter1_vln_rms_calc_rms__IN1);
        _three_phase_meter1_vln_rms_calc_rms__RMS2 = fabs(_three_phase_meter1_vln_rms_calc_rms__IN2);
        _three_phase_meter1_vln_rms_calc_rms__RMS3 = fabs(_three_phase_meter1_vln_rms_calc_rms__IN3);
        break ;
    }
    // Generated from the component: Three-phase Meter1.PLL.abc to dq.alpha beta to dq
    _three_phase_meter1_pll_abc_to_dq_alpha_beta_to_dq__k1 = cos(_three_phase_meter1_pll_unit_delay1__out);
    _three_phase_meter1_pll_abc_to_dq_alpha_beta_to_dq__k2 = sin(_three_phase_meter1_pll_unit_delay1__out);
    _three_phase_meter1_pll_abc_to_dq_alpha_beta_to_dq__d = _three_phase_meter1_pll_abc_to_dq_alpha_beta_to_dq__k2 * _three_phase_meter1_pll_abc_to_dq_abc_to_alpha_beta__alpha - _three_phase_meter1_pll_abc_to_dq_alpha_beta_to_dq__k1 * _three_phase_meter1_pll_abc_to_dq_abc_to_alpha_beta__beta;
    _three_phase_meter1_pll_abc_to_dq_alpha_beta_to_dq__q = _three_phase_meter1_pll_abc_to_dq_alpha_beta_to_dq__k1 * _three_phase_meter1_pll_abc_to_dq_abc_to_alpha_beta__alpha + _three_phase_meter1_pll_abc_to_dq_alpha_beta_to_dq__k2 * _three_phase_meter1_pll_abc_to_dq_abc_to_alpha_beta__beta;
    // Generated from the component: Three-phase Meter1.TRMz
    // Generated from the component: Three-phase Meter2.TRMsin
    // Generated from the component: Three-phase Meter2.I_RMS_calc.RMS
    _three_phase_meter2_i_rms_calc_rms__IN1 = _three_phase_meter2_ia_ia1__out;
    _three_phase_meter2_i_rms_calc_rms__IN2 = _three_phase_meter2_ib_ia1__out;
    _three_phase_meter2_i_rms_calc_rms__IN3 = _three_phase_meter2_ic_ia1__out;
    _three_phase_meter2_i_rms_calc_rms__dFract = _three_phase_meter2_meassm_mode_and_dfract__dFract;
    _three_phase_meter2_i_rms_calc_rms__mode = _three_phase_meter2_meassm_mode_and_dfract__mode;
    switch (_three_phase_meter2_i_rms_calc_rms__mode) {
    case 1:
        _three_phase_meter2_i_rms_calc_rms__rmsSum1 = 0.0;
        _three_phase_meter2_i_rms_calc_rms__rmsSum2 = 0.0;
        _three_phase_meter2_i_rms_calc_rms__rmsSum3 = 0.0;
        break ;
    case 2:
        _three_phase_meter2_i_rms_calc_rms__RMS1 = _three_phase_meter2_i_rms_calc_rms__IN1;
        _three_phase_meter2_i_rms_calc_rms__RMS2 = _three_phase_meter2_i_rms_calc_rms__IN2;
        _three_phase_meter2_i_rms_calc_rms__RMS3 = _three_phase_meter2_i_rms_calc_rms__IN3;
        break ;
    case 3:
        _three_phase_meter2_i_rms_calc_rms__rmsSum1 += _three_phase_meter2_i_rms_calc_rms__dFract * (_three_phase_meter2_i_rms_calc_rms__IN1 * _three_phase_meter2_i_rms_calc_rms__IN1);
        _three_phase_meter2_i_rms_calc_rms__rmsSum2 += _three_phase_meter2_i_rms_calc_rms__dFract * (_three_phase_meter2_i_rms_calc_rms__IN2 * _three_phase_meter2_i_rms_calc_rms__IN2);
        _three_phase_meter2_i_rms_calc_rms__rmsSum3 += _three_phase_meter2_i_rms_calc_rms__dFract * (_three_phase_meter2_i_rms_calc_rms__IN3 * _three_phase_meter2_i_rms_calc_rms__IN3);
        break ;
    case 4:
        _three_phase_meter2_i_rms_calc_rms__RMS1 = sqrt(_three_phase_meter2_i_rms_calc_rms__rmsSum1);
        _three_phase_meter2_i_rms_calc_rms__RMS2 = sqrt(_three_phase_meter2_i_rms_calc_rms__rmsSum2);
        _three_phase_meter2_i_rms_calc_rms__RMS3 = sqrt(_three_phase_meter2_i_rms_calc_rms__rmsSum3);
        break ;
    case 5:
        _three_phase_meter2_i_rms_calc_rms__RMS1 = fabs(_three_phase_meter2_i_rms_calc_rms__IN1);
        _three_phase_meter2_i_rms_calc_rms__RMS2 = fabs(_three_phase_meter2_i_rms_calc_rms__IN2);
        _three_phase_meter2_i_rms_calc_rms__RMS3 = fabs(_three_phase_meter2_i_rms_calc_rms__IN3);
        break ;
    }
    // Generated from the component: Three-phase Meter2.VLn_RMS_calc.RMS
    _three_phase_meter2_vln_rms_calc_rms__IN1 = _three_phase_meter2_van_va1__out;
    _three_phase_meter2_vln_rms_calc_rms__IN2 = _three_phase_meter2_vbn_va1__out;
    _three_phase_meter2_vln_rms_calc_rms__IN3 = _three_phase_meter2_vcn_va1__out;
    _three_phase_meter2_vln_rms_calc_rms__dFract = _three_phase_meter2_meassm_mode_and_dfract__dFract;
    _three_phase_meter2_vln_rms_calc_rms__mode = _three_phase_meter2_meassm_mode_and_dfract__mode;
    switch (_three_phase_meter2_vln_rms_calc_rms__mode) {
    case 1:
        _three_phase_meter2_vln_rms_calc_rms__rmsSum1 = 0.0;
        _three_phase_meter2_vln_rms_calc_rms__rmsSum2 = 0.0;
        _three_phase_meter2_vln_rms_calc_rms__rmsSum3 = 0.0;
        break ;
    case 2:
        _three_phase_meter2_vln_rms_calc_rms__RMS1 = _three_phase_meter2_vln_rms_calc_rms__IN1;
        _three_phase_meter2_vln_rms_calc_rms__RMS2 = _three_phase_meter2_vln_rms_calc_rms__IN2;
        _three_phase_meter2_vln_rms_calc_rms__RMS3 = _three_phase_meter2_vln_rms_calc_rms__IN3;
        break ;
    case 3:
        _three_phase_meter2_vln_rms_calc_rms__rmsSum1 += _three_phase_meter2_vln_rms_calc_rms__dFract * (_three_phase_meter2_vln_rms_calc_rms__IN1 * _three_phase_meter2_vln_rms_calc_rms__IN1);
        _three_phase_meter2_vln_rms_calc_rms__rmsSum2 += _three_phase_meter2_vln_rms_calc_rms__dFract * (_three_phase_meter2_vln_rms_calc_rms__IN2 * _three_phase_meter2_vln_rms_calc_rms__IN2);
        _three_phase_meter2_vln_rms_calc_rms__rmsSum3 += _three_phase_meter2_vln_rms_calc_rms__dFract * (_three_phase_meter2_vln_rms_calc_rms__IN3 * _three_phase_meter2_vln_rms_calc_rms__IN3);
        break ;
    case 4:
        _three_phase_meter2_vln_rms_calc_rms__RMS1 = sqrt(_three_phase_meter2_vln_rms_calc_rms__rmsSum1);
        _three_phase_meter2_vln_rms_calc_rms__RMS2 = sqrt(_three_phase_meter2_vln_rms_calc_rms__rmsSum2);
        _three_phase_meter2_vln_rms_calc_rms__RMS3 = sqrt(_three_phase_meter2_vln_rms_calc_rms__rmsSum3);
        break ;
    case 5:
        _three_phase_meter2_vln_rms_calc_rms__RMS1 = fabs(_three_phase_meter2_vln_rms_calc_rms__IN1);
        _three_phase_meter2_vln_rms_calc_rms__RMS2 = fabs(_three_phase_meter2_vln_rms_calc_rms__IN2);
        _three_phase_meter2_vln_rms_calc_rms__RMS3 = fabs(_three_phase_meter2_vln_rms_calc_rms__IN3);
        break ;
    }
    // Generated from the component: Three-phase Meter2.PLL.abc to dq.alpha beta to dq
    _three_phase_meter2_pll_abc_to_dq_alpha_beta_to_dq__k1 = cos(_three_phase_meter2_pll_unit_delay1__out);
    _three_phase_meter2_pll_abc_to_dq_alpha_beta_to_dq__k2 = sin(_three_phase_meter2_pll_unit_delay1__out);
    _three_phase_meter2_pll_abc_to_dq_alpha_beta_to_dq__d = _three_phase_meter2_pll_abc_to_dq_alpha_beta_to_dq__k2 * _three_phase_meter2_pll_abc_to_dq_abc_to_alpha_beta__alpha - _three_phase_meter2_pll_abc_to_dq_alpha_beta_to_dq__k1 * _three_phase_meter2_pll_abc_to_dq_abc_to_alpha_beta__beta;
    _three_phase_meter2_pll_abc_to_dq_alpha_beta_to_dq__q = _three_phase_meter2_pll_abc_to_dq_alpha_beta_to_dq__k1 * _three_phase_meter2_pll_abc_to_dq_abc_to_alpha_beta__alpha + _three_phase_meter2_pll_abc_to_dq_alpha_beta_to_dq__k2 * _three_phase_meter2_pll_abc_to_dq_abc_to_alpha_beta__beta;
    // Generated from the component: Three-phase Meter2.TRMz
    // Generated from the component: Three-phase Meter3.TRMsin
    // Generated from the component: Three-phase Meter3.I_RMS_calc.RMS
    _three_phase_meter3_i_rms_calc_rms__IN1 = _three_phase_meter3_ia_ia1__out;
    _three_phase_meter3_i_rms_calc_rms__IN2 = _three_phase_meter3_ib_ia1__out;
    _three_phase_meter3_i_rms_calc_rms__IN3 = _three_phase_meter3_ic_ia1__out;
    _three_phase_meter3_i_rms_calc_rms__dFract = _three_phase_meter3_meassm_mode_and_dfract__dFract;
    _three_phase_meter3_i_rms_calc_rms__mode = _three_phase_meter3_meassm_mode_and_dfract__mode;
    switch (_three_phase_meter3_i_rms_calc_rms__mode) {
    case 1:
        _three_phase_meter3_i_rms_calc_rms__rmsSum1 = 0.0;
        _three_phase_meter3_i_rms_calc_rms__rmsSum2 = 0.0;
        _three_phase_meter3_i_rms_calc_rms__rmsSum3 = 0.0;
        break ;
    case 2:
        _three_phase_meter3_i_rms_calc_rms__RMS1 = _three_phase_meter3_i_rms_calc_rms__IN1;
        _three_phase_meter3_i_rms_calc_rms__RMS2 = _three_phase_meter3_i_rms_calc_rms__IN2;
        _three_phase_meter3_i_rms_calc_rms__RMS3 = _three_phase_meter3_i_rms_calc_rms__IN3;
        break ;
    case 3:
        _three_phase_meter3_i_rms_calc_rms__rmsSum1 += _three_phase_meter3_i_rms_calc_rms__dFract * (_three_phase_meter3_i_rms_calc_rms__IN1 * _three_phase_meter3_i_rms_calc_rms__IN1);
        _three_phase_meter3_i_rms_calc_rms__rmsSum2 += _three_phase_meter3_i_rms_calc_rms__dFract * (_three_phase_meter3_i_rms_calc_rms__IN2 * _three_phase_meter3_i_rms_calc_rms__IN2);
        _three_phase_meter3_i_rms_calc_rms__rmsSum3 += _three_phase_meter3_i_rms_calc_rms__dFract * (_three_phase_meter3_i_rms_calc_rms__IN3 * _three_phase_meter3_i_rms_calc_rms__IN3);
        break ;
    case 4:
        _three_phase_meter3_i_rms_calc_rms__RMS1 = sqrt(_three_phase_meter3_i_rms_calc_rms__rmsSum1);
        _three_phase_meter3_i_rms_calc_rms__RMS2 = sqrt(_three_phase_meter3_i_rms_calc_rms__rmsSum2);
        _three_phase_meter3_i_rms_calc_rms__RMS3 = sqrt(_three_phase_meter3_i_rms_calc_rms__rmsSum3);
        break ;
    case 5:
        _three_phase_meter3_i_rms_calc_rms__RMS1 = fabs(_three_phase_meter3_i_rms_calc_rms__IN1);
        _three_phase_meter3_i_rms_calc_rms__RMS2 = fabs(_three_phase_meter3_i_rms_calc_rms__IN2);
        _three_phase_meter3_i_rms_calc_rms__RMS3 = fabs(_three_phase_meter3_i_rms_calc_rms__IN3);
        break ;
    }
    // Generated from the component: Three-phase Meter3.VLn_RMS_calc.RMS
    _three_phase_meter3_vln_rms_calc_rms__IN1 = _three_phase_meter3_van_va1__out;
    _three_phase_meter3_vln_rms_calc_rms__IN2 = _three_phase_meter3_vbn_va1__out;
    _three_phase_meter3_vln_rms_calc_rms__IN3 = _three_phase_meter3_vcn_va1__out;
    _three_phase_meter3_vln_rms_calc_rms__dFract = _three_phase_meter3_meassm_mode_and_dfract__dFract;
    _three_phase_meter3_vln_rms_calc_rms__mode = _three_phase_meter3_meassm_mode_and_dfract__mode;
    switch (_three_phase_meter3_vln_rms_calc_rms__mode) {
    case 1:
        _three_phase_meter3_vln_rms_calc_rms__rmsSum1 = 0.0;
        _three_phase_meter3_vln_rms_calc_rms__rmsSum2 = 0.0;
        _three_phase_meter3_vln_rms_calc_rms__rmsSum3 = 0.0;
        break ;
    case 2:
        _three_phase_meter3_vln_rms_calc_rms__RMS1 = _three_phase_meter3_vln_rms_calc_rms__IN1;
        _three_phase_meter3_vln_rms_calc_rms__RMS2 = _three_phase_meter3_vln_rms_calc_rms__IN2;
        _three_phase_meter3_vln_rms_calc_rms__RMS3 = _three_phase_meter3_vln_rms_calc_rms__IN3;
        break ;
    case 3:
        _three_phase_meter3_vln_rms_calc_rms__rmsSum1 += _three_phase_meter3_vln_rms_calc_rms__dFract * (_three_phase_meter3_vln_rms_calc_rms__IN1 * _three_phase_meter3_vln_rms_calc_rms__IN1);
        _three_phase_meter3_vln_rms_calc_rms__rmsSum2 += _three_phase_meter3_vln_rms_calc_rms__dFract * (_three_phase_meter3_vln_rms_calc_rms__IN2 * _three_phase_meter3_vln_rms_calc_rms__IN2);
        _three_phase_meter3_vln_rms_calc_rms__rmsSum3 += _three_phase_meter3_vln_rms_calc_rms__dFract * (_three_phase_meter3_vln_rms_calc_rms__IN3 * _three_phase_meter3_vln_rms_calc_rms__IN3);
        break ;
    case 4:
        _three_phase_meter3_vln_rms_calc_rms__RMS1 = sqrt(_three_phase_meter3_vln_rms_calc_rms__rmsSum1);
        _three_phase_meter3_vln_rms_calc_rms__RMS2 = sqrt(_three_phase_meter3_vln_rms_calc_rms__rmsSum2);
        _three_phase_meter3_vln_rms_calc_rms__RMS3 = sqrt(_three_phase_meter3_vln_rms_calc_rms__rmsSum3);
        break ;
    case 5:
        _three_phase_meter3_vln_rms_calc_rms__RMS1 = fabs(_three_phase_meter3_vln_rms_calc_rms__IN1);
        _three_phase_meter3_vln_rms_calc_rms__RMS2 = fabs(_three_phase_meter3_vln_rms_calc_rms__IN2);
        _three_phase_meter3_vln_rms_calc_rms__RMS3 = fabs(_three_phase_meter3_vln_rms_calc_rms__IN3);
        break ;
    }
    // Generated from the component: Three-phase Meter3.PLL.abc to dq.alpha beta to dq
    _three_phase_meter3_pll_abc_to_dq_alpha_beta_to_dq__k1 = cos(_three_phase_meter3_pll_unit_delay1__out);
    _three_phase_meter3_pll_abc_to_dq_alpha_beta_to_dq__k2 = sin(_three_phase_meter3_pll_unit_delay1__out);
    _three_phase_meter3_pll_abc_to_dq_alpha_beta_to_dq__d = _three_phase_meter3_pll_abc_to_dq_alpha_beta_to_dq__k2 * _three_phase_meter3_pll_abc_to_dq_abc_to_alpha_beta__alpha - _three_phase_meter3_pll_abc_to_dq_alpha_beta_to_dq__k1 * _three_phase_meter3_pll_abc_to_dq_abc_to_alpha_beta__beta;
    _three_phase_meter3_pll_abc_to_dq_alpha_beta_to_dq__q = _three_phase_meter3_pll_abc_to_dq_alpha_beta_to_dq__k1 * _three_phase_meter3_pll_abc_to_dq_abc_to_alpha_beta__alpha + _three_phase_meter3_pll_abc_to_dq_alpha_beta_to_dq__k2 * _three_phase_meter3_pll_abc_to_dq_abc_to_alpha_beta__beta;
    // Generated from the component: Three-phase Meter3.TRMz
    // Generated from the component: Three-phase Meter1.IA_RMS
    HIL_OutAO(0x4001, (float)_three_phase_meter1_i_rms_calc_rms__RMS1);
    // Generated from the component: Three-phase Meter1.IB_RMS
    HIL_OutAO(0x4002, (float)_three_phase_meter1_i_rms_calc_rms__RMS2);
    // Generated from the component: Three-phase Meter1.IC_RMS
    HIL_OutAO(0x4003, (float)_three_phase_meter1_i_rms_calc_rms__RMS3);
    // Generated from the component: Three-phase Meter1.Power Meter.POWER
    _three_phase_meter1_power_meter_power__Ia = _three_phase_meter1_ia_ia1__out;
    _three_phase_meter1_power_meter_power__Ib = _three_phase_meter1_ib_ia1__out;
    _three_phase_meter1_power_meter_power__Ic = _three_phase_meter1_ic_ia1__out;
    _three_phase_meter1_power_meter_power__IrmsA = _three_phase_meter1_i_rms_calc_rms__RMS1;
    _three_phase_meter1_power_meter_power__IrmsB = _three_phase_meter1_i_rms_calc_rms__RMS2;
    _three_phase_meter1_power_meter_power__IrmsC = _three_phase_meter1_i_rms_calc_rms__RMS3;
    _three_phase_meter1_power_meter_power__Va = _three_phase_meter1_van_va1__out;
    _three_phase_meter1_power_meter_power__Vb = _three_phase_meter1_vbn_va1__out;
    _three_phase_meter1_power_meter_power__Vc = _three_phase_meter1_vcn_va1__out;
    _three_phase_meter1_power_meter_power__VrmsA = _three_phase_meter1_vln_rms_calc_rms__RMS1;
    _three_phase_meter1_power_meter_power__VrmsB = _three_phase_meter1_vln_rms_calc_rms__RMS2;
    _three_phase_meter1_power_meter_power__VrmsC = _three_phase_meter1_vln_rms_calc_rms__RMS3;
    _three_phase_meter1_power_meter_power__dFract = _three_phase_meter1_meassm_mode_and_dfract__dFract;
    _three_phase_meter1_power_meter_power__mode = _three_phase_meter1_meassm_mode_and_dfract__mode;
    _three_phase_meter1_power_meter_power__submode = _three_phase_meter1_meassm_mode_and_dfract__submode;
    switch (_three_phase_meter1_power_meter_power__mode) {
    case 1:
        _three_phase_meter1_power_meter_power__VevenSumA = 0.0;
        _three_phase_meter1_power_meter_power__VoddSumA = 0.0;
        _three_phase_meter1_power_meter_power__VevenSumB = 0.0;
        _three_phase_meter1_power_meter_power__VoddSumB = 0.0;
        _three_phase_meter1_power_meter_power__VevenSumC = 0.0;
        _three_phase_meter1_power_meter_power__VoddSumC = 0.0;
        _three_phase_meter1_power_meter_power__IevenSumA = 0.0;
        _three_phase_meter1_power_meter_power__IoddSumA = 0.0;
        _three_phase_meter1_power_meter_power__IevenSumB = 0.0;
        _three_phase_meter1_power_meter_power__IoddSumB = 0.0;
        _three_phase_meter1_power_meter_power__IevenSumC = 0.0;
        _three_phase_meter1_power_meter_power__IoddSumC = 0.0;
        _three_phase_meter1_power_meter_power__PsumA = 0.0;
        _three_phase_meter1_power_meter_power__PsumB = 0.0;
        _three_phase_meter1_power_meter_power__PsumC = 0.0;
        break ;
    case 2:
        _three_phase_meter1_power_meter_power__Pa = _three_phase_meter1_power_meter_power__Va * _three_phase_meter1_power_meter_power__Ia;
        _three_phase_meter1_power_meter_power__Pb = _three_phase_meter1_power_meter_power__Vb * _three_phase_meter1_power_meter_power__Ib;
        _three_phase_meter1_power_meter_power__Pc = _three_phase_meter1_power_meter_power__Vc * _three_phase_meter1_power_meter_power__Ic;
        _three_phase_meter1_power_meter_power__P = _three_phase_meter1_power_meter_power__Pa + _three_phase_meter1_power_meter_power__Pb + _three_phase_meter1_power_meter_power__Pc;
        _three_phase_meter1_power_meter_power__Qa = 0;
        _three_phase_meter1_power_meter_power__Qb = 0;
        _three_phase_meter1_power_meter_power__Qc = 0;
        _three_phase_meter1_power_meter_power__Q = _three_phase_meter1_power_meter_power__Qa + _three_phase_meter1_power_meter_power__Qb + _three_phase_meter1_power_meter_power__Qc;
        _three_phase_meter1_power_meter_power__Sa = _three_phase_meter1_power_meter_power__Pa;
        _three_phase_meter1_power_meter_power__Sb = _three_phase_meter1_power_meter_power__Pb;
        _three_phase_meter1_power_meter_power__Sc = _three_phase_meter1_power_meter_power__Pc;
        _three_phase_meter1_power_meter_power__S = _three_phase_meter1_power_meter_power__Sa + _three_phase_meter1_power_meter_power__Sb + _three_phase_meter1_power_meter_power__Sc;
        _three_phase_meter1_power_meter_power__PFa = 1.0;
        _three_phase_meter1_power_meter_power__PFb = 1.0;
        _three_phase_meter1_power_meter_power__PFc = 1.0;
        _three_phase_meter1_power_meter_power__PF = 1.0;
        break ;
    case 3:
        _three_phase_meter1_power_meter_power__PsumA += _three_phase_meter1_power_meter_power__dFract * (_three_phase_meter1_power_meter_power__Va * _three_phase_meter1_power_meter_power__Ia);
        _three_phase_meter1_power_meter_power__PsumB += _three_phase_meter1_power_meter_power__dFract * (_three_phase_meter1_power_meter_power__Vb * _three_phase_meter1_power_meter_power__Ib);
        _three_phase_meter1_power_meter_power__PsumC += _three_phase_meter1_power_meter_power__dFract * (_three_phase_meter1_power_meter_power__Vc * _three_phase_meter1_power_meter_power__Ic);
        switch (_three_phase_meter1_power_meter_power__submode) {
        case 1:
            _three_phase_meter1_power_meter_power__VevenSumA += _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Va;
            _three_phase_meter1_power_meter_power__VevenSumB += _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Vb;
            _three_phase_meter1_power_meter_power__VevenSumC += _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Vc;
            _three_phase_meter1_power_meter_power__IevenSumA += _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Ia;
            _three_phase_meter1_power_meter_power__IevenSumB += _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Ib;
            _three_phase_meter1_power_meter_power__IevenSumC += _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Ic;
            _three_phase_meter1_power_meter_power__VoddSumA += _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Va;
            _three_phase_meter1_power_meter_power__VoddSumB += _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Vb;
            _three_phase_meter1_power_meter_power__VoddSumC += _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Vc;
            _three_phase_meter1_power_meter_power__IoddSumA += _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Ia;
            _three_phase_meter1_power_meter_power__IoddSumB += _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Ib;
            _three_phase_meter1_power_meter_power__IoddSumC += _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Ic;
            break ;
        case 2:
            _three_phase_meter1_power_meter_power__VevenSumA -= _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Va;
            _three_phase_meter1_power_meter_power__VevenSumB -= _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Vb;
            _three_phase_meter1_power_meter_power__VevenSumC -= _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Vc;
            _three_phase_meter1_power_meter_power__IevenSumA -= _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Ia;
            _three_phase_meter1_power_meter_power__IevenSumB -= _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Ib;
            _three_phase_meter1_power_meter_power__IevenSumC -= _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Ic;
            _three_phase_meter1_power_meter_power__VoddSumA += _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Va;
            _three_phase_meter1_power_meter_power__VoddSumB += _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Vb;
            _three_phase_meter1_power_meter_power__VoddSumC += _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Vc;
            _three_phase_meter1_power_meter_power__IoddSumA += _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Ia;
            _three_phase_meter1_power_meter_power__IoddSumB += _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Ib;
            _three_phase_meter1_power_meter_power__IoddSumC += _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Ic;
            break ;
        case 3:
            _three_phase_meter1_power_meter_power__VevenSumA -= _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Va;
            _three_phase_meter1_power_meter_power__VevenSumB -= _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Vb;
            _three_phase_meter1_power_meter_power__VevenSumC -= _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Vc;
            _three_phase_meter1_power_meter_power__IevenSumA -= _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Ia;
            _three_phase_meter1_power_meter_power__IevenSumB -= _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Ib;
            _three_phase_meter1_power_meter_power__IevenSumC -= _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Ic;
            _three_phase_meter1_power_meter_power__VoddSumA -= _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Va;
            _three_phase_meter1_power_meter_power__VoddSumB -= _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Vb;
            _three_phase_meter1_power_meter_power__VoddSumC -= _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Vc;
            _three_phase_meter1_power_meter_power__IoddSumA -= _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Ia;
            _three_phase_meter1_power_meter_power__IoddSumB -= _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Ib;
            _three_phase_meter1_power_meter_power__IoddSumC -= _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Ic;
            break ;
        case 4:
            _three_phase_meter1_power_meter_power__VevenSumA += _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Va;
            _three_phase_meter1_power_meter_power__VevenSumB += _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Vb;
            _three_phase_meter1_power_meter_power__VevenSumC += _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Vc;
            _three_phase_meter1_power_meter_power__IevenSumA += _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Ia;
            _three_phase_meter1_power_meter_power__IevenSumB += _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Ib;
            _three_phase_meter1_power_meter_power__IevenSumC += _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Ic;
            _three_phase_meter1_power_meter_power__VoddSumA -= _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Va;
            _three_phase_meter1_power_meter_power__VoddSumB -= _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Vb;
            _three_phase_meter1_power_meter_power__VoddSumC -= _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Vc;
            _three_phase_meter1_power_meter_power__IoddSumA -= _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Ia;
            _three_phase_meter1_power_meter_power__IoddSumB -= _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Ib;
            _three_phase_meter1_power_meter_power__IoddSumC -= _three_phase_meter1_power_meter_power__dFract * _three_phase_meter1_power_meter_power__Ic;
            break ;
        }
        break ;
    case 4:
        _three_phase_meter1_power_meter_power__Pa = _three_phase_meter1_power_meter_power__PsumA;
        _three_phase_meter1_power_meter_power__Pb = _three_phase_meter1_power_meter_power__PsumB;
        _three_phase_meter1_power_meter_power__Pc = _three_phase_meter1_power_meter_power__PsumC;
        _three_phase_meter1_power_meter_power__P = _three_phase_meter1_power_meter_power__Pa + _three_phase_meter1_power_meter_power__Pb + _three_phase_meter1_power_meter_power__Pc;
        _three_phase_meter1_power_meter_power__Sa = _three_phase_meter1_power_meter_power__VrmsA * _three_phase_meter1_power_meter_power__IrmsA;
        _three_phase_meter1_power_meter_power__Sb = _three_phase_meter1_power_meter_power__VrmsB * _three_phase_meter1_power_meter_power__IrmsB;
        _three_phase_meter1_power_meter_power__Sc = _three_phase_meter1_power_meter_power__VrmsC * _three_phase_meter1_power_meter_power__IrmsC;
        _three_phase_meter1_power_meter_power__S = _three_phase_meter1_power_meter_power__Sa + _three_phase_meter1_power_meter_power__Sb + _three_phase_meter1_power_meter_power__Sc;
        _three_phase_meter1_power_meter_power__Qa = _three_phase_meter1_power_meter_power__Sa * _three_phase_meter1_power_meter_power__Sa - _three_phase_meter1_power_meter_power__Pa * _three_phase_meter1_power_meter_power__Pa;
        if (_three_phase_meter1_power_meter_power__Qa < 0.0) {
            _three_phase_meter1_power_meter_power__Qa = 0.0;
        }
        else {
            _three_phase_meter1_power_meter_power__Qa = sqrt(_three_phase_meter1_power_meter_power__Qa);
            if (atan2f((_three_phase_meter1_power_meter_power__VoddSumA * _three_phase_meter1_power_meter_power__IevenSumA - _three_phase_meter1_power_meter_power__IoddSumA * _three_phase_meter1_power_meter_power__VevenSumA), (_three_phase_meter1_power_meter_power__VevenSumA * _three_phase_meter1_power_meter_power__IevenSumA + _three_phase_meter1_power_meter_power__VoddSumA * _three_phase_meter1_power_meter_power__IoddSumA)) > 0.0) {
                _three_phase_meter1_power_meter_power__Qa *= -1;
            }
        }
        _three_phase_meter1_power_meter_power__Qb = _three_phase_meter1_power_meter_power__Sb * _three_phase_meter1_power_meter_power__Sb - _three_phase_meter1_power_meter_power__Pb * _three_phase_meter1_power_meter_power__Pb;
        if (_three_phase_meter1_power_meter_power__Qb < 0.0) {
            _three_phase_meter1_power_meter_power__Qb = 0.0;
        }
        else {
            _three_phase_meter1_power_meter_power__Qb = sqrt(_three_phase_meter1_power_meter_power__Qb);
            if (atan2f((_three_phase_meter1_power_meter_power__VoddSumB * _three_phase_meter1_power_meter_power__IevenSumB - _three_phase_meter1_power_meter_power__IoddSumB * _three_phase_meter1_power_meter_power__VevenSumB), (_three_phase_meter1_power_meter_power__VevenSumB * _three_phase_meter1_power_meter_power__IevenSumB + _three_phase_meter1_power_meter_power__VoddSumB * _three_phase_meter1_power_meter_power__IoddSumB)) > 0.0) {
                _three_phase_meter1_power_meter_power__Qb *= -1;
            }
        }
        _three_phase_meter1_power_meter_power__Qc = _three_phase_meter1_power_meter_power__Sc * _three_phase_meter1_power_meter_power__Sc - _three_phase_meter1_power_meter_power__Pc * _three_phase_meter1_power_meter_power__Pc;
        if (_three_phase_meter1_power_meter_power__Qc < 0.0) {
            _three_phase_meter1_power_meter_power__Qc = 0.0;
        }
        else {
            _three_phase_meter1_power_meter_power__Qc = sqrt(_three_phase_meter1_power_meter_power__Qc);
            if (atan2f((_three_phase_meter1_power_meter_power__VoddSumC * _three_phase_meter1_power_meter_power__IevenSumC - _three_phase_meter1_power_meter_power__IoddSumC * _three_phase_meter1_power_meter_power__VevenSumC), (_three_phase_meter1_power_meter_power__VevenSumC * _three_phase_meter1_power_meter_power__IevenSumC + _three_phase_meter1_power_meter_power__VoddSumC * _three_phase_meter1_power_meter_power__IoddSumC)) > 0.0) {
                _three_phase_meter1_power_meter_power__Qc *= -1;
            }
        }
        _three_phase_meter1_power_meter_power__Q = _three_phase_meter1_power_meter_power__Qa + _three_phase_meter1_power_meter_power__Qb + _three_phase_meter1_power_meter_power__Qc;
        if (_three_phase_meter1_power_meter_power__Sa > 0) {
            _three_phase_meter1_power_meter_power__PFa = _three_phase_meter1_power_meter_power__Pa / _three_phase_meter1_power_meter_power__Sa;
        }
        else {
            _three_phase_meter1_power_meter_power__PFa = 0.0;
        }
        if (_three_phase_meter1_power_meter_power__Sb > 0) {
            _three_phase_meter1_power_meter_power__PFb = _three_phase_meter1_power_meter_power__Pb / _three_phase_meter1_power_meter_power__Sb;
        }
        else {
            _three_phase_meter1_power_meter_power__PFb = 0.0;
        }
        if (_three_phase_meter1_power_meter_power__Sc > 0) {
            _three_phase_meter1_power_meter_power__PFc = _three_phase_meter1_power_meter_power__Pc / _three_phase_meter1_power_meter_power__Sc;
        }
        else {
            _three_phase_meter1_power_meter_power__PFc = 0.0;
        }
        if (_three_phase_meter1_power_meter_power__S > 0) {
            _three_phase_meter1_power_meter_power__PF = _three_phase_meter1_power_meter_power__P / _three_phase_meter1_power_meter_power__S;
        }
        else {
            _three_phase_meter1_power_meter_power__PF = 0.0;
        }
        break ;
    case 5:
        _three_phase_meter1_power_meter_power__Pa = _three_phase_meter1_power_meter_power__Va * _three_phase_meter1_power_meter_power__Ia;
        _three_phase_meter1_power_meter_power__Pb = _three_phase_meter1_power_meter_power__Vb * _three_phase_meter1_power_meter_power__Ib;
        _three_phase_meter1_power_meter_power__Pc = _three_phase_meter1_power_meter_power__Vc * _three_phase_meter1_power_meter_power__Ic;
        _three_phase_meter1_power_meter_power__P = _three_phase_meter1_power_meter_power__Pa + _three_phase_meter1_power_meter_power__Pb + _three_phase_meter1_power_meter_power__Pc;
        _three_phase_meter1_power_meter_power__Qa = 0;
        _three_phase_meter1_power_meter_power__Qb = 0;
        _three_phase_meter1_power_meter_power__Qc = 0;
        _three_phase_meter1_power_meter_power__Q = 0.0;
        _three_phase_meter1_power_meter_power__Sa = 0;
        _three_phase_meter1_power_meter_power__Sb = 0;
        _three_phase_meter1_power_meter_power__Sc = 0;
        _three_phase_meter1_power_meter_power__S = 0;
        _three_phase_meter1_power_meter_power__PFa = 0.0;
        _three_phase_meter1_power_meter_power__PFb = 0.0;
        _three_phase_meter1_power_meter_power__PFc = 0.0;
        _three_phase_meter1_power_meter_power__PF = 0.0;
        break ;
    }
    // Generated from the component: Three-phase Meter1.VAn_RMS
    HIL_OutAO(0x4014, (float)_three_phase_meter1_vln_rms_calc_rms__RMS1);
    // Generated from the component: Three-phase Meter1.VBn_RMS
    HIL_OutAO(0x4015, (float)_three_phase_meter1_vln_rms_calc_rms__RMS2);
    // Generated from the component: Three-phase Meter1.VCn_RMS
    HIL_OutAO(0x4016, (float)_three_phase_meter1_vln_rms_calc_rms__RMS3);
    // Generated from the component: Three-phase Meter1.PLL.abc to dq.LPF_d
    _three_phase_meter1_pll_abc_to_dq_lpf_d__previous_filtered_value = _three_phase_meter1_pll_abc_to_dq_lpf_d__filtered_value;
    _three_phase_meter1_pll_abc_to_dq_lpf_d__filtered_value = _three_phase_meter1_pll_abc_to_dq_lpf_d__previous_in * (1.0 * 62.83185307 * 0.0001) + _three_phase_meter1_pll_abc_to_dq_lpf_d__previous_filtered_value * (1 - 1.0 * 62.83185307 * 0.0001 );
    _three_phase_meter1_pll_abc_to_dq_lpf_d__out = _three_phase_meter1_pll_abc_to_dq_lpf_d__filtered_value;
    _three_phase_meter1_pll_abc_to_dq_lpf_d__previous_in = _three_phase_meter1_pll_abc_to_dq_alpha_beta_to_dq__d;
    // Generated from the component: Three-phase Meter1.PLL.abc to dq.LPF_q
    _three_phase_meter1_pll_abc_to_dq_lpf_q__previous_filtered_value = _three_phase_meter1_pll_abc_to_dq_lpf_q__filtered_value;
    _three_phase_meter1_pll_abc_to_dq_lpf_q__filtered_value = _three_phase_meter1_pll_abc_to_dq_lpf_q__previous_in * (1.0 * 62.83185307 * 0.0001) + _three_phase_meter1_pll_abc_to_dq_lpf_q__previous_filtered_value * (1 - 1.0 * 62.83185307 * 0.0001 );
    _three_phase_meter1_pll_abc_to_dq_lpf_q__out = _three_phase_meter1_pll_abc_to_dq_lpf_q__filtered_value;
    _three_phase_meter1_pll_abc_to_dq_lpf_q__previous_in = _three_phase_meter1_pll_abc_to_dq_alpha_beta_to_dq__q;
    // Generated from the component: Three-phase Meter2.IA_RMS
    HIL_OutAO(0x4018, (float)_three_phase_meter2_i_rms_calc_rms__RMS1);
    // Generated from the component: Three-phase Meter2.IB_RMS
    HIL_OutAO(0x4019, (float)_three_phase_meter2_i_rms_calc_rms__RMS2);
    // Generated from the component: Three-phase Meter2.IC_RMS
    HIL_OutAO(0x401a, (float)_three_phase_meter2_i_rms_calc_rms__RMS3);
    // Generated from the component: Three-phase Meter2.Power Meter.POWER
    _three_phase_meter2_power_meter_power__Ia = _three_phase_meter2_ia_ia1__out;
    _three_phase_meter2_power_meter_power__Ib = _three_phase_meter2_ib_ia1__out;
    _three_phase_meter2_power_meter_power__Ic = _three_phase_meter2_ic_ia1__out;
    _three_phase_meter2_power_meter_power__IrmsA = _three_phase_meter2_i_rms_calc_rms__RMS1;
    _three_phase_meter2_power_meter_power__IrmsB = _three_phase_meter2_i_rms_calc_rms__RMS2;
    _three_phase_meter2_power_meter_power__IrmsC = _three_phase_meter2_i_rms_calc_rms__RMS3;
    _three_phase_meter2_power_meter_power__Va = _three_phase_meter2_van_va1__out;
    _three_phase_meter2_power_meter_power__Vb = _three_phase_meter2_vbn_va1__out;
    _three_phase_meter2_power_meter_power__Vc = _three_phase_meter2_vcn_va1__out;
    _three_phase_meter2_power_meter_power__VrmsA = _three_phase_meter2_vln_rms_calc_rms__RMS1;
    _three_phase_meter2_power_meter_power__VrmsB = _three_phase_meter2_vln_rms_calc_rms__RMS2;
    _three_phase_meter2_power_meter_power__VrmsC = _three_phase_meter2_vln_rms_calc_rms__RMS3;
    _three_phase_meter2_power_meter_power__dFract = _three_phase_meter2_meassm_mode_and_dfract__dFract;
    _three_phase_meter2_power_meter_power__mode = _three_phase_meter2_meassm_mode_and_dfract__mode;
    _three_phase_meter2_power_meter_power__submode = _three_phase_meter2_meassm_mode_and_dfract__submode;
    switch (_three_phase_meter2_power_meter_power__mode) {
    case 1:
        _three_phase_meter2_power_meter_power__VevenSumA = 0.0;
        _three_phase_meter2_power_meter_power__VoddSumA = 0.0;
        _three_phase_meter2_power_meter_power__VevenSumB = 0.0;
        _three_phase_meter2_power_meter_power__VoddSumB = 0.0;
        _three_phase_meter2_power_meter_power__VevenSumC = 0.0;
        _three_phase_meter2_power_meter_power__VoddSumC = 0.0;
        _three_phase_meter2_power_meter_power__IevenSumA = 0.0;
        _three_phase_meter2_power_meter_power__IoddSumA = 0.0;
        _three_phase_meter2_power_meter_power__IevenSumB = 0.0;
        _three_phase_meter2_power_meter_power__IoddSumB = 0.0;
        _three_phase_meter2_power_meter_power__IevenSumC = 0.0;
        _three_phase_meter2_power_meter_power__IoddSumC = 0.0;
        _three_phase_meter2_power_meter_power__PsumA = 0.0;
        _three_phase_meter2_power_meter_power__PsumB = 0.0;
        _three_phase_meter2_power_meter_power__PsumC = 0.0;
        break ;
    case 2:
        _three_phase_meter2_power_meter_power__Pa = _three_phase_meter2_power_meter_power__Va * _three_phase_meter2_power_meter_power__Ia;
        _three_phase_meter2_power_meter_power__Pb = _three_phase_meter2_power_meter_power__Vb * _three_phase_meter2_power_meter_power__Ib;
        _three_phase_meter2_power_meter_power__Pc = _three_phase_meter2_power_meter_power__Vc * _three_phase_meter2_power_meter_power__Ic;
        _three_phase_meter2_power_meter_power__P = _three_phase_meter2_power_meter_power__Pa + _three_phase_meter2_power_meter_power__Pb + _three_phase_meter2_power_meter_power__Pc;
        _three_phase_meter2_power_meter_power__Qa = 0;
        _three_phase_meter2_power_meter_power__Qb = 0;
        _three_phase_meter2_power_meter_power__Qc = 0;
        _three_phase_meter2_power_meter_power__Q = _three_phase_meter2_power_meter_power__Qa + _three_phase_meter2_power_meter_power__Qb + _three_phase_meter2_power_meter_power__Qc;
        _three_phase_meter2_power_meter_power__Sa = _three_phase_meter2_power_meter_power__Pa;
        _three_phase_meter2_power_meter_power__Sb = _three_phase_meter2_power_meter_power__Pb;
        _three_phase_meter2_power_meter_power__Sc = _three_phase_meter2_power_meter_power__Pc;
        _three_phase_meter2_power_meter_power__S = _three_phase_meter2_power_meter_power__Sa + _three_phase_meter2_power_meter_power__Sb + _three_phase_meter2_power_meter_power__Sc;
        _three_phase_meter2_power_meter_power__PFa = 1.0;
        _three_phase_meter2_power_meter_power__PFb = 1.0;
        _three_phase_meter2_power_meter_power__PFc = 1.0;
        _three_phase_meter2_power_meter_power__PF = 1.0;
        break ;
    case 3:
        _three_phase_meter2_power_meter_power__PsumA += _three_phase_meter2_power_meter_power__dFract * (_three_phase_meter2_power_meter_power__Va * _three_phase_meter2_power_meter_power__Ia);
        _three_phase_meter2_power_meter_power__PsumB += _three_phase_meter2_power_meter_power__dFract * (_three_phase_meter2_power_meter_power__Vb * _three_phase_meter2_power_meter_power__Ib);
        _three_phase_meter2_power_meter_power__PsumC += _three_phase_meter2_power_meter_power__dFract * (_three_phase_meter2_power_meter_power__Vc * _three_phase_meter2_power_meter_power__Ic);
        switch (_three_phase_meter2_power_meter_power__submode) {
        case 1:
            _three_phase_meter2_power_meter_power__VevenSumA += _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Va;
            _three_phase_meter2_power_meter_power__VevenSumB += _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Vb;
            _three_phase_meter2_power_meter_power__VevenSumC += _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Vc;
            _three_phase_meter2_power_meter_power__IevenSumA += _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Ia;
            _three_phase_meter2_power_meter_power__IevenSumB += _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Ib;
            _three_phase_meter2_power_meter_power__IevenSumC += _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Ic;
            _three_phase_meter2_power_meter_power__VoddSumA += _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Va;
            _three_phase_meter2_power_meter_power__VoddSumB += _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Vb;
            _three_phase_meter2_power_meter_power__VoddSumC += _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Vc;
            _three_phase_meter2_power_meter_power__IoddSumA += _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Ia;
            _three_phase_meter2_power_meter_power__IoddSumB += _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Ib;
            _three_phase_meter2_power_meter_power__IoddSumC += _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Ic;
            break ;
        case 2:
            _three_phase_meter2_power_meter_power__VevenSumA -= _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Va;
            _three_phase_meter2_power_meter_power__VevenSumB -= _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Vb;
            _three_phase_meter2_power_meter_power__VevenSumC -= _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Vc;
            _three_phase_meter2_power_meter_power__IevenSumA -= _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Ia;
            _three_phase_meter2_power_meter_power__IevenSumB -= _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Ib;
            _three_phase_meter2_power_meter_power__IevenSumC -= _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Ic;
            _three_phase_meter2_power_meter_power__VoddSumA += _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Va;
            _three_phase_meter2_power_meter_power__VoddSumB += _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Vb;
            _three_phase_meter2_power_meter_power__VoddSumC += _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Vc;
            _three_phase_meter2_power_meter_power__IoddSumA += _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Ia;
            _three_phase_meter2_power_meter_power__IoddSumB += _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Ib;
            _three_phase_meter2_power_meter_power__IoddSumC += _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Ic;
            break ;
        case 3:
            _three_phase_meter2_power_meter_power__VevenSumA -= _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Va;
            _three_phase_meter2_power_meter_power__VevenSumB -= _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Vb;
            _three_phase_meter2_power_meter_power__VevenSumC -= _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Vc;
            _three_phase_meter2_power_meter_power__IevenSumA -= _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Ia;
            _three_phase_meter2_power_meter_power__IevenSumB -= _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Ib;
            _three_phase_meter2_power_meter_power__IevenSumC -= _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Ic;
            _three_phase_meter2_power_meter_power__VoddSumA -= _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Va;
            _three_phase_meter2_power_meter_power__VoddSumB -= _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Vb;
            _three_phase_meter2_power_meter_power__VoddSumC -= _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Vc;
            _three_phase_meter2_power_meter_power__IoddSumA -= _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Ia;
            _three_phase_meter2_power_meter_power__IoddSumB -= _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Ib;
            _three_phase_meter2_power_meter_power__IoddSumC -= _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Ic;
            break ;
        case 4:
            _three_phase_meter2_power_meter_power__VevenSumA += _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Va;
            _three_phase_meter2_power_meter_power__VevenSumB += _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Vb;
            _three_phase_meter2_power_meter_power__VevenSumC += _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Vc;
            _three_phase_meter2_power_meter_power__IevenSumA += _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Ia;
            _three_phase_meter2_power_meter_power__IevenSumB += _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Ib;
            _three_phase_meter2_power_meter_power__IevenSumC += _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Ic;
            _three_phase_meter2_power_meter_power__VoddSumA -= _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Va;
            _three_phase_meter2_power_meter_power__VoddSumB -= _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Vb;
            _three_phase_meter2_power_meter_power__VoddSumC -= _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Vc;
            _three_phase_meter2_power_meter_power__IoddSumA -= _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Ia;
            _three_phase_meter2_power_meter_power__IoddSumB -= _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Ib;
            _three_phase_meter2_power_meter_power__IoddSumC -= _three_phase_meter2_power_meter_power__dFract * _three_phase_meter2_power_meter_power__Ic;
            break ;
        }
        break ;
    case 4:
        _three_phase_meter2_power_meter_power__Pa = _three_phase_meter2_power_meter_power__PsumA;
        _three_phase_meter2_power_meter_power__Pb = _three_phase_meter2_power_meter_power__PsumB;
        _three_phase_meter2_power_meter_power__Pc = _three_phase_meter2_power_meter_power__PsumC;
        _three_phase_meter2_power_meter_power__P = _three_phase_meter2_power_meter_power__Pa + _three_phase_meter2_power_meter_power__Pb + _three_phase_meter2_power_meter_power__Pc;
        _three_phase_meter2_power_meter_power__Sa = _three_phase_meter2_power_meter_power__VrmsA * _three_phase_meter2_power_meter_power__IrmsA;
        _three_phase_meter2_power_meter_power__Sb = _three_phase_meter2_power_meter_power__VrmsB * _three_phase_meter2_power_meter_power__IrmsB;
        _three_phase_meter2_power_meter_power__Sc = _three_phase_meter2_power_meter_power__VrmsC * _three_phase_meter2_power_meter_power__IrmsC;
        _three_phase_meter2_power_meter_power__S = _three_phase_meter2_power_meter_power__Sa + _three_phase_meter2_power_meter_power__Sb + _three_phase_meter2_power_meter_power__Sc;
        _three_phase_meter2_power_meter_power__Qa = _three_phase_meter2_power_meter_power__Sa * _three_phase_meter2_power_meter_power__Sa - _three_phase_meter2_power_meter_power__Pa * _three_phase_meter2_power_meter_power__Pa;
        if (_three_phase_meter2_power_meter_power__Qa < 0.0) {
            _three_phase_meter2_power_meter_power__Qa = 0.0;
        }
        else {
            _three_phase_meter2_power_meter_power__Qa = sqrt(_three_phase_meter2_power_meter_power__Qa);
            if (atan2f((_three_phase_meter2_power_meter_power__VoddSumA * _three_phase_meter2_power_meter_power__IevenSumA - _three_phase_meter2_power_meter_power__IoddSumA * _three_phase_meter2_power_meter_power__VevenSumA), (_three_phase_meter2_power_meter_power__VevenSumA * _three_phase_meter2_power_meter_power__IevenSumA + _three_phase_meter2_power_meter_power__VoddSumA * _three_phase_meter2_power_meter_power__IoddSumA)) > 0.0) {
                _three_phase_meter2_power_meter_power__Qa *= -1;
            }
        }
        _three_phase_meter2_power_meter_power__Qb = _three_phase_meter2_power_meter_power__Sb * _three_phase_meter2_power_meter_power__Sb - _three_phase_meter2_power_meter_power__Pb * _three_phase_meter2_power_meter_power__Pb;
        if (_three_phase_meter2_power_meter_power__Qb < 0.0) {
            _three_phase_meter2_power_meter_power__Qb = 0.0;
        }
        else {
            _three_phase_meter2_power_meter_power__Qb = sqrt(_three_phase_meter2_power_meter_power__Qb);
            if (atan2f((_three_phase_meter2_power_meter_power__VoddSumB * _three_phase_meter2_power_meter_power__IevenSumB - _three_phase_meter2_power_meter_power__IoddSumB * _three_phase_meter2_power_meter_power__VevenSumB), (_three_phase_meter2_power_meter_power__VevenSumB * _three_phase_meter2_power_meter_power__IevenSumB + _three_phase_meter2_power_meter_power__VoddSumB * _three_phase_meter2_power_meter_power__IoddSumB)) > 0.0) {
                _three_phase_meter2_power_meter_power__Qb *= -1;
            }
        }
        _three_phase_meter2_power_meter_power__Qc = _three_phase_meter2_power_meter_power__Sc * _three_phase_meter2_power_meter_power__Sc - _three_phase_meter2_power_meter_power__Pc * _three_phase_meter2_power_meter_power__Pc;
        if (_three_phase_meter2_power_meter_power__Qc < 0.0) {
            _three_phase_meter2_power_meter_power__Qc = 0.0;
        }
        else {
            _three_phase_meter2_power_meter_power__Qc = sqrt(_three_phase_meter2_power_meter_power__Qc);
            if (atan2f((_three_phase_meter2_power_meter_power__VoddSumC * _three_phase_meter2_power_meter_power__IevenSumC - _three_phase_meter2_power_meter_power__IoddSumC * _three_phase_meter2_power_meter_power__VevenSumC), (_three_phase_meter2_power_meter_power__VevenSumC * _three_phase_meter2_power_meter_power__IevenSumC + _three_phase_meter2_power_meter_power__VoddSumC * _three_phase_meter2_power_meter_power__IoddSumC)) > 0.0) {
                _three_phase_meter2_power_meter_power__Qc *= -1;
            }
        }
        _three_phase_meter2_power_meter_power__Q = _three_phase_meter2_power_meter_power__Qa + _three_phase_meter2_power_meter_power__Qb + _three_phase_meter2_power_meter_power__Qc;
        if (_three_phase_meter2_power_meter_power__Sa > 0) {
            _three_phase_meter2_power_meter_power__PFa = _three_phase_meter2_power_meter_power__Pa / _three_phase_meter2_power_meter_power__Sa;
        }
        else {
            _three_phase_meter2_power_meter_power__PFa = 0.0;
        }
        if (_three_phase_meter2_power_meter_power__Sb > 0) {
            _three_phase_meter2_power_meter_power__PFb = _three_phase_meter2_power_meter_power__Pb / _three_phase_meter2_power_meter_power__Sb;
        }
        else {
            _three_phase_meter2_power_meter_power__PFb = 0.0;
        }
        if (_three_phase_meter2_power_meter_power__Sc > 0) {
            _three_phase_meter2_power_meter_power__PFc = _three_phase_meter2_power_meter_power__Pc / _three_phase_meter2_power_meter_power__Sc;
        }
        else {
            _three_phase_meter2_power_meter_power__PFc = 0.0;
        }
        if (_three_phase_meter2_power_meter_power__S > 0) {
            _three_phase_meter2_power_meter_power__PF = _three_phase_meter2_power_meter_power__P / _three_phase_meter2_power_meter_power__S;
        }
        else {
            _three_phase_meter2_power_meter_power__PF = 0.0;
        }
        break ;
    case 5:
        _three_phase_meter2_power_meter_power__Pa = _three_phase_meter2_power_meter_power__Va * _three_phase_meter2_power_meter_power__Ia;
        _three_phase_meter2_power_meter_power__Pb = _three_phase_meter2_power_meter_power__Vb * _three_phase_meter2_power_meter_power__Ib;
        _three_phase_meter2_power_meter_power__Pc = _three_phase_meter2_power_meter_power__Vc * _three_phase_meter2_power_meter_power__Ic;
        _three_phase_meter2_power_meter_power__P = _three_phase_meter2_power_meter_power__Pa + _three_phase_meter2_power_meter_power__Pb + _three_phase_meter2_power_meter_power__Pc;
        _three_phase_meter2_power_meter_power__Qa = 0;
        _three_phase_meter2_power_meter_power__Qb = 0;
        _three_phase_meter2_power_meter_power__Qc = 0;
        _three_phase_meter2_power_meter_power__Q = 0.0;
        _three_phase_meter2_power_meter_power__Sa = 0;
        _three_phase_meter2_power_meter_power__Sb = 0;
        _three_phase_meter2_power_meter_power__Sc = 0;
        _three_phase_meter2_power_meter_power__S = 0;
        _three_phase_meter2_power_meter_power__PFa = 0.0;
        _three_phase_meter2_power_meter_power__PFb = 0.0;
        _three_phase_meter2_power_meter_power__PFc = 0.0;
        _three_phase_meter2_power_meter_power__PF = 0.0;
        break ;
    }
    // Generated from the component: Three-phase Meter2.VAn_RMS
    HIL_OutAO(0x402b, (float)_three_phase_meter2_vln_rms_calc_rms__RMS1);
    // Generated from the component: Three-phase Meter2.VBn_RMS
    HIL_OutAO(0x402c, (float)_three_phase_meter2_vln_rms_calc_rms__RMS2);
    // Generated from the component: Three-phase Meter2.VCn_RMS
    HIL_OutAO(0x402d, (float)_three_phase_meter2_vln_rms_calc_rms__RMS3);
    // Generated from the component: Three-phase Meter2.PLL.abc to dq.LPF_d
    _three_phase_meter2_pll_abc_to_dq_lpf_d__previous_filtered_value = _three_phase_meter2_pll_abc_to_dq_lpf_d__filtered_value;
    _three_phase_meter2_pll_abc_to_dq_lpf_d__filtered_value = _three_phase_meter2_pll_abc_to_dq_lpf_d__previous_in * (1.0 * 62.83185307 * 0.0001) + _three_phase_meter2_pll_abc_to_dq_lpf_d__previous_filtered_value * (1 - 1.0 * 62.83185307 * 0.0001 );
    _three_phase_meter2_pll_abc_to_dq_lpf_d__out = _three_phase_meter2_pll_abc_to_dq_lpf_d__filtered_value;
    _three_phase_meter2_pll_abc_to_dq_lpf_d__previous_in = _three_phase_meter2_pll_abc_to_dq_alpha_beta_to_dq__d;
    // Generated from the component: Three-phase Meter2.PLL.abc to dq.LPF_q
    _three_phase_meter2_pll_abc_to_dq_lpf_q__previous_filtered_value = _three_phase_meter2_pll_abc_to_dq_lpf_q__filtered_value;
    _three_phase_meter2_pll_abc_to_dq_lpf_q__filtered_value = _three_phase_meter2_pll_abc_to_dq_lpf_q__previous_in * (1.0 * 62.83185307 * 0.0001) + _three_phase_meter2_pll_abc_to_dq_lpf_q__previous_filtered_value * (1 - 1.0 * 62.83185307 * 0.0001 );
    _three_phase_meter2_pll_abc_to_dq_lpf_q__out = _three_phase_meter2_pll_abc_to_dq_lpf_q__filtered_value;
    _three_phase_meter2_pll_abc_to_dq_lpf_q__previous_in = _three_phase_meter2_pll_abc_to_dq_alpha_beta_to_dq__q;
    // Generated from the component: Three-phase Meter3.IA_RMS
    HIL_OutAO(0x402f, (float)_three_phase_meter3_i_rms_calc_rms__RMS1);
    // Generated from the component: Three-phase Meter3.IB_RMS
    HIL_OutAO(0x4030, (float)_three_phase_meter3_i_rms_calc_rms__RMS2);
    // Generated from the component: Three-phase Meter3.IC_RMS
    HIL_OutAO(0x4031, (float)_three_phase_meter3_i_rms_calc_rms__RMS3);
    // Generated from the component: Three-phase Meter3.Power Meter.POWER
    _three_phase_meter3_power_meter_power__Ia = _three_phase_meter3_ia_ia1__out;
    _three_phase_meter3_power_meter_power__Ib = _three_phase_meter3_ib_ia1__out;
    _three_phase_meter3_power_meter_power__Ic = _three_phase_meter3_ic_ia1__out;
    _three_phase_meter3_power_meter_power__IrmsA = _three_phase_meter3_i_rms_calc_rms__RMS1;
    _three_phase_meter3_power_meter_power__IrmsB = _three_phase_meter3_i_rms_calc_rms__RMS2;
    _three_phase_meter3_power_meter_power__IrmsC = _three_phase_meter3_i_rms_calc_rms__RMS3;
    _three_phase_meter3_power_meter_power__Va = _three_phase_meter3_van_va1__out;
    _three_phase_meter3_power_meter_power__Vb = _three_phase_meter3_vbn_va1__out;
    _three_phase_meter3_power_meter_power__Vc = _three_phase_meter3_vcn_va1__out;
    _three_phase_meter3_power_meter_power__VrmsA = _three_phase_meter3_vln_rms_calc_rms__RMS1;
    _three_phase_meter3_power_meter_power__VrmsB = _three_phase_meter3_vln_rms_calc_rms__RMS2;
    _three_phase_meter3_power_meter_power__VrmsC = _three_phase_meter3_vln_rms_calc_rms__RMS3;
    _three_phase_meter3_power_meter_power__dFract = _three_phase_meter3_meassm_mode_and_dfract__dFract;
    _three_phase_meter3_power_meter_power__mode = _three_phase_meter3_meassm_mode_and_dfract__mode;
    _three_phase_meter3_power_meter_power__submode = _three_phase_meter3_meassm_mode_and_dfract__submode;
    switch (_three_phase_meter3_power_meter_power__mode) {
    case 1:
        _three_phase_meter3_power_meter_power__VevenSumA = 0.0;
        _three_phase_meter3_power_meter_power__VoddSumA = 0.0;
        _three_phase_meter3_power_meter_power__VevenSumB = 0.0;
        _three_phase_meter3_power_meter_power__VoddSumB = 0.0;
        _three_phase_meter3_power_meter_power__VevenSumC = 0.0;
        _three_phase_meter3_power_meter_power__VoddSumC = 0.0;
        _three_phase_meter3_power_meter_power__IevenSumA = 0.0;
        _three_phase_meter3_power_meter_power__IoddSumA = 0.0;
        _three_phase_meter3_power_meter_power__IevenSumB = 0.0;
        _three_phase_meter3_power_meter_power__IoddSumB = 0.0;
        _three_phase_meter3_power_meter_power__IevenSumC = 0.0;
        _three_phase_meter3_power_meter_power__IoddSumC = 0.0;
        _three_phase_meter3_power_meter_power__PsumA = 0.0;
        _three_phase_meter3_power_meter_power__PsumB = 0.0;
        _three_phase_meter3_power_meter_power__PsumC = 0.0;
        break ;
    case 2:
        _three_phase_meter3_power_meter_power__Pa = _three_phase_meter3_power_meter_power__Va * _three_phase_meter3_power_meter_power__Ia;
        _three_phase_meter3_power_meter_power__Pb = _three_phase_meter3_power_meter_power__Vb * _three_phase_meter3_power_meter_power__Ib;
        _three_phase_meter3_power_meter_power__Pc = _three_phase_meter3_power_meter_power__Vc * _three_phase_meter3_power_meter_power__Ic;
        _three_phase_meter3_power_meter_power__P = _three_phase_meter3_power_meter_power__Pa + _three_phase_meter3_power_meter_power__Pb + _three_phase_meter3_power_meter_power__Pc;
        _three_phase_meter3_power_meter_power__Qa = 0;
        _three_phase_meter3_power_meter_power__Qb = 0;
        _three_phase_meter3_power_meter_power__Qc = 0;
        _three_phase_meter3_power_meter_power__Q = _three_phase_meter3_power_meter_power__Qa + _three_phase_meter3_power_meter_power__Qb + _three_phase_meter3_power_meter_power__Qc;
        _three_phase_meter3_power_meter_power__Sa = _three_phase_meter3_power_meter_power__Pa;
        _three_phase_meter3_power_meter_power__Sb = _three_phase_meter3_power_meter_power__Pb;
        _three_phase_meter3_power_meter_power__Sc = _three_phase_meter3_power_meter_power__Pc;
        _three_phase_meter3_power_meter_power__S = _three_phase_meter3_power_meter_power__Sa + _three_phase_meter3_power_meter_power__Sb + _three_phase_meter3_power_meter_power__Sc;
        _three_phase_meter3_power_meter_power__PFa = 1.0;
        _three_phase_meter3_power_meter_power__PFb = 1.0;
        _three_phase_meter3_power_meter_power__PFc = 1.0;
        _three_phase_meter3_power_meter_power__PF = 1.0;
        break ;
    case 3:
        _three_phase_meter3_power_meter_power__PsumA += _three_phase_meter3_power_meter_power__dFract * (_three_phase_meter3_power_meter_power__Va * _three_phase_meter3_power_meter_power__Ia);
        _three_phase_meter3_power_meter_power__PsumB += _three_phase_meter3_power_meter_power__dFract * (_three_phase_meter3_power_meter_power__Vb * _three_phase_meter3_power_meter_power__Ib);
        _three_phase_meter3_power_meter_power__PsumC += _three_phase_meter3_power_meter_power__dFract * (_three_phase_meter3_power_meter_power__Vc * _three_phase_meter3_power_meter_power__Ic);
        switch (_three_phase_meter3_power_meter_power__submode) {
        case 1:
            _three_phase_meter3_power_meter_power__VevenSumA += _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Va;
            _three_phase_meter3_power_meter_power__VevenSumB += _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Vb;
            _three_phase_meter3_power_meter_power__VevenSumC += _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Vc;
            _three_phase_meter3_power_meter_power__IevenSumA += _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Ia;
            _three_phase_meter3_power_meter_power__IevenSumB += _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Ib;
            _three_phase_meter3_power_meter_power__IevenSumC += _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Ic;
            _three_phase_meter3_power_meter_power__VoddSumA += _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Va;
            _three_phase_meter3_power_meter_power__VoddSumB += _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Vb;
            _three_phase_meter3_power_meter_power__VoddSumC += _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Vc;
            _three_phase_meter3_power_meter_power__IoddSumA += _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Ia;
            _three_phase_meter3_power_meter_power__IoddSumB += _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Ib;
            _three_phase_meter3_power_meter_power__IoddSumC += _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Ic;
            break ;
        case 2:
            _three_phase_meter3_power_meter_power__VevenSumA -= _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Va;
            _three_phase_meter3_power_meter_power__VevenSumB -= _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Vb;
            _three_phase_meter3_power_meter_power__VevenSumC -= _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Vc;
            _three_phase_meter3_power_meter_power__IevenSumA -= _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Ia;
            _three_phase_meter3_power_meter_power__IevenSumB -= _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Ib;
            _three_phase_meter3_power_meter_power__IevenSumC -= _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Ic;
            _three_phase_meter3_power_meter_power__VoddSumA += _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Va;
            _three_phase_meter3_power_meter_power__VoddSumB += _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Vb;
            _three_phase_meter3_power_meter_power__VoddSumC += _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Vc;
            _three_phase_meter3_power_meter_power__IoddSumA += _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Ia;
            _three_phase_meter3_power_meter_power__IoddSumB += _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Ib;
            _three_phase_meter3_power_meter_power__IoddSumC += _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Ic;
            break ;
        case 3:
            _three_phase_meter3_power_meter_power__VevenSumA -= _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Va;
            _three_phase_meter3_power_meter_power__VevenSumB -= _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Vb;
            _three_phase_meter3_power_meter_power__VevenSumC -= _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Vc;
            _three_phase_meter3_power_meter_power__IevenSumA -= _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Ia;
            _three_phase_meter3_power_meter_power__IevenSumB -= _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Ib;
            _three_phase_meter3_power_meter_power__IevenSumC -= _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Ic;
            _three_phase_meter3_power_meter_power__VoddSumA -= _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Va;
            _three_phase_meter3_power_meter_power__VoddSumB -= _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Vb;
            _three_phase_meter3_power_meter_power__VoddSumC -= _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Vc;
            _three_phase_meter3_power_meter_power__IoddSumA -= _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Ia;
            _three_phase_meter3_power_meter_power__IoddSumB -= _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Ib;
            _three_phase_meter3_power_meter_power__IoddSumC -= _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Ic;
            break ;
        case 4:
            _three_phase_meter3_power_meter_power__VevenSumA += _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Va;
            _three_phase_meter3_power_meter_power__VevenSumB += _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Vb;
            _three_phase_meter3_power_meter_power__VevenSumC += _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Vc;
            _three_phase_meter3_power_meter_power__IevenSumA += _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Ia;
            _three_phase_meter3_power_meter_power__IevenSumB += _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Ib;
            _three_phase_meter3_power_meter_power__IevenSumC += _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Ic;
            _three_phase_meter3_power_meter_power__VoddSumA -= _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Va;
            _three_phase_meter3_power_meter_power__VoddSumB -= _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Vb;
            _three_phase_meter3_power_meter_power__VoddSumC -= _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Vc;
            _three_phase_meter3_power_meter_power__IoddSumA -= _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Ia;
            _three_phase_meter3_power_meter_power__IoddSumB -= _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Ib;
            _three_phase_meter3_power_meter_power__IoddSumC -= _three_phase_meter3_power_meter_power__dFract * _three_phase_meter3_power_meter_power__Ic;
            break ;
        }
        break ;
    case 4:
        _three_phase_meter3_power_meter_power__Pa = _three_phase_meter3_power_meter_power__PsumA;
        _three_phase_meter3_power_meter_power__Pb = _three_phase_meter3_power_meter_power__PsumB;
        _three_phase_meter3_power_meter_power__Pc = _three_phase_meter3_power_meter_power__PsumC;
        _three_phase_meter3_power_meter_power__P = _three_phase_meter3_power_meter_power__Pa + _three_phase_meter3_power_meter_power__Pb + _three_phase_meter3_power_meter_power__Pc;
        _three_phase_meter3_power_meter_power__Sa = _three_phase_meter3_power_meter_power__VrmsA * _three_phase_meter3_power_meter_power__IrmsA;
        _three_phase_meter3_power_meter_power__Sb = _three_phase_meter3_power_meter_power__VrmsB * _three_phase_meter3_power_meter_power__IrmsB;
        _three_phase_meter3_power_meter_power__Sc = _three_phase_meter3_power_meter_power__VrmsC * _three_phase_meter3_power_meter_power__IrmsC;
        _three_phase_meter3_power_meter_power__S = _three_phase_meter3_power_meter_power__Sa + _three_phase_meter3_power_meter_power__Sb + _three_phase_meter3_power_meter_power__Sc;
        _three_phase_meter3_power_meter_power__Qa = _three_phase_meter3_power_meter_power__Sa * _three_phase_meter3_power_meter_power__Sa - _three_phase_meter3_power_meter_power__Pa * _three_phase_meter3_power_meter_power__Pa;
        if (_three_phase_meter3_power_meter_power__Qa < 0.0) {
            _three_phase_meter3_power_meter_power__Qa = 0.0;
        }
        else {
            _three_phase_meter3_power_meter_power__Qa = sqrt(_three_phase_meter3_power_meter_power__Qa);
            if (atan2f((_three_phase_meter3_power_meter_power__VoddSumA * _three_phase_meter3_power_meter_power__IevenSumA - _three_phase_meter3_power_meter_power__IoddSumA * _three_phase_meter3_power_meter_power__VevenSumA), (_three_phase_meter3_power_meter_power__VevenSumA * _three_phase_meter3_power_meter_power__IevenSumA + _three_phase_meter3_power_meter_power__VoddSumA * _three_phase_meter3_power_meter_power__IoddSumA)) > 0.0) {
                _three_phase_meter3_power_meter_power__Qa *= -1;
            }
        }
        _three_phase_meter3_power_meter_power__Qb = _three_phase_meter3_power_meter_power__Sb * _three_phase_meter3_power_meter_power__Sb - _three_phase_meter3_power_meter_power__Pb * _three_phase_meter3_power_meter_power__Pb;
        if (_three_phase_meter3_power_meter_power__Qb < 0.0) {
            _three_phase_meter3_power_meter_power__Qb = 0.0;
        }
        else {
            _three_phase_meter3_power_meter_power__Qb = sqrt(_three_phase_meter3_power_meter_power__Qb);
            if (atan2f((_three_phase_meter3_power_meter_power__VoddSumB * _three_phase_meter3_power_meter_power__IevenSumB - _three_phase_meter3_power_meter_power__IoddSumB * _three_phase_meter3_power_meter_power__VevenSumB), (_three_phase_meter3_power_meter_power__VevenSumB * _three_phase_meter3_power_meter_power__IevenSumB + _three_phase_meter3_power_meter_power__VoddSumB * _three_phase_meter3_power_meter_power__IoddSumB)) > 0.0) {
                _three_phase_meter3_power_meter_power__Qb *= -1;
            }
        }
        _three_phase_meter3_power_meter_power__Qc = _three_phase_meter3_power_meter_power__Sc * _three_phase_meter3_power_meter_power__Sc - _three_phase_meter3_power_meter_power__Pc * _three_phase_meter3_power_meter_power__Pc;
        if (_three_phase_meter3_power_meter_power__Qc < 0.0) {
            _three_phase_meter3_power_meter_power__Qc = 0.0;
        }
        else {
            _three_phase_meter3_power_meter_power__Qc = sqrt(_three_phase_meter3_power_meter_power__Qc);
            if (atan2f((_three_phase_meter3_power_meter_power__VoddSumC * _three_phase_meter3_power_meter_power__IevenSumC - _three_phase_meter3_power_meter_power__IoddSumC * _three_phase_meter3_power_meter_power__VevenSumC), (_three_phase_meter3_power_meter_power__VevenSumC * _three_phase_meter3_power_meter_power__IevenSumC + _three_phase_meter3_power_meter_power__VoddSumC * _three_phase_meter3_power_meter_power__IoddSumC)) > 0.0) {
                _three_phase_meter3_power_meter_power__Qc *= -1;
            }
        }
        _three_phase_meter3_power_meter_power__Q = _three_phase_meter3_power_meter_power__Qa + _three_phase_meter3_power_meter_power__Qb + _three_phase_meter3_power_meter_power__Qc;
        if (_three_phase_meter3_power_meter_power__Sa > 0) {
            _three_phase_meter3_power_meter_power__PFa = _three_phase_meter3_power_meter_power__Pa / _three_phase_meter3_power_meter_power__Sa;
        }
        else {
            _three_phase_meter3_power_meter_power__PFa = 0.0;
        }
        if (_three_phase_meter3_power_meter_power__Sb > 0) {
            _three_phase_meter3_power_meter_power__PFb = _three_phase_meter3_power_meter_power__Pb / _three_phase_meter3_power_meter_power__Sb;
        }
        else {
            _three_phase_meter3_power_meter_power__PFb = 0.0;
        }
        if (_three_phase_meter3_power_meter_power__Sc > 0) {
            _three_phase_meter3_power_meter_power__PFc = _three_phase_meter3_power_meter_power__Pc / _three_phase_meter3_power_meter_power__Sc;
        }
        else {
            _three_phase_meter3_power_meter_power__PFc = 0.0;
        }
        if (_three_phase_meter3_power_meter_power__S > 0) {
            _three_phase_meter3_power_meter_power__PF = _three_phase_meter3_power_meter_power__P / _three_phase_meter3_power_meter_power__S;
        }
        else {
            _three_phase_meter3_power_meter_power__PF = 0.0;
        }
        break ;
    case 5:
        _three_phase_meter3_power_meter_power__Pa = _three_phase_meter3_power_meter_power__Va * _three_phase_meter3_power_meter_power__Ia;
        _three_phase_meter3_power_meter_power__Pb = _three_phase_meter3_power_meter_power__Vb * _three_phase_meter3_power_meter_power__Ib;
        _three_phase_meter3_power_meter_power__Pc = _three_phase_meter3_power_meter_power__Vc * _three_phase_meter3_power_meter_power__Ic;
        _three_phase_meter3_power_meter_power__P = _three_phase_meter3_power_meter_power__Pa + _three_phase_meter3_power_meter_power__Pb + _three_phase_meter3_power_meter_power__Pc;
        _three_phase_meter3_power_meter_power__Qa = 0;
        _three_phase_meter3_power_meter_power__Qb = 0;
        _three_phase_meter3_power_meter_power__Qc = 0;
        _three_phase_meter3_power_meter_power__Q = 0.0;
        _three_phase_meter3_power_meter_power__Sa = 0;
        _three_phase_meter3_power_meter_power__Sb = 0;
        _three_phase_meter3_power_meter_power__Sc = 0;
        _three_phase_meter3_power_meter_power__S = 0;
        _three_phase_meter3_power_meter_power__PFa = 0.0;
        _three_phase_meter3_power_meter_power__PFb = 0.0;
        _three_phase_meter3_power_meter_power__PFc = 0.0;
        _three_phase_meter3_power_meter_power__PF = 0.0;
        break ;
    }
    // Generated from the component: Three-phase Meter3.VAn_RMS
    HIL_OutAO(0x4042, (float)_three_phase_meter3_vln_rms_calc_rms__RMS1);
    // Generated from the component: Three-phase Meter3.VBn_RMS
    HIL_OutAO(0x4043, (float)_three_phase_meter3_vln_rms_calc_rms__RMS2);
    // Generated from the component: Three-phase Meter3.VCn_RMS
    HIL_OutAO(0x4044, (float)_three_phase_meter3_vln_rms_calc_rms__RMS3);
    // Generated from the component: Three-phase Meter3.PLL.abc to dq.LPF_d
    _three_phase_meter3_pll_abc_to_dq_lpf_d__previous_filtered_value = _three_phase_meter3_pll_abc_to_dq_lpf_d__filtered_value;
    _three_phase_meter3_pll_abc_to_dq_lpf_d__filtered_value = _three_phase_meter3_pll_abc_to_dq_lpf_d__previous_in * (1.0 * 62.83185307 * 0.0001) + _three_phase_meter3_pll_abc_to_dq_lpf_d__previous_filtered_value * (1 - 1.0 * 62.83185307 * 0.0001 );
    _three_phase_meter3_pll_abc_to_dq_lpf_d__out = _three_phase_meter3_pll_abc_to_dq_lpf_d__filtered_value;
    _three_phase_meter3_pll_abc_to_dq_lpf_d__previous_in = _three_phase_meter3_pll_abc_to_dq_alpha_beta_to_dq__d;
    // Generated from the component: Three-phase Meter3.PLL.abc to dq.LPF_q
    _three_phase_meter3_pll_abc_to_dq_lpf_q__previous_filtered_value = _three_phase_meter3_pll_abc_to_dq_lpf_q__filtered_value;
    _three_phase_meter3_pll_abc_to_dq_lpf_q__filtered_value = _three_phase_meter3_pll_abc_to_dq_lpf_q__previous_in * (1.0 * 62.83185307 * 0.0001) + _three_phase_meter3_pll_abc_to_dq_lpf_q__previous_filtered_value * (1 - 1.0 * 62.83185307 * 0.0001 );
    _three_phase_meter3_pll_abc_to_dq_lpf_q__out = _three_phase_meter3_pll_abc_to_dq_lpf_q__filtered_value;
    _three_phase_meter3_pll_abc_to_dq_lpf_q__previous_in = _three_phase_meter3_pll_abc_to_dq_alpha_beta_to_dq__q;
    // Generated from the component: Three-phase Meter1.POWER_P
    HIL_OutAO(0x4004, (float)_three_phase_meter1_power_meter_power__P);
    // Generated from the component: Three-phase Meter1.POWER_PA
    HIL_OutAO(0x4005, (float)_three_phase_meter1_power_meter_power__Pa);
    // Generated from the component: Three-phase Meter1.POWER_PB
    HIL_OutAO(0x4006, (float)_three_phase_meter1_power_meter_power__Pb);
    // Generated from the component: Three-phase Meter1.POWER_PC
    HIL_OutAO(0x4007, (float)_three_phase_meter1_power_meter_power__Pc);
    // Generated from the component: Three-phase Meter1.POWER_PF
    HIL_OutAO(0x4008, (float)_three_phase_meter1_power_meter_power__PF);
    // Generated from the component: Three-phase Meter1.POWER_PFA
    HIL_OutAO(0x4009, (float)_three_phase_meter1_power_meter_power__PFa);
    // Generated from the component: Three-phase Meter1.POWER_PFB
    HIL_OutAO(0x400a, (float)_three_phase_meter1_power_meter_power__PFb);
    // Generated from the component: Three-phase Meter1.POWER_PFC
    HIL_OutAO(0x400b, (float)_three_phase_meter1_power_meter_power__PFc);
    // Generated from the component: Three-phase Meter1.POWER_Q
    HIL_OutAO(0x400c, (float)_three_phase_meter1_power_meter_power__Q);
    // Generated from the component: Three-phase Meter1.POWER_QA
    HIL_OutAO(0x400d, (float)_three_phase_meter1_power_meter_power__Qa);
    // Generated from the component: Three-phase Meter1.POWER_QB
    HIL_OutAO(0x400e, (float)_three_phase_meter1_power_meter_power__Qb);
    // Generated from the component: Three-phase Meter1.POWER_QC
    HIL_OutAO(0x400f, (float)_three_phase_meter1_power_meter_power__Qc);
    // Generated from the component: Three-phase Meter1.POWER_S
    HIL_OutAO(0x4010, (float)_three_phase_meter1_power_meter_power__S);
    // Generated from the component: Three-phase Meter1.POWER_SA
    HIL_OutAO(0x4011, (float)_three_phase_meter1_power_meter_power__Sa);
    // Generated from the component: Three-phase Meter1.POWER_SB
    HIL_OutAO(0x4012, (float)_three_phase_meter1_power_meter_power__Sb);
    // Generated from the component: Three-phase Meter1.POWER_SC
    HIL_OutAO(0x4013, (float)_three_phase_meter1_power_meter_power__Sc);
    // Generated from the component: Three-phase Meter1.extra_output_bus
    _three_phase_meter1_extra_output_bus__out[0] = _three_phase_meter1_power_meter_power__Pa;
    _three_phase_meter1_extra_output_bus__out[1] = _three_phase_meter1_power_meter_power__Pb;
    _three_phase_meter1_extra_output_bus__out[2] = _three_phase_meter1_power_meter_power__Pc;
    _three_phase_meter1_extra_output_bus__out[3] = _three_phase_meter1_power_meter_power__Qa;
    _three_phase_meter1_extra_output_bus__out[4] = _three_phase_meter1_power_meter_power__Qb;
    _three_phase_meter1_extra_output_bus__out[5] = _three_phase_meter1_power_meter_power__Qc;
    _three_phase_meter1_extra_output_bus__out[6] = _three_phase_meter1_power_meter_power__Sa;
    _three_phase_meter1_extra_output_bus__out[7] = _three_phase_meter1_power_meter_power__Sb;
    _three_phase_meter1_extra_output_bus__out[8] = _three_phase_meter1_power_meter_power__Sc;
    _three_phase_meter1_extra_output_bus__out[9] = _three_phase_meter1_power_meter_power__PFa;
    _three_phase_meter1_extra_output_bus__out[10] = _three_phase_meter1_power_meter_power__PFb;
    _three_phase_meter1_extra_output_bus__out[11] = _three_phase_meter1_power_meter_power__PFc;
    // Generated from the component: Three-phase Meter1.output_bus
    _three_phase_meter1_output_bus__out[0] = _three_phase_meter1_van_va1__out;
    _three_phase_meter1_output_bus__out[1] = _three_phase_meter1_vbn_va1__out;
    _three_phase_meter1_output_bus__out[2] = _three_phase_meter1_vcn_va1__out;
    _three_phase_meter1_output_bus__out[3] = _three_phase_meter1_vab_va1__out;
    _three_phase_meter1_output_bus__out[4] = _three_phase_meter1_vbc_va1__out;
    _three_phase_meter1_output_bus__out[5] = _three_phase_meter1_vca_va1__out;
    _three_phase_meter1_output_bus__out[6] = _three_phase_meter1_ia_ia1__out;
    _three_phase_meter1_output_bus__out[7] = _three_phase_meter1_ib_ia1__out;
    _three_phase_meter1_output_bus__out[8] = _three_phase_meter1_ic_ia1__out;
    _three_phase_meter1_output_bus__out[9] = _three_phase_meter1_pll_to_hz__out;
    _three_phase_meter1_output_bus__out[10] = _three_phase_meter1_vln_rms_calc_rms__RMS1;
    _three_phase_meter1_output_bus__out[11] = _three_phase_meter1_vln_rms_calc_rms__RMS2;
    _three_phase_meter1_output_bus__out[12] = _three_phase_meter1_vln_rms_calc_rms__RMS3;
    _three_phase_meter1_output_bus__out[13] = _three_phase_meter1_zero__out;
    _three_phase_meter1_output_bus__out[14] = _three_phase_meter1_zero__out;
    _three_phase_meter1_output_bus__out[15] = _three_phase_meter1_zero__out;
    _three_phase_meter1_output_bus__out[16] = _three_phase_meter1_zero__out;
    _three_phase_meter1_output_bus__out[17] = _three_phase_meter1_zero__out;
    _three_phase_meter1_output_bus__out[18] = _three_phase_meter1_i_rms_calc_rms__RMS1;
    _three_phase_meter1_output_bus__out[19] = _three_phase_meter1_i_rms_calc_rms__RMS2;
    _three_phase_meter1_output_bus__out[20] = _three_phase_meter1_i_rms_calc_rms__RMS3;
    _three_phase_meter1_output_bus__out[21] = _three_phase_meter1_zero__out;
    _three_phase_meter1_output_bus__out[22] = _three_phase_meter1_power_meter_power__P;
    _three_phase_meter1_output_bus__out[23] = _three_phase_meter1_power_meter_power__Q;
    _three_phase_meter1_output_bus__out[24] = _three_phase_meter1_power_meter_power__S;
    _three_phase_meter1_output_bus__out[25] = _three_phase_meter1_power_meter_power__PF;
    _three_phase_meter1_output_bus__out[26] = _three_phase_meter1_zero__out;
    _three_phase_meter1_output_bus__out[27] = _three_phase_meter1_zero__out;
    _three_phase_meter1_output_bus__out[28] = _three_phase_meter1_zero__out;
    _three_phase_meter1_output_bus__out[29] = _three_phase_meter1_zero__out;
    // Generated from the component: Three-phase Meter1.TRMd
    // Generated from the component: Three-phase Meter1.PLL.normalize
    _three_phase_meter1_pll_normalize__in1 = _three_phase_meter1_pll_abc_to_dq_lpf_d__out;
    _three_phase_meter1_pll_normalize__in2 = _three_phase_meter1_pll_abc_to_dq_lpf_q__out;
    _three_phase_meter1_pll_normalize__pk = (powf(_three_phase_meter1_pll_normalize__in1, 2.0) + powf(_three_phase_meter1_pll_normalize__in2, 2.0));
    _three_phase_meter1_pll_normalize__pk = sqrt(_three_phase_meter1_pll_normalize__pk);
    if (_three_phase_meter1_pll_normalize__pk < 0.1) {
        _three_phase_meter1_pll_normalize__in2_pu = _three_phase_meter1_pll_normalize__in2 / 0.1;
    }
    else {
        _three_phase_meter1_pll_normalize__in2_pu = _three_phase_meter1_pll_normalize__in2 / _three_phase_meter1_pll_normalize__pk;
    }
    // Generated from the component: Three-phase Meter1.TRMq
    // Generated from the component: Three-phase Meter2.POWER_P
    HIL_OutAO(0x401b, (float)_three_phase_meter2_power_meter_power__P);
    // Generated from the component: Three-phase Meter2.POWER_PA
    HIL_OutAO(0x401c, (float)_three_phase_meter2_power_meter_power__Pa);
    // Generated from the component: Three-phase Meter2.POWER_PB
    HIL_OutAO(0x401d, (float)_three_phase_meter2_power_meter_power__Pb);
    // Generated from the component: Three-phase Meter2.POWER_PC
    HIL_OutAO(0x401e, (float)_three_phase_meter2_power_meter_power__Pc);
    // Generated from the component: Three-phase Meter2.POWER_PF
    HIL_OutAO(0x401f, (float)_three_phase_meter2_power_meter_power__PF);
    // Generated from the component: Three-phase Meter2.POWER_PFA
    HIL_OutAO(0x4020, (float)_three_phase_meter2_power_meter_power__PFa);
    // Generated from the component: Three-phase Meter2.POWER_PFB
    HIL_OutAO(0x4021, (float)_three_phase_meter2_power_meter_power__PFb);
    // Generated from the component: Three-phase Meter2.POWER_PFC
    HIL_OutAO(0x4022, (float)_three_phase_meter2_power_meter_power__PFc);
    // Generated from the component: Three-phase Meter2.POWER_Q
    HIL_OutAO(0x4023, (float)_three_phase_meter2_power_meter_power__Q);
    // Generated from the component: Three-phase Meter2.POWER_QA
    HIL_OutAO(0x4024, (float)_three_phase_meter2_power_meter_power__Qa);
    // Generated from the component: Three-phase Meter2.POWER_QB
    HIL_OutAO(0x4025, (float)_three_phase_meter2_power_meter_power__Qb);
    // Generated from the component: Three-phase Meter2.POWER_QC
    HIL_OutAO(0x4026, (float)_three_phase_meter2_power_meter_power__Qc);
    // Generated from the component: Three-phase Meter2.POWER_S
    HIL_OutAO(0x4027, (float)_three_phase_meter2_power_meter_power__S);
    // Generated from the component: Three-phase Meter2.POWER_SA
    HIL_OutAO(0x4028, (float)_three_phase_meter2_power_meter_power__Sa);
    // Generated from the component: Three-phase Meter2.POWER_SB
    HIL_OutAO(0x4029, (float)_three_phase_meter2_power_meter_power__Sb);
    // Generated from the component: Three-phase Meter2.POWER_SC
    HIL_OutAO(0x402a, (float)_three_phase_meter2_power_meter_power__Sc);
    // Generated from the component: Three-phase Meter2.extra_output_bus
    _three_phase_meter2_extra_output_bus__out[0] = _three_phase_meter2_power_meter_power__Pa;
    _three_phase_meter2_extra_output_bus__out[1] = _three_phase_meter2_power_meter_power__Pb;
    _three_phase_meter2_extra_output_bus__out[2] = _three_phase_meter2_power_meter_power__Pc;
    _three_phase_meter2_extra_output_bus__out[3] = _three_phase_meter2_power_meter_power__Qa;
    _three_phase_meter2_extra_output_bus__out[4] = _three_phase_meter2_power_meter_power__Qb;
    _three_phase_meter2_extra_output_bus__out[5] = _three_phase_meter2_power_meter_power__Qc;
    _three_phase_meter2_extra_output_bus__out[6] = _three_phase_meter2_power_meter_power__Sa;
    _three_phase_meter2_extra_output_bus__out[7] = _three_phase_meter2_power_meter_power__Sb;
    _three_phase_meter2_extra_output_bus__out[8] = _three_phase_meter2_power_meter_power__Sc;
    _three_phase_meter2_extra_output_bus__out[9] = _three_phase_meter2_power_meter_power__PFa;
    _three_phase_meter2_extra_output_bus__out[10] = _three_phase_meter2_power_meter_power__PFb;
    _three_phase_meter2_extra_output_bus__out[11] = _three_phase_meter2_power_meter_power__PFc;
    // Generated from the component: Three-phase Meter2.output_bus
    _three_phase_meter2_output_bus__out[0] = _three_phase_meter2_van_va1__out;
    _three_phase_meter2_output_bus__out[1] = _three_phase_meter2_vbn_va1__out;
    _three_phase_meter2_output_bus__out[2] = _three_phase_meter2_vcn_va1__out;
    _three_phase_meter2_output_bus__out[3] = _three_phase_meter2_zero__out;
    _three_phase_meter2_output_bus__out[4] = _three_phase_meter2_zero__out;
    _three_phase_meter2_output_bus__out[5] = _three_phase_meter2_zero__out;
    _three_phase_meter2_output_bus__out[6] = _three_phase_meter2_ia_ia1__out;
    _three_phase_meter2_output_bus__out[7] = _three_phase_meter2_ib_ia1__out;
    _three_phase_meter2_output_bus__out[8] = _three_phase_meter2_ic_ia1__out;
    _three_phase_meter2_output_bus__out[9] = _three_phase_meter2_pll_to_hz__out;
    _three_phase_meter2_output_bus__out[10] = _three_phase_meter2_vln_rms_calc_rms__RMS1;
    _three_phase_meter2_output_bus__out[11] = _three_phase_meter2_vln_rms_calc_rms__RMS2;
    _three_phase_meter2_output_bus__out[12] = _three_phase_meter2_vln_rms_calc_rms__RMS3;
    _three_phase_meter2_output_bus__out[13] = _three_phase_meter2_zero__out;
    _three_phase_meter2_output_bus__out[14] = _three_phase_meter2_zero__out;
    _three_phase_meter2_output_bus__out[15] = _three_phase_meter2_zero__out;
    _three_phase_meter2_output_bus__out[16] = _three_phase_meter2_zero__out;
    _three_phase_meter2_output_bus__out[17] = _three_phase_meter2_zero__out;
    _three_phase_meter2_output_bus__out[18] = _three_phase_meter2_i_rms_calc_rms__RMS1;
    _three_phase_meter2_output_bus__out[19] = _three_phase_meter2_i_rms_calc_rms__RMS2;
    _three_phase_meter2_output_bus__out[20] = _three_phase_meter2_i_rms_calc_rms__RMS3;
    _three_phase_meter2_output_bus__out[21] = _three_phase_meter2_zero__out;
    _three_phase_meter2_output_bus__out[22] = _three_phase_meter2_power_meter_power__P;
    _three_phase_meter2_output_bus__out[23] = _three_phase_meter2_power_meter_power__Q;
    _three_phase_meter2_output_bus__out[24] = _three_phase_meter2_power_meter_power__S;
    _three_phase_meter2_output_bus__out[25] = _three_phase_meter2_power_meter_power__PF;
    _three_phase_meter2_output_bus__out[26] = _three_phase_meter2_zero__out;
    _three_phase_meter2_output_bus__out[27] = _three_phase_meter2_zero__out;
    _three_phase_meter2_output_bus__out[28] = _three_phase_meter2_zero__out;
    _three_phase_meter2_output_bus__out[29] = _three_phase_meter2_zero__out;
    // Generated from the component: Three-phase Meter2.TRMd
    // Generated from the component: Three-phase Meter2.PLL.normalize
    _three_phase_meter2_pll_normalize__in1 = _three_phase_meter2_pll_abc_to_dq_lpf_d__out;
    _three_phase_meter2_pll_normalize__in2 = _three_phase_meter2_pll_abc_to_dq_lpf_q__out;
    _three_phase_meter2_pll_normalize__pk = (powf(_three_phase_meter2_pll_normalize__in1, 2.0) + powf(_three_phase_meter2_pll_normalize__in2, 2.0));
    _three_phase_meter2_pll_normalize__pk = sqrt(_three_phase_meter2_pll_normalize__pk);
    if (_three_phase_meter2_pll_normalize__pk < 0.1) {
        _three_phase_meter2_pll_normalize__in2_pu = _three_phase_meter2_pll_normalize__in2 / 0.1;
    }
    else {
        _three_phase_meter2_pll_normalize__in2_pu = _three_phase_meter2_pll_normalize__in2 / _three_phase_meter2_pll_normalize__pk;
    }
    // Generated from the component: Three-phase Meter2.TRMq
    // Generated from the component: Three-phase Meter3.POWER_P
    HIL_OutAO(0x4032, (float)_three_phase_meter3_power_meter_power__P);
    // Generated from the component: Three-phase Meter3.POWER_PA
    HIL_OutAO(0x4033, (float)_three_phase_meter3_power_meter_power__Pa);
    // Generated from the component: Three-phase Meter3.POWER_PB
    HIL_OutAO(0x4034, (float)_three_phase_meter3_power_meter_power__Pb);
    // Generated from the component: Three-phase Meter3.POWER_PC
    HIL_OutAO(0x4035, (float)_three_phase_meter3_power_meter_power__Pc);
    // Generated from the component: Three-phase Meter3.POWER_PF
    HIL_OutAO(0x4036, (float)_three_phase_meter3_power_meter_power__PF);
    // Generated from the component: Three-phase Meter3.POWER_PFA
    HIL_OutAO(0x4037, (float)_three_phase_meter3_power_meter_power__PFa);
    // Generated from the component: Three-phase Meter3.POWER_PFB
    HIL_OutAO(0x4038, (float)_three_phase_meter3_power_meter_power__PFb);
    // Generated from the component: Three-phase Meter3.POWER_PFC
    HIL_OutAO(0x4039, (float)_three_phase_meter3_power_meter_power__PFc);
    // Generated from the component: Three-phase Meter3.POWER_Q
    HIL_OutAO(0x403a, (float)_three_phase_meter3_power_meter_power__Q);
    // Generated from the component: Three-phase Meter3.POWER_QA
    HIL_OutAO(0x403b, (float)_three_phase_meter3_power_meter_power__Qa);
    // Generated from the component: Three-phase Meter3.POWER_QB
    HIL_OutAO(0x403c, (float)_three_phase_meter3_power_meter_power__Qb);
    // Generated from the component: Three-phase Meter3.POWER_QC
    HIL_OutAO(0x403d, (float)_three_phase_meter3_power_meter_power__Qc);
    // Generated from the component: Three-phase Meter3.POWER_S
    HIL_OutAO(0x403e, (float)_three_phase_meter3_power_meter_power__S);
    // Generated from the component: Three-phase Meter3.POWER_SA
    HIL_OutAO(0x403f, (float)_three_phase_meter3_power_meter_power__Sa);
    // Generated from the component: Three-phase Meter3.POWER_SB
    HIL_OutAO(0x4040, (float)_three_phase_meter3_power_meter_power__Sb);
    // Generated from the component: Three-phase Meter3.POWER_SC
    HIL_OutAO(0x4041, (float)_three_phase_meter3_power_meter_power__Sc);
    // Generated from the component: Three-phase Meter3.extra_output_bus
    _three_phase_meter3_extra_output_bus__out[0] = _three_phase_meter3_power_meter_power__Pa;
    _three_phase_meter3_extra_output_bus__out[1] = _three_phase_meter3_power_meter_power__Pb;
    _three_phase_meter3_extra_output_bus__out[2] = _three_phase_meter3_power_meter_power__Pc;
    _three_phase_meter3_extra_output_bus__out[3] = _three_phase_meter3_power_meter_power__Qa;
    _three_phase_meter3_extra_output_bus__out[4] = _three_phase_meter3_power_meter_power__Qb;
    _three_phase_meter3_extra_output_bus__out[5] = _three_phase_meter3_power_meter_power__Qc;
    _three_phase_meter3_extra_output_bus__out[6] = _three_phase_meter3_power_meter_power__Sa;
    _three_phase_meter3_extra_output_bus__out[7] = _three_phase_meter3_power_meter_power__Sb;
    _three_phase_meter3_extra_output_bus__out[8] = _three_phase_meter3_power_meter_power__Sc;
    _three_phase_meter3_extra_output_bus__out[9] = _three_phase_meter3_power_meter_power__PFa;
    _three_phase_meter3_extra_output_bus__out[10] = _three_phase_meter3_power_meter_power__PFb;
    _three_phase_meter3_extra_output_bus__out[11] = _three_phase_meter3_power_meter_power__PFc;
    // Generated from the component: Three-phase Meter3.output_bus
    _three_phase_meter3_output_bus__out[0] = _three_phase_meter3_van_va1__out;
    _three_phase_meter3_output_bus__out[1] = _three_phase_meter3_vbn_va1__out;
    _three_phase_meter3_output_bus__out[2] = _three_phase_meter3_vcn_va1__out;
    _three_phase_meter3_output_bus__out[3] = _three_phase_meter3_zero__out;
    _three_phase_meter3_output_bus__out[4] = _three_phase_meter3_zero__out;
    _three_phase_meter3_output_bus__out[5] = _three_phase_meter3_zero__out;
    _three_phase_meter3_output_bus__out[6] = _three_phase_meter3_ia_ia1__out;
    _three_phase_meter3_output_bus__out[7] = _three_phase_meter3_ib_ia1__out;
    _three_phase_meter3_output_bus__out[8] = _three_phase_meter3_ic_ia1__out;
    _three_phase_meter3_output_bus__out[9] = _three_phase_meter3_pll_to_hz__out;
    _three_phase_meter3_output_bus__out[10] = _three_phase_meter3_vln_rms_calc_rms__RMS1;
    _three_phase_meter3_output_bus__out[11] = _three_phase_meter3_vln_rms_calc_rms__RMS2;
    _three_phase_meter3_output_bus__out[12] = _three_phase_meter3_vln_rms_calc_rms__RMS3;
    _three_phase_meter3_output_bus__out[13] = _three_phase_meter3_zero__out;
    _three_phase_meter3_output_bus__out[14] = _three_phase_meter3_zero__out;
    _three_phase_meter3_output_bus__out[15] = _three_phase_meter3_zero__out;
    _three_phase_meter3_output_bus__out[16] = _three_phase_meter3_zero__out;
    _three_phase_meter3_output_bus__out[17] = _three_phase_meter3_zero__out;
    _three_phase_meter3_output_bus__out[18] = _three_phase_meter3_i_rms_calc_rms__RMS1;
    _three_phase_meter3_output_bus__out[19] = _three_phase_meter3_i_rms_calc_rms__RMS2;
    _three_phase_meter3_output_bus__out[20] = _three_phase_meter3_i_rms_calc_rms__RMS3;
    _three_phase_meter3_output_bus__out[21] = _three_phase_meter3_zero__out;
    _three_phase_meter3_output_bus__out[22] = _three_phase_meter3_power_meter_power__P;
    _three_phase_meter3_output_bus__out[23] = _three_phase_meter3_power_meter_power__Q;
    _three_phase_meter3_output_bus__out[24] = _three_phase_meter3_power_meter_power__S;
    _three_phase_meter3_output_bus__out[25] = _three_phase_meter3_power_meter_power__PF;
    _three_phase_meter3_output_bus__out[26] = _three_phase_meter3_zero__out;
    _three_phase_meter3_output_bus__out[27] = _three_phase_meter3_zero__out;
    _three_phase_meter3_output_bus__out[28] = _three_phase_meter3_zero__out;
    _three_phase_meter3_output_bus__out[29] = _three_phase_meter3_zero__out;
    // Generated from the component: Three-phase Meter3.TRMd
    // Generated from the component: Three-phase Meter3.PLL.normalize
    _three_phase_meter3_pll_normalize__in1 = _three_phase_meter3_pll_abc_to_dq_lpf_d__out;
    _three_phase_meter3_pll_normalize__in2 = _three_phase_meter3_pll_abc_to_dq_lpf_q__out;
    _three_phase_meter3_pll_normalize__pk = (powf(_three_phase_meter3_pll_normalize__in1, 2.0) + powf(_three_phase_meter3_pll_normalize__in2, 2.0));
    _three_phase_meter3_pll_normalize__pk = sqrt(_three_phase_meter3_pll_normalize__pk);
    if (_three_phase_meter3_pll_normalize__pk < 0.1) {
        _three_phase_meter3_pll_normalize__in2_pu = _three_phase_meter3_pll_normalize__in2 / 0.1;
    }
    else {
        _three_phase_meter3_pll_normalize__in2_pu = _three_phase_meter3_pll_normalize__in2 / _three_phase_meter3_pll_normalize__pk;
    }
    // Generated from the component: Three-phase Meter3.TRMq
    // Generated from the component: Three-phase Meter1.extra_out
    // Generated from the component: Three-phase Meter1.PLL.PID.Kd
    _three_phase_meter1_pll_pid_kd__out = 1.0 * _three_phase_meter1_pll_normalize__in2_pu;
    // Generated from the component: Three-phase Meter1.PLL.PID.Ki
    _three_phase_meter1_pll_pid_ki__out = 3200.0 * _three_phase_meter1_pll_normalize__in2_pu;
    // Generated from the component: Three-phase Meter1.PLL.PID.Kp
    _three_phase_meter1_pll_pid_kp__out = 100.0 * _three_phase_meter1_pll_normalize__in2_pu;
    // Generated from the component: Three-phase Meter1.PLL.term_pk
    // Generated from the component: Three-phase Meter2.extra_out
    // Generated from the component: Three-phase Meter2.PLL.PID.Kd
    _three_phase_meter2_pll_pid_kd__out = 1.0 * _three_phase_meter2_pll_normalize__in2_pu;
    // Generated from the component: Three-phase Meter2.PLL.PID.Ki
    _three_phase_meter2_pll_pid_ki__out = 3200.0 * _three_phase_meter2_pll_normalize__in2_pu;
    // Generated from the component: Three-phase Meter2.PLL.PID.Kp
    _three_phase_meter2_pll_pid_kp__out = 100.0 * _three_phase_meter2_pll_normalize__in2_pu;
    // Generated from the component: Three-phase Meter2.PLL.term_pk
    // Generated from the component: Three-phase Meter3.extra_out
    // Generated from the component: Three-phase Meter3.PLL.PID.Kd
    _three_phase_meter3_pll_pid_kd__out = 1.0 * _three_phase_meter3_pll_normalize__in2_pu;
    // Generated from the component: Three-phase Meter3.PLL.PID.Ki
    _three_phase_meter3_pll_pid_ki__out = 3200.0 * _three_phase_meter3_pll_normalize__in2_pu;
    // Generated from the component: Three-phase Meter3.PLL.PID.Kp
    _three_phase_meter3_pll_pid_kp__out = 100.0 * _three_phase_meter3_pll_normalize__in2_pu;
    // Generated from the component: Three-phase Meter3.PLL.term_pk
    // Generated from the component: Three-phase Meter1.PLL.PID.Sum8
    _three_phase_meter1_pll_pid_sum8__out = _three_phase_meter1_pll_pid_kd__out - _three_phase_meter1_pll_pid_integrator2__out;
    // Generated from the component: Three-phase Meter2.PLL.PID.Sum8
    _three_phase_meter2_pll_pid_sum8__out = _three_phase_meter2_pll_pid_kd__out - _three_phase_meter2_pll_pid_integrator2__out;
    // Generated from the component: Three-phase Meter3.PLL.PID.Sum8
    _three_phase_meter3_pll_pid_sum8__out = _three_phase_meter3_pll_pid_kd__out - _three_phase_meter3_pll_pid_integrator2__out;
    // Generated from the component: Three-phase Meter1.PLL.PID.Gain1
    _three_phase_meter1_pll_pid_gain1__out = 714.2857 * _three_phase_meter1_pll_pid_sum8__out;
    // Generated from the component: Three-phase Meter2.PLL.PID.Gain1
    _three_phase_meter2_pll_pid_gain1__out = 714.2857 * _three_phase_meter2_pll_pid_sum8__out;
    // Generated from the component: Three-phase Meter3.PLL.PID.Gain1
    _three_phase_meter3_pll_pid_gain1__out = 714.2857 * _three_phase_meter3_pll_pid_sum8__out;
    // Generated from the component: Three-phase Meter1.PLL.PID.Sum5
    _three_phase_meter1_pll_pid_sum5__out = _three_phase_meter1_pll_pid_kp__out + _three_phase_meter1_pll_pid_gain1__out + _three_phase_meter1_pll_pid_integrator1__out;
    // Generated from the component: Three-phase Meter2.PLL.PID.Sum5
    _three_phase_meter2_pll_pid_sum5__out = _three_phase_meter2_pll_pid_kp__out + _three_phase_meter2_pll_pid_gain1__out + _three_phase_meter2_pll_pid_integrator1__out;
    // Generated from the component: Three-phase Meter3.PLL.PID.Sum5
    _three_phase_meter3_pll_pid_sum5__out = _three_phase_meter3_pll_pid_kp__out + _three_phase_meter3_pll_pid_gain1__out + _three_phase_meter3_pll_pid_integrator1__out;
    // Generated from the component: Three-phase Meter1.PLL.PID.Limit1
    _three_phase_meter1_pll_pid_limit1__out = MIN(MAX(_three_phase_meter1_pll_pid_sum5__out, -10000.0), 10000.0);
    // Generated from the component: Three-phase Meter2.PLL.PID.Limit1
    _three_phase_meter2_pll_pid_limit1__out = MIN(MAX(_three_phase_meter2_pll_pid_sum5__out, -10000.0), 10000.0);
    // Generated from the component: Three-phase Meter3.PLL.PID.Limit1
    _three_phase_meter3_pll_pid_limit1__out = MIN(MAX(_three_phase_meter3_pll_pid_sum5__out, -10000.0), 10000.0);
    // Generated from the component: Three-phase Meter1.PLL.PID.Sum6
    _three_phase_meter1_pll_pid_sum6__out =  - _three_phase_meter1_pll_pid_sum5__out + _three_phase_meter1_pll_pid_limit1__out;
    // Generated from the component: Three-phase Meter1.PLL.Rate Limiter1
    if (_three_phase_meter1_pll_rate_limiter1__first_step) {
        _three_phase_meter1_pll_rate_limiter1__out = _three_phase_meter1_pll_pid_limit1__out;
        _three_phase_meter1_pll_rate_limiter1__state = _three_phase_meter1_pll_pid_limit1__out;
    } else {
        _three_phase_meter1_pll_rate_limiter1__out = _three_phase_meter1_pll_pid_limit1__out;
        if (_three_phase_meter1_pll_pid_limit1__out - _three_phase_meter1_pll_rate_limiter1__state > 0.007539822368615503)
            _three_phase_meter1_pll_rate_limiter1__out = _three_phase_meter1_pll_rate_limiter1__state + (0.007539822368615503);
        if (_three_phase_meter1_pll_pid_limit1__out - _three_phase_meter1_pll_rate_limiter1__state < -0.007539822368615503)
            _three_phase_meter1_pll_rate_limiter1__out = _three_phase_meter1_pll_rate_limiter1__state + (-0.007539822368615503);
    }
    // Generated from the component: Three-phase Meter1.PLL.integrator
    _three_phase_meter1_pll_integrator__in = _three_phase_meter1_pll_pid_limit1__out;
    _three_phase_meter1_pll_integrator__out += 0.0001 * _three_phase_meter1_pll_integrator__in;
    if (_three_phase_meter1_pll_integrator__in >= 0.0) {
        if (_three_phase_meter1_pll_integrator__out >= 6.283185307179586) {
            _three_phase_meter1_pll_integrator__out -= 6.283185307179586;
        }
    }
    else {
        if (_three_phase_meter1_pll_integrator__out <= -6.283185307179586) {
            _three_phase_meter1_pll_integrator__out += 6.283185307179586;
        }
    }
    // Generated from the component: Three-phase Meter2.PLL.PID.Sum6
    _three_phase_meter2_pll_pid_sum6__out =  - _three_phase_meter2_pll_pid_sum5__out + _three_phase_meter2_pll_pid_limit1__out;
    // Generated from the component: Three-phase Meter2.PLL.Rate Limiter1
    if (_three_phase_meter2_pll_rate_limiter1__first_step) {
        _three_phase_meter2_pll_rate_limiter1__out = _three_phase_meter2_pll_pid_limit1__out;
        _three_phase_meter2_pll_rate_limiter1__state = _three_phase_meter2_pll_pid_limit1__out;
    } else {
        _three_phase_meter2_pll_rate_limiter1__out = _three_phase_meter2_pll_pid_limit1__out;
        if (_three_phase_meter2_pll_pid_limit1__out - _three_phase_meter2_pll_rate_limiter1__state > 0.007539822368615503)
            _three_phase_meter2_pll_rate_limiter1__out = _three_phase_meter2_pll_rate_limiter1__state + (0.007539822368615503);
        if (_three_phase_meter2_pll_pid_limit1__out - _three_phase_meter2_pll_rate_limiter1__state < -0.007539822368615503)
            _three_phase_meter2_pll_rate_limiter1__out = _three_phase_meter2_pll_rate_limiter1__state + (-0.007539822368615503);
    }
    // Generated from the component: Three-phase Meter2.PLL.integrator
    _three_phase_meter2_pll_integrator__in = _three_phase_meter2_pll_pid_limit1__out;
    _three_phase_meter2_pll_integrator__out += 0.0001 * _three_phase_meter2_pll_integrator__in;
    if (_three_phase_meter2_pll_integrator__in >= 0.0) {
        if (_three_phase_meter2_pll_integrator__out >= 6.283185307179586) {
            _three_phase_meter2_pll_integrator__out -= 6.283185307179586;
        }
    }
    else {
        if (_three_phase_meter2_pll_integrator__out <= -6.283185307179586) {
            _three_phase_meter2_pll_integrator__out += 6.283185307179586;
        }
    }
    // Generated from the component: Three-phase Meter3.PLL.PID.Sum6
    _three_phase_meter3_pll_pid_sum6__out =  - _three_phase_meter3_pll_pid_sum5__out + _three_phase_meter3_pll_pid_limit1__out;
    // Generated from the component: Three-phase Meter3.PLL.Rate Limiter1
    if (_three_phase_meter3_pll_rate_limiter1__first_step) {
        _three_phase_meter3_pll_rate_limiter1__out = _three_phase_meter3_pll_pid_limit1__out;
        _three_phase_meter3_pll_rate_limiter1__state = _three_phase_meter3_pll_pid_limit1__out;
    } else {
        _three_phase_meter3_pll_rate_limiter1__out = _three_phase_meter3_pll_pid_limit1__out;
        if (_three_phase_meter3_pll_pid_limit1__out - _three_phase_meter3_pll_rate_limiter1__state > 0.007539822368615503)
            _three_phase_meter3_pll_rate_limiter1__out = _three_phase_meter3_pll_rate_limiter1__state + (0.007539822368615503);
        if (_three_phase_meter3_pll_pid_limit1__out - _three_phase_meter3_pll_rate_limiter1__state < -0.007539822368615503)
            _three_phase_meter3_pll_rate_limiter1__out = _three_phase_meter3_pll_rate_limiter1__state + (-0.007539822368615503);
    }
    // Generated from the component: Three-phase Meter3.PLL.integrator
    _three_phase_meter3_pll_integrator__in = _three_phase_meter3_pll_pid_limit1__out;
    _three_phase_meter3_pll_integrator__out += 0.0001 * _three_phase_meter3_pll_integrator__in;
    if (_three_phase_meter3_pll_integrator__in >= 0.0) {
        if (_three_phase_meter3_pll_integrator__out >= 6.283185307179586) {
            _three_phase_meter3_pll_integrator__out -= 6.283185307179586;
        }
    }
    else {
        if (_three_phase_meter3_pll_integrator__out <= -6.283185307179586) {
            _three_phase_meter3_pll_integrator__out += 6.283185307179586;
        }
    }
    // Generated from the component: Three-phase Meter1.PLL.PID.Kb
    _three_phase_meter1_pll_pid_kb__out = 1.0 * _three_phase_meter1_pll_pid_sum6__out;
    // Generated from the component: Three-phase Meter1.PLL.LPF.LPF
    X_UnInt32 _three_phase_meter1_pll_lpf_lpf__i;
    _three_phase_meter1_pll_lpf_lpf__a_sum = 0.0f;
    _three_phase_meter1_pll_lpf_lpf__b_sum = 0.0f;
    _three_phase_meter1_pll_lpf_lpf__delay_line_in = 0.0f;
    for (_three_phase_meter1_pll_lpf_lpf__i = 0; _three_phase_meter1_pll_lpf_lpf__i < 2; _three_phase_meter1_pll_lpf_lpf__i++) {
        _three_phase_meter1_pll_lpf_lpf__b_sum += _three_phase_meter1_pll_lpf_lpf__b_coeff[_three_phase_meter1_pll_lpf_lpf__i] * _three_phase_meter1_pll_lpf_lpf__states[_three_phase_meter1_pll_lpf_lpf__i + 0];
    }
    for (_three_phase_meter1_pll_lpf_lpf__i = 1; _three_phase_meter1_pll_lpf_lpf__i > 0; _three_phase_meter1_pll_lpf_lpf__i--) {
        _three_phase_meter1_pll_lpf_lpf__a_sum += _three_phase_meter1_pll_lpf_lpf__a_coeff[_three_phase_meter1_pll_lpf_lpf__i + 1] * _three_phase_meter1_pll_lpf_lpf__states[_three_phase_meter1_pll_lpf_lpf__i];
    }
    _three_phase_meter1_pll_lpf_lpf__a_sum += _three_phase_meter1_pll_lpf_lpf__states[0] * _three_phase_meter1_pll_lpf_lpf__a_coeff[1];
    _three_phase_meter1_pll_lpf_lpf__delay_line_in = _three_phase_meter1_pll_rate_limiter1__out - _three_phase_meter1_pll_lpf_lpf__a_sum;
    _three_phase_meter1_pll_lpf_lpf__out = _three_phase_meter1_pll_lpf_lpf__b_sum;
    // Generated from the component: Three-phase Meter2.PLL.PID.Kb
    _three_phase_meter2_pll_pid_kb__out = 1.0 * _three_phase_meter2_pll_pid_sum6__out;
    // Generated from the component: Three-phase Meter2.PLL.LPF.LPF
    X_UnInt32 _three_phase_meter2_pll_lpf_lpf__i;
    _three_phase_meter2_pll_lpf_lpf__a_sum = 0.0f;
    _three_phase_meter2_pll_lpf_lpf__b_sum = 0.0f;
    _three_phase_meter2_pll_lpf_lpf__delay_line_in = 0.0f;
    for (_three_phase_meter2_pll_lpf_lpf__i = 0; _three_phase_meter2_pll_lpf_lpf__i < 2; _three_phase_meter2_pll_lpf_lpf__i++) {
        _three_phase_meter2_pll_lpf_lpf__b_sum += _three_phase_meter2_pll_lpf_lpf__b_coeff[_three_phase_meter2_pll_lpf_lpf__i] * _three_phase_meter2_pll_lpf_lpf__states[_three_phase_meter2_pll_lpf_lpf__i + 0];
    }
    for (_three_phase_meter2_pll_lpf_lpf__i = 1; _three_phase_meter2_pll_lpf_lpf__i > 0; _three_phase_meter2_pll_lpf_lpf__i--) {
        _three_phase_meter2_pll_lpf_lpf__a_sum += _three_phase_meter2_pll_lpf_lpf__a_coeff[_three_phase_meter2_pll_lpf_lpf__i + 1] * _three_phase_meter2_pll_lpf_lpf__states[_three_phase_meter2_pll_lpf_lpf__i];
    }
    _three_phase_meter2_pll_lpf_lpf__a_sum += _three_phase_meter2_pll_lpf_lpf__states[0] * _three_phase_meter2_pll_lpf_lpf__a_coeff[1];
    _three_phase_meter2_pll_lpf_lpf__delay_line_in = _three_phase_meter2_pll_rate_limiter1__out - _three_phase_meter2_pll_lpf_lpf__a_sum;
    _three_phase_meter2_pll_lpf_lpf__out = _three_phase_meter2_pll_lpf_lpf__b_sum;
    // Generated from the component: Three-phase Meter3.PLL.PID.Kb
    _three_phase_meter3_pll_pid_kb__out = 1.0 * _three_phase_meter3_pll_pid_sum6__out;
    // Generated from the component: Three-phase Meter3.PLL.LPF.LPF
    X_UnInt32 _three_phase_meter3_pll_lpf_lpf__i;
    _three_phase_meter3_pll_lpf_lpf__a_sum = 0.0f;
    _three_phase_meter3_pll_lpf_lpf__b_sum = 0.0f;
    _three_phase_meter3_pll_lpf_lpf__delay_line_in = 0.0f;
    for (_three_phase_meter3_pll_lpf_lpf__i = 0; _three_phase_meter3_pll_lpf_lpf__i < 2; _three_phase_meter3_pll_lpf_lpf__i++) {
        _three_phase_meter3_pll_lpf_lpf__b_sum += _three_phase_meter3_pll_lpf_lpf__b_coeff[_three_phase_meter3_pll_lpf_lpf__i] * _three_phase_meter3_pll_lpf_lpf__states[_three_phase_meter3_pll_lpf_lpf__i + 0];
    }
    for (_three_phase_meter3_pll_lpf_lpf__i = 1; _three_phase_meter3_pll_lpf_lpf__i > 0; _three_phase_meter3_pll_lpf_lpf__i--) {
        _three_phase_meter3_pll_lpf_lpf__a_sum += _three_phase_meter3_pll_lpf_lpf__a_coeff[_three_phase_meter3_pll_lpf_lpf__i + 1] * _three_phase_meter3_pll_lpf_lpf__states[_three_phase_meter3_pll_lpf_lpf__i];
    }
    _three_phase_meter3_pll_lpf_lpf__a_sum += _three_phase_meter3_pll_lpf_lpf__states[0] * _three_phase_meter3_pll_lpf_lpf__a_coeff[1];
    _three_phase_meter3_pll_lpf_lpf__delay_line_in = _three_phase_meter3_pll_rate_limiter1__out - _three_phase_meter3_pll_lpf_lpf__a_sum;
    _three_phase_meter3_pll_lpf_lpf__out = _three_phase_meter3_pll_lpf_lpf__b_sum;
    // Generated from the component: Three-phase Meter1.PLL.PID.Sum7
    _three_phase_meter1_pll_pid_sum7__out = _three_phase_meter1_pll_pid_ki__out + _three_phase_meter1_pll_pid_kb__out;
    // Generated from the component: Three-phase Meter2.PLL.PID.Sum7
    _three_phase_meter2_pll_pid_sum7__out = _three_phase_meter2_pll_pid_ki__out + _three_phase_meter2_pll_pid_kb__out;
    // Generated from the component: Three-phase Meter3.PLL.PID.Sum7
    _three_phase_meter3_pll_pid_sum7__out = _three_phase_meter3_pll_pid_ki__out + _three_phase_meter3_pll_pid_kb__out;
//@cmp.out.block.end
    //////////////////////////////////////////////////////////////////////////
    // Update block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.update.block.start
    // Generated from the component: Three-phase Meter1.PLL.PID.Integrator1
    _three_phase_meter1_pll_pid_integrator1__state += _three_phase_meter1_pll_pid_sum7__out * 0.0001;
    // Generated from the component: Three-phase Meter1.PLL.PID.Integrator2
    _three_phase_meter1_pll_pid_integrator2__state += _three_phase_meter1_pll_pid_gain1__out * 0.0001;
    // Generated from the component: Three-phase Meter1.PLL.Unit Delay1
    _three_phase_meter1_pll_unit_delay1__state = _three_phase_meter1_pll_integrator__out;
    // Generated from the component: Three-phase Meter2.PLL.PID.Integrator1
    _three_phase_meter2_pll_pid_integrator1__state += _three_phase_meter2_pll_pid_sum7__out * 0.0001;
    // Generated from the component: Three-phase Meter2.PLL.PID.Integrator2
    _three_phase_meter2_pll_pid_integrator2__state += _three_phase_meter2_pll_pid_gain1__out * 0.0001;
    // Generated from the component: Three-phase Meter2.PLL.Unit Delay1
    _three_phase_meter2_pll_unit_delay1__state = _three_phase_meter2_pll_integrator__out;
    // Generated from the component: Three-phase Meter3.PLL.PID.Integrator1
    _three_phase_meter3_pll_pid_integrator1__state += _three_phase_meter3_pll_pid_sum7__out * 0.0001;
    // Generated from the component: Three-phase Meter3.PLL.PID.Integrator2
    _three_phase_meter3_pll_pid_integrator2__state += _three_phase_meter3_pll_pid_gain1__out * 0.0001;
    // Generated from the component: Three-phase Meter3.PLL.Unit Delay1
    _three_phase_meter3_pll_unit_delay1__state = _three_phase_meter3_pll_integrator__out;
    // Generated from the component: Three-phase Meter1.measSM.mode_and_dFract
    // Generated from the component: Three-phase Meter2.measSM.mode_and_dFract
    // Generated from the component: Three-phase Meter3.measSM.mode_and_dFract
    // Generated from the component: Three-phase Meter1.I_RMS_calc.RMS
    // Generated from the component: Three-phase Meter1.VLn_RMS_calc.RMS
    // Generated from the component: Three-phase Meter2.I_RMS_calc.RMS
    // Generated from the component: Three-phase Meter2.VLn_RMS_calc.RMS
    // Generated from the component: Three-phase Meter3.I_RMS_calc.RMS
    // Generated from the component: Three-phase Meter3.VLn_RMS_calc.RMS
    // Generated from the component: Three-phase Meter1.Power Meter.POWER
    // Generated from the component: Three-phase Meter2.Power Meter.POWER
    // Generated from the component: Three-phase Meter3.Power Meter.POWER
    // Generated from the component: Three-phase Meter1.PLL.normalize
    // Generated from the component: Three-phase Meter2.PLL.normalize
    // Generated from the component: Three-phase Meter3.PLL.normalize
    // Generated from the component: Three-phase Meter1.PLL.Rate Limiter1
    if (_three_phase_meter1_pll_pid_limit1__out - _three_phase_meter1_pll_rate_limiter1__state > 0.007539822368615503)
        _three_phase_meter1_pll_rate_limiter1__state += (0.007539822368615503);
    else  if (_three_phase_meter1_pll_pid_limit1__out - _three_phase_meter1_pll_rate_limiter1__state < -0.007539822368615503)
        _three_phase_meter1_pll_rate_limiter1__state += (-0.007539822368615503);
    else
        _three_phase_meter1_pll_rate_limiter1__state = _three_phase_meter1_pll_pid_limit1__out;
    _three_phase_meter1_pll_rate_limiter1__first_step = 0;
    // Generated from the component: Three-phase Meter1.PLL.integrator
    // Generated from the component: Three-phase Meter2.PLL.Rate Limiter1
    if (_three_phase_meter2_pll_pid_limit1__out - _three_phase_meter2_pll_rate_limiter1__state > 0.007539822368615503)
        _three_phase_meter2_pll_rate_limiter1__state += (0.007539822368615503);
    else  if (_three_phase_meter2_pll_pid_limit1__out - _three_phase_meter2_pll_rate_limiter1__state < -0.007539822368615503)
        _three_phase_meter2_pll_rate_limiter1__state += (-0.007539822368615503);
    else
        _three_phase_meter2_pll_rate_limiter1__state = _three_phase_meter2_pll_pid_limit1__out;
    _three_phase_meter2_pll_rate_limiter1__first_step = 0;
    // Generated from the component: Three-phase Meter2.PLL.integrator
    // Generated from the component: Three-phase Meter3.PLL.Rate Limiter1
    if (_three_phase_meter3_pll_pid_limit1__out - _three_phase_meter3_pll_rate_limiter1__state > 0.007539822368615503)
        _three_phase_meter3_pll_rate_limiter1__state += (0.007539822368615503);
    else  if (_three_phase_meter3_pll_pid_limit1__out - _three_phase_meter3_pll_rate_limiter1__state < -0.007539822368615503)
        _three_phase_meter3_pll_rate_limiter1__state += (-0.007539822368615503);
    else
        _three_phase_meter3_pll_rate_limiter1__state = _three_phase_meter3_pll_pid_limit1__out;
    _three_phase_meter3_pll_rate_limiter1__first_step = 0;
    // Generated from the component: Three-phase Meter3.PLL.integrator
    // Generated from the component: Three-phase Meter1.PLL.LPF.LPF
    for (_three_phase_meter1_pll_lpf_lpf__i = 1; _three_phase_meter1_pll_lpf_lpf__i > 0; _three_phase_meter1_pll_lpf_lpf__i--) {
        _three_phase_meter1_pll_lpf_lpf__states[_three_phase_meter1_pll_lpf_lpf__i] = _three_phase_meter1_pll_lpf_lpf__states[_three_phase_meter1_pll_lpf_lpf__i - 1];
    }
    _three_phase_meter1_pll_lpf_lpf__states[0] = _three_phase_meter1_pll_lpf_lpf__delay_line_in;
    // Generated from the component: Three-phase Meter2.PLL.LPF.LPF
    for (_three_phase_meter2_pll_lpf_lpf__i = 1; _three_phase_meter2_pll_lpf_lpf__i > 0; _three_phase_meter2_pll_lpf_lpf__i--) {
        _three_phase_meter2_pll_lpf_lpf__states[_three_phase_meter2_pll_lpf_lpf__i] = _three_phase_meter2_pll_lpf_lpf__states[_three_phase_meter2_pll_lpf_lpf__i - 1];
    }
    _three_phase_meter2_pll_lpf_lpf__states[0] = _three_phase_meter2_pll_lpf_lpf__delay_line_in;
    // Generated from the component: Three-phase Meter3.PLL.LPF.LPF
    for (_three_phase_meter3_pll_lpf_lpf__i = 1; _three_phase_meter3_pll_lpf_lpf__i > 0; _three_phase_meter3_pll_lpf_lpf__i--) {
        _three_phase_meter3_pll_lpf_lpf__states[_three_phase_meter3_pll_lpf_lpf__i] = _three_phase_meter3_pll_lpf_lpf__states[_three_phase_meter3_pll_lpf_lpf__i - 1];
    }
    _three_phase_meter3_pll_lpf_lpf__states[0] = _three_phase_meter3_pll_lpf_lpf__delay_line_in;
    //@cmp.update.block.end
}
// ----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------