Model area1withcapacitor


REM LUT solver inputs...
rtds_write 0x01000000 0x00000003
rtds_write 0x01000200 0x0000002D
rtds_write 0x01000300 79.00927585834586
rtds_write 0x01000400 3.157857065382089
rtds_write 0x01000600 498.0
rtds_file_write 0x01200000 nlin_ind_Tr2.tr1.Lm_nonlin.txt
rtds_write 0x01000100 0x00000001
rtds_write 0x01000201 0x0000002F
rtds_write 0x01000301 79.00927585834586
rtds_write 0x01000401 3.157857065382089
rtds_write 0x01000601 498.0
rtds_file_write 0x01200200 nlin_ind_Tr2.tr2.Lm_nonlin.txt
rtds_write 0x01000101 0x00000001
rtds_write 0x01000202 0x00000031
rtds_write 0x01000302 79.00927585834586
rtds_write 0x01000402 3.157857065382089
rtds_write 0x01000602 498.0
rtds_file_write 0x01200400 nlin_ind_Tr2.tr3.Lm_nonlin.txt
rtds_write 0x01000102 0x00000001