Model Area1_Area2_withoutCapacitor


REM LUT solver inputs...
rtds_write 0x01000000 0x00000006
rtds_write 0x01000200 0x00000057
rtds_write 0x01000300 79.00927585834586
rtds_write 0x01000400 3.157857065382089
rtds_write 0x01000600 498.0
rtds_file_write 0x01200000 nlin_ind_Tr2.tr1.Lm_nonlin.txt
rtds_write 0x01000100 0x00000001
rtds_write 0x01000201 0x00000059
rtds_write 0x01000301 79.00927585834586
rtds_write 0x01000401 3.157857065382089
rtds_write 0x01000601 498.0
rtds_file_write 0x01200200 nlin_ind_Tr2.tr2.Lm_nonlin.txt
rtds_write 0x01000101 0x00000001
rtds_write 0x01000202 0x0000005B
rtds_write 0x01000302 79.00927585834586
rtds_write 0x01000402 3.157857065382089
rtds_write 0x01000602 498.0
rtds_file_write 0x01200400 nlin_ind_Tr2.tr3.Lm_nonlin.txt
rtds_write 0x01000102 0x00000001
rtds_write 0x01000203 0x0000005D
rtds_write 0x01000303 79.00927585834586
rtds_write 0x01000403 3.157857065382089
rtds_write 0x01000603 498.0
rtds_file_write 0x01200600 nlin_ind_Tr4.tr1.Lm_nonlin.txt
rtds_write 0x01000103 0x00000001
rtds_write 0x01000204 0x0000005F
rtds_write 0x01000304 79.00927585834586
rtds_write 0x01000404 3.157857065382089
rtds_write 0x01000604 498.0
rtds_file_write 0x01200800 nlin_ind_Tr4.tr2.Lm_nonlin.txt
rtds_write 0x01000104 0x00000001
rtds_write 0x01000205 0x00000061
rtds_write 0x01000305 79.00927585834586
rtds_write 0x01000405 3.157857065382089
rtds_write 0x01000605 498.0
rtds_file_write 0x01200A00 nlin_ind_Tr4.tr3.Lm_nonlin.txt
rtds_write 0x01000105 0x00000001