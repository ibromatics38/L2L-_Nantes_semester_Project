// generated using template: cop_main.template---------------------------------------------
/******************************************************************************************
**
**  Module Name: cop_main.c
**  NOTE: Automatically generated file. DO NOT MODIFY!
**  Description:
**            Main file
**
******************************************************************************************/
// generated using template: arm/custom_include.template-----------------------------------


#ifdef __cplusplus
#include <limits>

extern "C" {
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <stdint.h>
#include <complex.h>

// x86 libraries:
#include "../include/sp_functions_dev0.h"


#ifdef __cplusplus
}
#endif


// ----------------------------------------------------------------------------------------                // generated using template:generic_macros.template-----------------------------------------
/*********************** Macros (Inline Functions) Definitions ***************************/

// ----------------------------------------------------------------------------------------

#ifndef MAX
#define MAX(value, limit) (((value) > (limit)) ? (value) : (limit))
#endif
#ifndef MIN
#define MIN(value, limit) (((value) < (limit)) ? (value) : (limit))
#endif

// generated using template: VirtualHIL/custom_defines.template----------------------------

typedef unsigned char X_UnInt8;
typedef char X_Int8;
typedef signed short X_Int16;
typedef unsigned short X_UnInt16;
typedef int X_Int32;
typedef unsigned int X_UnInt32;
typedef unsigned int uint;
typedef double real;

// ----------------------------------------------------------------------------------------
// generated using template: custom_consts.template----------------------------------------

// arithmetic constants
#define C_SQRT_2                    1.4142135623730950488016887242097f
#define C_SQRT_3                    1.7320508075688772935274463415059f
#define C_PI                        3.1415926535897932384626433832795f
#define C_E                         2.7182818284590452353602874713527f
#define C_2PI                       6.283185307179586476925286766559f

//@cmp.def.start
//component defines








































































































































































































































































































































































































#define SQRT_2OVER3 0.8164965809277260327324280249019f
#define SQRT3_OVER_2 0.8660254037844386467637231707529f
#define ONE_DIV_BY_SQRT_3 0.57735026918962576450914878f




































#define SQRT_2OVER3 0.8164965809277260327324280249019f
#define SQRT3_OVER_2 0.8660254037844386467637231707529f
#define ONE_DIV_BY_SQRT_3 0.57735026918962576450914878f




































#define SQRT_2OVER3 0.8164965809277260327324280249019f
#define SQRT3_OVER_2 0.8660254037844386467637231707529f
#define ONE_DIV_BY_SQRT_3 0.57735026918962576450914878f




































#define SQRT_2OVER3 0.8164965809277260327324280249019f
#define SQRT3_OVER_2 0.8660254037844386467637231707529f
#define ONE_DIV_BY_SQRT_3 0.57735026918962576450914878f







































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































//@cmp.def.end


//-----------------------------------------------------------------------------------------
// generated using template: common_variables.template-------------------------------------
// true global variables



//@cmp.var.start
// variables
double _dg_in_gen_control_mode__out;
double _dg_in_gen_op_mode__out;
double _dg_in_gen_on__out;
double _dg_in_load_share__out;
double _dg_in_load_share_on__out;
double _dg_in_pref__out;
double _dg_in_vref__out;
double _dg_in_pf_ref__out;
double _dg_in_wref__out;
double _dg_in1_gen_control_mode__out;
double _dg_in1_gen_op_mode__out;
double _dg_in1_gen_on__out;
double _dg_in1_load_share__out;
double _dg_in1_load_share_on__out;
double _dg_in1_pref__out;
double _dg_in1_vref__out;
double _dg_in1_pf_ref__out;
double _dg_in1_wref__out;
double _dg_in3_gen_control_mode__out;
double _dg_in3_gen_op_mode__out;
double _dg_in3_gen_on__out;
double _dg_in3_load_share__out;
double _dg_in3_load_share_on__out;
double _dg_in3_pref__out;
double _dg_in3_vref__out;
double _dg_in3_pf_ref__out;
double _dg_in3_wref__out;
double _dg_in4_gen_control_mode__out;
double _dg_in4_gen_op_mode__out;
double _dg_in4_gen_on__out;
double _dg_in4_load_share__out;
double _dg_in4_load_share_on__out;
double _dg_in4_pref__out;
double _dg_in4_vref__out;
double _dg_in4_pf_ref__out;
double _dg_in4_wref__out;
double _diesel_gen1_control_exciter_const__out = 0.0;
double _diesel_gen1_control_exciter_dc4b_kf__out;
double _diesel_gen1_control_exciter_dc4b_one__out = 1.0;
double _diesel_gen1_control_exciter_one__out = 1.0;
double _diesel_gen1_control_exciter_v_inner_droop__out = 0.1;
double _diesel_gen1_control_exciter_vpss__out = 0.0;
double _diesel_gen1_control_exciter_zero__out = 0.0;
double _diesel_gen1_control_freq_setpoint_control_p_droop__out = 2.7;
double _diesel_gen1_control_freq_setpoint_control_w_droop__out = 0.1;
double _diesel_gen1_control_freq_setpoint_control_zero1__out = 0.0;
double _diesel_gen1_control_governor_and_engine_degov_kp__out;
double _diesel_gen1_control_governor_and_engine_degov_transport_delay1__out;
double _diesel_gen1_control_governor_and_engine_inner_w_droop__out = 0.1;
double _diesel_gen1_control_governor_and_engine_zero__out = 0.0;
double _diesel_gen1_control_start_exciter_steadystate_w__out = 1.0;
double _diesel_gen1_control_unit_delay1__out;
double _diesel_gen1_control_unit_delay2__out;
double _diesel_gen1_control_unit_delay3__out;
double _diesel_gen1_control_check_steady_state_w_constant3__out = 188.49555921538757;
double _diesel_gen1_control_pf_control_constant1__out = 1.0000000000000001e-07;
double _diesel_gen1_control_pf_control_zero1__out = 0.0;
double _diesel_gen1_gen_machine_wrapper1__out[2];

double _diesel_gen1_ggrid_meas_va_va1__out;
double _diesel_gen1_ggrid_meas_vb_va1__out;
double _diesel_gen1_ggrid_meas_vc_va1__out;

double _diesel_gen1_measurements_3ph_pll_gen_pll_normalize_v_terminal__d;
double _diesel_gen1_measurements_3ph_pll_gen_pll_normalize_v_terminal__q;


double _diesel_gen1_measurements_3ph_pll_gen_pll_normalize_v_terminal__q_pu;
double _diesel_gen1_measurements_3ph_pll_gen_pll_normalize_v_terminal__t;
double _diesel_gen1_measurements_3ph_pll_gen_pll_pi_integrator1__out;
double _diesel_gen1_measurements_3ph_pll_gen_pll_pi_integrator2__out;
double _diesel_gen1_measurements_3ph_pll_gen_pll_unit_delay1__out;
double _diesel_gen1_measurements_gain10__out;
double _diesel_gen1_measurements_ia_ia1__out;
double _diesel_gen1_measurements_ib_ia1__out;
double _diesel_gen1_measurements_ic_ia1__out;
double _diesel_gen1_measurements_va_va1__out;
double _diesel_gen1_measurements_vb_va1__out;
double _diesel_gen1_measurements_vc_va1__out;
double _diesel_gen1_sync_check_calculate_dw_synch_unit_delay1__out;
double _diesel_gen1_sync_check_calculate_dw_synch_dw_k__out;
double _diesel_gen1_sync_check_calculate_dw_synch_zero__out = 0.0;
double _diesel_gen1_sync_check_contactor_control_close__out = 1.0;
double _diesel_gen1_sync_check_contactor_control_edge_detection1_unit_delay1__out;
double _diesel_gen1_sync_check_contactor_control_sr_flip_flop1__out;
double _diesel_gen1_sync_check_contactor_control_sr_flip_flop1__out_n;
double _diesel_gen1_sync_check_plls_pll_grid_pll_pi_integrator1__out;
double _diesel_gen1_sync_check_plls_pll_grid_pll_unit_delay1__out;
double _diesel_gen1_sync_check_check_v_diff_abs4__out;
double _diesel_gen1_sync_check_check_v_diff_unit_delay1__out;
double _diesel_gen1_sync_check_check_v_diff_one__out = 1.0;
double _diesel_gen1_sync_check_check_v_diff_one1__out = 1.0;
double _diesel_gen1_sync_check_check_v_diff_zero__out = 0.0;
double _diesel_gen1_sync_check_check_f_diff_abs3__out;
double _diesel_gen1_sync_check_check_f_diff_constant1__out = 60.0;
double _diesel_gen1_sync_check_check_f_diff_topu__out;
double _diesel_gen1_sync_check_check_phase_diff_abs2__out;
double _diesel_gen1_sync_check_check_phase_diff_counter_counter1_accumulator1__out;
double _diesel_gen1_sync_check_check_phase_diff_counter_counter1_const_value_0__out = 0.0;
double _diesel_gen1_sync_check_check_phase_diff_counter_counter1_const_value_1__out = 1.0;
double _diesel_gen1_sync_check_check_phase_diff_one__out = 1.0;
double _diesel_gen1_sync_check_check_phase_diff_to_pu__out;
double _diesel_gen1_bus_split__out;
double _diesel_gen1_bus_split__out1;
double _diesel_gen2_control_exciter_const__out = 0.0;
double _diesel_gen2_control_exciter_dc4b_kf__out;
double _diesel_gen2_control_exciter_dc4b_one__out = 1.0;
double _diesel_gen2_control_exciter_one__out = 1.0;
double _diesel_gen2_control_exciter_v_inner_droop__out = 0.1;
double _diesel_gen2_control_exciter_vpss__out = 0.0;
double _diesel_gen2_control_exciter_zero__out = 0.0;
double _diesel_gen2_control_freq_setpoint_control_p_droop__out = 2.7;
double _diesel_gen2_control_freq_setpoint_control_w_droop__out = 0.1;
double _diesel_gen2_control_freq_setpoint_control_zero1__out = 0.0;
double _diesel_gen2_control_governor_and_engine_degov_kp__out;
double _diesel_gen2_control_governor_and_engine_degov_transport_delay1__out;
double _diesel_gen2_control_governor_and_engine_inner_w_droop__out = 0.1;
double _diesel_gen2_control_governor_and_engine_zero__out = 0.0;
double _diesel_gen2_control_start_exciter_steadystate_w__out = 1.0;
double _diesel_gen2_control_unit_delay1__out;
double _diesel_gen2_control_unit_delay2__out;
double _diesel_gen2_control_unit_delay3__out;
double _diesel_gen2_control_check_steady_state_w_constant3__out = 188.49555921538757;
double _diesel_gen2_control_pf_control_constant1__out = 1.0000000000000001e-07;
double _diesel_gen2_control_pf_control_zero1__out = 0.0;
double _diesel_gen2_gen_machine_wrapper1__out[2];

double _diesel_gen2_ggrid_meas_va_va1__out;
double _diesel_gen2_ggrid_meas_vb_va1__out;
double _diesel_gen2_ggrid_meas_vc_va1__out;

double _diesel_gen2_measurements_3ph_pll_gen_pll_normalize_v_terminal__d;
double _diesel_gen2_measurements_3ph_pll_gen_pll_normalize_v_terminal__q;


double _diesel_gen2_measurements_3ph_pll_gen_pll_normalize_v_terminal__q_pu;
double _diesel_gen2_measurements_3ph_pll_gen_pll_normalize_v_terminal__t;
double _diesel_gen2_measurements_3ph_pll_gen_pll_pi_integrator1__out;
double _diesel_gen2_measurements_3ph_pll_gen_pll_pi_integrator2__out;
double _diesel_gen2_measurements_3ph_pll_gen_pll_unit_delay1__out;
double _diesel_gen2_measurements_gain10__out;
double _diesel_gen2_measurements_ia_ia1__out;
double _diesel_gen2_measurements_ib_ia1__out;
double _diesel_gen2_measurements_ic_ia1__out;
double _diesel_gen2_measurements_va_va1__out;
double _diesel_gen2_measurements_vb_va1__out;
double _diesel_gen2_measurements_vc_va1__out;
double _diesel_gen2_sync_check_calculate_dw_synch_unit_delay1__out;
double _diesel_gen2_sync_check_calculate_dw_synch_dw_k__out;
double _diesel_gen2_sync_check_calculate_dw_synch_zero__out = 0.0;
double _diesel_gen2_sync_check_contactor_control_close__out = 1.0;
double _diesel_gen2_sync_check_contactor_control_edge_detection1_unit_delay1__out;
double _diesel_gen2_sync_check_contactor_control_sr_flip_flop1__out;
double _diesel_gen2_sync_check_contactor_control_sr_flip_flop1__out_n;
double _diesel_gen2_sync_check_plls_pll_grid_pll_pi_integrator1__out;
double _diesel_gen2_sync_check_plls_pll_grid_pll_unit_delay1__out;
double _diesel_gen2_sync_check_check_v_diff_abs4__out;
double _diesel_gen2_sync_check_check_v_diff_unit_delay1__out;
double _diesel_gen2_sync_check_check_v_diff_one__out = 1.0;
double _diesel_gen2_sync_check_check_v_diff_one1__out = 1.0;
double _diesel_gen2_sync_check_check_v_diff_zero__out = 0.0;
double _diesel_gen2_sync_check_check_f_diff_abs3__out;
double _diesel_gen2_sync_check_check_f_diff_constant1__out = 60.0;
double _diesel_gen2_sync_check_check_f_diff_topu__out;
double _diesel_gen2_sync_check_check_phase_diff_abs2__out;
double _diesel_gen2_sync_check_check_phase_diff_counter_counter1_accumulator1__out;
double _diesel_gen2_sync_check_check_phase_diff_counter_counter1_const_value_0__out = 0.0;
double _diesel_gen2_sync_check_check_phase_diff_counter_counter1_const_value_1__out = 1.0;
double _diesel_gen2_sync_check_check_phase_diff_one__out = 1.0;
double _diesel_gen2_sync_check_check_phase_diff_to_pu__out;
double _diesel_gen2_bus_split__out;
double _diesel_gen2_bus_split__out1;
double _diesel_gen3_control_exciter_const__out = 0.0;
double _diesel_gen3_control_exciter_dc4b_kf__out;
double _diesel_gen3_control_exciter_dc4b_one__out = 1.0;
double _diesel_gen3_control_exciter_one__out = 1.0;
double _diesel_gen3_control_exciter_v_inner_droop__out = 0.1;
double _diesel_gen3_control_exciter_vpss__out = 0.0;
double _diesel_gen3_control_exciter_zero__out = 0.0;
double _diesel_gen3_control_freq_setpoint_control_p_droop__out = 2.7;
double _diesel_gen3_control_freq_setpoint_control_w_droop__out = 0.1;
double _diesel_gen3_control_freq_setpoint_control_zero1__out = 0.0;
double _diesel_gen3_control_governor_and_engine_degov_kp__out;
double _diesel_gen3_control_governor_and_engine_degov_transport_delay1__out;
double _diesel_gen3_control_governor_and_engine_inner_w_droop__out = 0.1;
double _diesel_gen3_control_governor_and_engine_zero__out = 0.0;
double _diesel_gen3_control_start_exciter_steadystate_w__out = 1.0;
double _diesel_gen3_control_unit_delay1__out;
double _diesel_gen3_control_unit_delay2__out;
double _diesel_gen3_control_unit_delay3__out;
double _diesel_gen3_control_check_steady_state_w_constant3__out = 188.49555921538757;
double _diesel_gen3_control_pf_control_constant1__out = 1.0000000000000001e-07;
double _diesel_gen3_control_pf_control_zero1__out = 0.0;
double _diesel_gen3_gen_machine_wrapper1__out[2];

double _diesel_gen3_ggrid_meas_va_va1__out;
double _diesel_gen3_ggrid_meas_vb_va1__out;
double _diesel_gen3_ggrid_meas_vc_va1__out;

double _diesel_gen3_measurements_3ph_pll_gen_pll_normalize_v_terminal__d;
double _diesel_gen3_measurements_3ph_pll_gen_pll_normalize_v_terminal__q;


double _diesel_gen3_measurements_3ph_pll_gen_pll_normalize_v_terminal__q_pu;
double _diesel_gen3_measurements_3ph_pll_gen_pll_normalize_v_terminal__t;
double _diesel_gen3_measurements_3ph_pll_gen_pll_pi_integrator1__out;
double _diesel_gen3_measurements_3ph_pll_gen_pll_pi_integrator2__out;
double _diesel_gen3_measurements_3ph_pll_gen_pll_unit_delay1__out;
double _diesel_gen3_measurements_gain10__out;
double _diesel_gen3_measurements_ia_ia1__out;
double _diesel_gen3_measurements_ib_ia1__out;
double _diesel_gen3_measurements_ic_ia1__out;
double _diesel_gen3_measurements_va_va1__out;
double _diesel_gen3_measurements_vb_va1__out;
double _diesel_gen3_measurements_vc_va1__out;
double _diesel_gen3_sync_check_calculate_dw_synch_unit_delay1__out;
double _diesel_gen3_sync_check_calculate_dw_synch_dw_k__out;
double _diesel_gen3_sync_check_calculate_dw_synch_zero__out = 0.0;
double _diesel_gen3_sync_check_contactor_control_close__out = 1.0;
double _diesel_gen3_sync_check_contactor_control_edge_detection1_unit_delay1__out;
double _diesel_gen3_sync_check_contactor_control_sr_flip_flop1__out;
double _diesel_gen3_sync_check_contactor_control_sr_flip_flop1__out_n;
double _diesel_gen3_sync_check_plls_pll_grid_pll_pi_integrator1__out;
double _diesel_gen3_sync_check_plls_pll_grid_pll_unit_delay1__out;
double _diesel_gen3_sync_check_check_v_diff_abs4__out;
double _diesel_gen3_sync_check_check_v_diff_unit_delay1__out;
double _diesel_gen3_sync_check_check_v_diff_one__out = 1.0;
double _diesel_gen3_sync_check_check_v_diff_one1__out = 1.0;
double _diesel_gen3_sync_check_check_v_diff_zero__out = 0.0;
double _diesel_gen3_sync_check_check_f_diff_abs3__out;
double _diesel_gen3_sync_check_check_f_diff_constant1__out = 60.0;
double _diesel_gen3_sync_check_check_f_diff_topu__out;
double _diesel_gen3_sync_check_check_phase_diff_abs2__out;
double _diesel_gen3_sync_check_check_phase_diff_counter_counter1_accumulator1__out;
double _diesel_gen3_sync_check_check_phase_diff_counter_counter1_const_value_0__out = 0.0;
double _diesel_gen3_sync_check_check_phase_diff_counter_counter1_const_value_1__out = 1.0;
double _diesel_gen3_sync_check_check_phase_diff_one__out = 1.0;
double _diesel_gen3_sync_check_check_phase_diff_to_pu__out;
double _diesel_gen3_bus_split__out;
double _diesel_gen3_bus_split__out1;
double _diesel_gen4_control_exciter_const__out = 0.0;
double _diesel_gen4_control_exciter_dc4b_kf__out;
double _diesel_gen4_control_exciter_dc4b_one__out = 1.0;
double _diesel_gen4_control_exciter_one__out = 1.0;
double _diesel_gen4_control_exciter_v_inner_droop__out = 0.1;
double _diesel_gen4_control_exciter_vpss__out = 0.0;
double _diesel_gen4_control_exciter_zero__out = 0.0;
double _diesel_gen4_control_freq_setpoint_control_p_droop__out = 2.7;
double _diesel_gen4_control_freq_setpoint_control_w_droop__out = 0.1;
double _diesel_gen4_control_freq_setpoint_control_zero1__out = 0.0;
double _diesel_gen4_control_governor_and_engine_degov_kp__out;
double _diesel_gen4_control_governor_and_engine_degov_transport_delay1__out;
double _diesel_gen4_control_governor_and_engine_inner_w_droop__out = 0.1;
double _diesel_gen4_control_governor_and_engine_zero__out = 0.0;
double _diesel_gen4_control_start_exciter_steadystate_w__out = 1.0;
double _diesel_gen4_control_unit_delay1__out;
double _diesel_gen4_control_unit_delay2__out;
double _diesel_gen4_control_unit_delay3__out;
double _diesel_gen4_control_check_steady_state_w_constant3__out = 188.49555921538757;
double _diesel_gen4_control_pf_control_constant1__out = 1.0000000000000001e-07;
double _diesel_gen4_control_pf_control_zero1__out = 0.0;
double _diesel_gen4_gen_machine_wrapper1__out[2];

double _diesel_gen4_ggrid_meas_va_va1__out;
double _diesel_gen4_ggrid_meas_vb_va1__out;
double _diesel_gen4_ggrid_meas_vc_va1__out;

double _diesel_gen4_measurements_3ph_pll_gen_pll_normalize_v_terminal__d;
double _diesel_gen4_measurements_3ph_pll_gen_pll_normalize_v_terminal__q;


double _diesel_gen4_measurements_3ph_pll_gen_pll_normalize_v_terminal__q_pu;
double _diesel_gen4_measurements_3ph_pll_gen_pll_normalize_v_terminal__t;
double _diesel_gen4_measurements_3ph_pll_gen_pll_pi_integrator1__out;
double _diesel_gen4_measurements_3ph_pll_gen_pll_pi_integrator2__out;
double _diesel_gen4_measurements_3ph_pll_gen_pll_unit_delay1__out;
double _diesel_gen4_measurements_gain10__out;
double _diesel_gen4_measurements_ia_ia1__out;
double _diesel_gen4_measurements_ib_ia1__out;
double _diesel_gen4_measurements_ic_ia1__out;
double _diesel_gen4_measurements_va_va1__out;
double _diesel_gen4_measurements_vb_va1__out;
double _diesel_gen4_measurements_vc_va1__out;
double _diesel_gen4_sync_check_calculate_dw_synch_unit_delay1__out;
double _diesel_gen4_sync_check_calculate_dw_synch_dw_k__out;
double _diesel_gen4_sync_check_calculate_dw_synch_zero__out = 0.0;
double _diesel_gen4_sync_check_contactor_control_close__out = 1.0;
double _diesel_gen4_sync_check_contactor_control_edge_detection1_unit_delay1__out;
double _diesel_gen4_sync_check_contactor_control_sr_flip_flop1__out;
double _diesel_gen4_sync_check_contactor_control_sr_flip_flop1__out_n;
double _diesel_gen4_sync_check_plls_pll_grid_pll_pi_integrator1__out;
double _diesel_gen4_sync_check_plls_pll_grid_pll_unit_delay1__out;
double _diesel_gen4_sync_check_check_v_diff_abs4__out;
double _diesel_gen4_sync_check_check_v_diff_unit_delay1__out;
double _diesel_gen4_sync_check_check_v_diff_one__out = 1.0;
double _diesel_gen4_sync_check_check_v_diff_one1__out = 1.0;
double _diesel_gen4_sync_check_check_v_diff_zero__out = 0.0;
double _diesel_gen4_sync_check_check_f_diff_abs3__out;
double _diesel_gen4_sync_check_check_f_diff_constant1__out = 60.0;
double _diesel_gen4_sync_check_check_f_diff_topu__out;
double _diesel_gen4_sync_check_check_phase_diff_abs2__out;
double _diesel_gen4_sync_check_check_phase_diff_counter_counter1_accumulator1__out;
double _diesel_gen4_sync_check_check_phase_diff_counter_counter1_const_value_0__out = 0.0;
double _diesel_gen4_sync_check_check_phase_diff_counter_counter1_const_value_1__out = 1.0;
double _diesel_gen4_sync_check_check_phase_diff_one__out = 1.0;
double _diesel_gen4_sync_check_check_phase_diff_to_pu__out;
double _diesel_gen4_bus_split__out;
double _diesel_gen4_bus_split__out1;
double _three_phase_at_load_7__area_1__ia_ia1__out;
double _three_phase_at_load_7__area_1__ib_ia1__out;
double _three_phase_at_load_7__area_1__ic_ia1__out;
double _three_phase_at_load_7__area_1__pll_pid_integrator1__out;
double _three_phase_at_load_7__area_1__pll_pid_integrator2__out;
double _three_phase_at_load_7__area_1__pll_unit_delay1__out;
double _three_phase_at_load_7__area_1__pll_to_hz__out;
double _three_phase_at_load_7__area_1__vab_va1__out;
double _three_phase_at_load_7__area_1__van_va1__out;
double _three_phase_at_load_7__area_1__vbc_va1__out;
double _three_phase_at_load_7__area_1__vbn_va1__out;
double _three_phase_at_load_7__area_1__vca_va1__out;
double _three_phase_at_load_7__area_1__vcn_va1__out;
double _three_phase_at_load_7__area_1__zero__out = 0.0;
double _three_phase_at_load_8__mid__ia_ia1__out;
double _three_phase_at_load_8__mid__ib_ia1__out;
double _three_phase_at_load_8__mid__ic_ia1__out;
double _three_phase_at_load_8__mid__pll_pid_integrator1__out;
double _three_phase_at_load_8__mid__pll_pid_integrator2__out;
double _three_phase_at_load_8__mid__pll_unit_delay1__out;
double _three_phase_at_load_8__mid__pll_to_hz__out;
double _three_phase_at_load_8__mid__vab_va1__out;
double _three_phase_at_load_8__mid__van_va1__out;
double _three_phase_at_load_8__mid__vbc_va1__out;
double _three_phase_at_load_8__mid__vbn_va1__out;
double _three_phase_at_load_8__mid__vca_va1__out;
double _three_phase_at_load_8__mid__vcn_va1__out;
double _three_phase_at_load_8__mid__zero__out = 0.0;
double _three_phase_at_load_9__area_2__ia_ia1__out;
double _three_phase_at_load_9__area_2__ib_ia1__out;
double _three_phase_at_load_9__area_2__ic_ia1__out;
double _three_phase_at_load_9__area_2__pll_pid_integrator1__out;
double _three_phase_at_load_9__area_2__pll_pid_integrator2__out;
double _three_phase_at_load_9__area_2__pll_unit_delay1__out;
double _three_phase_at_load_9__area_2__pll_to_hz__out;
double _three_phase_at_load_9__area_2__vab_va1__out;
double _three_phase_at_load_9__area_2__van_va1__out;
double _three_phase_at_load_9__area_2__vbc_va1__out;
double _three_phase_at_load_9__area_2__vbn_va1__out;
double _three_phase_at_load_9__area_2__vca_va1__out;
double _three_phase_at_load_9__area_2__vcn_va1__out;
double _three_phase_at_load_9__area_2__zero__out = 0.0;
double _voltage_gen_1_ia_ia1__out;
double _voltage_gen_1_ib_ia1__out;
double _voltage_gen_1_ic_ia1__out;
double _voltage_gen_1_vab_va1__out;
double _voltage_gen_1_van_va1__out;
double _voltage_gen_1_vbc_va1__out;
double _voltage_gen_1_vbn_va1__out;
double _voltage_gen_1_vca_va1__out;
double _voltage_gen_1_vcn_va1__out;
double _voltage_gen_1_zero__out = 0.0;
double _voltage_gen_2_ia_ia1__out;
double _voltage_gen_2_ib_ia1__out;
double _voltage_gen_2_ic_ia1__out;
double _voltage_gen_2_vab_va1__out;
double _voltage_gen_2_van_va1__out;
double _voltage_gen_2_vbc_va1__out;
double _voltage_gen_2_vbn_va1__out;
double _voltage_gen_2_vca_va1__out;
double _voltage_gen_2_vcn_va1__out;
double _voltage_gen_2_zero__out = 0.0;
double _voltage_gen_3_ia_ia1__out;
double _voltage_gen_3_ib_ia1__out;
double _voltage_gen_3_ic_ia1__out;
double _voltage_gen_3_vab_va1__out;
double _voltage_gen_3_van_va1__out;
double _voltage_gen_3_vbc_va1__out;
double _voltage_gen_3_vbn_va1__out;
double _voltage_gen_3_vca_va1__out;
double _voltage_gen_3_vcn_va1__out;
double _voltage_gen_3_zero__out = 0.0;
double _voltage_gen_4_ia_ia1__out;
double _voltage_gen_4_ib_ia1__out;
double _voltage_gen_4_ic_ia1__out;
double _voltage_gen_4_vab_va1__out;
double _voltage_gen_4_van_va1__out;
double _voltage_gen_4_vbc_va1__out;
double _voltage_gen_4_vbn_va1__out;
double _voltage_gen_4_vca_va1__out;
double _voltage_gen_4_vcn_va1__out;
double _voltage_gen_4_zero__out = 0.0;
double _dg_in_bus_join2__out[9];
double _dg_in1_bus_join2__out[9];
double _dg_in3_bus_join2__out[9];
double _dg_in4_bus_join2__out[9];
double _diesel_gen1_control_exciter_dc4b_tf4__out;
double _diesel_gen1_control_exciter_dc4b_tf4__b_coeff[2] = {9803.92156862747, -9803.921568627435};
double _diesel_gen1_control_exciter_dc4b_tf4__a_coeff[2] = {1.0, 0.9607843137254902};
double _diesel_gen1_control_exciter_dc4b_tf4__a_sum;
double _diesel_gen1_control_exciter_dc4b_tf4__b_sum;
double _diesel_gen1_control_exciter_dc4b_tf4__delay_line_in;
double _diesel_gen1_control_exciter_dc4b_switch__out;
double _diesel_gen1_control_exciter_one_ov_sqrt_3__out;
double _diesel_gen1_control_exciter_sum1__out;
double _diesel_gen1_control_governor_and_engine_degov_k__out;
double _diesel_gen1_control_governor_and_engine_tpu_to_t__out;
double _diesel_gen1_control_start_exciter_exciter_start_speed__out;
double _diesel_gen1_control_check_steady_state_w_speed_diff__out;
double _diesel_gen1_ggrid_meas_bus_join1__out[3];
double _diesel_gen1_measurements_3ph_pll_gen_pll_pi_kd__out;
double _diesel_gen1_measurements_3ph_pll_gen_pll_pi_ki__out;
double _diesel_gen1_measurements_3ph_pll_gen_pll_pi_kp__out;
double _diesel_gen1_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__alpha;
double _diesel_gen1_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__beta;
double _diesel_gen1_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__gamma;
double _diesel_gen1_measurements_pq_measure_pq_power_meter1__Pdc;
double _diesel_gen1_measurements_pq_measure_pq_power_meter1__Qdc;
double _diesel_gen1_measurements_pq_measure_pq_power_meter1__P0dc;
double _diesel_gen1_measurements_pq_measure_pq_power_meter1__Pac;
double _diesel_gen1_measurements_pq_measure_pq_power_meter1__Qac;
double _diesel_gen1_measurements_pq_measure_pq_power_meter1__P0ac;
double _diesel_gen1_measurements_pq_measure_pq_power_meter1__apparent;
double _diesel_gen1_measurements_pq_measure_pq_power_meter1__k_factor;
double _diesel_gen1_measurements_pq_measure_pq_power_meter1__v_alpha;
double _diesel_gen1_measurements_pq_measure_pq_power_meter1__v_beta;
double _diesel_gen1_measurements_pq_measure_pq_power_meter1__i_alpha;
double _diesel_gen1_measurements_pq_measure_pq_power_meter1__i_beta;
double _diesel_gen1_measurements_pq_measure_pq_power_meter1__v_zero;
double _diesel_gen1_measurements_pq_measure_pq_power_meter1__i_zero;
double _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_output;
double _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_outputQ;
double _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_outputP0;
double _diesel_gen1_sync_check_calculate_dw_synch_signal_switch1__out;
float _diesel_gen1_sync_check_contactor_control_gcb_cmd__tmp;
double _diesel_gen1_sync_check_not__out;
double _diesel_gen1_sync_check_check_v_diff_pu1__out;
double _diesel_gen1_sync_check_check_v_diff_pi_integrator1__out;
double _diesel_gen1_sync_check_check_v_diff_volt_diff__out;
double _diesel_gen1_sync_check_check_v_diff_vgrid_lowlim__out;
double _diesel_gen1_sync_check_check_v_diff_vgrid_uplim__out;
double _diesel_gen1_sync_check_check_f_diff_freq_diff__out;
double _diesel_gen1_sync_check_check_phase_diff_counter_c_function__counter;


double _diesel_gen1_sync_check_check_phase_diff_counter_c_function__out;
double _diesel_gen1_sync_check_check_phase_diff_phase_diff__out;
double _diesel_gen1_sync_check_check_phase_diff_pi_ki__out;
double _diesel_gen1_sync_check_check_phase_diff_pi_kp__out;
double _diesel_gen1_control_freq_setpoint_control_w_to_wpu__out;
double _diesel_gen1_control_governor_and_engine_w_to_wpu__out;
double _diesel_gen1_control_start_exciter_w_to_wpu__out;
double _diesel_gen1_control_check_steady_state_w_sum3__out;
double _diesel_gen2_control_exciter_dc4b_tf4__out;
double _diesel_gen2_control_exciter_dc4b_tf4__b_coeff[2] = {9803.92156862747, -9803.921568627435};
double _diesel_gen2_control_exciter_dc4b_tf4__a_coeff[2] = {1.0, 0.9607843137254902};
double _diesel_gen2_control_exciter_dc4b_tf4__a_sum;
double _diesel_gen2_control_exciter_dc4b_tf4__b_sum;
double _diesel_gen2_control_exciter_dc4b_tf4__delay_line_in;
double _diesel_gen2_control_exciter_dc4b_switch__out;
double _diesel_gen2_control_exciter_one_ov_sqrt_3__out;
double _diesel_gen2_control_exciter_sum1__out;
double _diesel_gen2_control_governor_and_engine_degov_k__out;
double _diesel_gen2_control_governor_and_engine_tpu_to_t__out;
double _diesel_gen2_control_start_exciter_exciter_start_speed__out;
double _diesel_gen2_control_check_steady_state_w_speed_diff__out;
double _diesel_gen2_ggrid_meas_bus_join1__out[3];
double _diesel_gen2_measurements_3ph_pll_gen_pll_pi_kd__out;
double _diesel_gen2_measurements_3ph_pll_gen_pll_pi_ki__out;
double _diesel_gen2_measurements_3ph_pll_gen_pll_pi_kp__out;
double _diesel_gen2_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__alpha;
double _diesel_gen2_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__beta;
double _diesel_gen2_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__gamma;
double _diesel_gen2_measurements_pq_measure_pq_power_meter1__Pdc;
double _diesel_gen2_measurements_pq_measure_pq_power_meter1__Qdc;
double _diesel_gen2_measurements_pq_measure_pq_power_meter1__P0dc;
double _diesel_gen2_measurements_pq_measure_pq_power_meter1__Pac;
double _diesel_gen2_measurements_pq_measure_pq_power_meter1__Qac;
double _diesel_gen2_measurements_pq_measure_pq_power_meter1__P0ac;
double _diesel_gen2_measurements_pq_measure_pq_power_meter1__apparent;
double _diesel_gen2_measurements_pq_measure_pq_power_meter1__k_factor;
double _diesel_gen2_measurements_pq_measure_pq_power_meter1__v_alpha;
double _diesel_gen2_measurements_pq_measure_pq_power_meter1__v_beta;
double _diesel_gen2_measurements_pq_measure_pq_power_meter1__i_alpha;
double _diesel_gen2_measurements_pq_measure_pq_power_meter1__i_beta;
double _diesel_gen2_measurements_pq_measure_pq_power_meter1__v_zero;
double _diesel_gen2_measurements_pq_measure_pq_power_meter1__i_zero;
double _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_output;
double _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_outputQ;
double _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_outputP0;
double _diesel_gen2_sync_check_calculate_dw_synch_signal_switch1__out;
float _diesel_gen2_sync_check_contactor_control_gcb_cmd__tmp;
double _diesel_gen2_sync_check_not__out;
double _diesel_gen2_sync_check_check_v_diff_pu1__out;
double _diesel_gen2_sync_check_check_v_diff_pi_integrator1__out;
double _diesel_gen2_sync_check_check_v_diff_volt_diff__out;
double _diesel_gen2_sync_check_check_v_diff_vgrid_lowlim__out;
double _diesel_gen2_sync_check_check_v_diff_vgrid_uplim__out;
double _diesel_gen2_sync_check_check_f_diff_freq_diff__out;
double _diesel_gen2_sync_check_check_phase_diff_counter_c_function__counter;


double _diesel_gen2_sync_check_check_phase_diff_counter_c_function__out;
double _diesel_gen2_sync_check_check_phase_diff_phase_diff__out;
double _diesel_gen2_sync_check_check_phase_diff_pi_ki__out;
double _diesel_gen2_sync_check_check_phase_diff_pi_kp__out;
double _diesel_gen2_control_freq_setpoint_control_w_to_wpu__out;
double _diesel_gen2_control_governor_and_engine_w_to_wpu__out;
double _diesel_gen2_control_start_exciter_w_to_wpu__out;
double _diesel_gen2_control_check_steady_state_w_sum3__out;
double _diesel_gen3_control_exciter_dc4b_tf4__out;
double _diesel_gen3_control_exciter_dc4b_tf4__b_coeff[2] = {9803.92156862747, -9803.921568627435};
double _diesel_gen3_control_exciter_dc4b_tf4__a_coeff[2] = {1.0, 0.9607843137254902};
double _diesel_gen3_control_exciter_dc4b_tf4__a_sum;
double _diesel_gen3_control_exciter_dc4b_tf4__b_sum;
double _diesel_gen3_control_exciter_dc4b_tf4__delay_line_in;
double _diesel_gen3_control_exciter_dc4b_switch__out;
double _diesel_gen3_control_exciter_one_ov_sqrt_3__out;
double _diesel_gen3_control_exciter_sum1__out;
double _diesel_gen3_control_governor_and_engine_degov_k__out;
double _diesel_gen3_control_governor_and_engine_tpu_to_t__out;
double _diesel_gen3_control_start_exciter_exciter_start_speed__out;
double _diesel_gen3_control_check_steady_state_w_speed_diff__out;
double _diesel_gen3_ggrid_meas_bus_join1__out[3];
double _diesel_gen3_measurements_3ph_pll_gen_pll_pi_kd__out;
double _diesel_gen3_measurements_3ph_pll_gen_pll_pi_ki__out;
double _diesel_gen3_measurements_3ph_pll_gen_pll_pi_kp__out;
double _diesel_gen3_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__alpha;
double _diesel_gen3_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__beta;
double _diesel_gen3_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__gamma;
double _diesel_gen3_measurements_pq_measure_pq_power_meter1__Pdc;
double _diesel_gen3_measurements_pq_measure_pq_power_meter1__Qdc;
double _diesel_gen3_measurements_pq_measure_pq_power_meter1__P0dc;
double _diesel_gen3_measurements_pq_measure_pq_power_meter1__Pac;
double _diesel_gen3_measurements_pq_measure_pq_power_meter1__Qac;
double _diesel_gen3_measurements_pq_measure_pq_power_meter1__P0ac;
double _diesel_gen3_measurements_pq_measure_pq_power_meter1__apparent;
double _diesel_gen3_measurements_pq_measure_pq_power_meter1__k_factor;
double _diesel_gen3_measurements_pq_measure_pq_power_meter1__v_alpha;
double _diesel_gen3_measurements_pq_measure_pq_power_meter1__v_beta;
double _diesel_gen3_measurements_pq_measure_pq_power_meter1__i_alpha;
double _diesel_gen3_measurements_pq_measure_pq_power_meter1__i_beta;
double _diesel_gen3_measurements_pq_measure_pq_power_meter1__v_zero;
double _diesel_gen3_measurements_pq_measure_pq_power_meter1__i_zero;
double _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_output;
double _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_outputQ;
double _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_outputP0;
double _diesel_gen3_sync_check_calculate_dw_synch_signal_switch1__out;
float _diesel_gen3_sync_check_contactor_control_gcb_cmd__tmp;
double _diesel_gen3_sync_check_not__out;
double _diesel_gen3_sync_check_check_v_diff_pu1__out;
double _diesel_gen3_sync_check_check_v_diff_pi_integrator1__out;
double _diesel_gen3_sync_check_check_v_diff_volt_diff__out;
double _diesel_gen3_sync_check_check_v_diff_vgrid_lowlim__out;
double _diesel_gen3_sync_check_check_v_diff_vgrid_uplim__out;
double _diesel_gen3_sync_check_check_f_diff_freq_diff__out;
double _diesel_gen3_sync_check_check_phase_diff_counter_c_function__counter;


double _diesel_gen3_sync_check_check_phase_diff_counter_c_function__out;
double _diesel_gen3_sync_check_check_phase_diff_phase_diff__out;
double _diesel_gen3_sync_check_check_phase_diff_pi_ki__out;
double _diesel_gen3_sync_check_check_phase_diff_pi_kp__out;
double _diesel_gen3_control_freq_setpoint_control_w_to_wpu__out;
double _diesel_gen3_control_governor_and_engine_w_to_wpu__out;
double _diesel_gen3_control_start_exciter_w_to_wpu__out;
double _diesel_gen3_control_check_steady_state_w_sum3__out;
double _diesel_gen4_control_exciter_dc4b_tf4__out;
double _diesel_gen4_control_exciter_dc4b_tf4__b_coeff[2] = {9803.92156862747, -9803.921568627435};
double _diesel_gen4_control_exciter_dc4b_tf4__a_coeff[2] = {1.0, 0.9607843137254902};
double _diesel_gen4_control_exciter_dc4b_tf4__a_sum;
double _diesel_gen4_control_exciter_dc4b_tf4__b_sum;
double _diesel_gen4_control_exciter_dc4b_tf4__delay_line_in;
double _diesel_gen4_control_exciter_dc4b_switch__out;
double _diesel_gen4_control_exciter_one_ov_sqrt_3__out;
double _diesel_gen4_control_exciter_sum1__out;
double _diesel_gen4_control_governor_and_engine_degov_k__out;
double _diesel_gen4_control_governor_and_engine_tpu_to_t__out;
double _diesel_gen4_control_start_exciter_exciter_start_speed__out;
double _diesel_gen4_control_check_steady_state_w_speed_diff__out;
double _diesel_gen4_ggrid_meas_bus_join1__out[3];
double _diesel_gen4_measurements_3ph_pll_gen_pll_pi_kd__out;
double _diesel_gen4_measurements_3ph_pll_gen_pll_pi_ki__out;
double _diesel_gen4_measurements_3ph_pll_gen_pll_pi_kp__out;
double _diesel_gen4_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__alpha;
double _diesel_gen4_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__beta;
double _diesel_gen4_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__gamma;
double _diesel_gen4_measurements_pq_measure_pq_power_meter1__Pdc;
double _diesel_gen4_measurements_pq_measure_pq_power_meter1__Qdc;
double _diesel_gen4_measurements_pq_measure_pq_power_meter1__P0dc;
double _diesel_gen4_measurements_pq_measure_pq_power_meter1__Pac;
double _diesel_gen4_measurements_pq_measure_pq_power_meter1__Qac;
double _diesel_gen4_measurements_pq_measure_pq_power_meter1__P0ac;
double _diesel_gen4_measurements_pq_measure_pq_power_meter1__apparent;
double _diesel_gen4_measurements_pq_measure_pq_power_meter1__k_factor;
double _diesel_gen4_measurements_pq_measure_pq_power_meter1__v_alpha;
double _diesel_gen4_measurements_pq_measure_pq_power_meter1__v_beta;
double _diesel_gen4_measurements_pq_measure_pq_power_meter1__i_alpha;
double _diesel_gen4_measurements_pq_measure_pq_power_meter1__i_beta;
double _diesel_gen4_measurements_pq_measure_pq_power_meter1__v_zero;
double _diesel_gen4_measurements_pq_measure_pq_power_meter1__i_zero;
double _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_output;
double _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_outputQ;
double _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_outputP0;
double _diesel_gen4_sync_check_calculate_dw_synch_signal_switch1__out;
float _diesel_gen4_sync_check_contactor_control_gcb_cmd__tmp;
double _diesel_gen4_sync_check_not__out;
double _diesel_gen4_sync_check_check_v_diff_pu1__out;
double _diesel_gen4_sync_check_check_v_diff_pi_integrator1__out;
double _diesel_gen4_sync_check_check_v_diff_volt_diff__out;
double _diesel_gen4_sync_check_check_v_diff_vgrid_lowlim__out;
double _diesel_gen4_sync_check_check_v_diff_vgrid_uplim__out;
double _diesel_gen4_sync_check_check_f_diff_freq_diff__out;
double _diesel_gen4_sync_check_check_phase_diff_counter_c_function__counter;


double _diesel_gen4_sync_check_check_phase_diff_counter_c_function__out;
double _diesel_gen4_sync_check_check_phase_diff_phase_diff__out;
double _diesel_gen4_sync_check_check_phase_diff_pi_ki__out;
double _diesel_gen4_sync_check_check_phase_diff_pi_kp__out;
double _diesel_gen4_control_freq_setpoint_control_w_to_wpu__out;
double _diesel_gen4_control_governor_and_engine_w_to_wpu__out;
double _diesel_gen4_control_start_exciter_w_to_wpu__out;
double _diesel_gen4_control_check_steady_state_w_sum3__out;
double _three_phase_at_load_7__area_1__pll_sin__out;

double _three_phase_at_load_7__area_1__meassm_mode_and_dfract__Freq;


double _three_phase_at_load_7__area_1__meassm_mode_and_dfract__dFract;
X_Int32 _three_phase_at_load_7__area_1__meassm_mode_and_dfract__mode;
X_Int32 _three_phase_at_load_7__area_1__meassm_mode_and_dfract__submode;
double _three_phase_at_load_7__area_1__pll_abc_to_dq_abc_to_alpha_beta__alpha;
double _three_phase_at_load_7__area_1__pll_abc_to_dq_abc_to_alpha_beta__beta;
double _three_phase_at_load_7__area_1__pll_abc_to_dq_abc_to_alpha_beta__gamma;
double _three_phase_at_load_8__mid__pll_sin__out;

double _three_phase_at_load_8__mid__meassm_mode_and_dfract__Freq;


double _three_phase_at_load_8__mid__meassm_mode_and_dfract__dFract;
X_Int32 _three_phase_at_load_8__mid__meassm_mode_and_dfract__mode;
X_Int32 _three_phase_at_load_8__mid__meassm_mode_and_dfract__submode;
double _three_phase_at_load_8__mid__pll_abc_to_dq_abc_to_alpha_beta__alpha;
double _three_phase_at_load_8__mid__pll_abc_to_dq_abc_to_alpha_beta__beta;
double _three_phase_at_load_8__mid__pll_abc_to_dq_abc_to_alpha_beta__gamma;
double _three_phase_at_load_9__area_2__pll_sin__out;

double _three_phase_at_load_9__area_2__meassm_mode_and_dfract__Freq;


double _three_phase_at_load_9__area_2__meassm_mode_and_dfract__dFract;
X_Int32 _three_phase_at_load_9__area_2__meassm_mode_and_dfract__mode;
X_Int32 _three_phase_at_load_9__area_2__meassm_mode_and_dfract__submode;
double _three_phase_at_load_9__area_2__pll_abc_to_dq_abc_to_alpha_beta__alpha;
double _three_phase_at_load_9__area_2__pll_abc_to_dq_abc_to_alpha_beta__beta;
double _three_phase_at_load_9__area_2__pll_abc_to_dq_abc_to_alpha_beta__gamma;
double _voltage_gen_1_extra_output_bus__out[12];
double _voltage_gen_1_output_bus__out[30];
double _voltage_gen_2_extra_output_bus__out[12];
double _voltage_gen_2_output_bus__out[30];
double _voltage_gen_3_extra_output_bus__out[12];
double _voltage_gen_3_output_bus__out[30];
double _voltage_gen_4_extra_output_bus__out[12];
double _voltage_gen_4_output_bus__out[30];
double _diesel_gen1_control_bus_split3__out;
double _diesel_gen1_control_bus_split3__out1;
double _diesel_gen1_control_bus_split3__out2;
double _diesel_gen1_control_bus_split3__out3;
double _diesel_gen1_control_bus_split3__out4;
double _diesel_gen1_control_bus_split3__out5;
double _diesel_gen1_control_bus_split3__out6;
double _diesel_gen1_control_bus_split3__out7;
double _diesel_gen1_control_bus_split3__out8;
double _diesel_gen2_control_bus_split3__out;
double _diesel_gen2_control_bus_split3__out1;
double _diesel_gen2_control_bus_split3__out2;
double _diesel_gen2_control_bus_split3__out3;
double _diesel_gen2_control_bus_split3__out4;
double _diesel_gen2_control_bus_split3__out5;
double _diesel_gen2_control_bus_split3__out6;
double _diesel_gen2_control_bus_split3__out7;
double _diesel_gen2_control_bus_split3__out8;
double _diesel_gen4_control_bus_split3__out;
double _diesel_gen4_control_bus_split3__out1;
double _diesel_gen4_control_bus_split3__out2;
double _diesel_gen4_control_bus_split3__out3;
double _diesel_gen4_control_bus_split3__out4;
double _diesel_gen4_control_bus_split3__out5;
double _diesel_gen4_control_bus_split3__out6;
double _diesel_gen4_control_bus_split3__out7;
double _diesel_gen4_control_bus_split3__out8;
double _diesel_gen3_control_bus_split3__out;
double _diesel_gen3_control_bus_split3__out1;
double _diesel_gen3_control_bus_split3__out2;
double _diesel_gen3_control_bus_split3__out3;
double _diesel_gen3_control_bus_split3__out4;
double _diesel_gen3_control_bus_split3__out5;
double _diesel_gen3_control_bus_split3__out6;
double _diesel_gen3_control_bus_split3__out7;
double _diesel_gen3_control_bus_split3__out8;
double _diesel_gen1_control_exciter_dc4b_variable_limit__LimitChange;
double _diesel_gen1_control_exciter_dc4b_variable_limit__in;


double _diesel_gen1_control_exciter_dc4b_variable_limit__out;
double _diesel_gen1_control_governor_and_engine_degov_tf2__out;
double _diesel_gen1_control_governor_and_engine_degov_tf2__b_coeff[3] = {0.4297945205479452, 0.003424657534246256, -0.4263698630136985};
double _diesel_gen1_control_governor_and_engine_degov_tf2__a_coeff[3] = {1.0, -1.7657534246575342, 0.7726027397260274};
double _diesel_gen1_control_governor_and_engine_degov_tf2__a_sum;
double _diesel_gen1_control_governor_and_engine_degov_tf2__b_sum;
double _diesel_gen1_control_governor_and_engine_degov_tf2__delay_line_in;
double _diesel_gen1_sync_check_plls_split__out;
double _diesel_gen1_sync_check_plls_split__out1;
double _diesel_gen1_sync_check_plls_split__out2;
double _diesel_gen1_measurements_3ph_pll_gen_pll_pi_sum8__out;
double _diesel_gen1_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__d;
double _diesel_gen1_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__q;
double _diesel_gen1_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k1;
double _diesel_gen1_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k2;
double _diesel_gen1_measurements_bus_join1__out[4];
double _diesel_gen1_measurements_gain7__out;
double _diesel_gen1_measurements_gain8__out;
double _diesel_gen1_measurements_gain9__out;
double _diesel_gen1_sync_check_check_v_diff_greater_equal__out;
double _diesel_gen1_sync_check_check_v_diff_less_equal__out;
double _diesel_gen1_sync_check_check_f_diff_comparator1__out;
float _diesel_gen1_sync_check_phase_match__tmp;
double _diesel_gen1_sync_check_check_phase_diff_comparator2__out;
double _diesel_gen1_control_start_exciter_comparator1__out;
double _diesel_gen1_control_check_steady_state_w_abs1__out;

double _diesel_gen2_control_exciter_dc4b_variable_limit__LimitChange;
double _diesel_gen2_control_exciter_dc4b_variable_limit__in;


double _diesel_gen2_control_exciter_dc4b_variable_limit__out;
double _diesel_gen2_control_governor_and_engine_degov_tf2__out;
double _diesel_gen2_control_governor_and_engine_degov_tf2__b_coeff[3] = {0.4297945205479452, 0.003424657534246256, -0.4263698630136985};
double _diesel_gen2_control_governor_and_engine_degov_tf2__a_coeff[3] = {1.0, -1.7657534246575342, 0.7726027397260274};
double _diesel_gen2_control_governor_and_engine_degov_tf2__a_sum;
double _diesel_gen2_control_governor_and_engine_degov_tf2__b_sum;
double _diesel_gen2_control_governor_and_engine_degov_tf2__delay_line_in;
double _diesel_gen2_sync_check_plls_split__out;
double _diesel_gen2_sync_check_plls_split__out1;
double _diesel_gen2_sync_check_plls_split__out2;
double _diesel_gen2_measurements_3ph_pll_gen_pll_pi_sum8__out;
double _diesel_gen2_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__d;
double _diesel_gen2_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__q;
double _diesel_gen2_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k1;
double _diesel_gen2_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k2;
double _diesel_gen2_measurements_bus_join1__out[4];
double _diesel_gen2_measurements_gain7__out;
double _diesel_gen2_measurements_gain8__out;
double _diesel_gen2_measurements_gain9__out;
double _diesel_gen2_sync_check_check_v_diff_greater_equal__out;
double _diesel_gen2_sync_check_check_v_diff_less_equal__out;
double _diesel_gen2_sync_check_check_f_diff_comparator1__out;
float _diesel_gen2_sync_check_phase_match__tmp;
double _diesel_gen2_sync_check_check_phase_diff_comparator2__out;
double _diesel_gen2_control_start_exciter_comparator1__out;
double _diesel_gen2_control_check_steady_state_w_abs1__out;

double _diesel_gen3_control_exciter_dc4b_variable_limit__LimitChange;
double _diesel_gen3_control_exciter_dc4b_variable_limit__in;


double _diesel_gen3_control_exciter_dc4b_variable_limit__out;
double _diesel_gen3_control_governor_and_engine_degov_tf2__out;
double _diesel_gen3_control_governor_and_engine_degov_tf2__b_coeff[3] = {0.4297945205479452, 0.003424657534246256, -0.4263698630136985};
double _diesel_gen3_control_governor_and_engine_degov_tf2__a_coeff[3] = {1.0, -1.7657534246575342, 0.7726027397260274};
double _diesel_gen3_control_governor_and_engine_degov_tf2__a_sum;
double _diesel_gen3_control_governor_and_engine_degov_tf2__b_sum;
double _diesel_gen3_control_governor_and_engine_degov_tf2__delay_line_in;
double _diesel_gen3_sync_check_plls_split__out;
double _diesel_gen3_sync_check_plls_split__out1;
double _diesel_gen3_sync_check_plls_split__out2;
double _diesel_gen3_measurements_3ph_pll_gen_pll_pi_sum8__out;
double _diesel_gen3_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__d;
double _diesel_gen3_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__q;
double _diesel_gen3_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k1;
double _diesel_gen3_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k2;
double _diesel_gen3_measurements_bus_join1__out[4];
double _diesel_gen3_measurements_gain7__out;
double _diesel_gen3_measurements_gain8__out;
double _diesel_gen3_measurements_gain9__out;
double _diesel_gen3_sync_check_check_v_diff_greater_equal__out;
double _diesel_gen3_sync_check_check_v_diff_less_equal__out;
double _diesel_gen3_sync_check_check_f_diff_comparator1__out;
float _diesel_gen3_sync_check_phase_match__tmp;
double _diesel_gen3_sync_check_check_phase_diff_comparator2__out;
double _diesel_gen3_control_start_exciter_comparator1__out;
double _diesel_gen3_control_check_steady_state_w_abs1__out;

double _diesel_gen4_control_exciter_dc4b_variable_limit__LimitChange;
double _diesel_gen4_control_exciter_dc4b_variable_limit__in;


double _diesel_gen4_control_exciter_dc4b_variable_limit__out;
double _diesel_gen4_control_governor_and_engine_degov_tf2__out;
double _diesel_gen4_control_governor_and_engine_degov_tf2__b_coeff[3] = {0.4297945205479452, 0.003424657534246256, -0.4263698630136985};
double _diesel_gen4_control_governor_and_engine_degov_tf2__a_coeff[3] = {1.0, -1.7657534246575342, 0.7726027397260274};
double _diesel_gen4_control_governor_and_engine_degov_tf2__a_sum;
double _diesel_gen4_control_governor_and_engine_degov_tf2__b_sum;
double _diesel_gen4_control_governor_and_engine_degov_tf2__delay_line_in;
double _diesel_gen4_sync_check_plls_split__out;
double _diesel_gen4_sync_check_plls_split__out1;
double _diesel_gen4_sync_check_plls_split__out2;
double _diesel_gen4_measurements_3ph_pll_gen_pll_pi_sum8__out;
double _diesel_gen4_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__d;
double _diesel_gen4_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__q;
double _diesel_gen4_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k1;
double _diesel_gen4_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k2;
double _diesel_gen4_measurements_bus_join1__out[4];
double _diesel_gen4_measurements_gain7__out;
double _diesel_gen4_measurements_gain8__out;
double _diesel_gen4_measurements_gain9__out;
double _diesel_gen4_sync_check_check_v_diff_greater_equal__out;
double _diesel_gen4_sync_check_check_v_diff_less_equal__out;
double _diesel_gen4_sync_check_check_f_diff_comparator1__out;
float _diesel_gen4_sync_check_phase_match__tmp;
double _diesel_gen4_sync_check_check_phase_diff_comparator2__out;
double _diesel_gen4_control_start_exciter_comparator1__out;
double _diesel_gen4_control_check_steady_state_w_abs1__out;

double _three_phase_at_load_7__area_1__i_rms_calc_rms__IN1;
double _three_phase_at_load_7__area_1__i_rms_calc_rms__IN2;
double _three_phase_at_load_7__area_1__i_rms_calc_rms__IN3;
double _three_phase_at_load_7__area_1__i_rms_calc_rms__dFract;
X_Int32 _three_phase_at_load_7__area_1__i_rms_calc_rms__mode;


double _three_phase_at_load_7__area_1__i_rms_calc_rms__RMS1;
double _three_phase_at_load_7__area_1__i_rms_calc_rms__RMS2;
double _three_phase_at_load_7__area_1__i_rms_calc_rms__RMS3;

double _three_phase_at_load_7__area_1__vll_rms_calc_rms__IN1;
double _three_phase_at_load_7__area_1__vll_rms_calc_rms__IN2;
double _three_phase_at_load_7__area_1__vll_rms_calc_rms__IN3;
double _three_phase_at_load_7__area_1__vll_rms_calc_rms__dFract;
X_Int32 _three_phase_at_load_7__area_1__vll_rms_calc_rms__mode;


double _three_phase_at_load_7__area_1__vll_rms_calc_rms__RMS1;
double _three_phase_at_load_7__area_1__vll_rms_calc_rms__RMS2;
double _three_phase_at_load_7__area_1__vll_rms_calc_rms__RMS3;

double _three_phase_at_load_7__area_1__vln_rms_calc_rms__IN1;
double _three_phase_at_load_7__area_1__vln_rms_calc_rms__IN2;
double _three_phase_at_load_7__area_1__vln_rms_calc_rms__IN3;
double _three_phase_at_load_7__area_1__vln_rms_calc_rms__dFract;
X_Int32 _three_phase_at_load_7__area_1__vln_rms_calc_rms__mode;


double _three_phase_at_load_7__area_1__vln_rms_calc_rms__RMS1;
double _three_phase_at_load_7__area_1__vln_rms_calc_rms__RMS2;
double _three_phase_at_load_7__area_1__vln_rms_calc_rms__RMS3;
double _three_phase_at_load_7__area_1__pll_abc_to_dq_alpha_beta_to_dq__d;
double _three_phase_at_load_7__area_1__pll_abc_to_dq_alpha_beta_to_dq__q;
double _three_phase_at_load_7__area_1__pll_abc_to_dq_alpha_beta_to_dq__k1;
double _three_phase_at_load_7__area_1__pll_abc_to_dq_alpha_beta_to_dq__k2;

double _three_phase_at_load_8__mid__i_rms_calc_rms__IN1;
double _three_phase_at_load_8__mid__i_rms_calc_rms__IN2;
double _three_phase_at_load_8__mid__i_rms_calc_rms__IN3;
double _three_phase_at_load_8__mid__i_rms_calc_rms__dFract;
X_Int32 _three_phase_at_load_8__mid__i_rms_calc_rms__mode;


double _three_phase_at_load_8__mid__i_rms_calc_rms__RMS1;
double _three_phase_at_load_8__mid__i_rms_calc_rms__RMS2;
double _three_phase_at_load_8__mid__i_rms_calc_rms__RMS3;

double _three_phase_at_load_8__mid__vln_rms_calc_rms__IN1;
double _three_phase_at_load_8__mid__vln_rms_calc_rms__IN2;
double _three_phase_at_load_8__mid__vln_rms_calc_rms__IN3;
double _three_phase_at_load_8__mid__vln_rms_calc_rms__dFract;
X_Int32 _three_phase_at_load_8__mid__vln_rms_calc_rms__mode;


double _three_phase_at_load_8__mid__vln_rms_calc_rms__RMS1;
double _three_phase_at_load_8__mid__vln_rms_calc_rms__RMS2;
double _three_phase_at_load_8__mid__vln_rms_calc_rms__RMS3;
double _three_phase_at_load_8__mid__pll_abc_to_dq_alpha_beta_to_dq__d;
double _three_phase_at_load_8__mid__pll_abc_to_dq_alpha_beta_to_dq__q;
double _three_phase_at_load_8__mid__pll_abc_to_dq_alpha_beta_to_dq__k1;
double _three_phase_at_load_8__mid__pll_abc_to_dq_alpha_beta_to_dq__k2;

double _three_phase_at_load_9__area_2__i_rms_calc_rms__IN1;
double _three_phase_at_load_9__area_2__i_rms_calc_rms__IN2;
double _three_phase_at_load_9__area_2__i_rms_calc_rms__IN3;
double _three_phase_at_load_9__area_2__i_rms_calc_rms__dFract;
X_Int32 _three_phase_at_load_9__area_2__i_rms_calc_rms__mode;


double _three_phase_at_load_9__area_2__i_rms_calc_rms__RMS1;
double _three_phase_at_load_9__area_2__i_rms_calc_rms__RMS2;
double _three_phase_at_load_9__area_2__i_rms_calc_rms__RMS3;

double _three_phase_at_load_9__area_2__vll_rms_calc_rms__IN1;
double _three_phase_at_load_9__area_2__vll_rms_calc_rms__IN2;
double _three_phase_at_load_9__area_2__vll_rms_calc_rms__IN3;
double _three_phase_at_load_9__area_2__vll_rms_calc_rms__dFract;
X_Int32 _three_phase_at_load_9__area_2__vll_rms_calc_rms__mode;


double _three_phase_at_load_9__area_2__vll_rms_calc_rms__RMS1;
double _three_phase_at_load_9__area_2__vll_rms_calc_rms__RMS2;
double _three_phase_at_load_9__area_2__vll_rms_calc_rms__RMS3;

double _three_phase_at_load_9__area_2__vln_rms_calc_rms__IN1;
double _three_phase_at_load_9__area_2__vln_rms_calc_rms__IN2;
double _three_phase_at_load_9__area_2__vln_rms_calc_rms__IN3;
double _three_phase_at_load_9__area_2__vln_rms_calc_rms__dFract;
X_Int32 _three_phase_at_load_9__area_2__vln_rms_calc_rms__mode;


double _three_phase_at_load_9__area_2__vln_rms_calc_rms__RMS1;
double _three_phase_at_load_9__area_2__vln_rms_calc_rms__RMS2;
double _three_phase_at_load_9__area_2__vln_rms_calc_rms__RMS3;
double _three_phase_at_load_9__area_2__pll_abc_to_dq_alpha_beta_to_dq__d;
double _three_phase_at_load_9__area_2__pll_abc_to_dq_alpha_beta_to_dq__q;
double _three_phase_at_load_9__area_2__pll_abc_to_dq_alpha_beta_to_dq__k1;
double _three_phase_at_load_9__area_2__pll_abc_to_dq_alpha_beta_to_dq__k2;

double _diesel_gen1_control_define_control_mode_control_mode__Control_mode;


double _diesel_gen1_control_define_control_mode_control_mode__P_control;
double _diesel_gen1_control_define_control_mode_control_mode__Q_control;
double _diesel_gen1_control_freq_setpoint_control_p_limit__out;
double _diesel_gen1_control_freq_setpoint_control_load_share_switch__out;
float _diesel_gen1_control_gen_on__tmp;
double _diesel_gen1_control_governor_and_engine_degov_integrator_integrator1__out;
double _diesel_gen1_control_governor_and_engine_w_switch__out;
double _diesel_gen1_control_round1__out;
double _diesel_gen1_control_pf_control_greater_equal__out;
double _diesel_gen1_output_bus_join1__out[14];

double _diesel_gen2_control_define_control_mode_control_mode__Control_mode;


double _diesel_gen2_control_define_control_mode_control_mode__P_control;
double _diesel_gen2_control_define_control_mode_control_mode__Q_control;
double _diesel_gen2_control_freq_setpoint_control_p_limit__out;
double _diesel_gen2_control_freq_setpoint_control_load_share_switch__out;
float _diesel_gen2_control_gen_on__tmp;
double _diesel_gen2_control_governor_and_engine_degov_integrator_integrator1__out;
double _diesel_gen2_control_governor_and_engine_w_switch__out;
double _diesel_gen2_control_round1__out;
double _diesel_gen2_control_pf_control_greater_equal__out;
double _diesel_gen2_output_bus_join1__out[14];

double _diesel_gen4_control_define_control_mode_control_mode__Control_mode;


double _diesel_gen4_control_define_control_mode_control_mode__P_control;
double _diesel_gen4_control_define_control_mode_control_mode__Q_control;
double _diesel_gen4_control_freq_setpoint_control_p_limit__out;
double _diesel_gen4_control_freq_setpoint_control_load_share_switch__out;
float _diesel_gen4_control_gen_on__tmp;
double _diesel_gen4_control_governor_and_engine_degov_integrator_integrator1__out;
double _diesel_gen4_control_governor_and_engine_w_switch__out;
double _diesel_gen4_control_round1__out;
double _diesel_gen4_control_pf_control_greater_equal__out;
double _diesel_gen4_output_bus_join1__out[14];

double _diesel_gen3_control_define_control_mode_control_mode__Control_mode;


double _diesel_gen3_control_define_control_mode_control_mode__P_control;
double _diesel_gen3_control_define_control_mode_control_mode__Q_control;
double _diesel_gen3_control_freq_setpoint_control_p_limit__out;
double _diesel_gen3_control_freq_setpoint_control_load_share_switch__out;
float _diesel_gen3_control_gen_on__tmp;
double _diesel_gen3_control_governor_and_engine_degov_integrator_integrator1__out;
double _diesel_gen3_control_governor_and_engine_w_switch__out;
double _diesel_gen3_control_round1__out;
double _diesel_gen3_control_pf_control_greater_equal__out;
double _diesel_gen3_output_bus_join1__out[14];
double _diesel_gen1_control_exciter_dc4b_tf3__out;
double _diesel_gen1_control_exciter_dc4b_tf3__b_coeff[2] = {0.9999000099990002, 0.9999000099990002};
double _diesel_gen1_control_exciter_dc4b_tf3__a_coeff[2] = {1.0, 0.9998000199980002};
double _diesel_gen1_control_exciter_dc4b_tf3__a_sum;
double _diesel_gen1_control_exciter_dc4b_tf3__b_sum;
double _diesel_gen1_control_exciter_dc4b_tf3__delay_line_in;
double _diesel_gen1_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__alpha;
double _diesel_gen1_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__beta;
double _diesel_gen1_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__gamma;
double _diesel_gen1_measurements_3ph_pll_gen_pll_pi_gain1__out;
double _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__out;
double _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__b_coeff[2] = {0.006243953390974721, 0.006243953390974721};
double _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__a_coeff[2] = {1.0, -0.9875120932180504};
double _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__a_sum;
double _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__b_sum;
double _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__delay_line_in;
double _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__out;
double _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__b_coeff[2] = {0.006243953390974721, 0.006243953390974721};
double _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__a_coeff[2] = {1.0, -0.9875120932180504};
double _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__a_sum;
double _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__b_sum;
double _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__delay_line_in;
double _diesel_gen1_control_bus_split1__out;
double _diesel_gen1_control_bus_split1__out1;
double _diesel_gen1_control_bus_split1__out2;
double _diesel_gen1_control_bus_split1__out3;
double _diesel_gen1_sync_check_check_v_diff_and__out;
float _diesel_gen1_sync_check_f_match__tmp;
double _diesel_gen1_sync_check_check_phase_diff_counter_counter1_en_switch__out;
double _diesel_gen1_sync_check_check_phase_diff_counter_not__out;
double _diesel_gen1_control_start_exciter_and__out;
double _diesel_gen1_control_check_steady_state_w_comparator3__out;
double _diesel_gen2_control_exciter_dc4b_tf3__out;
double _diesel_gen2_control_exciter_dc4b_tf3__b_coeff[2] = {0.9999000099990002, 0.9999000099990002};
double _diesel_gen2_control_exciter_dc4b_tf3__a_coeff[2] = {1.0, 0.9998000199980002};
double _diesel_gen2_control_exciter_dc4b_tf3__a_sum;
double _diesel_gen2_control_exciter_dc4b_tf3__b_sum;
double _diesel_gen2_control_exciter_dc4b_tf3__delay_line_in;
double _diesel_gen2_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__alpha;
double _diesel_gen2_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__beta;
double _diesel_gen2_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__gamma;
double _diesel_gen2_measurements_3ph_pll_gen_pll_pi_gain1__out;
double _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__out;
double _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__b_coeff[2] = {0.006243953390974721, 0.006243953390974721};
double _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__a_coeff[2] = {1.0, -0.9875120932180504};
double _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__a_sum;
double _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__b_sum;
double _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__delay_line_in;
double _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__out;
double _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__b_coeff[2] = {0.006243953390974721, 0.006243953390974721};
double _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__a_coeff[2] = {1.0, -0.9875120932180504};
double _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__a_sum;
double _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__b_sum;
double _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__delay_line_in;
double _diesel_gen2_control_bus_split1__out;
double _diesel_gen2_control_bus_split1__out1;
double _diesel_gen2_control_bus_split1__out2;
double _diesel_gen2_control_bus_split1__out3;
double _diesel_gen2_sync_check_check_v_diff_and__out;
float _diesel_gen2_sync_check_f_match__tmp;
double _diesel_gen2_sync_check_check_phase_diff_counter_counter1_en_switch__out;
double _diesel_gen2_sync_check_check_phase_diff_counter_not__out;
double _diesel_gen2_control_start_exciter_and__out;
double _diesel_gen2_control_check_steady_state_w_comparator3__out;
double _diesel_gen3_control_exciter_dc4b_tf3__out;
double _diesel_gen3_control_exciter_dc4b_tf3__b_coeff[2] = {0.9999000099990002, 0.9999000099990002};
double _diesel_gen3_control_exciter_dc4b_tf3__a_coeff[2] = {1.0, 0.9998000199980002};
double _diesel_gen3_control_exciter_dc4b_tf3__a_sum;
double _diesel_gen3_control_exciter_dc4b_tf3__b_sum;
double _diesel_gen3_control_exciter_dc4b_tf3__delay_line_in;
double _diesel_gen3_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__alpha;
double _diesel_gen3_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__beta;
double _diesel_gen3_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__gamma;
double _diesel_gen3_measurements_3ph_pll_gen_pll_pi_gain1__out;
double _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__out;
double _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__b_coeff[2] = {0.006243953390974721, 0.006243953390974721};
double _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__a_coeff[2] = {1.0, -0.9875120932180504};
double _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__a_sum;
double _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__b_sum;
double _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__delay_line_in;
double _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__out;
double _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__b_coeff[2] = {0.006243953390974721, 0.006243953390974721};
double _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__a_coeff[2] = {1.0, -0.9875120932180504};
double _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__a_sum;
double _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__b_sum;
double _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__delay_line_in;
double _diesel_gen3_control_bus_split1__out;
double _diesel_gen3_control_bus_split1__out1;
double _diesel_gen3_control_bus_split1__out2;
double _diesel_gen3_control_bus_split1__out3;
double _diesel_gen3_sync_check_check_v_diff_and__out;
float _diesel_gen3_sync_check_f_match__tmp;
double _diesel_gen3_sync_check_check_phase_diff_counter_counter1_en_switch__out;
double _diesel_gen3_sync_check_check_phase_diff_counter_not__out;
double _diesel_gen3_control_start_exciter_and__out;
double _diesel_gen3_control_check_steady_state_w_comparator3__out;
double _diesel_gen4_control_exciter_dc4b_tf3__out;
double _diesel_gen4_control_exciter_dc4b_tf3__b_coeff[2] = {0.9999000099990002, 0.9999000099990002};
double _diesel_gen4_control_exciter_dc4b_tf3__a_coeff[2] = {1.0, 0.9998000199980002};
double _diesel_gen4_control_exciter_dc4b_tf3__a_sum;
double _diesel_gen4_control_exciter_dc4b_tf3__b_sum;
double _diesel_gen4_control_exciter_dc4b_tf3__delay_line_in;
double _diesel_gen4_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__alpha;
double _diesel_gen4_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__beta;
double _diesel_gen4_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__gamma;
double _diesel_gen4_measurements_3ph_pll_gen_pll_pi_gain1__out;
double _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__out;
double _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__b_coeff[2] = {0.006243953390974721, 0.006243953390974721};
double _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__a_coeff[2] = {1.0, -0.9875120932180504};
double _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__a_sum;
double _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__b_sum;
double _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__delay_line_in;
double _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__out;
double _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__b_coeff[2] = {0.006243953390974721, 0.006243953390974721};
double _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__a_coeff[2] = {1.0, -0.9875120932180504};
double _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__a_sum;
double _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__b_sum;
double _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__delay_line_in;
double _diesel_gen4_control_bus_split1__out;
double _diesel_gen4_control_bus_split1__out1;
double _diesel_gen4_control_bus_split1__out2;
double _diesel_gen4_control_bus_split1__out3;
double _diesel_gen4_sync_check_check_v_diff_and__out;
float _diesel_gen4_sync_check_f_match__tmp;
double _diesel_gen4_sync_check_check_phase_diff_counter_counter1_en_switch__out;
double _diesel_gen4_sync_check_check_phase_diff_counter_not__out;
double _diesel_gen4_control_start_exciter_and__out;
double _diesel_gen4_control_check_steady_state_w_comparator3__out;
double _three_phase_at_load_7__area_1__power_meter_power__Ia;
double _three_phase_at_load_7__area_1__power_meter_power__Ib;
double _three_phase_at_load_7__area_1__power_meter_power__Ic;
double _three_phase_at_load_7__area_1__power_meter_power__IrmsA;
double _three_phase_at_load_7__area_1__power_meter_power__IrmsB;
double _three_phase_at_load_7__area_1__power_meter_power__IrmsC;
double _three_phase_at_load_7__area_1__power_meter_power__Va;
double _three_phase_at_load_7__area_1__power_meter_power__Vb;
double _three_phase_at_load_7__area_1__power_meter_power__Vc;
double _three_phase_at_load_7__area_1__power_meter_power__VrmsA;
double _three_phase_at_load_7__area_1__power_meter_power__VrmsB;
double _three_phase_at_load_7__area_1__power_meter_power__VrmsC;
double _three_phase_at_load_7__area_1__power_meter_power__dFract;
X_Int32 _three_phase_at_load_7__area_1__power_meter_power__mode;
X_Int32 _three_phase_at_load_7__area_1__power_meter_power__submode;


double _three_phase_at_load_7__area_1__power_meter_power__P;
double _three_phase_at_load_7__area_1__power_meter_power__PF;
double _three_phase_at_load_7__area_1__power_meter_power__PFa;
double _three_phase_at_load_7__area_1__power_meter_power__PFb;
double _three_phase_at_load_7__area_1__power_meter_power__PFc;
double _three_phase_at_load_7__area_1__power_meter_power__Pa;
double _three_phase_at_load_7__area_1__power_meter_power__Pb;
double _three_phase_at_load_7__area_1__power_meter_power__Pc;
double _three_phase_at_load_7__area_1__power_meter_power__Q;
double _three_phase_at_load_7__area_1__power_meter_power__Qa;
double _three_phase_at_load_7__area_1__power_meter_power__Qb;
double _three_phase_at_load_7__area_1__power_meter_power__Qc;
double _three_phase_at_load_7__area_1__power_meter_power__S;
double _three_phase_at_load_7__area_1__power_meter_power__Sa;
double _three_phase_at_load_7__area_1__power_meter_power__Sb;
double _three_phase_at_load_7__area_1__power_meter_power__Sc;
double _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_d__out;
double _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_d__previous_filtered_value;
double _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_q__out;
double _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_q__previous_filtered_value;
double _three_phase_at_load_8__mid__power_meter_power__Ia;
double _three_phase_at_load_8__mid__power_meter_power__Ib;
double _three_phase_at_load_8__mid__power_meter_power__Ic;
double _three_phase_at_load_8__mid__power_meter_power__IrmsA;
double _three_phase_at_load_8__mid__power_meter_power__IrmsB;
double _three_phase_at_load_8__mid__power_meter_power__IrmsC;
double _three_phase_at_load_8__mid__power_meter_power__Va;
double _three_phase_at_load_8__mid__power_meter_power__Vb;
double _three_phase_at_load_8__mid__power_meter_power__Vc;
double _three_phase_at_load_8__mid__power_meter_power__VrmsA;
double _three_phase_at_load_8__mid__power_meter_power__VrmsB;
double _three_phase_at_load_8__mid__power_meter_power__VrmsC;
double _three_phase_at_load_8__mid__power_meter_power__dFract;
X_Int32 _three_phase_at_load_8__mid__power_meter_power__mode;
X_Int32 _three_phase_at_load_8__mid__power_meter_power__submode;


double _three_phase_at_load_8__mid__power_meter_power__P;
double _three_phase_at_load_8__mid__power_meter_power__PF;
double _three_phase_at_load_8__mid__power_meter_power__PFa;
double _three_phase_at_load_8__mid__power_meter_power__PFb;
double _three_phase_at_load_8__mid__power_meter_power__PFc;
double _three_phase_at_load_8__mid__power_meter_power__Pa;
double _three_phase_at_load_8__mid__power_meter_power__Pb;
double _three_phase_at_load_8__mid__power_meter_power__Pc;
double _three_phase_at_load_8__mid__power_meter_power__Q;
double _three_phase_at_load_8__mid__power_meter_power__Qa;
double _three_phase_at_load_8__mid__power_meter_power__Qb;
double _three_phase_at_load_8__mid__power_meter_power__Qc;
double _three_phase_at_load_8__mid__power_meter_power__S;
double _three_phase_at_load_8__mid__power_meter_power__Sa;
double _three_phase_at_load_8__mid__power_meter_power__Sb;
double _three_phase_at_load_8__mid__power_meter_power__Sc;
double _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_d__out;
double _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_d__previous_filtered_value;
double _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_q__out;
double _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_q__previous_filtered_value;
double _three_phase_at_load_9__area_2__power_meter_power__Ia;
double _three_phase_at_load_9__area_2__power_meter_power__Ib;
double _three_phase_at_load_9__area_2__power_meter_power__Ic;
double _three_phase_at_load_9__area_2__power_meter_power__IrmsA;
double _three_phase_at_load_9__area_2__power_meter_power__IrmsB;
double _three_phase_at_load_9__area_2__power_meter_power__IrmsC;
double _three_phase_at_load_9__area_2__power_meter_power__Va;
double _three_phase_at_load_9__area_2__power_meter_power__Vb;
double _three_phase_at_load_9__area_2__power_meter_power__Vc;
double _three_phase_at_load_9__area_2__power_meter_power__VrmsA;
double _three_phase_at_load_9__area_2__power_meter_power__VrmsB;
double _three_phase_at_load_9__area_2__power_meter_power__VrmsC;
double _three_phase_at_load_9__area_2__power_meter_power__dFract;
X_Int32 _three_phase_at_load_9__area_2__power_meter_power__mode;
X_Int32 _three_phase_at_load_9__area_2__power_meter_power__submode;


double _three_phase_at_load_9__area_2__power_meter_power__P;
double _three_phase_at_load_9__area_2__power_meter_power__PF;
double _three_phase_at_load_9__area_2__power_meter_power__PFa;
double _three_phase_at_load_9__area_2__power_meter_power__PFb;
double _three_phase_at_load_9__area_2__power_meter_power__PFc;
double _three_phase_at_load_9__area_2__power_meter_power__Pa;
double _three_phase_at_load_9__area_2__power_meter_power__Pb;
double _three_phase_at_load_9__area_2__power_meter_power__Pc;
double _three_phase_at_load_9__area_2__power_meter_power__Q;
double _three_phase_at_load_9__area_2__power_meter_power__Qa;
double _three_phase_at_load_9__area_2__power_meter_power__Qb;
double _three_phase_at_load_9__area_2__power_meter_power__Qc;
double _three_phase_at_load_9__area_2__power_meter_power__S;
double _three_phase_at_load_9__area_2__power_meter_power__Sa;
double _three_phase_at_load_9__area_2__power_meter_power__Sb;
double _three_phase_at_load_9__area_2__power_meter_power__Sc;
double _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_d__out;
double _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_d__previous_filtered_value;
double _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_q__out;
double _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_q__previous_filtered_value;
double _diesel_gen1_control_freq_setpoint_control_p_ramp__out;
double _diesel_gen1_control_governor_and_engine_degov_integrator_limit1__out;
double _diesel_gen1_control_governor_and_engine_w_ramp__out;

double _diesel_gen1_control_read_op_mode__GCB_status;
double _diesel_gen1_control_read_op_mode__OP_mode;


double _diesel_gen1_control_read_op_mode__GridFollowing;
double _diesel_gen1_control_read_op_mode__GridForming;
double _diesel_gen1_control_read_op_mode__StandBy;
double _diesel_gen1_control_read_op_mode__enable;
double _diesel_gen2_control_freq_setpoint_control_p_ramp__out;
double _diesel_gen2_control_governor_and_engine_degov_integrator_limit1__out;
double _diesel_gen2_control_governor_and_engine_w_ramp__out;

double _diesel_gen2_control_read_op_mode__GCB_status;
double _diesel_gen2_control_read_op_mode__OP_mode;


double _diesel_gen2_control_read_op_mode__GridFollowing;
double _diesel_gen2_control_read_op_mode__GridForming;
double _diesel_gen2_control_read_op_mode__StandBy;
double _diesel_gen2_control_read_op_mode__enable;
double _diesel_gen4_control_freq_setpoint_control_p_ramp__out;
double _diesel_gen4_control_governor_and_engine_degov_integrator_limit1__out;
double _diesel_gen4_control_governor_and_engine_w_ramp__out;

double _diesel_gen4_control_read_op_mode__GCB_status;
double _diesel_gen4_control_read_op_mode__OP_mode;


double _diesel_gen4_control_read_op_mode__GridFollowing;
double _diesel_gen4_control_read_op_mode__GridForming;
double _diesel_gen4_control_read_op_mode__StandBy;
double _diesel_gen4_control_read_op_mode__enable;
double _diesel_gen3_control_freq_setpoint_control_p_ramp__out;
double _diesel_gen3_control_governor_and_engine_degov_integrator_limit1__out;
double _diesel_gen3_control_governor_and_engine_w_ramp__out;

double _diesel_gen3_control_read_op_mode__GCB_status;
double _diesel_gen3_control_read_op_mode__OP_mode;


double _diesel_gen3_control_read_op_mode__GridFollowing;
double _diesel_gen3_control_read_op_mode__GridForming;
double _diesel_gen3_control_read_op_mode__StandBy;
double _diesel_gen3_control_read_op_mode__enable;
double _diesel_gen1_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__d;
double _diesel_gen1_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__q;
double _diesel_gen1_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k1;
double _diesel_gen1_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k2;
double _diesel_gen1_measurements_3ph_pll_gen_pll_pi_sum5__out;
double _diesel_gen1_control_exciter_vt_to_vtpu__out;
double _diesel_gen1_control_exciter_to_pu__out;
double _diesel_gen1_control_freq_setpoint_control_p_3ph_to_pu__out;
double _diesel_gen1_control_governor_and_engine_to_pu__out;
double _diesel_gen1_control_pf_control_norm_pf_meas__Q;
double _diesel_gen1_control_pf_control_norm_pf_meas__pf;


double _diesel_gen1_control_pf_control_norm_pf_meas__pf_norm;

double _diesel_gen1_control_pf_control_norm_pf_ref__P;
double _diesel_gen1_control_pf_control_norm_pf_ref__pf;


double _diesel_gen1_control_pf_control_norm_pf_ref__pf_norm;
double _diesel_gen1_control_exciter_dc4b_pi_integrator1__out;
double _diesel_gen1_control_exciter_product1__out;
double _diesel_gen1_control_exciter_switch__out;
float _diesel_gen1_control_exciter_on__tmp;
double _diesel_gen2_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__d;
double _diesel_gen2_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__q;
double _diesel_gen2_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k1;
double _diesel_gen2_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k2;
double _diesel_gen2_measurements_3ph_pll_gen_pll_pi_sum5__out;
double _diesel_gen2_control_exciter_vt_to_vtpu__out;
double _diesel_gen2_control_exciter_to_pu__out;
double _diesel_gen2_control_freq_setpoint_control_p_3ph_to_pu__out;
double _diesel_gen2_control_governor_and_engine_to_pu__out;
double _diesel_gen2_control_pf_control_norm_pf_meas__Q;
double _diesel_gen2_control_pf_control_norm_pf_meas__pf;


double _diesel_gen2_control_pf_control_norm_pf_meas__pf_norm;

double _diesel_gen2_control_pf_control_norm_pf_ref__P;
double _diesel_gen2_control_pf_control_norm_pf_ref__pf;


double _diesel_gen2_control_pf_control_norm_pf_ref__pf_norm;
double _diesel_gen2_control_exciter_dc4b_pi_integrator1__out;
double _diesel_gen2_control_exciter_product1__out;
double _diesel_gen2_control_exciter_switch__out;
float _diesel_gen2_control_exciter_on__tmp;
double _diesel_gen3_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__d;
double _diesel_gen3_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__q;
double _diesel_gen3_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k1;
double _diesel_gen3_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k2;
double _diesel_gen3_measurements_3ph_pll_gen_pll_pi_sum5__out;
double _diesel_gen3_control_exciter_vt_to_vtpu__out;
double _diesel_gen3_control_exciter_to_pu__out;
double _diesel_gen3_control_freq_setpoint_control_p_3ph_to_pu__out;
double _diesel_gen3_control_governor_and_engine_to_pu__out;
double _diesel_gen3_control_pf_control_norm_pf_meas__Q;
double _diesel_gen3_control_pf_control_norm_pf_meas__pf;


double _diesel_gen3_control_pf_control_norm_pf_meas__pf_norm;

double _diesel_gen3_control_pf_control_norm_pf_ref__P;
double _diesel_gen3_control_pf_control_norm_pf_ref__pf;


double _diesel_gen3_control_pf_control_norm_pf_ref__pf_norm;
double _diesel_gen3_control_exciter_dc4b_pi_integrator1__out;
double _diesel_gen3_control_exciter_product1__out;
double _diesel_gen3_control_exciter_switch__out;
float _diesel_gen3_control_exciter_on__tmp;
double _diesel_gen4_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__d;
double _diesel_gen4_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__q;
double _diesel_gen4_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k1;
double _diesel_gen4_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k2;
double _diesel_gen4_measurements_3ph_pll_gen_pll_pi_sum5__out;
double _diesel_gen4_control_exciter_vt_to_vtpu__out;
double _diesel_gen4_control_exciter_to_pu__out;
double _diesel_gen4_control_freq_setpoint_control_p_3ph_to_pu__out;
double _diesel_gen4_control_governor_and_engine_to_pu__out;
double _diesel_gen4_control_pf_control_norm_pf_meas__Q;
double _diesel_gen4_control_pf_control_norm_pf_meas__pf;


double _diesel_gen4_control_pf_control_norm_pf_meas__pf_norm;

double _diesel_gen4_control_pf_control_norm_pf_ref__P;
double _diesel_gen4_control_pf_control_norm_pf_ref__pf;


double _diesel_gen4_control_pf_control_norm_pf_ref__pf_norm;
double _diesel_gen4_control_exciter_dc4b_pi_integrator1__out;
double _diesel_gen4_control_exciter_product1__out;
double _diesel_gen4_control_exciter_switch__out;
float _diesel_gen4_control_exciter_on__tmp;
double _three_phase_at_load_7__area_1__extra_output_bus__out[12];
double _three_phase_at_load_7__area_1__output_bus__out[30];

double _three_phase_at_load_7__area_1__pll_normalize__in1;
double _three_phase_at_load_7__area_1__pll_normalize__in2;


double _three_phase_at_load_7__area_1__pll_normalize__in2_pu;
double _three_phase_at_load_7__area_1__pll_normalize__pk;
double _three_phase_at_load_8__mid__extra_output_bus__out[12];
double _three_phase_at_load_8__mid__output_bus__out[30];

double _three_phase_at_load_8__mid__pll_normalize__in1;
double _three_phase_at_load_8__mid__pll_normalize__in2;


double _three_phase_at_load_8__mid__pll_normalize__in2_pu;
double _three_phase_at_load_8__mid__pll_normalize__pk;
double _three_phase_at_load_9__area_2__extra_output_bus__out[12];
double _three_phase_at_load_9__area_2__output_bus__out[30];

double _three_phase_at_load_9__area_2__pll_normalize__in1;
double _three_phase_at_load_9__area_2__pll_normalize__in2;


double _three_phase_at_load_9__area_2__pll_normalize__in2_pu;
double _three_phase_at_load_9__area_2__pll_normalize__pk;
double _diesel_gen1_control_freq_setpoint_control_product2__out;
double _diesel_gen1_control_governor_and_engine_degov_integrator_sum6__out;
double _diesel_gen1_control_bus_join1__out[5];
double _diesel_gen1_control_freq_setpoint_control_pi_integrator1__out;
double _diesel_gen1_control_freq_setpoint_control_w_switch__out;
float _diesel_gen1_control_gridfollowing__tmp;
float _diesel_gen1_control_gridforming__tmp;
float _diesel_gen1_control_standby__tmp;
double _diesel_gen1_control_pf_control_logical_operator5__out;
double _diesel_gen2_control_freq_setpoint_control_product2__out;
double _diesel_gen2_control_governor_and_engine_degov_integrator_sum6__out;
double _diesel_gen2_control_bus_join1__out[5];
double _diesel_gen2_control_freq_setpoint_control_pi_integrator1__out;
double _diesel_gen2_control_freq_setpoint_control_w_switch__out;
float _diesel_gen2_control_gridfollowing__tmp;
float _diesel_gen2_control_gridforming__tmp;
float _diesel_gen2_control_standby__tmp;
double _diesel_gen2_control_pf_control_logical_operator5__out;
double _diesel_gen4_control_freq_setpoint_control_product2__out;
double _diesel_gen4_control_governor_and_engine_degov_integrator_sum6__out;
double _diesel_gen4_control_bus_join1__out[5];
double _diesel_gen4_control_freq_setpoint_control_pi_integrator1__out;
double _diesel_gen4_control_freq_setpoint_control_w_switch__out;
float _diesel_gen4_control_gridfollowing__tmp;
float _diesel_gen4_control_gridforming__tmp;
float _diesel_gen4_control_standby__tmp;
double _diesel_gen4_control_pf_control_logical_operator5__out;
double _diesel_gen3_control_freq_setpoint_control_product2__out;
double _diesel_gen3_control_governor_and_engine_degov_integrator_sum6__out;
double _diesel_gen3_control_bus_join1__out[5];
double _diesel_gen3_control_freq_setpoint_control_pi_integrator1__out;
double _diesel_gen3_control_freq_setpoint_control_w_switch__out;
float _diesel_gen3_control_gridfollowing__tmp;
float _diesel_gen3_control_gridforming__tmp;
float _diesel_gen3_control_standby__tmp;
double _diesel_gen3_control_pf_control_logical_operator5__out;

double _diesel_gen1_sync_check_plls_pll_grid_pll_normalize_v_terminal__d;
double _diesel_gen1_sync_check_plls_pll_grid_pll_normalize_v_terminal__q;


double _diesel_gen1_sync_check_plls_pll_grid_pll_normalize_v_terminal__q_pu;
double _diesel_gen1_sync_check_plls_pll_grid_pll_normalize_v_terminal__t;
double _diesel_gen1_measurements_3ph_pll_gen_pll_pi_limit1__out;
double _diesel_gen1_control_exciter_dc4b_tf1__out;
double _diesel_gen1_control_exciter_dc4b_tf1__b_coeff[2] = {0.9803921568627451, 0.9803921568627452};
double _diesel_gen1_control_exciter_dc4b_tf1__a_coeff[2] = {1.0, 0.9607843137254902};
double _diesel_gen1_control_exciter_dc4b_tf1__a_sum;
double _diesel_gen1_control_exciter_dc4b_tf1__b_sum;
double _diesel_gen1_control_exciter_dc4b_tf1__delay_line_in;
double _diesel_gen1_control_exciter_product2__out;
double _diesel_gen1_control_freq_setpoint_control_product1__out;
double _diesel_gen1_control_freq_setpoint_control_product3__out;
double _diesel_gen1_control_governor_and_engine_product1__out;
double _diesel_gen1_control_exciter_vfpu_to_vf__out;
double _diesel_gen1_control_exciter_rate_limit__out;

double _diesel_gen2_sync_check_plls_pll_grid_pll_normalize_v_terminal__d;
double _diesel_gen2_sync_check_plls_pll_grid_pll_normalize_v_terminal__q;


double _diesel_gen2_sync_check_plls_pll_grid_pll_normalize_v_terminal__q_pu;
double _diesel_gen2_sync_check_plls_pll_grid_pll_normalize_v_terminal__t;
double _diesel_gen2_measurements_3ph_pll_gen_pll_pi_limit1__out;
double _diesel_gen2_control_exciter_dc4b_tf1__out;
double _diesel_gen2_control_exciter_dc4b_tf1__b_coeff[2] = {0.9803921568627451, 0.9803921568627452};
double _diesel_gen2_control_exciter_dc4b_tf1__a_coeff[2] = {1.0, 0.9607843137254902};
double _diesel_gen2_control_exciter_dc4b_tf1__a_sum;
double _diesel_gen2_control_exciter_dc4b_tf1__b_sum;
double _diesel_gen2_control_exciter_dc4b_tf1__delay_line_in;
double _diesel_gen2_control_exciter_product2__out;
double _diesel_gen2_control_freq_setpoint_control_product1__out;
double _diesel_gen2_control_freq_setpoint_control_product3__out;
double _diesel_gen2_control_governor_and_engine_product1__out;
double _diesel_gen2_control_exciter_vfpu_to_vf__out;
double _diesel_gen2_control_exciter_rate_limit__out;

double _diesel_gen3_sync_check_plls_pll_grid_pll_normalize_v_terminal__d;
double _diesel_gen3_sync_check_plls_pll_grid_pll_normalize_v_terminal__q;


double _diesel_gen3_sync_check_plls_pll_grid_pll_normalize_v_terminal__q_pu;
double _diesel_gen3_sync_check_plls_pll_grid_pll_normalize_v_terminal__t;
double _diesel_gen3_measurements_3ph_pll_gen_pll_pi_limit1__out;
double _diesel_gen3_control_exciter_dc4b_tf1__out;
double _diesel_gen3_control_exciter_dc4b_tf1__b_coeff[2] = {0.9803921568627451, 0.9803921568627452};
double _diesel_gen3_control_exciter_dc4b_tf1__a_coeff[2] = {1.0, 0.9607843137254902};
double _diesel_gen3_control_exciter_dc4b_tf1__a_sum;
double _diesel_gen3_control_exciter_dc4b_tf1__b_sum;
double _diesel_gen3_control_exciter_dc4b_tf1__delay_line_in;
double _diesel_gen3_control_exciter_product2__out;
double _diesel_gen3_control_freq_setpoint_control_product1__out;
double _diesel_gen3_control_freq_setpoint_control_product3__out;
double _diesel_gen3_control_governor_and_engine_product1__out;
double _diesel_gen3_control_exciter_vfpu_to_vf__out;
double _diesel_gen3_control_exciter_rate_limit__out;

double _diesel_gen4_sync_check_plls_pll_grid_pll_normalize_v_terminal__d;
double _diesel_gen4_sync_check_plls_pll_grid_pll_normalize_v_terminal__q;


double _diesel_gen4_sync_check_plls_pll_grid_pll_normalize_v_terminal__q_pu;
double _diesel_gen4_sync_check_plls_pll_grid_pll_normalize_v_terminal__t;
double _diesel_gen4_measurements_3ph_pll_gen_pll_pi_limit1__out;
double _diesel_gen4_control_exciter_dc4b_tf1__out;
double _diesel_gen4_control_exciter_dc4b_tf1__b_coeff[2] = {0.9803921568627451, 0.9803921568627452};
double _diesel_gen4_control_exciter_dc4b_tf1__a_coeff[2] = {1.0, 0.9607843137254902};
double _diesel_gen4_control_exciter_dc4b_tf1__a_sum;
double _diesel_gen4_control_exciter_dc4b_tf1__b_sum;
double _diesel_gen4_control_exciter_dc4b_tf1__delay_line_in;
double _diesel_gen4_control_exciter_product2__out;
double _diesel_gen4_control_freq_setpoint_control_product1__out;
double _diesel_gen4_control_freq_setpoint_control_product3__out;
double _diesel_gen4_control_governor_and_engine_product1__out;
double _diesel_gen4_control_exciter_vfpu_to_vf__out;
double _diesel_gen4_control_exciter_rate_limit__out;
double _three_phase_at_load_7__area_1__pll_pid_kd__out;
double _three_phase_at_load_7__area_1__pll_pid_ki__out;
double _three_phase_at_load_7__area_1__pll_pid_kp__out;
double _three_phase_at_load_8__mid__pll_pid_kd__out;
double _three_phase_at_load_8__mid__pll_pid_ki__out;
double _three_phase_at_load_8__mid__pll_pid_kp__out;
double _three_phase_at_load_9__area_2__pll_pid_kd__out;
double _three_phase_at_load_9__area_2__pll_pid_ki__out;
double _three_phase_at_load_9__area_2__pll_pid_kp__out;
double _diesel_gen1_control_freq_setpoint_control_sum5__out;
double _diesel_gen1_control_governor_and_engine_degov_integrator_kb__out;
double _diesel_gen1_sync_check_bus_split1__out;
double _diesel_gen1_sync_check_bus_split1__out1;
double _diesel_gen1_sync_check_bus_split1__out2;
double _diesel_gen1_sync_check_bus_split1__out3;
double _diesel_gen1_sync_check_bus_split1__out4;
double _diesel_gen1_control_freq_setpoint_control_w_ramp__out;

double _diesel_gen1_control_read_control_mode_state__P;
double _diesel_gen1_control_read_control_mode_state__Q;
double _diesel_gen1_control_read_control_mode_state__enable;


double _diesel_gen1_control_read_control_mode_state__PQ;
double _diesel_gen1_control_read_control_mode_state__PV;
double _diesel_gen1_control_read_control_mode_state__Vf;
double _diesel_gen1_control_pf_control_pi_integrator1__out;
double _diesel_gen1_control_pf_control_signal_switch2__out;
double _diesel_gen2_control_freq_setpoint_control_sum5__out;
double _diesel_gen2_control_governor_and_engine_degov_integrator_kb__out;
double _diesel_gen2_sync_check_bus_split1__out;
double _diesel_gen2_sync_check_bus_split1__out1;
double _diesel_gen2_sync_check_bus_split1__out2;
double _diesel_gen2_sync_check_bus_split1__out3;
double _diesel_gen2_sync_check_bus_split1__out4;
double _diesel_gen2_control_freq_setpoint_control_w_ramp__out;

double _diesel_gen2_control_read_control_mode_state__P;
double _diesel_gen2_control_read_control_mode_state__Q;
double _diesel_gen2_control_read_control_mode_state__enable;


double _diesel_gen2_control_read_control_mode_state__PQ;
double _diesel_gen2_control_read_control_mode_state__PV;
double _diesel_gen2_control_read_control_mode_state__Vf;
double _diesel_gen2_control_pf_control_pi_integrator1__out;
double _diesel_gen2_control_pf_control_signal_switch2__out;
double _diesel_gen4_control_freq_setpoint_control_sum5__out;
double _diesel_gen4_control_governor_and_engine_degov_integrator_kb__out;
double _diesel_gen4_sync_check_bus_split1__out;
double _diesel_gen4_sync_check_bus_split1__out1;
double _diesel_gen4_sync_check_bus_split1__out2;
double _diesel_gen4_sync_check_bus_split1__out3;
double _diesel_gen4_sync_check_bus_split1__out4;
double _diesel_gen4_control_freq_setpoint_control_w_ramp__out;

double _diesel_gen4_control_read_control_mode_state__P;
double _diesel_gen4_control_read_control_mode_state__Q;
double _diesel_gen4_control_read_control_mode_state__enable;


double _diesel_gen4_control_read_control_mode_state__PQ;
double _diesel_gen4_control_read_control_mode_state__PV;
double _diesel_gen4_control_read_control_mode_state__Vf;
double _diesel_gen4_control_pf_control_pi_integrator1__out;
double _diesel_gen4_control_pf_control_signal_switch2__out;
double _diesel_gen3_control_freq_setpoint_control_sum5__out;
double _diesel_gen3_control_governor_and_engine_degov_integrator_kb__out;
double _diesel_gen3_sync_check_bus_split1__out;
double _diesel_gen3_sync_check_bus_split1__out1;
double _diesel_gen3_sync_check_bus_split1__out2;
double _diesel_gen3_sync_check_bus_split1__out3;
double _diesel_gen3_sync_check_bus_split1__out4;
double _diesel_gen3_control_freq_setpoint_control_w_ramp__out;

double _diesel_gen3_control_read_control_mode_state__P;
double _diesel_gen3_control_read_control_mode_state__Q;
double _diesel_gen3_control_read_control_mode_state__enable;


double _diesel_gen3_control_read_control_mode_state__PQ;
double _diesel_gen3_control_read_control_mode_state__PV;
double _diesel_gen3_control_read_control_mode_state__Vf;
double _diesel_gen3_control_pf_control_pi_integrator1__out;
double _diesel_gen3_control_pf_control_signal_switch2__out;
double _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__out;
double _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__b_coeff[2] = {0.006243953390974721, 0.006243953390974721};
double _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__a_coeff[2] = {1.0, -0.9875120932180504};
double _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__a_sum;
double _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__b_sum;
double _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__delay_line_in;
double _diesel_gen1_sync_check_plls_pll_grid_pll_pi_ki__out;
double _diesel_gen1_sync_check_plls_pll_grid_pll_pi_kp__out;
double _diesel_gen1_measurements_3ph_pll_gen_pll_pi_sum6__out;
double _diesel_gen1_measurements_3ph_pll_gen_pll_rate_limiter1__out;

double _diesel_gen1_measurements_3ph_pll_gen_pll_integrator__in;


double _diesel_gen1_measurements_3ph_pll_gen_pll_integrator__out;
double _diesel_gen1_control_freq_setpoint_control_f_droop_switch__out;
double _diesel_gen1_control_governor_and_engine_w_switch1__out;
double _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__out;
double _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__b_coeff[2] = {0.006243953390974721, 0.006243953390974721};
double _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__a_coeff[2] = {1.0, -0.9875120932180504};
double _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__a_sum;
double _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__b_sum;
double _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__delay_line_in;
double _diesel_gen2_sync_check_plls_pll_grid_pll_pi_ki__out;
double _diesel_gen2_sync_check_plls_pll_grid_pll_pi_kp__out;
double _diesel_gen2_measurements_3ph_pll_gen_pll_pi_sum6__out;
double _diesel_gen2_measurements_3ph_pll_gen_pll_rate_limiter1__out;

double _diesel_gen2_measurements_3ph_pll_gen_pll_integrator__in;


double _diesel_gen2_measurements_3ph_pll_gen_pll_integrator__out;
double _diesel_gen2_control_freq_setpoint_control_f_droop_switch__out;
double _diesel_gen2_control_governor_and_engine_w_switch1__out;
double _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__out;
double _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__b_coeff[2] = {0.006243953390974721, 0.006243953390974721};
double _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__a_coeff[2] = {1.0, -0.9875120932180504};
double _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__a_sum;
double _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__b_sum;
double _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__delay_line_in;
double _diesel_gen3_sync_check_plls_pll_grid_pll_pi_ki__out;
double _diesel_gen3_sync_check_plls_pll_grid_pll_pi_kp__out;
double _diesel_gen3_measurements_3ph_pll_gen_pll_pi_sum6__out;
double _diesel_gen3_measurements_3ph_pll_gen_pll_rate_limiter1__out;

double _diesel_gen3_measurements_3ph_pll_gen_pll_integrator__in;


double _diesel_gen3_measurements_3ph_pll_gen_pll_integrator__out;
double _diesel_gen3_control_freq_setpoint_control_f_droop_switch__out;
double _diesel_gen3_control_governor_and_engine_w_switch1__out;
double _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__out;
double _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__b_coeff[2] = {0.006243953390974721, 0.006243953390974721};
double _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__a_coeff[2] = {1.0, -0.9875120932180504};
double _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__a_sum;
double _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__b_sum;
double _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__delay_line_in;
double _diesel_gen4_sync_check_plls_pll_grid_pll_pi_ki__out;
double _diesel_gen4_sync_check_plls_pll_grid_pll_pi_kp__out;
double _diesel_gen4_measurements_3ph_pll_gen_pll_pi_sum6__out;
double _diesel_gen4_measurements_3ph_pll_gen_pll_rate_limiter1__out;

double _diesel_gen4_measurements_3ph_pll_gen_pll_integrator__in;


double _diesel_gen4_measurements_3ph_pll_gen_pll_integrator__out;
double _diesel_gen4_control_freq_setpoint_control_f_droop_switch__out;
double _diesel_gen4_control_governor_and_engine_w_switch1__out;
double _three_phase_at_load_7__area_1__pll_pid_sum8__out;
double _three_phase_at_load_8__mid__pll_pid_sum8__out;
double _three_phase_at_load_9__area_2__pll_pid_sum8__out;
double _diesel_gen1_control_freq_setpoint_control_sum6__out;
double _diesel_gen1_control_governor_and_engine_degov_integrator_sum7__out;
double _diesel_gen1_sync_check_bus_join2__out[3];
double _diesel_gen1_sync_check_contactor_control_not__out;
float _diesel_gen1_sync_check_speed_ss__tmp;
double _diesel_gen1_sync_check_and2__out;
float _diesel_gen1_control_read_control_mode_pq_mode__tmp;
float _diesel_gen1_control_read_control_mode_pv_mode__tmp;
float _diesel_gen1_control_read_control_mode_vf_mode__tmp;
double _diesel_gen1_control_pf_control_rate_limiter1__out;
double _diesel_gen2_control_freq_setpoint_control_sum6__out;
double _diesel_gen2_control_governor_and_engine_degov_integrator_sum7__out;
double _diesel_gen2_sync_check_bus_join2__out[3];
double _diesel_gen2_sync_check_contactor_control_not__out;
float _diesel_gen2_sync_check_speed_ss__tmp;
double _diesel_gen2_sync_check_and2__out;
float _diesel_gen2_control_read_control_mode_pq_mode__tmp;
float _diesel_gen2_control_read_control_mode_pv_mode__tmp;
float _diesel_gen2_control_read_control_mode_vf_mode__tmp;
double _diesel_gen2_control_pf_control_rate_limiter1__out;
double _diesel_gen4_control_freq_setpoint_control_sum6__out;
double _diesel_gen4_control_governor_and_engine_degov_integrator_sum7__out;
double _diesel_gen4_sync_check_bus_join2__out[3];
double _diesel_gen4_sync_check_contactor_control_not__out;
float _diesel_gen4_sync_check_speed_ss__tmp;
double _diesel_gen4_sync_check_and2__out;
float _diesel_gen4_control_read_control_mode_pq_mode__tmp;
float _diesel_gen4_control_read_control_mode_pv_mode__tmp;
float _diesel_gen4_control_read_control_mode_vf_mode__tmp;
double _diesel_gen4_control_pf_control_rate_limiter1__out;
double _diesel_gen3_control_freq_setpoint_control_sum6__out;
double _diesel_gen3_control_governor_and_engine_degov_integrator_sum7__out;
double _diesel_gen3_sync_check_bus_join2__out[3];
double _diesel_gen3_sync_check_contactor_control_not__out;
float _diesel_gen3_sync_check_speed_ss__tmp;
double _diesel_gen3_sync_check_and2__out;
float _diesel_gen3_control_read_control_mode_pq_mode__tmp;
float _diesel_gen3_control_read_control_mode_pv_mode__tmp;
float _diesel_gen3_control_read_control_mode_vf_mode__tmp;
double _diesel_gen3_control_pf_control_rate_limiter1__out;
double _diesel_gen1_sync_check_plls_pll_grid_pll_pi_sum8__out;
double _diesel_gen1_measurements_3ph_pll_gen_pll_pi_kb__out;
double _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__out;
double _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__b_coeff[3] = {0.00024132058064985085, 0.00048264116129992374, 0.0002413205806496288};
double _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__a_coeff[3] = {1.0, -1.9555883083348007, 0.9565535906574002};
double _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__a_sum;
double _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__b_sum;
double _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__delay_line_in;
double _diesel_gen1_measurements_bus_join3__out[3];
double _diesel_gen1_control_freq_setpoint_control_sum8__out;
double _diesel_gen2_sync_check_plls_pll_grid_pll_pi_sum8__out;
double _diesel_gen2_measurements_3ph_pll_gen_pll_pi_kb__out;
double _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__out;
double _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__b_coeff[3] = {0.00024132058064985085, 0.00048264116129992374, 0.0002413205806496288};
double _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__a_coeff[3] = {1.0, -1.9555883083348007, 0.9565535906574002};
double _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__a_sum;
double _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__b_sum;
double _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__delay_line_in;
double _diesel_gen2_measurements_bus_join3__out[3];
double _diesel_gen2_control_freq_setpoint_control_sum8__out;
double _diesel_gen3_sync_check_plls_pll_grid_pll_pi_sum8__out;
double _diesel_gen3_measurements_3ph_pll_gen_pll_pi_kb__out;
double _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__out;
double _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__b_coeff[3] = {0.00024132058064985085, 0.00048264116129992374, 0.0002413205806496288};
double _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__a_coeff[3] = {1.0, -1.9555883083348007, 0.9565535906574002};
double _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__a_sum;
double _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__b_sum;
double _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__delay_line_in;
double _diesel_gen3_measurements_bus_join3__out[3];
double _diesel_gen3_control_freq_setpoint_control_sum8__out;
double _diesel_gen4_sync_check_plls_pll_grid_pll_pi_sum8__out;
double _diesel_gen4_measurements_3ph_pll_gen_pll_pi_kb__out;
double _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__out;
double _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__b_coeff[3] = {0.00024132058064985085, 0.00048264116129992374, 0.0002413205806496288};
double _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__a_coeff[3] = {1.0, -1.9555883083348007, 0.9565535906574002};
double _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__a_sum;
double _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__b_sum;
double _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__delay_line_in;
double _diesel_gen4_measurements_bus_join3__out[3];
double _diesel_gen4_control_freq_setpoint_control_sum8__out;
double _three_phase_at_load_7__area_1__pll_pid_gain1__out;
double _three_phase_at_load_8__mid__pll_pid_gain1__out;
double _three_phase_at_load_9__area_2__pll_pid_gain1__out;
double _diesel_gen1_sync_check_contactor_control_bus_split1__out;
double _diesel_gen1_sync_check_contactor_control_bus_split1__out1;
double _diesel_gen1_sync_check_contactor_control_bus_split1__out2;
double _diesel_gen1_sync_check_and1__out;
float _diesel_gen1_sync_check_dw_synch_on__tmp;
double _diesel_gen1_control_pf_control_sum6__out;
double _diesel_gen2_sync_check_contactor_control_bus_split1__out;
double _diesel_gen2_sync_check_contactor_control_bus_split1__out1;
double _diesel_gen2_sync_check_contactor_control_bus_split1__out2;
double _diesel_gen2_sync_check_and1__out;
float _diesel_gen2_sync_check_dw_synch_on__tmp;
double _diesel_gen2_control_pf_control_sum6__out;
double _diesel_gen4_sync_check_contactor_control_bus_split1__out;
double _diesel_gen4_sync_check_contactor_control_bus_split1__out1;
double _diesel_gen4_sync_check_contactor_control_bus_split1__out2;
double _diesel_gen4_sync_check_and1__out;
float _diesel_gen4_sync_check_dw_synch_on__tmp;
double _diesel_gen4_control_pf_control_sum6__out;
double _diesel_gen3_sync_check_contactor_control_bus_split1__out;
double _diesel_gen3_sync_check_contactor_control_bus_split1__out1;
double _diesel_gen3_sync_check_contactor_control_bus_split1__out2;
double _diesel_gen3_sync_check_and1__out;
float _diesel_gen3_sync_check_dw_synch_on__tmp;
double _diesel_gen3_control_pf_control_sum6__out;
double _diesel_gen1_sync_check_plls_pll_grid_pll_pi_limit1__out;
double _diesel_gen1_measurements_3ph_pll_gen_pll_pi_sum7__out;
double _diesel_gen1_sync_check_plls_split1__out;
double _diesel_gen1_sync_check_plls_split1__out1;
double _diesel_gen1_sync_check_plls_split1__out2;
double _diesel_gen1_control_freq_setpoint_control_mode_switch__out;
double _diesel_gen2_sync_check_plls_pll_grid_pll_pi_limit1__out;
double _diesel_gen2_measurements_3ph_pll_gen_pll_pi_sum7__out;
double _diesel_gen2_sync_check_plls_split1__out;
double _diesel_gen2_sync_check_plls_split1__out1;
double _diesel_gen2_sync_check_plls_split1__out2;
double _diesel_gen2_control_freq_setpoint_control_mode_switch__out;
double _diesel_gen3_sync_check_plls_pll_grid_pll_pi_limit1__out;
double _diesel_gen3_measurements_3ph_pll_gen_pll_pi_sum7__out;
double _diesel_gen3_sync_check_plls_split1__out;
double _diesel_gen3_sync_check_plls_split1__out1;
double _diesel_gen3_sync_check_plls_split1__out2;
double _diesel_gen3_control_freq_setpoint_control_mode_switch__out;
double _diesel_gen4_sync_check_plls_pll_grid_pll_pi_limit1__out;
double _diesel_gen4_measurements_3ph_pll_gen_pll_pi_sum7__out;
double _diesel_gen4_sync_check_plls_split1__out;
double _diesel_gen4_sync_check_plls_split1__out1;
double _diesel_gen4_sync_check_plls_split1__out2;
double _diesel_gen4_control_freq_setpoint_control_mode_switch__out;
double _three_phase_at_load_7__area_1__pll_pid_sum5__out;
double _three_phase_at_load_8__mid__pll_pid_sum5__out;
double _three_phase_at_load_9__area_2__pll_pid_sum5__out;
double _diesel_gen1_sync_check_contactor_control_edge_detection1_relational_operator1__out;
double _diesel_gen1_sync_check_contactor_control_or__out;
float _diesel_gen1_sync_check_check_phase_on__tmp;
double _diesel_gen1_sync_check_check_phase_diff_pi_integrator1__out;
double _diesel_gen1_control_pf_control_pi_ki__out;
double _diesel_gen1_control_pf_control_pi_kp__out;
double _diesel_gen2_sync_check_contactor_control_edge_detection1_relational_operator1__out;
double _diesel_gen2_sync_check_contactor_control_or__out;
float _diesel_gen2_sync_check_check_phase_on__tmp;
double _diesel_gen2_sync_check_check_phase_diff_pi_integrator1__out;
double _diesel_gen2_control_pf_control_pi_ki__out;
double _diesel_gen2_control_pf_control_pi_kp__out;
double _diesel_gen4_sync_check_contactor_control_edge_detection1_relational_operator1__out;
double _diesel_gen4_sync_check_contactor_control_or__out;
float _diesel_gen4_sync_check_check_phase_on__tmp;
double _diesel_gen4_sync_check_check_phase_diff_pi_integrator1__out;
double _diesel_gen4_control_pf_control_pi_ki__out;
double _diesel_gen4_control_pf_control_pi_kp__out;
double _diesel_gen3_sync_check_contactor_control_edge_detection1_relational_operator1__out;
double _diesel_gen3_sync_check_contactor_control_or__out;
float _diesel_gen3_sync_check_check_phase_on__tmp;
double _diesel_gen3_sync_check_check_phase_diff_pi_integrator1__out;
double _diesel_gen3_control_pf_control_pi_ki__out;
double _diesel_gen3_control_pf_control_pi_kp__out;
double _diesel_gen1_sync_check_plls_pll_grid_pll_pi_sum6__out;

double _diesel_gen1_sync_check_plls_pll_grid_pll_integrator__in;


double _diesel_gen1_sync_check_plls_pll_grid_pll_integrator__output;
double _diesel_gen1_sync_check_plls_pll_grid_pll_rads_to_hz__out;
double _diesel_gen1_sync_check_plls_gain1__out;
double _diesel_gen1_sync_check_check_v_diff_sum1__out;
double _diesel_gen1_control_freq_setpoint_control_sum7__out;
double _diesel_gen2_sync_check_plls_pll_grid_pll_pi_sum6__out;

double _diesel_gen2_sync_check_plls_pll_grid_pll_integrator__in;


double _diesel_gen2_sync_check_plls_pll_grid_pll_integrator__output;
double _diesel_gen2_sync_check_plls_pll_grid_pll_rads_to_hz__out;
double _diesel_gen2_sync_check_plls_gain1__out;
double _diesel_gen2_sync_check_check_v_diff_sum1__out;
double _diesel_gen2_control_freq_setpoint_control_sum7__out;
double _diesel_gen3_sync_check_plls_pll_grid_pll_pi_sum6__out;

double _diesel_gen3_sync_check_plls_pll_grid_pll_integrator__in;


double _diesel_gen3_sync_check_plls_pll_grid_pll_integrator__output;
double _diesel_gen3_sync_check_plls_pll_grid_pll_rads_to_hz__out;
double _diesel_gen3_sync_check_plls_gain1__out;
double _diesel_gen3_sync_check_check_v_diff_sum1__out;
double _diesel_gen3_control_freq_setpoint_control_sum7__out;
double _diesel_gen4_sync_check_plls_pll_grid_pll_pi_sum6__out;

double _diesel_gen4_sync_check_plls_pll_grid_pll_integrator__in;


double _diesel_gen4_sync_check_plls_pll_grid_pll_integrator__output;
double _diesel_gen4_sync_check_plls_pll_grid_pll_rads_to_hz__out;
double _diesel_gen4_sync_check_plls_gain1__out;
double _diesel_gen4_sync_check_check_v_diff_sum1__out;
double _diesel_gen4_control_freq_setpoint_control_sum7__out;
double _three_phase_at_load_7__area_1__pll_pid_limit1__out;
double _three_phase_at_load_8__mid__pll_pid_limit1__out;
double _three_phase_at_load_9__area_2__pll_pid_limit1__out;

double _diesel_gen1_sync_check_contactor_control_wait_to_trip__Reset;
double _diesel_gen1_sync_check_contactor_control_wait_to_trip__boolean;


double _diesel_gen1_sync_check_contactor_control_wait_to_trip__Trip;
double _diesel_gen1_sync_check_check_phase_diff_pi_sum5__out;
double _diesel_gen1_control_pf_control_pi_sum5__out;

double _diesel_gen2_sync_check_contactor_control_wait_to_trip__Reset;
double _diesel_gen2_sync_check_contactor_control_wait_to_trip__boolean;


double _diesel_gen2_sync_check_contactor_control_wait_to_trip__Trip;
double _diesel_gen2_sync_check_check_phase_diff_pi_sum5__out;
double _diesel_gen2_control_pf_control_pi_sum5__out;

double _diesel_gen4_sync_check_contactor_control_wait_to_trip__Reset;
double _diesel_gen4_sync_check_contactor_control_wait_to_trip__boolean;


double _diesel_gen4_sync_check_contactor_control_wait_to_trip__Trip;
double _diesel_gen4_sync_check_check_phase_diff_pi_sum5__out;
double _diesel_gen4_control_pf_control_pi_sum5__out;

double _diesel_gen3_sync_check_contactor_control_wait_to_trip__Reset;
double _diesel_gen3_sync_check_contactor_control_wait_to_trip__boolean;


double _diesel_gen3_sync_check_contactor_control_wait_to_trip__Trip;
double _diesel_gen3_sync_check_check_phase_diff_pi_sum5__out;
double _diesel_gen3_control_pf_control_pi_sum5__out;
double _diesel_gen1_sync_check_plls_pll_grid_pll_pi_kb__out;
double _diesel_gen1_sync_check_plls_sum1__out;
double _diesel_gen1_sync_check_plls_pll_grid_lpf_f__out;
double _diesel_gen1_sync_check_plls_pll_grid_lpf_f__b_coeff[2] = {0.006243953390974721, 0.006243953390974721};
double _diesel_gen1_sync_check_plls_pll_grid_lpf_f__a_coeff[2] = {1.0, -0.9875120932180504};
double _diesel_gen1_sync_check_plls_pll_grid_lpf_f__a_sum;
double _diesel_gen1_sync_check_plls_pll_grid_lpf_f__b_sum;
double _diesel_gen1_sync_check_plls_pll_grid_lpf_f__delay_line_in;
double _diesel_gen1_sync_check_check_f_diff_sum1__out;
double _diesel_gen1_sync_check_check_v_diff_pu__out;
double _diesel_gen1_control_freq_setpoint_control_sum3__out;
double _diesel_gen2_sync_check_plls_pll_grid_pll_pi_kb__out;
double _diesel_gen2_sync_check_plls_sum1__out;
double _diesel_gen2_sync_check_plls_pll_grid_lpf_f__out;
double _diesel_gen2_sync_check_plls_pll_grid_lpf_f__b_coeff[2] = {0.006243953390974721, 0.006243953390974721};
double _diesel_gen2_sync_check_plls_pll_grid_lpf_f__a_coeff[2] = {1.0, -0.9875120932180504};
double _diesel_gen2_sync_check_plls_pll_grid_lpf_f__a_sum;
double _diesel_gen2_sync_check_plls_pll_grid_lpf_f__b_sum;
double _diesel_gen2_sync_check_plls_pll_grid_lpf_f__delay_line_in;
double _diesel_gen2_sync_check_check_f_diff_sum1__out;
double _diesel_gen2_sync_check_check_v_diff_pu__out;
double _diesel_gen2_control_freq_setpoint_control_sum3__out;
double _diesel_gen3_sync_check_plls_pll_grid_pll_pi_kb__out;
double _diesel_gen3_sync_check_plls_sum1__out;
double _diesel_gen3_sync_check_plls_pll_grid_lpf_f__out;
double _diesel_gen3_sync_check_plls_pll_grid_lpf_f__b_coeff[2] = {0.006243953390974721, 0.006243953390974721};
double _diesel_gen3_sync_check_plls_pll_grid_lpf_f__a_coeff[2] = {1.0, -0.9875120932180504};
double _diesel_gen3_sync_check_plls_pll_grid_lpf_f__a_sum;
double _diesel_gen3_sync_check_plls_pll_grid_lpf_f__b_sum;
double _diesel_gen3_sync_check_plls_pll_grid_lpf_f__delay_line_in;
double _diesel_gen3_sync_check_check_f_diff_sum1__out;
double _diesel_gen3_sync_check_check_v_diff_pu__out;
double _diesel_gen3_control_freq_setpoint_control_sum3__out;
double _diesel_gen4_sync_check_plls_pll_grid_pll_pi_kb__out;
double _diesel_gen4_sync_check_plls_sum1__out;
double _diesel_gen4_sync_check_plls_pll_grid_lpf_f__out;
double _diesel_gen4_sync_check_plls_pll_grid_lpf_f__b_coeff[2] = {0.006243953390974721, 0.006243953390974721};
double _diesel_gen4_sync_check_plls_pll_grid_lpf_f__a_coeff[2] = {1.0, -0.9875120932180504};
double _diesel_gen4_sync_check_plls_pll_grid_lpf_f__a_sum;
double _diesel_gen4_sync_check_plls_pll_grid_lpf_f__b_sum;
double _diesel_gen4_sync_check_plls_pll_grid_lpf_f__delay_line_in;
double _diesel_gen4_sync_check_check_f_diff_sum1__out;
double _diesel_gen4_sync_check_check_v_diff_pu__out;
double _diesel_gen4_control_freq_setpoint_control_sum3__out;
double _three_phase_at_load_7__area_1__pll_pid_sum6__out;
double _three_phase_at_load_7__area_1__pll_rate_limiter1__out;

double _three_phase_at_load_7__area_1__pll_integrator__in;


double _three_phase_at_load_7__area_1__pll_integrator__out;
double _three_phase_at_load_8__mid__pll_pid_sum6__out;
double _three_phase_at_load_8__mid__pll_rate_limiter1__out;

double _three_phase_at_load_8__mid__pll_integrator__in;


double _three_phase_at_load_8__mid__pll_integrator__out;
double _three_phase_at_load_9__area_2__pll_pid_sum6__out;
double _three_phase_at_load_9__area_2__pll_rate_limiter1__out;

double _three_phase_at_load_9__area_2__pll_integrator__in;


double _three_phase_at_load_9__area_2__pll_integrator__out;
double _diesel_gen1_sync_check_check_phase_diff_pi_limit1__out;
double _diesel_gen1_control_pf_control_pi_limit1__out;
double _diesel_gen2_sync_check_check_phase_diff_pi_limit1__out;
double _diesel_gen2_control_pf_control_pi_limit1__out;
double _diesel_gen4_sync_check_check_phase_diff_pi_limit1__out;
double _diesel_gen4_control_pf_control_pi_limit1__out;
double _diesel_gen3_sync_check_check_phase_diff_pi_limit1__out;
double _diesel_gen3_control_pf_control_pi_limit1__out;
double _diesel_gen1_sync_check_plls_pll_grid_pll_pi_sum7__out;

double _diesel_gen1_sync_check_check_phase_diff_confine_phase__dtheta;


double _diesel_gen1_sync_check_check_phase_diff_confine_phase__dtheta_confined;
double _diesel_gen1_sync_check_check_f_diff_lpf_dwf__out;
double _diesel_gen1_sync_check_check_f_diff_lpf_dwf__b_coeff[2] = {0.0006279239944363413, 0.0006279239944364523};
double _diesel_gen1_sync_check_check_f_diff_lpf_dwf__a_coeff[2] = {1.0, -0.9987441520111273};
double _diesel_gen1_sync_check_check_f_diff_lpf_dwf__a_sum;
double _diesel_gen1_sync_check_check_f_diff_lpf_dwf__b_sum;
double _diesel_gen1_sync_check_check_f_diff_lpf_dwf__delay_line_in;
double _diesel_gen1_sync_check_check_v_diff_abs3__out;
double _diesel_gen1_sync_check_check_v_diff_pi_ki__out;
double _diesel_gen1_sync_check_check_v_diff_pi_kp__out;
double _diesel_gen1_control_freq_setpoint_control_pi_ki__out;
double _diesel_gen1_control_freq_setpoint_control_pi_kp__out;
double _diesel_gen2_sync_check_plls_pll_grid_pll_pi_sum7__out;

double _diesel_gen2_sync_check_check_phase_diff_confine_phase__dtheta;


double _diesel_gen2_sync_check_check_phase_diff_confine_phase__dtheta_confined;
double _diesel_gen2_sync_check_check_f_diff_lpf_dwf__out;
double _diesel_gen2_sync_check_check_f_diff_lpf_dwf__b_coeff[2] = {0.0006279239944363413, 0.0006279239944364523};
double _diesel_gen2_sync_check_check_f_diff_lpf_dwf__a_coeff[2] = {1.0, -0.9987441520111273};
double _diesel_gen2_sync_check_check_f_diff_lpf_dwf__a_sum;
double _diesel_gen2_sync_check_check_f_diff_lpf_dwf__b_sum;
double _diesel_gen2_sync_check_check_f_diff_lpf_dwf__delay_line_in;
double _diesel_gen2_sync_check_check_v_diff_abs3__out;
double _diesel_gen2_sync_check_check_v_diff_pi_ki__out;
double _diesel_gen2_sync_check_check_v_diff_pi_kp__out;
double _diesel_gen2_control_freq_setpoint_control_pi_ki__out;
double _diesel_gen2_control_freq_setpoint_control_pi_kp__out;
double _diesel_gen3_sync_check_plls_pll_grid_pll_pi_sum7__out;

double _diesel_gen3_sync_check_check_phase_diff_confine_phase__dtheta;


double _diesel_gen3_sync_check_check_phase_diff_confine_phase__dtheta_confined;
double _diesel_gen3_sync_check_check_f_diff_lpf_dwf__out;
double _diesel_gen3_sync_check_check_f_diff_lpf_dwf__b_coeff[2] = {0.0006279239944363413, 0.0006279239944364523};
double _diesel_gen3_sync_check_check_f_diff_lpf_dwf__a_coeff[2] = {1.0, -0.9987441520111273};
double _diesel_gen3_sync_check_check_f_diff_lpf_dwf__a_sum;
double _diesel_gen3_sync_check_check_f_diff_lpf_dwf__b_sum;
double _diesel_gen3_sync_check_check_f_diff_lpf_dwf__delay_line_in;
double _diesel_gen3_sync_check_check_v_diff_abs3__out;
double _diesel_gen3_sync_check_check_v_diff_pi_ki__out;
double _diesel_gen3_sync_check_check_v_diff_pi_kp__out;
double _diesel_gen3_control_freq_setpoint_control_pi_ki__out;
double _diesel_gen3_control_freq_setpoint_control_pi_kp__out;
double _diesel_gen4_sync_check_plls_pll_grid_pll_pi_sum7__out;

double _diesel_gen4_sync_check_check_phase_diff_confine_phase__dtheta;


double _diesel_gen4_sync_check_check_phase_diff_confine_phase__dtheta_confined;
double _diesel_gen4_sync_check_check_f_diff_lpf_dwf__out;
double _diesel_gen4_sync_check_check_f_diff_lpf_dwf__b_coeff[2] = {0.0006279239944363413, 0.0006279239944364523};
double _diesel_gen4_sync_check_check_f_diff_lpf_dwf__a_coeff[2] = {1.0, -0.9987441520111273};
double _diesel_gen4_sync_check_check_f_diff_lpf_dwf__a_sum;
double _diesel_gen4_sync_check_check_f_diff_lpf_dwf__b_sum;
double _diesel_gen4_sync_check_check_f_diff_lpf_dwf__delay_line_in;
double _diesel_gen4_sync_check_check_v_diff_abs3__out;
double _diesel_gen4_sync_check_check_v_diff_pi_ki__out;
double _diesel_gen4_sync_check_check_v_diff_pi_kp__out;
double _diesel_gen4_control_freq_setpoint_control_pi_ki__out;
double _diesel_gen4_control_freq_setpoint_control_pi_kp__out;
double _three_phase_at_load_7__area_1__pll_pid_kb__out;
double _three_phase_at_load_7__area_1__pll_lpf_lpf__out;
double _three_phase_at_load_7__area_1__pll_lpf_lpf__b_coeff[2] = {2.220446049250313e-16, 0.0002467400073613568};
double _three_phase_at_load_7__area_1__pll_lpf_lpf__a_coeff[3] = {1.0, -1.97778894456, 0.9780356845673617};
double _three_phase_at_load_7__area_1__pll_lpf_lpf__a_sum;
double _three_phase_at_load_7__area_1__pll_lpf_lpf__b_sum;
double _three_phase_at_load_7__area_1__pll_lpf_lpf__delay_line_in;
double _three_phase_at_load_8__mid__pll_pid_kb__out;
double _three_phase_at_load_8__mid__pll_lpf_lpf__out;
double _three_phase_at_load_8__mid__pll_lpf_lpf__b_coeff[2] = {2.220446049250313e-16, 0.0002467400073613568};
double _three_phase_at_load_8__mid__pll_lpf_lpf__a_coeff[3] = {1.0, -1.97778894456, 0.9780356845673617};
double _three_phase_at_load_8__mid__pll_lpf_lpf__a_sum;
double _three_phase_at_load_8__mid__pll_lpf_lpf__b_sum;
double _three_phase_at_load_8__mid__pll_lpf_lpf__delay_line_in;
double _three_phase_at_load_9__area_2__pll_pid_kb__out;
double _three_phase_at_load_9__area_2__pll_lpf_lpf__out;
double _three_phase_at_load_9__area_2__pll_lpf_lpf__b_coeff[2] = {2.220446049250313e-16, 0.0002467400073613568};
double _three_phase_at_load_9__area_2__pll_lpf_lpf__a_coeff[3] = {1.0, -1.97778894456, 0.9780356845673617};
double _three_phase_at_load_9__area_2__pll_lpf_lpf__a_sum;
double _three_phase_at_load_9__area_2__pll_lpf_lpf__b_sum;
double _three_phase_at_load_9__area_2__pll_lpf_lpf__delay_line_in;
double _diesel_gen1_sync_check_check_phase_diff_pi_sum6__out;
double _diesel_gen1_sync_check_check_phase_diff_product1__out;
double _diesel_gen1_control_pf_control_pi_sum6__out;
double _diesel_gen1_control_pf_control_signal_switch4__out;
double _diesel_gen2_sync_check_check_phase_diff_pi_sum6__out;
double _diesel_gen2_sync_check_check_phase_diff_product1__out;
double _diesel_gen2_control_pf_control_pi_sum6__out;
double _diesel_gen2_control_pf_control_signal_switch4__out;
double _diesel_gen4_sync_check_check_phase_diff_pi_sum6__out;
double _diesel_gen4_sync_check_check_phase_diff_product1__out;
double _diesel_gen4_control_pf_control_pi_sum6__out;
double _diesel_gen4_control_pf_control_signal_switch4__out;
double _diesel_gen3_sync_check_check_phase_diff_pi_sum6__out;
double _diesel_gen3_sync_check_check_phase_diff_product1__out;
double _diesel_gen3_control_pf_control_pi_sum6__out;
double _diesel_gen3_control_pf_control_signal_switch4__out;

double _diesel_gen1_sync_check_check_phase_diff_offset_phase__phase;


double _diesel_gen1_sync_check_check_phase_diff_offset_phase__phase_out;
double _diesel_gen1_sync_check_check_v_diff_comparator1__out;
double _diesel_gen1_sync_check_check_v_diff_pi_sum5__out;
double _diesel_gen1_control_freq_setpoint_control_pi_sum5__out;

double _diesel_gen2_sync_check_check_phase_diff_offset_phase__phase;


double _diesel_gen2_sync_check_check_phase_diff_offset_phase__phase_out;
double _diesel_gen2_sync_check_check_v_diff_comparator1__out;
double _diesel_gen2_sync_check_check_v_diff_pi_sum5__out;
double _diesel_gen2_control_freq_setpoint_control_pi_sum5__out;

double _diesel_gen3_sync_check_check_phase_diff_offset_phase__phase;


double _diesel_gen3_sync_check_check_phase_diff_offset_phase__phase_out;
double _diesel_gen3_sync_check_check_v_diff_comparator1__out;
double _diesel_gen3_sync_check_check_v_diff_pi_sum5__out;
double _diesel_gen3_control_freq_setpoint_control_pi_sum5__out;

double _diesel_gen4_sync_check_check_phase_diff_offset_phase__phase;


double _diesel_gen4_sync_check_check_phase_diff_offset_phase__phase_out;
double _diesel_gen4_sync_check_check_v_diff_comparator1__out;
double _diesel_gen4_sync_check_check_v_diff_pi_sum5__out;
double _diesel_gen4_control_freq_setpoint_control_pi_sum5__out;
double _three_phase_at_load_7__area_1__pll_pid_sum7__out;
double _three_phase_at_load_8__mid__pll_pid_sum7__out;
double _three_phase_at_load_9__area_2__pll_pid_sum7__out;
double _diesel_gen1_sync_check_check_phase_diff_pi_kb__out;
double _diesel_gen1_sync_check_calculate_dw_synch_sum4__out;
double _diesel_gen1_control_pf_control_pi_kb__out;
double _diesel_gen2_sync_check_check_phase_diff_pi_kb__out;
double _diesel_gen2_sync_check_calculate_dw_synch_sum4__out;
double _diesel_gen2_control_pf_control_pi_kb__out;
double _diesel_gen4_sync_check_check_phase_diff_pi_kb__out;
double _diesel_gen4_sync_check_calculate_dw_synch_sum4__out;
double _diesel_gen4_control_pf_control_pi_kb__out;
double _diesel_gen3_sync_check_check_phase_diff_pi_kb__out;
double _diesel_gen3_sync_check_calculate_dw_synch_sum4__out;
double _diesel_gen3_control_pf_control_pi_kb__out;
double _diesel_gen1_sync_check_check_phase_diff_lpf__out;
double _diesel_gen1_sync_check_check_phase_diff_lpf__b_coeff[2] = {0.0003140606003114721, 0.0003140606003114721};
double _diesel_gen1_sync_check_check_phase_diff_lpf__a_coeff[2] = {1.0, -0.999371878799377};
double _diesel_gen1_sync_check_check_phase_diff_lpf__a_sum;
double _diesel_gen1_sync_check_check_phase_diff_lpf__b_sum;
double _diesel_gen1_sync_check_check_phase_diff_lpf__delay_line_in;
double _diesel_gen1_sync_check_contactor_control_and__out;
float _diesel_gen1_sync_check_v_match__tmp;
double _diesel_gen1_sync_check_check_v_diff_pi_limit1__out;
double _diesel_gen1_control_freq_setpoint_control_pi_limit1__out;
double _diesel_gen2_sync_check_check_phase_diff_lpf__out;
double _diesel_gen2_sync_check_check_phase_diff_lpf__b_coeff[2] = {0.0003140606003114721, 0.0003140606003114721};
double _diesel_gen2_sync_check_check_phase_diff_lpf__a_coeff[2] = {1.0, -0.999371878799377};
double _diesel_gen2_sync_check_check_phase_diff_lpf__a_sum;
double _diesel_gen2_sync_check_check_phase_diff_lpf__b_sum;
double _diesel_gen2_sync_check_check_phase_diff_lpf__delay_line_in;
double _diesel_gen2_sync_check_contactor_control_and__out;
float _diesel_gen2_sync_check_v_match__tmp;
double _diesel_gen2_sync_check_check_v_diff_pi_limit1__out;
double _diesel_gen2_control_freq_setpoint_control_pi_limit1__out;
double _diesel_gen3_sync_check_check_phase_diff_lpf__out;
double _diesel_gen3_sync_check_check_phase_diff_lpf__b_coeff[2] = {0.0003140606003114721, 0.0003140606003114721};
double _diesel_gen3_sync_check_check_phase_diff_lpf__a_coeff[2] = {1.0, -0.999371878799377};
double _diesel_gen3_sync_check_check_phase_diff_lpf__a_sum;
double _diesel_gen3_sync_check_check_phase_diff_lpf__b_sum;
double _diesel_gen3_sync_check_check_phase_diff_lpf__delay_line_in;
double _diesel_gen3_sync_check_contactor_control_and__out;
float _diesel_gen3_sync_check_v_match__tmp;
double _diesel_gen3_sync_check_check_v_diff_pi_limit1__out;
double _diesel_gen3_control_freq_setpoint_control_pi_limit1__out;
double _diesel_gen4_sync_check_check_phase_diff_lpf__out;
double _diesel_gen4_sync_check_check_phase_diff_lpf__b_coeff[2] = {0.0003140606003114721, 0.0003140606003114721};
double _diesel_gen4_sync_check_check_phase_diff_lpf__a_coeff[2] = {1.0, -0.999371878799377};
double _diesel_gen4_sync_check_check_phase_diff_lpf__a_sum;
double _diesel_gen4_sync_check_check_phase_diff_lpf__b_sum;
double _diesel_gen4_sync_check_check_phase_diff_lpf__delay_line_in;
double _diesel_gen4_sync_check_contactor_control_and__out;
float _diesel_gen4_sync_check_v_match__tmp;
double _diesel_gen4_sync_check_check_v_diff_pi_limit1__out;
double _diesel_gen4_control_freq_setpoint_control_pi_limit1__out;
double _diesel_gen1_sync_check_check_phase_diff_pi_sum7__out;
double _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__out;
double _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__b_coeff[2] = {0.0006279239944363413, 0.0006279239944364523};
double _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__a_coeff[2] = {1.0, -0.9987441520111273};
double _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__a_sum;
double _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__b_sum;
double _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__delay_line_in;
double _diesel_gen1_control_pf_control_pi_sum7__out;
double _diesel_gen2_sync_check_check_phase_diff_pi_sum7__out;
double _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__out;
double _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__b_coeff[2] = {0.0006279239944363413, 0.0006279239944364523};
double _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__a_coeff[2] = {1.0, -0.9987441520111273};
double _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__a_sum;
double _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__b_sum;
double _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__delay_line_in;
double _diesel_gen2_control_pf_control_pi_sum7__out;
double _diesel_gen4_sync_check_check_phase_diff_pi_sum7__out;
double _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__out;
double _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__b_coeff[2] = {0.0006279239944363413, 0.0006279239944364523};
double _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__a_coeff[2] = {1.0, -0.9987441520111273};
double _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__a_sum;
double _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__b_sum;
double _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__delay_line_in;
double _diesel_gen4_control_pf_control_pi_sum7__out;
double _diesel_gen3_sync_check_check_phase_diff_pi_sum7__out;
double _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__out;
double _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__b_coeff[2] = {0.0006279239944363413, 0.0006279239944364523};
double _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__a_coeff[2] = {1.0, -0.9987441520111273};
double _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__a_sum;
double _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__b_sum;
double _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__delay_line_in;
double _diesel_gen3_control_pf_control_pi_sum7__out;
float _diesel_gen1_sync_check_contactor_control_gcb_control__tmp;
double _diesel_gen1_sync_check_contactor_control_signal_switch1__out;
double _diesel_gen1_sync_check_check_v_diff_pi_sum6__out;
double _diesel_gen1_sync_check_check_v_diff_signal_switch1__out;
double _diesel_gen1_control_freq_setpoint_control_pi_sum6__out;
double _diesel_gen1_control_freq_setpoint_control_mode_switch1__out;
float _diesel_gen2_sync_check_contactor_control_gcb_control__tmp;
double _diesel_gen2_sync_check_contactor_control_signal_switch1__out;
double _diesel_gen2_sync_check_check_v_diff_pi_sum6__out;
double _diesel_gen2_sync_check_check_v_diff_signal_switch1__out;
double _diesel_gen2_control_freq_setpoint_control_pi_sum6__out;
double _diesel_gen2_control_freq_setpoint_control_mode_switch1__out;
float _diesel_gen3_sync_check_contactor_control_gcb_control__tmp;
double _diesel_gen3_sync_check_contactor_control_signal_switch1__out;
double _diesel_gen3_sync_check_check_v_diff_pi_sum6__out;
double _diesel_gen3_sync_check_check_v_diff_signal_switch1__out;
double _diesel_gen3_control_freq_setpoint_control_pi_sum6__out;
double _diesel_gen3_control_freq_setpoint_control_mode_switch1__out;
float _diesel_gen4_sync_check_contactor_control_gcb_control__tmp;
double _diesel_gen4_sync_check_contactor_control_signal_switch1__out;
double _diesel_gen4_sync_check_check_v_diff_pi_sum6__out;
double _diesel_gen4_sync_check_check_v_diff_signal_switch1__out;
double _diesel_gen4_control_freq_setpoint_control_pi_sum6__out;
double _diesel_gen4_control_freq_setpoint_control_mode_switch1__out;
double _diesel_gen1_sync_check_check_v_diff_pi_kb__out;
double _diesel_gen1_sync_check_bus_join__out[3];
double _diesel_gen1_control_freq_setpoint_control_pi_kb__out;
double _diesel_gen2_sync_check_check_v_diff_pi_kb__out;
double _diesel_gen2_sync_check_bus_join__out[3];
double _diesel_gen2_control_freq_setpoint_control_pi_kb__out;
double _diesel_gen3_sync_check_check_v_diff_pi_kb__out;
double _diesel_gen3_sync_check_bus_join__out[3];
double _diesel_gen3_control_freq_setpoint_control_pi_kb__out;
double _diesel_gen4_sync_check_check_v_diff_pi_kb__out;
double _diesel_gen4_sync_check_bus_join__out[3];
double _diesel_gen4_control_freq_setpoint_control_pi_kb__out;
double _diesel_gen1_sync_check_check_v_diff_pi_sum7__out;
double _diesel_gen1_control_bus_split2__out;
double _diesel_gen1_control_bus_split2__out1;
double _diesel_gen1_control_bus_split2__out2;
double _diesel_gen1_control_freq_setpoint_control_pi_sum7__out;
double _diesel_gen2_sync_check_check_v_diff_pi_sum7__out;
double _diesel_gen2_control_bus_split2__out;
double _diesel_gen2_control_bus_split2__out1;
double _diesel_gen2_control_bus_split2__out2;
double _diesel_gen2_control_freq_setpoint_control_pi_sum7__out;
double _diesel_gen3_sync_check_check_v_diff_pi_sum7__out;
double _diesel_gen3_control_bus_split2__out;
double _diesel_gen3_control_bus_split2__out1;
double _diesel_gen3_control_bus_split2__out2;
double _diesel_gen3_control_freq_setpoint_control_pi_sum7__out;
double _diesel_gen4_sync_check_check_v_diff_pi_sum7__out;
double _diesel_gen4_control_bus_split2__out;
double _diesel_gen4_control_bus_split2__out1;
double _diesel_gen4_control_bus_split2__out2;
double _diesel_gen4_control_freq_setpoint_control_pi_sum7__out;
double _diesel_gen1_control_exciter_sum__out;
double _diesel_gen1_control_governor_and_engine_sum5__out;
double _diesel_gen2_control_exciter_sum__out;
double _diesel_gen2_control_governor_and_engine_sum5__out;
double _diesel_gen3_control_exciter_sum__out;
double _diesel_gen3_control_governor_and_engine_sum5__out;
double _diesel_gen4_control_exciter_sum__out;
double _diesel_gen4_control_governor_and_engine_sum5__out;
double _diesel_gen1_control_exciter_sum2__out;
double _diesel_gen1_control_governor_and_engine_sum4__out;
double _diesel_gen2_control_exciter_sum2__out;
double _diesel_gen2_control_governor_and_engine_sum4__out;
double _diesel_gen3_control_exciter_sum2__out;
double _diesel_gen3_control_governor_and_engine_sum4__out;
double _diesel_gen4_control_exciter_sum2__out;
double _diesel_gen4_control_governor_and_engine_sum4__out;
double _diesel_gen1_control_exciter_dc4b_sum1__out;
double _diesel_gen1_control_governor_and_engine_degov_tf1__out;
double _diesel_gen1_control_governor_and_engine_degov_tf1__b_coeff[3] = {2488.557213930348, 0.9950248756208566, -2487.5621890537072};
double _diesel_gen1_control_governor_and_engine_degov_tf1__a_coeff[3] = {1.0, 0.9850746268656716, 0.004975124378109485};
double _diesel_gen1_control_governor_and_engine_degov_tf1__a_sum;
double _diesel_gen1_control_governor_and_engine_degov_tf1__b_sum;
double _diesel_gen1_control_governor_and_engine_degov_tf1__delay_line_in;
double _diesel_gen2_control_exciter_dc4b_sum1__out;
double _diesel_gen2_control_governor_and_engine_degov_tf1__out;
double _diesel_gen2_control_governor_and_engine_degov_tf1__b_coeff[3] = {2488.557213930348, 0.9950248756208566, -2487.5621890537072};
double _diesel_gen2_control_governor_and_engine_degov_tf1__a_coeff[3] = {1.0, 0.9850746268656716, 0.004975124378109485};
double _diesel_gen2_control_governor_and_engine_degov_tf1__a_sum;
double _diesel_gen2_control_governor_and_engine_degov_tf1__b_sum;
double _diesel_gen2_control_governor_and_engine_degov_tf1__delay_line_in;
double _diesel_gen3_control_exciter_dc4b_sum1__out;
double _diesel_gen3_control_governor_and_engine_degov_tf1__out;
double _diesel_gen3_control_governor_and_engine_degov_tf1__b_coeff[3] = {2488.557213930348, 0.9950248756208566, -2487.5621890537072};
double _diesel_gen3_control_governor_and_engine_degov_tf1__a_coeff[3] = {1.0, 0.9850746268656716, 0.004975124378109485};
double _diesel_gen3_control_governor_and_engine_degov_tf1__a_sum;
double _diesel_gen3_control_governor_and_engine_degov_tf1__b_sum;
double _diesel_gen3_control_governor_and_engine_degov_tf1__delay_line_in;
double _diesel_gen4_control_exciter_dc4b_sum1__out;
double _diesel_gen4_control_governor_and_engine_degov_tf1__out;
double _diesel_gen4_control_governor_and_engine_degov_tf1__b_coeff[3] = {2488.557213930348, 0.9950248756208566, -2487.5621890537072};
double _diesel_gen4_control_governor_and_engine_degov_tf1__a_coeff[3] = {1.0, 0.9850746268656716, 0.004975124378109485};
double _diesel_gen4_control_governor_and_engine_degov_tf1__a_sum;
double _diesel_gen4_control_governor_and_engine_degov_tf1__b_sum;
double _diesel_gen4_control_governor_and_engine_degov_tf1__delay_line_in;
double _diesel_gen1_control_exciter_dc4b_sum2__out;
double _diesel_gen2_control_exciter_dc4b_sum2__out;
double _diesel_gen3_control_exciter_dc4b_sum2__out;
double _diesel_gen4_control_exciter_dc4b_sum2__out;
double _diesel_gen1_control_exciter_dc4b_pi_ki__out;
double _diesel_gen1_control_exciter_dc4b_pi_kp__out;
double _diesel_gen2_control_exciter_dc4b_pi_ki__out;
double _diesel_gen2_control_exciter_dc4b_pi_kp__out;
double _diesel_gen3_control_exciter_dc4b_pi_ki__out;
double _diesel_gen3_control_exciter_dc4b_pi_kp__out;
double _diesel_gen4_control_exciter_dc4b_pi_ki__out;
double _diesel_gen4_control_exciter_dc4b_pi_kp__out;
double _diesel_gen1_control_exciter_dc4b_pi_sum5__out;
double _diesel_gen2_control_exciter_dc4b_pi_sum5__out;
double _diesel_gen3_control_exciter_dc4b_pi_sum5__out;
double _diesel_gen4_control_exciter_dc4b_pi_sum5__out;
double _diesel_gen1_control_exciter_dc4b_pi_limit1__out;
double _diesel_gen2_control_exciter_dc4b_pi_limit1__out;
double _diesel_gen3_control_exciter_dc4b_pi_limit1__out;
double _diesel_gen4_control_exciter_dc4b_pi_limit1__out;
double _diesel_gen1_control_exciter_dc4b_pi_sum6__out;
double _diesel_gen1_control_exciter_dc4b_product1__out;
double _diesel_gen2_control_exciter_dc4b_pi_sum6__out;
double _diesel_gen2_control_exciter_dc4b_product1__out;
double _diesel_gen3_control_exciter_dc4b_pi_sum6__out;
double _diesel_gen3_control_exciter_dc4b_product1__out;
double _diesel_gen4_control_exciter_dc4b_pi_sum6__out;
double _diesel_gen4_control_exciter_dc4b_product1__out;
double _diesel_gen1_control_exciter_dc4b_pi_kb__out;
double _diesel_gen1_control_exciter_dc4b_ka__out;
double _diesel_gen2_control_exciter_dc4b_pi_kb__out;
double _diesel_gen2_control_exciter_dc4b_ka__out;
double _diesel_gen3_control_exciter_dc4b_pi_kb__out;
double _diesel_gen3_control_exciter_dc4b_ka__out;
double _diesel_gen4_control_exciter_dc4b_pi_kb__out;
double _diesel_gen4_control_exciter_dc4b_ka__out;
double _diesel_gen1_control_exciter_dc4b_pi_sum7__out;
double _diesel_gen1_control_exciter_dc4b_tf2__out;
double _diesel_gen1_control_exciter_dc4b_tf2__b_coeff[2] = {0.04761904761904767, 0.04761904761904756};
double _diesel_gen1_control_exciter_dc4b_tf2__a_coeff[2] = {1.0, -0.9047619047619047};
double _diesel_gen1_control_exciter_dc4b_tf2__a_sum;
double _diesel_gen1_control_exciter_dc4b_tf2__b_sum;
double _diesel_gen1_control_exciter_dc4b_tf2__delay_line_in;
double _diesel_gen2_control_exciter_dc4b_pi_sum7__out;
double _diesel_gen2_control_exciter_dc4b_tf2__out;
double _diesel_gen2_control_exciter_dc4b_tf2__b_coeff[2] = {0.04761904761904767, 0.04761904761904756};
double _diesel_gen2_control_exciter_dc4b_tf2__a_coeff[2] = {1.0, -0.9047619047619047};
double _diesel_gen2_control_exciter_dc4b_tf2__a_sum;
double _diesel_gen2_control_exciter_dc4b_tf2__b_sum;
double _diesel_gen2_control_exciter_dc4b_tf2__delay_line_in;
double _diesel_gen3_control_exciter_dc4b_pi_sum7__out;
double _diesel_gen3_control_exciter_dc4b_tf2__out;
double _diesel_gen3_control_exciter_dc4b_tf2__b_coeff[2] = {0.04761904761904767, 0.04761904761904756};
double _diesel_gen3_control_exciter_dc4b_tf2__a_coeff[2] = {1.0, -0.9047619047619047};
double _diesel_gen3_control_exciter_dc4b_tf2__a_sum;
double _diesel_gen3_control_exciter_dc4b_tf2__b_sum;
double _diesel_gen3_control_exciter_dc4b_tf2__delay_line_in;
double _diesel_gen4_control_exciter_dc4b_pi_sum7__out;
double _diesel_gen4_control_exciter_dc4b_tf2__out;
double _diesel_gen4_control_exciter_dc4b_tf2__b_coeff[2] = {0.04761904761904767, 0.04761904761904756};
double _diesel_gen4_control_exciter_dc4b_tf2__a_coeff[2] = {1.0, -0.9047619047619047};
double _diesel_gen4_control_exciter_dc4b_tf2__a_sum;
double _diesel_gen4_control_exciter_dc4b_tf2__b_sum;
double _diesel_gen4_control_exciter_dc4b_tf2__delay_line_in;//@cmp.var.end

//@cmp.svar.start
// state variables
double _diesel_gen1_control_governor_and_engine_degov_transport_delay1__state[120];
X_UnInt32 _diesel_gen1_control_governor_and_engine_degov_transport_delay1__cbi;
double _diesel_gen1_control_unit_delay1__state;
double _diesel_gen1_control_unit_delay2__state;
double _diesel_gen1_control_unit_delay3__state;
double _diesel_gen1_gen_machine_wrapper1__model_load;
double _diesel_gen1_measurements_3ph_pll_gen_pll_pi_integrator1__state;
double _diesel_gen1_measurements_3ph_pll_gen_pll_pi_integrator2__state;
double _diesel_gen1_measurements_3ph_pll_gen_pll_unit_delay1__state;
double _diesel_gen1_sync_check_calculate_dw_synch_unit_delay1__state;
double _diesel_gen1_sync_check_contactor_control_edge_detection1_unit_delay1__state;
double _diesel_gen1_sync_check_contactor_control_sr_flip_flop1__state;
double _diesel_gen1_sync_check_plls_pll_grid_pll_pi_integrator1__state;
double _diesel_gen1_sync_check_plls_pll_grid_pll_unit_delay1__state;
double _diesel_gen1_sync_check_check_v_diff_unit_delay1__state;
double _diesel_gen1_sync_check_check_phase_diff_counter_counter1_accumulator1__state;
double _diesel_gen1_sync_check_check_phase_diff_counter_counter1_accumulator1__reset_state;
double _diesel_gen2_control_governor_and_engine_degov_transport_delay1__state[120];
X_UnInt32 _diesel_gen2_control_governor_and_engine_degov_transport_delay1__cbi;
double _diesel_gen2_control_unit_delay1__state;
double _diesel_gen2_control_unit_delay2__state;
double _diesel_gen2_control_unit_delay3__state;
double _diesel_gen2_gen_machine_wrapper1__model_load;
double _diesel_gen2_measurements_3ph_pll_gen_pll_pi_integrator1__state;
double _diesel_gen2_measurements_3ph_pll_gen_pll_pi_integrator2__state;
double _diesel_gen2_measurements_3ph_pll_gen_pll_unit_delay1__state;
double _diesel_gen2_sync_check_calculate_dw_synch_unit_delay1__state;
double _diesel_gen2_sync_check_contactor_control_edge_detection1_unit_delay1__state;
double _diesel_gen2_sync_check_contactor_control_sr_flip_flop1__state;
double _diesel_gen2_sync_check_plls_pll_grid_pll_pi_integrator1__state;
double _diesel_gen2_sync_check_plls_pll_grid_pll_unit_delay1__state;
double _diesel_gen2_sync_check_check_v_diff_unit_delay1__state;
double _diesel_gen2_sync_check_check_phase_diff_counter_counter1_accumulator1__state;
double _diesel_gen2_sync_check_check_phase_diff_counter_counter1_accumulator1__reset_state;
double _diesel_gen3_control_governor_and_engine_degov_transport_delay1__state[120];
X_UnInt32 _diesel_gen3_control_governor_and_engine_degov_transport_delay1__cbi;
double _diesel_gen3_control_unit_delay1__state;
double _diesel_gen3_control_unit_delay2__state;
double _diesel_gen3_control_unit_delay3__state;
double _diesel_gen3_gen_machine_wrapper1__model_load;
double _diesel_gen3_measurements_3ph_pll_gen_pll_pi_integrator1__state;
double _diesel_gen3_measurements_3ph_pll_gen_pll_pi_integrator2__state;
double _diesel_gen3_measurements_3ph_pll_gen_pll_unit_delay1__state;
double _diesel_gen3_sync_check_calculate_dw_synch_unit_delay1__state;
double _diesel_gen3_sync_check_contactor_control_edge_detection1_unit_delay1__state;
double _diesel_gen3_sync_check_contactor_control_sr_flip_flop1__state;
double _diesel_gen3_sync_check_plls_pll_grid_pll_pi_integrator1__state;
double _diesel_gen3_sync_check_plls_pll_grid_pll_unit_delay1__state;
double _diesel_gen3_sync_check_check_v_diff_unit_delay1__state;
double _diesel_gen3_sync_check_check_phase_diff_counter_counter1_accumulator1__state;
double _diesel_gen3_sync_check_check_phase_diff_counter_counter1_accumulator1__reset_state;
double _diesel_gen4_control_governor_and_engine_degov_transport_delay1__state[120];
X_UnInt32 _diesel_gen4_control_governor_and_engine_degov_transport_delay1__cbi;
double _diesel_gen4_control_unit_delay1__state;
double _diesel_gen4_control_unit_delay2__state;
double _diesel_gen4_control_unit_delay3__state;
double _diesel_gen4_gen_machine_wrapper1__model_load;
double _diesel_gen4_measurements_3ph_pll_gen_pll_pi_integrator1__state;
double _diesel_gen4_measurements_3ph_pll_gen_pll_pi_integrator2__state;
double _diesel_gen4_measurements_3ph_pll_gen_pll_unit_delay1__state;
double _diesel_gen4_sync_check_calculate_dw_synch_unit_delay1__state;
double _diesel_gen4_sync_check_contactor_control_edge_detection1_unit_delay1__state;
double _diesel_gen4_sync_check_contactor_control_sr_flip_flop1__state;
double _diesel_gen4_sync_check_plls_pll_grid_pll_pi_integrator1__state;
double _diesel_gen4_sync_check_plls_pll_grid_pll_unit_delay1__state;
double _diesel_gen4_sync_check_check_v_diff_unit_delay1__state;
double _diesel_gen4_sync_check_check_phase_diff_counter_counter1_accumulator1__state;
double _diesel_gen4_sync_check_check_phase_diff_counter_counter1_accumulator1__reset_state;
double _three_phase_at_load_7__area_1__pll_pid_integrator1__state;
double _three_phase_at_load_7__area_1__pll_pid_integrator2__state;
double _three_phase_at_load_7__area_1__pll_unit_delay1__state;
double _three_phase_at_load_8__mid__pll_pid_integrator1__state;
double _three_phase_at_load_8__mid__pll_pid_integrator2__state;
double _three_phase_at_load_8__mid__pll_unit_delay1__state;
double _three_phase_at_load_9__area_2__pll_pid_integrator1__state;
double _three_phase_at_load_9__area_2__pll_pid_integrator2__state;
double _three_phase_at_load_9__area_2__pll_unit_delay1__state;
double _diesel_gen1_control_exciter_dc4b_tf4__states[1];
double _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1;
double _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1;
double _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1Q;
double _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1Q;
double _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1P0;
double _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1P0;
double _diesel_gen1_sync_check_check_v_diff_pi_integrator1__state;
double _diesel_gen1_sync_check_check_v_diff_pi_integrator1__reset_state;
double _diesel_gen2_control_exciter_dc4b_tf4__states[1];
double _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1;
double _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1;
double _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1Q;
double _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1Q;
double _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1P0;
double _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1P0;
double _diesel_gen2_sync_check_check_v_diff_pi_integrator1__state;
double _diesel_gen2_sync_check_check_v_diff_pi_integrator1__reset_state;
double _diesel_gen3_control_exciter_dc4b_tf4__states[1];
double _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1;
double _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1;
double _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1Q;
double _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1Q;
double _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1P0;
double _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1P0;
double _diesel_gen3_sync_check_check_v_diff_pi_integrator1__state;
double _diesel_gen3_sync_check_check_v_diff_pi_integrator1__reset_state;
double _diesel_gen4_control_exciter_dc4b_tf4__states[1];
double _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1;
double _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1;
double _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1Q;
double _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1Q;
double _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1P0;
double _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1P0;
double _diesel_gen4_sync_check_check_v_diff_pi_integrator1__state;
double _diesel_gen4_sync_check_check_v_diff_pi_integrator1__reset_state;
double _three_phase_at_load_7__area_1__meassm_mode_and_dfract__Tfract;
double _three_phase_at_load_7__area_1__meassm_mode_and_dfract__freqAbs;
double _three_phase_at_load_7__area_1__meassm_mode_and_dfract__fMax;
X_Int32 _three_phase_at_load_7__area_1__meassm_mode_and_dfract__reset;
X_Int32 _three_phase_at_load_7__area_1__meassm_mode_and_dfract__cycle_counter;
double _three_phase_at_load_8__mid__meassm_mode_and_dfract__Tfract;
double _three_phase_at_load_8__mid__meassm_mode_and_dfract__freqAbs;
double _three_phase_at_load_8__mid__meassm_mode_and_dfract__fMax;
X_Int32 _three_phase_at_load_8__mid__meassm_mode_and_dfract__reset;
X_Int32 _three_phase_at_load_8__mid__meassm_mode_and_dfract__cycle_counter;
double _three_phase_at_load_9__area_2__meassm_mode_and_dfract__Tfract;
double _three_phase_at_load_9__area_2__meassm_mode_and_dfract__freqAbs;
double _three_phase_at_load_9__area_2__meassm_mode_and_dfract__fMax;
X_Int32 _three_phase_at_load_9__area_2__meassm_mode_and_dfract__reset;
X_Int32 _three_phase_at_load_9__area_2__meassm_mode_and_dfract__cycle_counter;
double _diesel_gen1_control_governor_and_engine_degov_tf2__states[2];
double _diesel_gen1_sync_check_check_f_diff_comparator1__state;
double _diesel_gen1_sync_check_check_phase_diff_comparator2__state;
double _diesel_gen1_control_start_exciter_comparator1__state;
double _diesel_gen2_control_governor_and_engine_degov_tf2__states[2];
double _diesel_gen2_sync_check_check_f_diff_comparator1__state;
double _diesel_gen2_sync_check_check_phase_diff_comparator2__state;
double _diesel_gen2_control_start_exciter_comparator1__state;
double _diesel_gen3_control_governor_and_engine_degov_tf2__states[2];
double _diesel_gen3_sync_check_check_f_diff_comparator1__state;
double _diesel_gen3_sync_check_check_phase_diff_comparator2__state;
double _diesel_gen3_control_start_exciter_comparator1__state;
double _diesel_gen4_control_governor_and_engine_degov_tf2__states[2];
double _diesel_gen4_sync_check_check_f_diff_comparator1__state;
double _diesel_gen4_sync_check_check_phase_diff_comparator2__state;
double _diesel_gen4_control_start_exciter_comparator1__state;
double _three_phase_at_load_7__area_1__i_rms_calc_rms__rmsSum1;
double _three_phase_at_load_7__area_1__i_rms_calc_rms__rmsSum2;
double _three_phase_at_load_7__area_1__i_rms_calc_rms__rmsSum3;
double _three_phase_at_load_7__area_1__vll_rms_calc_rms__rmsSum1;
double _three_phase_at_load_7__area_1__vll_rms_calc_rms__rmsSum2;
double _three_phase_at_load_7__area_1__vll_rms_calc_rms__rmsSum3;
double _three_phase_at_load_7__area_1__vln_rms_calc_rms__rmsSum1;
double _three_phase_at_load_7__area_1__vln_rms_calc_rms__rmsSum2;
double _three_phase_at_load_7__area_1__vln_rms_calc_rms__rmsSum3;
double _three_phase_at_load_8__mid__i_rms_calc_rms__rmsSum1;
double _three_phase_at_load_8__mid__i_rms_calc_rms__rmsSum2;
double _three_phase_at_load_8__mid__i_rms_calc_rms__rmsSum3;
double _three_phase_at_load_8__mid__vln_rms_calc_rms__rmsSum1;
double _three_phase_at_load_8__mid__vln_rms_calc_rms__rmsSum2;
double _three_phase_at_load_8__mid__vln_rms_calc_rms__rmsSum3;
double _three_phase_at_load_9__area_2__i_rms_calc_rms__rmsSum1;
double _three_phase_at_load_9__area_2__i_rms_calc_rms__rmsSum2;
double _three_phase_at_load_9__area_2__i_rms_calc_rms__rmsSum3;
double _three_phase_at_load_9__area_2__vll_rms_calc_rms__rmsSum1;
double _three_phase_at_load_9__area_2__vll_rms_calc_rms__rmsSum2;
double _three_phase_at_load_9__area_2__vll_rms_calc_rms__rmsSum3;
double _three_phase_at_load_9__area_2__vln_rms_calc_rms__rmsSum1;
double _three_phase_at_load_9__area_2__vln_rms_calc_rms__rmsSum2;
double _three_phase_at_load_9__area_2__vln_rms_calc_rms__rmsSum3;
double _diesel_gen1_control_governor_and_engine_degov_integrator_integrator1__state;
double _diesel_gen1_control_governor_and_engine_degov_integrator_integrator1__reset_state;
double _diesel_gen2_control_governor_and_engine_degov_integrator_integrator1__state;
double _diesel_gen2_control_governor_and_engine_degov_integrator_integrator1__reset_state;
double _diesel_gen4_control_governor_and_engine_degov_integrator_integrator1__state;
double _diesel_gen4_control_governor_and_engine_degov_integrator_integrator1__reset_state;
double _diesel_gen3_control_governor_and_engine_degov_integrator_integrator1__state;
double _diesel_gen3_control_governor_and_engine_degov_integrator_integrator1__reset_state;
double _diesel_gen1_control_exciter_dc4b_tf3__states[1];
double _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__states[1];
double _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__states[1];
double _diesel_gen1_control_check_steady_state_w_comparator3__state;
double _diesel_gen2_control_exciter_dc4b_tf3__states[1];
double _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__states[1];
double _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__states[1];
double _diesel_gen2_control_check_steady_state_w_comparator3__state;
double _diesel_gen3_control_exciter_dc4b_tf3__states[1];
double _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__states[1];
double _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__states[1];
double _diesel_gen3_control_check_steady_state_w_comparator3__state;
double _diesel_gen4_control_exciter_dc4b_tf3__states[1];
double _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__states[1];
double _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__states[1];
double _diesel_gen4_control_check_steady_state_w_comparator3__state;
double _three_phase_at_load_7__area_1__power_meter_power__PsumA;
double _three_phase_at_load_7__area_1__power_meter_power__PsumB;
double _three_phase_at_load_7__area_1__power_meter_power__PsumC;
double _three_phase_at_load_7__area_1__power_meter_power__VevenSumA;
double _three_phase_at_load_7__area_1__power_meter_power__VevenSumB;
double _three_phase_at_load_7__area_1__power_meter_power__VevenSumC;
double _three_phase_at_load_7__area_1__power_meter_power__VoddSumA;
double _three_phase_at_load_7__area_1__power_meter_power__VoddSumB;
double _three_phase_at_load_7__area_1__power_meter_power__VoddSumC;
double _three_phase_at_load_7__area_1__power_meter_power__IevenSumA;
double _three_phase_at_load_7__area_1__power_meter_power__IevenSumB;
double _three_phase_at_load_7__area_1__power_meter_power__IevenSumC;
double _three_phase_at_load_7__area_1__power_meter_power__IoddSumA;
double _three_phase_at_load_7__area_1__power_meter_power__IoddSumB;
double _three_phase_at_load_7__area_1__power_meter_power__IoddSumC;
double _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_d__filtered_value;
double _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_d__previous_in;
double _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_q__filtered_value;
double _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_q__previous_in;
double _three_phase_at_load_8__mid__power_meter_power__PsumA;
double _three_phase_at_load_8__mid__power_meter_power__PsumB;
double _three_phase_at_load_8__mid__power_meter_power__PsumC;
double _three_phase_at_load_8__mid__power_meter_power__VevenSumA;
double _three_phase_at_load_8__mid__power_meter_power__VevenSumB;
double _three_phase_at_load_8__mid__power_meter_power__VevenSumC;
double _three_phase_at_load_8__mid__power_meter_power__VoddSumA;
double _three_phase_at_load_8__mid__power_meter_power__VoddSumB;
double _three_phase_at_load_8__mid__power_meter_power__VoddSumC;
double _three_phase_at_load_8__mid__power_meter_power__IevenSumA;
double _three_phase_at_load_8__mid__power_meter_power__IevenSumB;
double _three_phase_at_load_8__mid__power_meter_power__IevenSumC;
double _three_phase_at_load_8__mid__power_meter_power__IoddSumA;
double _three_phase_at_load_8__mid__power_meter_power__IoddSumB;
double _three_phase_at_load_8__mid__power_meter_power__IoddSumC;
double _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_d__filtered_value;
double _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_d__previous_in;
double _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_q__filtered_value;
double _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_q__previous_in;
double _three_phase_at_load_9__area_2__power_meter_power__PsumA;
double _three_phase_at_load_9__area_2__power_meter_power__PsumB;
double _three_phase_at_load_9__area_2__power_meter_power__PsumC;
double _three_phase_at_load_9__area_2__power_meter_power__VevenSumA;
double _three_phase_at_load_9__area_2__power_meter_power__VevenSumB;
double _three_phase_at_load_9__area_2__power_meter_power__VevenSumC;
double _three_phase_at_load_9__area_2__power_meter_power__VoddSumA;
double _three_phase_at_load_9__area_2__power_meter_power__VoddSumB;
double _three_phase_at_load_9__area_2__power_meter_power__VoddSumC;
double _three_phase_at_load_9__area_2__power_meter_power__IevenSumA;
double _three_phase_at_load_9__area_2__power_meter_power__IevenSumB;
double _three_phase_at_load_9__area_2__power_meter_power__IevenSumC;
double _three_phase_at_load_9__area_2__power_meter_power__IoddSumA;
double _three_phase_at_load_9__area_2__power_meter_power__IoddSumB;
double _three_phase_at_load_9__area_2__power_meter_power__IoddSumC;
double _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_d__filtered_value;
double _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_d__previous_in;
double _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_q__filtered_value;
double _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_q__previous_in;
double _diesel_gen1_control_freq_setpoint_control_p_ramp__state;
X_Int32 _diesel_gen1_control_freq_setpoint_control_p_ramp__first_step;
double _diesel_gen1_control_governor_and_engine_w_ramp__state;
X_Int32 _diesel_gen1_control_governor_and_engine_w_ramp__first_step;
double _diesel_gen2_control_freq_setpoint_control_p_ramp__state;
X_Int32 _diesel_gen2_control_freq_setpoint_control_p_ramp__first_step;
double _diesel_gen2_control_governor_and_engine_w_ramp__state;
X_Int32 _diesel_gen2_control_governor_and_engine_w_ramp__first_step;
double _diesel_gen4_control_freq_setpoint_control_p_ramp__state;
X_Int32 _diesel_gen4_control_freq_setpoint_control_p_ramp__first_step;
double _diesel_gen4_control_governor_and_engine_w_ramp__state;
X_Int32 _diesel_gen4_control_governor_and_engine_w_ramp__first_step;
double _diesel_gen3_control_freq_setpoint_control_p_ramp__state;
X_Int32 _diesel_gen3_control_freq_setpoint_control_p_ramp__first_step;
double _diesel_gen3_control_governor_and_engine_w_ramp__state;
X_Int32 _diesel_gen3_control_governor_and_engine_w_ramp__first_step;
double _diesel_gen1_control_pf_control_norm_pf_ref__u;
double _diesel_gen1_control_exciter_dc4b_pi_integrator1__state;
double _diesel_gen1_control_exciter_dc4b_pi_integrator1__reset_state;
double _diesel_gen2_control_pf_control_norm_pf_ref__u;
double _diesel_gen2_control_exciter_dc4b_pi_integrator1__state;
double _diesel_gen2_control_exciter_dc4b_pi_integrator1__reset_state;
double _diesel_gen3_control_pf_control_norm_pf_ref__u;
double _diesel_gen3_control_exciter_dc4b_pi_integrator1__state;
double _diesel_gen3_control_exciter_dc4b_pi_integrator1__reset_state;
double _diesel_gen4_control_pf_control_norm_pf_ref__u;
double _diesel_gen4_control_exciter_dc4b_pi_integrator1__state;
double _diesel_gen4_control_exciter_dc4b_pi_integrator1__reset_state;
double _diesel_gen1_control_freq_setpoint_control_pi_integrator1__state;
double _diesel_gen1_control_freq_setpoint_control_pi_integrator1__reset_state;
double _diesel_gen2_control_freq_setpoint_control_pi_integrator1__state;
double _diesel_gen2_control_freq_setpoint_control_pi_integrator1__reset_state;
double _diesel_gen4_control_freq_setpoint_control_pi_integrator1__state;
double _diesel_gen4_control_freq_setpoint_control_pi_integrator1__reset_state;
double _diesel_gen3_control_freq_setpoint_control_pi_integrator1__state;
double _diesel_gen3_control_freq_setpoint_control_pi_integrator1__reset_state;
double _diesel_gen1_control_exciter_dc4b_tf1__states[1];
double _diesel_gen1_control_exciter_rate_limit__state;
X_Int32 _diesel_gen1_control_exciter_rate_limit__first_step;
double _diesel_gen2_control_exciter_dc4b_tf1__states[1];
double _diesel_gen2_control_exciter_rate_limit__state;
X_Int32 _diesel_gen2_control_exciter_rate_limit__first_step;
double _diesel_gen3_control_exciter_dc4b_tf1__states[1];
double _diesel_gen3_control_exciter_rate_limit__state;
X_Int32 _diesel_gen3_control_exciter_rate_limit__first_step;
double _diesel_gen4_control_exciter_dc4b_tf1__states[1];
double _diesel_gen4_control_exciter_rate_limit__state;
X_Int32 _diesel_gen4_control_exciter_rate_limit__first_step;
double _diesel_gen1_control_freq_setpoint_control_w_ramp__state;
X_Int32 _diesel_gen1_control_freq_setpoint_control_w_ramp__first_step;
double _diesel_gen1_control_pf_control_pi_integrator1__state;
double _diesel_gen1_control_pf_control_pi_integrator1__reset_state;
double _diesel_gen2_control_freq_setpoint_control_w_ramp__state;
X_Int32 _diesel_gen2_control_freq_setpoint_control_w_ramp__first_step;
double _diesel_gen2_control_pf_control_pi_integrator1__state;
double _diesel_gen2_control_pf_control_pi_integrator1__reset_state;
double _diesel_gen4_control_freq_setpoint_control_w_ramp__state;
X_Int32 _diesel_gen4_control_freq_setpoint_control_w_ramp__first_step;
double _diesel_gen4_control_pf_control_pi_integrator1__state;
double _diesel_gen4_control_pf_control_pi_integrator1__reset_state;
double _diesel_gen3_control_freq_setpoint_control_w_ramp__state;
X_Int32 _diesel_gen3_control_freq_setpoint_control_w_ramp__first_step;
double _diesel_gen3_control_pf_control_pi_integrator1__state;
double _diesel_gen3_control_pf_control_pi_integrator1__reset_state;
double _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__states[1];
double _diesel_gen1_measurements_3ph_pll_gen_pll_rate_limiter1__state;
X_Int32 _diesel_gen1_measurements_3ph_pll_gen_pll_rate_limiter1__first_step;
double _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__states[1];
double _diesel_gen2_measurements_3ph_pll_gen_pll_rate_limiter1__state;
X_Int32 _diesel_gen2_measurements_3ph_pll_gen_pll_rate_limiter1__first_step;
double _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__states[1];
double _diesel_gen3_measurements_3ph_pll_gen_pll_rate_limiter1__state;
X_Int32 _diesel_gen3_measurements_3ph_pll_gen_pll_rate_limiter1__first_step;
double _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__states[1];
double _diesel_gen4_measurements_3ph_pll_gen_pll_rate_limiter1__state;
X_Int32 _diesel_gen4_measurements_3ph_pll_gen_pll_rate_limiter1__first_step;
double _diesel_gen1_control_pf_control_rate_limiter1__state;
X_Int32 _diesel_gen1_control_pf_control_rate_limiter1__first_step;
double _diesel_gen2_control_pf_control_rate_limiter1__state;
X_Int32 _diesel_gen2_control_pf_control_rate_limiter1__first_step;
double _diesel_gen4_control_pf_control_rate_limiter1__state;
X_Int32 _diesel_gen4_control_pf_control_rate_limiter1__first_step;
double _diesel_gen3_control_pf_control_rate_limiter1__state;
X_Int32 _diesel_gen3_control_pf_control_rate_limiter1__first_step;
double _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__states[2];
double _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__states[2];
double _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__states[2];
double _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__states[2];
double _diesel_gen1_sync_check_check_phase_diff_pi_integrator1__state;
double _diesel_gen1_sync_check_check_phase_diff_pi_integrator1__reset_state;
double _diesel_gen2_sync_check_check_phase_diff_pi_integrator1__state;
double _diesel_gen2_sync_check_check_phase_diff_pi_integrator1__reset_state;
double _diesel_gen4_sync_check_check_phase_diff_pi_integrator1__state;
double _diesel_gen4_sync_check_check_phase_diff_pi_integrator1__reset_state;
double _diesel_gen3_sync_check_check_phase_diff_pi_integrator1__state;
double _diesel_gen3_sync_check_check_phase_diff_pi_integrator1__reset_state;
double _diesel_gen1_sync_check_plls_pll_grid_pll_integrator__out;
double _diesel_gen2_sync_check_plls_pll_grid_pll_integrator__out;
double _diesel_gen3_sync_check_plls_pll_grid_pll_integrator__out;
double _diesel_gen4_sync_check_plls_pll_grid_pll_integrator__out;
double _diesel_gen1_sync_check_contactor_control_wait_to_trip__time_acc;
double _diesel_gen2_sync_check_contactor_control_wait_to_trip__time_acc;
double _diesel_gen4_sync_check_contactor_control_wait_to_trip__time_acc;
double _diesel_gen3_sync_check_contactor_control_wait_to_trip__time_acc;
double _diesel_gen1_sync_check_plls_pll_grid_lpf_f__states[1];
double _diesel_gen2_sync_check_plls_pll_grid_lpf_f__states[1];
double _diesel_gen3_sync_check_plls_pll_grid_lpf_f__states[1];
double _diesel_gen4_sync_check_plls_pll_grid_lpf_f__states[1];
double _three_phase_at_load_7__area_1__pll_rate_limiter1__state;
X_Int32 _three_phase_at_load_7__area_1__pll_rate_limiter1__first_step;
double _three_phase_at_load_8__mid__pll_rate_limiter1__state;
X_Int32 _three_phase_at_load_8__mid__pll_rate_limiter1__first_step;
double _three_phase_at_load_9__area_2__pll_rate_limiter1__state;
X_Int32 _three_phase_at_load_9__area_2__pll_rate_limiter1__first_step;
double _diesel_gen1_sync_check_check_f_diff_lpf_dwf__states[1];
double _diesel_gen2_sync_check_check_f_diff_lpf_dwf__states[1];
double _diesel_gen3_sync_check_check_f_diff_lpf_dwf__states[1];
double _diesel_gen4_sync_check_check_f_diff_lpf_dwf__states[1];
double _three_phase_at_load_7__area_1__pll_lpf_lpf__states[2];
double _three_phase_at_load_8__mid__pll_lpf_lpf__states[2];
double _three_phase_at_load_9__area_2__pll_lpf_lpf__states[2];
double _diesel_gen1_sync_check_check_phase_diff_offset_phase__off1;
double _diesel_gen1_sync_check_check_phase_diff_offset_phase__off2;
double _diesel_gen1_sync_check_check_v_diff_comparator1__state;
double _diesel_gen2_sync_check_check_phase_diff_offset_phase__off1;
double _diesel_gen2_sync_check_check_phase_diff_offset_phase__off2;
double _diesel_gen2_sync_check_check_v_diff_comparator1__state;
double _diesel_gen3_sync_check_check_phase_diff_offset_phase__off1;
double _diesel_gen3_sync_check_check_phase_diff_offset_phase__off2;
double _diesel_gen3_sync_check_check_v_diff_comparator1__state;
double _diesel_gen4_sync_check_check_phase_diff_offset_phase__off1;
double _diesel_gen4_sync_check_check_phase_diff_offset_phase__off2;
double _diesel_gen4_sync_check_check_v_diff_comparator1__state;
double _diesel_gen1_sync_check_check_phase_diff_lpf__states[1];
double _diesel_gen2_sync_check_check_phase_diff_lpf__states[1];
double _diesel_gen3_sync_check_check_phase_diff_lpf__states[1];
double _diesel_gen4_sync_check_check_phase_diff_lpf__states[1];
double _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__states[1];
double _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__states[1];
double _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__states[1];
double _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__states[1];
double _diesel_gen1_control_governor_and_engine_degov_tf1__states[2];
double _diesel_gen2_control_governor_and_engine_degov_tf1__states[2];
double _diesel_gen3_control_governor_and_engine_degov_tf1__states[2];
double _diesel_gen4_control_governor_and_engine_degov_tf1__states[2];
double _diesel_gen1_control_exciter_dc4b_tf2__states[1];
double _diesel_gen2_control_exciter_dc4b_tf2__states[1];
double _diesel_gen3_control_exciter_dc4b_tf2__states[1];
double _diesel_gen4_control_exciter_dc4b_tf2__states[1];
//@cmp.svar.end

//
// Tunable parameters
//
static struct Tunable_params {
} __attribute__((__packed__)) tunable_params;

void *tunable_params_dev0_cpu0_ptr = &tunable_params;

// Dll function pointers
#if defined(_WIN64)
#else
// Define handles for loading dlls
#endif








// generated using template: virtual_hil/custom_functions.template---------------------------------
void ReInit_user_sp_cpu0_dev0() {
#if DEBUG_MODE
    printf("\n\rReInitTimer");
#endif
    //@cmp.init.block.start
    X_UnInt32 _diesel_gen1_control_governor_and_engine_degov_transport_delay1__i;
    for (_diesel_gen1_control_governor_and_engine_degov_transport_delay1__i = 0; _diesel_gen1_control_governor_and_engine_degov_transport_delay1__i < 120; _diesel_gen1_control_governor_and_engine_degov_transport_delay1__i++) {
        _diesel_gen1_control_governor_and_engine_degov_transport_delay1__state[_diesel_gen1_control_governor_and_engine_degov_transport_delay1__i] =  0.0;
    }
    _diesel_gen1_control_governor_and_engine_degov_transport_delay1__cbi = 0;
    _diesel_gen1_control_unit_delay1__state = 0.0;
    _diesel_gen1_control_unit_delay2__state = 0.0;
    _diesel_gen1_control_unit_delay3__state = 0.0;
    _diesel_gen1_gen_machine_wrapper1__model_load = 0.0;
    _diesel_gen1_measurements_3ph_pll_gen_pll_normalize_v_terminal__d = 0;
    _diesel_gen1_measurements_3ph_pll_gen_pll_normalize_v_terminal__q = 0;
    _diesel_gen1_measurements_3ph_pll_gen_pll_normalize_v_terminal__t = 0;
    _diesel_gen1_measurements_3ph_pll_gen_pll_pi_integrator1__state = 376.99111843077515;
    _diesel_gen1_measurements_3ph_pll_gen_pll_pi_integrator2__state = 0.0;
    _diesel_gen1_measurements_3ph_pll_gen_pll_unit_delay1__state = 0.0;
    _diesel_gen1_sync_check_calculate_dw_synch_unit_delay1__state = 0.0;
    _diesel_gen1_sync_check_contactor_control_edge_detection1_unit_delay1__state = 0.0;
    _diesel_gen1_sync_check_contactor_control_sr_flip_flop1__state =  0;
    _diesel_gen1_sync_check_plls_pll_grid_pll_pi_integrator1__state = 376.99111843077515;
    _diesel_gen1_sync_check_plls_pll_grid_pll_unit_delay1__state = 0.0;
    HIL_OutAO(0x4015, 0.0f);
    _diesel_gen1_sync_check_check_v_diff_unit_delay1__state = 0.0;
    HIL_OutAO(0x4019, 0.0f);
    _diesel_gen1_sync_check_check_phase_diff_counter_counter1_accumulator1__state = 0.0;
    _diesel_gen1_sync_check_check_phase_diff_counter_counter1_accumulator1__reset_state = 2;
    HIL_OutAO(0x401b, 0.0f);
    X_UnInt32 _diesel_gen2_control_governor_and_engine_degov_transport_delay1__i;
    for (_diesel_gen2_control_governor_and_engine_degov_transport_delay1__i = 0; _diesel_gen2_control_governor_and_engine_degov_transport_delay1__i < 120; _diesel_gen2_control_governor_and_engine_degov_transport_delay1__i++) {
        _diesel_gen2_control_governor_and_engine_degov_transport_delay1__state[_diesel_gen2_control_governor_and_engine_degov_transport_delay1__i] =  0.0;
    }
    _diesel_gen2_control_governor_and_engine_degov_transport_delay1__cbi = 0;
    _diesel_gen2_control_unit_delay1__state = 0.0;
    _diesel_gen2_control_unit_delay2__state = 0.0;
    _diesel_gen2_control_unit_delay3__state = 0.0;
    _diesel_gen2_gen_machine_wrapper1__model_load = 0.0;
    _diesel_gen2_measurements_3ph_pll_gen_pll_normalize_v_terminal__d = 0;
    _diesel_gen2_measurements_3ph_pll_gen_pll_normalize_v_terminal__q = 0;
    _diesel_gen2_measurements_3ph_pll_gen_pll_normalize_v_terminal__t = 0;
    _diesel_gen2_measurements_3ph_pll_gen_pll_pi_integrator1__state = 376.99111843077515;
    _diesel_gen2_measurements_3ph_pll_gen_pll_pi_integrator2__state = 0.0;
    _diesel_gen2_measurements_3ph_pll_gen_pll_unit_delay1__state = 0.0;
    _diesel_gen2_sync_check_calculate_dw_synch_unit_delay1__state = 0.0;
    _diesel_gen2_sync_check_contactor_control_edge_detection1_unit_delay1__state = 0.0;
    _diesel_gen2_sync_check_contactor_control_sr_flip_flop1__state =  0;
    _diesel_gen2_sync_check_plls_pll_grid_pll_pi_integrator1__state = 376.99111843077515;
    _diesel_gen2_sync_check_plls_pll_grid_pll_unit_delay1__state = 0.0;
    HIL_OutAO(0x4035, 0.0f);
    _diesel_gen2_sync_check_check_v_diff_unit_delay1__state = 0.0;
    HIL_OutAO(0x4039, 0.0f);
    _diesel_gen2_sync_check_check_phase_diff_counter_counter1_accumulator1__state = 0.0;
    _diesel_gen2_sync_check_check_phase_diff_counter_counter1_accumulator1__reset_state = 2;
    HIL_OutAO(0x403b, 0.0f);
    X_UnInt32 _diesel_gen3_control_governor_and_engine_degov_transport_delay1__i;
    for (_diesel_gen3_control_governor_and_engine_degov_transport_delay1__i = 0; _diesel_gen3_control_governor_and_engine_degov_transport_delay1__i < 120; _diesel_gen3_control_governor_and_engine_degov_transport_delay1__i++) {
        _diesel_gen3_control_governor_and_engine_degov_transport_delay1__state[_diesel_gen3_control_governor_and_engine_degov_transport_delay1__i] =  0.0;
    }
    _diesel_gen3_control_governor_and_engine_degov_transport_delay1__cbi = 0;
    _diesel_gen3_control_unit_delay1__state = 0.0;
    _diesel_gen3_control_unit_delay2__state = 0.0;
    _diesel_gen3_control_unit_delay3__state = 0.0;
    _diesel_gen3_gen_machine_wrapper1__model_load = 0.0;
    _diesel_gen3_measurements_3ph_pll_gen_pll_normalize_v_terminal__d = 0;
    _diesel_gen3_measurements_3ph_pll_gen_pll_normalize_v_terminal__q = 0;
    _diesel_gen3_measurements_3ph_pll_gen_pll_normalize_v_terminal__t = 0;
    _diesel_gen3_measurements_3ph_pll_gen_pll_pi_integrator1__state = 376.99111843077515;
    _diesel_gen3_measurements_3ph_pll_gen_pll_pi_integrator2__state = 0.0;
    _diesel_gen3_measurements_3ph_pll_gen_pll_unit_delay1__state = 0.0;
    _diesel_gen3_sync_check_calculate_dw_synch_unit_delay1__state = 0.0;
    _diesel_gen3_sync_check_contactor_control_edge_detection1_unit_delay1__state = 0.0;
    _diesel_gen3_sync_check_contactor_control_sr_flip_flop1__state =  0;
    _diesel_gen3_sync_check_plls_pll_grid_pll_pi_integrator1__state = 376.99111843077515;
    _diesel_gen3_sync_check_plls_pll_grid_pll_unit_delay1__state = 0.0;
    HIL_OutAO(0x4055, 0.0f);
    _diesel_gen3_sync_check_check_v_diff_unit_delay1__state = 0.0;
    HIL_OutAO(0x4059, 0.0f);
    _diesel_gen3_sync_check_check_phase_diff_counter_counter1_accumulator1__state = 0.0;
    _diesel_gen3_sync_check_check_phase_diff_counter_counter1_accumulator1__reset_state = 2;
    HIL_OutAO(0x405b, 0.0f);
    X_UnInt32 _diesel_gen4_control_governor_and_engine_degov_transport_delay1__i;
    for (_diesel_gen4_control_governor_and_engine_degov_transport_delay1__i = 0; _diesel_gen4_control_governor_and_engine_degov_transport_delay1__i < 120; _diesel_gen4_control_governor_and_engine_degov_transport_delay1__i++) {
        _diesel_gen4_control_governor_and_engine_degov_transport_delay1__state[_diesel_gen4_control_governor_and_engine_degov_transport_delay1__i] =  0.0;
    }
    _diesel_gen4_control_governor_and_engine_degov_transport_delay1__cbi = 0;
    _diesel_gen4_control_unit_delay1__state = 0.0;
    _diesel_gen4_control_unit_delay2__state = 0.0;
    _diesel_gen4_control_unit_delay3__state = 0.0;
    _diesel_gen4_gen_machine_wrapper1__model_load = 0.0;
    _diesel_gen4_measurements_3ph_pll_gen_pll_normalize_v_terminal__d = 0;
    _diesel_gen4_measurements_3ph_pll_gen_pll_normalize_v_terminal__q = 0;
    _diesel_gen4_measurements_3ph_pll_gen_pll_normalize_v_terminal__t = 0;
    _diesel_gen4_measurements_3ph_pll_gen_pll_pi_integrator1__state = 376.99111843077515;
    _diesel_gen4_measurements_3ph_pll_gen_pll_pi_integrator2__state = 0.0;
    _diesel_gen4_measurements_3ph_pll_gen_pll_unit_delay1__state = 0.0;
    _diesel_gen4_sync_check_calculate_dw_synch_unit_delay1__state = 0.0;
    _diesel_gen4_sync_check_contactor_control_edge_detection1_unit_delay1__state = 0.0;
    _diesel_gen4_sync_check_contactor_control_sr_flip_flop1__state =  0;
    _diesel_gen4_sync_check_plls_pll_grid_pll_pi_integrator1__state = 376.99111843077515;
    _diesel_gen4_sync_check_plls_pll_grid_pll_unit_delay1__state = 0.0;
    HIL_OutAO(0x4075, 0.0f);
    _diesel_gen4_sync_check_check_v_diff_unit_delay1__state = 0.0;
    HIL_OutAO(0x4079, 0.0f);
    _diesel_gen4_sync_check_check_phase_diff_counter_counter1_accumulator1__state = 0.0;
    _diesel_gen4_sync_check_check_phase_diff_counter_counter1_accumulator1__reset_state = 2;
    HIL_OutAO(0x407b, 0.0f);
    _three_phase_at_load_7__area_1__pll_pid_integrator1__state = 376.99111843;
    _three_phase_at_load_7__area_1__pll_pid_integrator2__state = 0.0;
    _three_phase_at_load_7__area_1__pll_unit_delay1__state = 0.0;
    _three_phase_at_load_8__mid__pll_pid_integrator1__state = 376.99111843;
    _three_phase_at_load_8__mid__pll_pid_integrator2__state = 0.0;
    _three_phase_at_load_8__mid__pll_unit_delay1__state = 0.0;
    _three_phase_at_load_9__area_2__pll_pid_integrator1__state = 376.99111843;
    _three_phase_at_load_9__area_2__pll_pid_integrator2__state = 0.0;
    _three_phase_at_load_9__area_2__pll_unit_delay1__state = 0.0;
    X_UnInt32 _diesel_gen1_control_exciter_dc4b_tf4__i;
    for (_diesel_gen1_control_exciter_dc4b_tf4__i = 0; _diesel_gen1_control_exciter_dc4b_tf4__i < 1; _diesel_gen1_control_exciter_dc4b_tf4__i++) {
        _diesel_gen1_control_exciter_dc4b_tf4__states[_diesel_gen1_control_exciter_dc4b_tf4__i] = 0;
    }
    HIL_OutAO(0x4012, 0.0f);
    _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1 = 0.0;
    _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1 = 0.0;
    _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1Q = 0.0;
    _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1Q = 0.0;
    _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1P0 = 0.0;
    _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1P0 = 0.0;
    _diesel_gen1_sync_check_check_v_diff_pi_integrator1__state = 0.0;
    _diesel_gen1_sync_check_check_v_diff_pi_integrator1__reset_state = 2;
    HIL_OutAO(0x401d, 0.0f);
    X_UnInt32 _diesel_gen2_control_exciter_dc4b_tf4__i;
    for (_diesel_gen2_control_exciter_dc4b_tf4__i = 0; _diesel_gen2_control_exciter_dc4b_tf4__i < 1; _diesel_gen2_control_exciter_dc4b_tf4__i++) {
        _diesel_gen2_control_exciter_dc4b_tf4__states[_diesel_gen2_control_exciter_dc4b_tf4__i] = 0;
    }
    HIL_OutAO(0x4032, 0.0f);
    _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1 = 0.0;
    _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1 = 0.0;
    _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1Q = 0.0;
    _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1Q = 0.0;
    _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1P0 = 0.0;
    _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1P0 = 0.0;
    _diesel_gen2_sync_check_check_v_diff_pi_integrator1__state = 0.0;
    _diesel_gen2_sync_check_check_v_diff_pi_integrator1__reset_state = 2;
    HIL_OutAO(0x403d, 0.0f);
    X_UnInt32 _diesel_gen3_control_exciter_dc4b_tf4__i;
    for (_diesel_gen3_control_exciter_dc4b_tf4__i = 0; _diesel_gen3_control_exciter_dc4b_tf4__i < 1; _diesel_gen3_control_exciter_dc4b_tf4__i++) {
        _diesel_gen3_control_exciter_dc4b_tf4__states[_diesel_gen3_control_exciter_dc4b_tf4__i] = 0;
    }
    HIL_OutAO(0x4052, 0.0f);
    _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1 = 0.0;
    _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1 = 0.0;
    _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1Q = 0.0;
    _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1Q = 0.0;
    _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1P0 = 0.0;
    _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1P0 = 0.0;
    _diesel_gen3_sync_check_check_v_diff_pi_integrator1__state = 0.0;
    _diesel_gen3_sync_check_check_v_diff_pi_integrator1__reset_state = 2;
    HIL_OutAO(0x405d, 0.0f);
    X_UnInt32 _diesel_gen4_control_exciter_dc4b_tf4__i;
    for (_diesel_gen4_control_exciter_dc4b_tf4__i = 0; _diesel_gen4_control_exciter_dc4b_tf4__i < 1; _diesel_gen4_control_exciter_dc4b_tf4__i++) {
        _diesel_gen4_control_exciter_dc4b_tf4__states[_diesel_gen4_control_exciter_dc4b_tf4__i] = 0;
    }
    HIL_OutAO(0x4072, 0.0f);
    _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1 = 0.0;
    _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1 = 0.0;
    _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1Q = 0.0;
    _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1Q = 0.0;
    _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1P0 = 0.0;
    _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1P0 = 0.0;
    _diesel_gen4_sync_check_check_v_diff_pi_integrator1__state = 0.0;
    _diesel_gen4_sync_check_check_v_diff_pi_integrator1__reset_state = 2;
    HIL_OutAO(0x407d, 0.0f);
    HIL_OutAO(0x4080, 0.0f);
    _three_phase_at_load_7__area_1__meassm_mode_and_dfract__dFract = 0;
    _three_phase_at_load_7__area_1__meassm_mode_and_dfract__fMax = 1.0 / 0.0001;
    _three_phase_at_load_7__area_1__meassm_mode_and_dfract__cycle_counter = 0;
    _three_phase_at_load_7__area_1__meassm_mode_and_dfract__reset = 1;
    HIL_OutAO(0x409a, 0.0f);
    _three_phase_at_load_8__mid__meassm_mode_and_dfract__dFract = 0;
    _three_phase_at_load_8__mid__meassm_mode_and_dfract__fMax = 1.0 / 0.0001;
    _three_phase_at_load_8__mid__meassm_mode_and_dfract__cycle_counter = 0;
    _three_phase_at_load_8__mid__meassm_mode_and_dfract__reset = 1;
    HIL_OutAO(0x40b1, 0.0f);
    _three_phase_at_load_9__area_2__meassm_mode_and_dfract__dFract = 0;
    _three_phase_at_load_9__area_2__meassm_mode_and_dfract__fMax = 1.0 / 0.0001;
    _three_phase_at_load_9__area_2__meassm_mode_and_dfract__cycle_counter = 0;
    _three_phase_at_load_9__area_2__meassm_mode_and_dfract__reset = 1;
    _diesel_gen1_control_exciter_dc4b_variable_limit__LimitChange = 0;
    _diesel_gen1_control_exciter_dc4b_variable_limit__out = 0;
    X_UnInt32 _diesel_gen1_control_governor_and_engine_degov_tf2__i;
    for (_diesel_gen1_control_governor_and_engine_degov_tf2__i = 0; _diesel_gen1_control_governor_and_engine_degov_tf2__i < 2; _diesel_gen1_control_governor_and_engine_degov_tf2__i++) {
        _diesel_gen1_control_governor_and_engine_degov_tf2__states[_diesel_gen1_control_governor_and_engine_degov_tf2__i] = 0;
    }
    HIL_OutAO(0x400a, 0.0f);
    HIL_OutAO(0x4013, 0.0f);
    HIL_OutAO(0x401f, 0.0f);
    _diesel_gen1_sync_check_check_f_diff_comparator1__state = 0.0f;
    _diesel_gen1_sync_check_check_phase_diff_comparator2__state = 0.0f;
    HIL_OutAO(0x4008, 0.0f);
    _diesel_gen1_control_start_exciter_comparator1__state = 0.0f;
    _diesel_gen2_control_exciter_dc4b_variable_limit__LimitChange = 0;
    _diesel_gen2_control_exciter_dc4b_variable_limit__out = 0;
    X_UnInt32 _diesel_gen2_control_governor_and_engine_degov_tf2__i;
    for (_diesel_gen2_control_governor_and_engine_degov_tf2__i = 0; _diesel_gen2_control_governor_and_engine_degov_tf2__i < 2; _diesel_gen2_control_governor_and_engine_degov_tf2__i++) {
        _diesel_gen2_control_governor_and_engine_degov_tf2__states[_diesel_gen2_control_governor_and_engine_degov_tf2__i] = 0;
    }
    HIL_OutAO(0x402a, 0.0f);
    HIL_OutAO(0x4033, 0.0f);
    HIL_OutAO(0x403f, 0.0f);
    _diesel_gen2_sync_check_check_f_diff_comparator1__state = 0.0f;
    _diesel_gen2_sync_check_check_phase_diff_comparator2__state = 0.0f;
    HIL_OutAO(0x4028, 0.0f);
    _diesel_gen2_control_start_exciter_comparator1__state = 0.0f;
    _diesel_gen3_control_exciter_dc4b_variable_limit__LimitChange = 0;
    _diesel_gen3_control_exciter_dc4b_variable_limit__out = 0;
    X_UnInt32 _diesel_gen3_control_governor_and_engine_degov_tf2__i;
    for (_diesel_gen3_control_governor_and_engine_degov_tf2__i = 0; _diesel_gen3_control_governor_and_engine_degov_tf2__i < 2; _diesel_gen3_control_governor_and_engine_degov_tf2__i++) {
        _diesel_gen3_control_governor_and_engine_degov_tf2__states[_diesel_gen3_control_governor_and_engine_degov_tf2__i] = 0;
    }
    HIL_OutAO(0x404a, 0.0f);
    HIL_OutAO(0x4053, 0.0f);
    HIL_OutAO(0x405f, 0.0f);
    _diesel_gen3_sync_check_check_f_diff_comparator1__state = 0.0f;
    _diesel_gen3_sync_check_check_phase_diff_comparator2__state = 0.0f;
    HIL_OutAO(0x4048, 0.0f);
    _diesel_gen3_control_start_exciter_comparator1__state = 0.0f;
    _diesel_gen4_control_exciter_dc4b_variable_limit__LimitChange = 0;
    _diesel_gen4_control_exciter_dc4b_variable_limit__out = 0;
    X_UnInt32 _diesel_gen4_control_governor_and_engine_degov_tf2__i;
    for (_diesel_gen4_control_governor_and_engine_degov_tf2__i = 0; _diesel_gen4_control_governor_and_engine_degov_tf2__i < 2; _diesel_gen4_control_governor_and_engine_degov_tf2__i++) {
        _diesel_gen4_control_governor_and_engine_degov_tf2__states[_diesel_gen4_control_governor_and_engine_degov_tf2__i] = 0;
    }
    HIL_OutAO(0x406a, 0.0f);
    HIL_OutAO(0x4073, 0.0f);
    HIL_OutAO(0x407f, 0.0f);
    _diesel_gen4_sync_check_check_f_diff_comparator1__state = 0.0f;
    _diesel_gen4_sync_check_check_phase_diff_comparator2__state = 0.0f;
    HIL_OutAO(0x4068, 0.0f);
    _diesel_gen4_control_start_exciter_comparator1__state = 0.0f;
    _three_phase_at_load_7__area_1__i_rms_calc_rms__mode = 1;
    _three_phase_at_load_7__area_1__vll_rms_calc_rms__mode = 1;
    _three_phase_at_load_7__area_1__vln_rms_calc_rms__mode = 1;
    _three_phase_at_load_8__mid__i_rms_calc_rms__mode = 1;
    _three_phase_at_load_8__mid__vln_rms_calc_rms__mode = 1;
    _three_phase_at_load_9__area_2__i_rms_calc_rms__mode = 1;
    _three_phase_at_load_9__area_2__vll_rms_calc_rms__mode = 1;
    _three_phase_at_load_9__area_2__vln_rms_calc_rms__mode = 1;
    _diesel_gen1_control_define_control_mode_control_mode__P_control = 0;
    _diesel_gen1_control_define_control_mode_control_mode__Q_control = 0;
    _diesel_gen1_control_governor_and_engine_degov_integrator_integrator1__state = 0.0;
    _diesel_gen1_control_governor_and_engine_degov_integrator_integrator1__reset_state = 2;
    _diesel_gen2_control_define_control_mode_control_mode__P_control = 0;
    _diesel_gen2_control_define_control_mode_control_mode__Q_control = 0;
    _diesel_gen2_control_governor_and_engine_degov_integrator_integrator1__state = 0.0;
    _diesel_gen2_control_governor_and_engine_degov_integrator_integrator1__reset_state = 2;
    _diesel_gen4_control_define_control_mode_control_mode__P_control = 0;
    _diesel_gen4_control_define_control_mode_control_mode__Q_control = 0;
    _diesel_gen4_control_governor_and_engine_degov_integrator_integrator1__state = 0.0;
    _diesel_gen4_control_governor_and_engine_degov_integrator_integrator1__reset_state = 2;
    _diesel_gen3_control_define_control_mode_control_mode__P_control = 0;
    _diesel_gen3_control_define_control_mode_control_mode__Q_control = 0;
    _diesel_gen3_control_governor_and_engine_degov_integrator_integrator1__state = 0.0;
    _diesel_gen3_control_governor_and_engine_degov_integrator_integrator1__reset_state = 2;
    X_UnInt32 _diesel_gen1_control_exciter_dc4b_tf3__i;
    for (_diesel_gen1_control_exciter_dc4b_tf3__i = 0; _diesel_gen1_control_exciter_dc4b_tf3__i < 1; _diesel_gen1_control_exciter_dc4b_tf3__i++) {
        _diesel_gen1_control_exciter_dc4b_tf3__states[_diesel_gen1_control_exciter_dc4b_tf3__i] = 0;
    }
    X_UnInt32 _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__i;
    for (_diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__i = 0; _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__i < 1; _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__i++) {
        _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__states[_diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__i] = 0;
    }
    X_UnInt32 _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__i;
    for (_diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__i = 0; _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__i < 1; _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__i++) {
        _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__states[_diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__i] = 0;
    }
    HIL_OutAO(0x4011, 0.0f);
    HIL_OutAO(0x4010, 0.0f);
    HIL_OutAO(0x400f, 0.0f);
    _diesel_gen1_control_check_steady_state_w_comparator3__state = 0.0f;
    X_UnInt32 _diesel_gen2_control_exciter_dc4b_tf3__i;
    for (_diesel_gen2_control_exciter_dc4b_tf3__i = 0; _diesel_gen2_control_exciter_dc4b_tf3__i < 1; _diesel_gen2_control_exciter_dc4b_tf3__i++) {
        _diesel_gen2_control_exciter_dc4b_tf3__states[_diesel_gen2_control_exciter_dc4b_tf3__i] = 0;
    }
    X_UnInt32 _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__i;
    for (_diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__i = 0; _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__i < 1; _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__i++) {
        _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__states[_diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__i] = 0;
    }
    X_UnInt32 _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__i;
    for (_diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__i = 0; _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__i < 1; _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__i++) {
        _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__states[_diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__i] = 0;
    }
    HIL_OutAO(0x4031, 0.0f);
    HIL_OutAO(0x4030, 0.0f);
    HIL_OutAO(0x402f, 0.0f);
    _diesel_gen2_control_check_steady_state_w_comparator3__state = 0.0f;
    X_UnInt32 _diesel_gen3_control_exciter_dc4b_tf3__i;
    for (_diesel_gen3_control_exciter_dc4b_tf3__i = 0; _diesel_gen3_control_exciter_dc4b_tf3__i < 1; _diesel_gen3_control_exciter_dc4b_tf3__i++) {
        _diesel_gen3_control_exciter_dc4b_tf3__states[_diesel_gen3_control_exciter_dc4b_tf3__i] = 0;
    }
    X_UnInt32 _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__i;
    for (_diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__i = 0; _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__i < 1; _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__i++) {
        _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__states[_diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__i] = 0;
    }
    X_UnInt32 _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__i;
    for (_diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__i = 0; _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__i < 1; _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__i++) {
        _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__states[_diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__i] = 0;
    }
    HIL_OutAO(0x4051, 0.0f);
    HIL_OutAO(0x4050, 0.0f);
    HIL_OutAO(0x404f, 0.0f);
    _diesel_gen3_control_check_steady_state_w_comparator3__state = 0.0f;
    X_UnInt32 _diesel_gen4_control_exciter_dc4b_tf3__i;
    for (_diesel_gen4_control_exciter_dc4b_tf3__i = 0; _diesel_gen4_control_exciter_dc4b_tf3__i < 1; _diesel_gen4_control_exciter_dc4b_tf3__i++) {
        _diesel_gen4_control_exciter_dc4b_tf3__states[_diesel_gen4_control_exciter_dc4b_tf3__i] = 0;
    }
    X_UnInt32 _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__i;
    for (_diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__i = 0; _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__i < 1; _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__i++) {
        _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__states[_diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__i] = 0;
    }
    X_UnInt32 _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__i;
    for (_diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__i = 0; _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__i < 1; _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__i++) {
        _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__states[_diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__i] = 0;
    }
    HIL_OutAO(0x4071, 0.0f);
    HIL_OutAO(0x4070, 0.0f);
    HIL_OutAO(0x406f, 0.0f);
    _diesel_gen4_control_check_steady_state_w_comparator3__state = 0.0f;
    HIL_OutAO(0x4081, 0.0f);
    HIL_OutAO(0x4082, 0.0f);
    HIL_OutAO(0x4083, 0.0f);
    HIL_OutAO(0x4094, 0.0f);
    HIL_OutAO(0x4096, 0.0f);
    HIL_OutAO(0x4098, 0.0f);
    _three_phase_at_load_7__area_1__power_meter_power__mode = 1;
    HIL_OutAO(0x4095, 0.0f);
    HIL_OutAO(0x4097, 0.0f);
    HIL_OutAO(0x4099, 0.0f);
    _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_d__filtered_value = 0.0 / (1 - 1.0 * 62.83185307 * 0.0001 );
    _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_d__previous_in = 0x0;
    _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_q__filtered_value = 0.0 / (1 - 1.0 * 62.83185307 * 0.0001 );
    _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_q__previous_in = 0x0;
    HIL_OutAO(0x409b, 0.0f);
    HIL_OutAO(0x409c, 0.0f);
    HIL_OutAO(0x409d, 0.0f);
    _three_phase_at_load_8__mid__power_meter_power__mode = 1;
    HIL_OutAO(0x40ae, 0.0f);
    HIL_OutAO(0x40af, 0.0f);
    HIL_OutAO(0x40b0, 0.0f);
    _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_d__filtered_value = 0.0 / (1 - 1.0 * 62.83185307 * 0.0001 );
    _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_d__previous_in = 0x0;
    _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_q__filtered_value = 0.0 / (1 - 1.0 * 62.83185307 * 0.0001 );
    _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_q__previous_in = 0x0;
    HIL_OutAO(0x40b2, 0.0f);
    HIL_OutAO(0x40b3, 0.0f);
    HIL_OutAO(0x40b4, 0.0f);
    HIL_OutAO(0x40c5, 0.0f);
    HIL_OutAO(0x40c7, 0.0f);
    HIL_OutAO(0x40c9, 0.0f);
    _three_phase_at_load_9__area_2__power_meter_power__mode = 1;
    HIL_OutAO(0x40c6, 0.0f);
    HIL_OutAO(0x40c8, 0.0f);
    HIL_OutAO(0x40ca, 0.0f);
    _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_d__filtered_value = 0.0 / (1 - 1.0 * 62.83185307 * 0.0001 );
    _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_d__previous_in = 0x0;
    _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_q__filtered_value = 0.0 / (1 - 1.0 * 62.83185307 * 0.0001 );
    _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_q__previous_in = 0x0;
    _diesel_gen1_control_freq_setpoint_control_p_ramp__state = 0;
    _diesel_gen1_control_freq_setpoint_control_p_ramp__first_step = 1;
    _diesel_gen1_control_governor_and_engine_w_ramp__state = 0;
    _diesel_gen1_control_governor_and_engine_w_ramp__first_step = 1;
    _diesel_gen1_control_read_op_mode__OP_mode = 0;
    _diesel_gen1_control_read_op_mode__enable = 0;
    _diesel_gen1_control_read_op_mode__StandBy = 1;
    _diesel_gen1_control_read_op_mode__GridFollowing = 0;
    _diesel_gen1_control_read_op_mode__GridForming = 0;
    _diesel_gen2_control_freq_setpoint_control_p_ramp__state = 0;
    _diesel_gen2_control_freq_setpoint_control_p_ramp__first_step = 1;
    _diesel_gen2_control_governor_and_engine_w_ramp__state = 0;
    _diesel_gen2_control_governor_and_engine_w_ramp__first_step = 1;
    _diesel_gen2_control_read_op_mode__OP_mode = 0;
    _diesel_gen2_control_read_op_mode__enable = 0;
    _diesel_gen2_control_read_op_mode__StandBy = 1;
    _diesel_gen2_control_read_op_mode__GridFollowing = 0;
    _diesel_gen2_control_read_op_mode__GridForming = 0;
    _diesel_gen4_control_freq_setpoint_control_p_ramp__state = 0;
    _diesel_gen4_control_freq_setpoint_control_p_ramp__first_step = 1;
    _diesel_gen4_control_governor_and_engine_w_ramp__state = 0;
    _diesel_gen4_control_governor_and_engine_w_ramp__first_step = 1;
    _diesel_gen4_control_read_op_mode__OP_mode = 0;
    _diesel_gen4_control_read_op_mode__enable = 0;
    _diesel_gen4_control_read_op_mode__StandBy = 1;
    _diesel_gen4_control_read_op_mode__GridFollowing = 0;
    _diesel_gen4_control_read_op_mode__GridForming = 0;
    _diesel_gen3_control_freq_setpoint_control_p_ramp__state = 0;
    _diesel_gen3_control_freq_setpoint_control_p_ramp__first_step = 1;
    _diesel_gen3_control_governor_and_engine_w_ramp__state = 0;
    _diesel_gen3_control_governor_and_engine_w_ramp__first_step = 1;
    _diesel_gen3_control_read_op_mode__OP_mode = 0;
    _diesel_gen3_control_read_op_mode__enable = 0;
    _diesel_gen3_control_read_op_mode__StandBy = 1;
    _diesel_gen3_control_read_op_mode__GridFollowing = 0;
    _diesel_gen3_control_read_op_mode__GridForming = 0;
    _diesel_gen1_control_pf_control_norm_pf_meas__pf = 1.0;
    _diesel_gen1_control_pf_control_norm_pf_meas__pf_norm = 1.0;
    _diesel_gen1_control_pf_control_norm_pf_meas__Q = 0.0;
    _diesel_gen1_control_pf_control_norm_pf_ref__pf = 1.0;
    _diesel_gen1_control_pf_control_norm_pf_ref__pf_norm = 1.0;
    _diesel_gen1_control_exciter_dc4b_pi_integrator1__state = 0.0;
    _diesel_gen1_control_exciter_dc4b_pi_integrator1__reset_state = 2;
    _diesel_gen2_control_pf_control_norm_pf_meas__pf = 1.0;
    _diesel_gen2_control_pf_control_norm_pf_meas__pf_norm = 1.0;
    _diesel_gen2_control_pf_control_norm_pf_meas__Q = 0.0;
    _diesel_gen2_control_pf_control_norm_pf_ref__pf = 1.0;
    _diesel_gen2_control_pf_control_norm_pf_ref__pf_norm = 1.0;
    _diesel_gen2_control_exciter_dc4b_pi_integrator1__state = 0.0;
    _diesel_gen2_control_exciter_dc4b_pi_integrator1__reset_state = 2;
    _diesel_gen3_control_pf_control_norm_pf_meas__pf = 1.0;
    _diesel_gen3_control_pf_control_norm_pf_meas__pf_norm = 1.0;
    _diesel_gen3_control_pf_control_norm_pf_meas__Q = 0.0;
    _diesel_gen3_control_pf_control_norm_pf_ref__pf = 1.0;
    _diesel_gen3_control_pf_control_norm_pf_ref__pf_norm = 1.0;
    _diesel_gen3_control_exciter_dc4b_pi_integrator1__state = 0.0;
    _diesel_gen3_control_exciter_dc4b_pi_integrator1__reset_state = 2;
    _diesel_gen4_control_pf_control_norm_pf_meas__pf = 1.0;
    _diesel_gen4_control_pf_control_norm_pf_meas__pf_norm = 1.0;
    _diesel_gen4_control_pf_control_norm_pf_meas__Q = 0.0;
    _diesel_gen4_control_pf_control_norm_pf_ref__pf = 1.0;
    _diesel_gen4_control_pf_control_norm_pf_ref__pf_norm = 1.0;
    _diesel_gen4_control_exciter_dc4b_pi_integrator1__state = 0.0;
    _diesel_gen4_control_exciter_dc4b_pi_integrator1__reset_state = 2;
    HIL_OutAO(0x4084, 0.0f);
    HIL_OutAO(0x4085, 0.0f);
    HIL_OutAO(0x4086, 0.0f);
    HIL_OutAO(0x4087, 0.0f);
    HIL_OutAO(0x4088, 0.0f);
    HIL_OutAO(0x4089, 0.0f);
    HIL_OutAO(0x408a, 0.0f);
    HIL_OutAO(0x408b, 0.0f);
    HIL_OutAO(0x408c, 0.0f);
    HIL_OutAO(0x408d, 0.0f);
    HIL_OutAO(0x408e, 0.0f);
    HIL_OutAO(0x408f, 0.0f);
    HIL_OutAO(0x4090, 0.0f);
    HIL_OutAO(0x4091, 0.0f);
    HIL_OutAO(0x4092, 0.0f);
    HIL_OutAO(0x4093, 0.0f);
    _three_phase_at_load_7__area_1__pll_normalize__pk = 0;
    HIL_OutAO(0x409e, 0.0f);
    HIL_OutAO(0x409f, 0.0f);
    HIL_OutAO(0x40a0, 0.0f);
    HIL_OutAO(0x40a1, 0.0f);
    HIL_OutAO(0x40a2, 0.0f);
    HIL_OutAO(0x40a3, 0.0f);
    HIL_OutAO(0x40a4, 0.0f);
    HIL_OutAO(0x40a5, 0.0f);
    HIL_OutAO(0x40a6, 0.0f);
    HIL_OutAO(0x40a7, 0.0f);
    HIL_OutAO(0x40a8, 0.0f);
    HIL_OutAO(0x40a9, 0.0f);
    HIL_OutAO(0x40aa, 0.0f);
    HIL_OutAO(0x40ab, 0.0f);
    HIL_OutAO(0x40ac, 0.0f);
    HIL_OutAO(0x40ad, 0.0f);
    _three_phase_at_load_8__mid__pll_normalize__pk = 0;
    HIL_OutAO(0x40b5, 0.0f);
    HIL_OutAO(0x40b6, 0.0f);
    HIL_OutAO(0x40b7, 0.0f);
    HIL_OutAO(0x40b8, 0.0f);
    HIL_OutAO(0x40b9, 0.0f);
    HIL_OutAO(0x40ba, 0.0f);
    HIL_OutAO(0x40bb, 0.0f);
    HIL_OutAO(0x40bc, 0.0f);
    HIL_OutAO(0x40bd, 0.0f);
    HIL_OutAO(0x40be, 0.0f);
    HIL_OutAO(0x40bf, 0.0f);
    HIL_OutAO(0x40c0, 0.0f);
    HIL_OutAO(0x40c1, 0.0f);
    HIL_OutAO(0x40c2, 0.0f);
    HIL_OutAO(0x40c3, 0.0f);
    HIL_OutAO(0x40c4, 0.0f);
    _three_phase_at_load_9__area_2__pll_normalize__pk = 0;
    _diesel_gen1_control_freq_setpoint_control_pi_integrator1__state = 0.0;
    _diesel_gen1_control_freq_setpoint_control_pi_integrator1__reset_state = 2;
    _diesel_gen2_control_freq_setpoint_control_pi_integrator1__state = 0.0;
    _diesel_gen2_control_freq_setpoint_control_pi_integrator1__reset_state = 2;
    _diesel_gen4_control_freq_setpoint_control_pi_integrator1__state = 0.0;
    _diesel_gen4_control_freq_setpoint_control_pi_integrator1__reset_state = 2;
    _diesel_gen3_control_freq_setpoint_control_pi_integrator1__state = 0.0;
    _diesel_gen3_control_freq_setpoint_control_pi_integrator1__reset_state = 2;
    _diesel_gen1_sync_check_plls_pll_grid_pll_normalize_v_terminal__d = 0;
    _diesel_gen1_sync_check_plls_pll_grid_pll_normalize_v_terminal__q = 0;
    _diesel_gen1_sync_check_plls_pll_grid_pll_normalize_v_terminal__t = 0;
    X_UnInt32 _diesel_gen1_control_exciter_dc4b_tf1__i;
    for (_diesel_gen1_control_exciter_dc4b_tf1__i = 0; _diesel_gen1_control_exciter_dc4b_tf1__i < 1; _diesel_gen1_control_exciter_dc4b_tf1__i++) {
        _diesel_gen1_control_exciter_dc4b_tf1__states[_diesel_gen1_control_exciter_dc4b_tf1__i] = 0;
    }
    HIL_OutAO(0x4002, 0.0f);
    HIL_OutAO(0x400d, 0.0f);
    HIL_OutAO(0x400e, 0.0f);
    _diesel_gen1_control_exciter_rate_limit__state = 0;
    _diesel_gen1_control_exciter_rate_limit__first_step = 1;
    _diesel_gen2_sync_check_plls_pll_grid_pll_normalize_v_terminal__d = 0;
    _diesel_gen2_sync_check_plls_pll_grid_pll_normalize_v_terminal__q = 0;
    _diesel_gen2_sync_check_plls_pll_grid_pll_normalize_v_terminal__t = 0;
    X_UnInt32 _diesel_gen2_control_exciter_dc4b_tf1__i;
    for (_diesel_gen2_control_exciter_dc4b_tf1__i = 0; _diesel_gen2_control_exciter_dc4b_tf1__i < 1; _diesel_gen2_control_exciter_dc4b_tf1__i++) {
        _diesel_gen2_control_exciter_dc4b_tf1__states[_diesel_gen2_control_exciter_dc4b_tf1__i] = 0;
    }
    HIL_OutAO(0x4022, 0.0f);
    HIL_OutAO(0x402d, 0.0f);
    HIL_OutAO(0x402e, 0.0f);
    _diesel_gen2_control_exciter_rate_limit__state = 0;
    _diesel_gen2_control_exciter_rate_limit__first_step = 1;
    _diesel_gen3_sync_check_plls_pll_grid_pll_normalize_v_terminal__d = 0;
    _diesel_gen3_sync_check_plls_pll_grid_pll_normalize_v_terminal__q = 0;
    _diesel_gen3_sync_check_plls_pll_grid_pll_normalize_v_terminal__t = 0;
    X_UnInt32 _diesel_gen3_control_exciter_dc4b_tf1__i;
    for (_diesel_gen3_control_exciter_dc4b_tf1__i = 0; _diesel_gen3_control_exciter_dc4b_tf1__i < 1; _diesel_gen3_control_exciter_dc4b_tf1__i++) {
        _diesel_gen3_control_exciter_dc4b_tf1__states[_diesel_gen3_control_exciter_dc4b_tf1__i] = 0;
    }
    HIL_OutAO(0x4042, 0.0f);
    HIL_OutAO(0x404d, 0.0f);
    HIL_OutAO(0x404e, 0.0f);
    _diesel_gen3_control_exciter_rate_limit__state = 0;
    _diesel_gen3_control_exciter_rate_limit__first_step = 1;
    _diesel_gen4_sync_check_plls_pll_grid_pll_normalize_v_terminal__d = 0;
    _diesel_gen4_sync_check_plls_pll_grid_pll_normalize_v_terminal__q = 0;
    _diesel_gen4_sync_check_plls_pll_grid_pll_normalize_v_terminal__t = 0;
    X_UnInt32 _diesel_gen4_control_exciter_dc4b_tf1__i;
    for (_diesel_gen4_control_exciter_dc4b_tf1__i = 0; _diesel_gen4_control_exciter_dc4b_tf1__i < 1; _diesel_gen4_control_exciter_dc4b_tf1__i++) {
        _diesel_gen4_control_exciter_dc4b_tf1__states[_diesel_gen4_control_exciter_dc4b_tf1__i] = 0;
    }
    HIL_OutAO(0x4062, 0.0f);
    HIL_OutAO(0x406d, 0.0f);
    HIL_OutAO(0x406e, 0.0f);
    _diesel_gen4_control_exciter_rate_limit__state = 0;
    _diesel_gen4_control_exciter_rate_limit__first_step = 1;
    _diesel_gen1_control_freq_setpoint_control_w_ramp__state = 0;
    _diesel_gen1_control_freq_setpoint_control_w_ramp__first_step = 1;
    _diesel_gen1_control_read_control_mode_state__Vf = 0;
    _diesel_gen1_control_read_control_mode_state__PV = 0;
    _diesel_gen1_control_read_control_mode_state__PQ = 0;
    _diesel_gen1_control_pf_control_pi_integrator1__state = 0.0;
    _diesel_gen1_control_pf_control_pi_integrator1__reset_state = 2;
    _diesel_gen2_control_freq_setpoint_control_w_ramp__state = 0;
    _diesel_gen2_control_freq_setpoint_control_w_ramp__first_step = 1;
    _diesel_gen2_control_read_control_mode_state__Vf = 0;
    _diesel_gen2_control_read_control_mode_state__PV = 0;
    _diesel_gen2_control_read_control_mode_state__PQ = 0;
    _diesel_gen2_control_pf_control_pi_integrator1__state = 0.0;
    _diesel_gen2_control_pf_control_pi_integrator1__reset_state = 2;
    _diesel_gen4_control_freq_setpoint_control_w_ramp__state = 0;
    _diesel_gen4_control_freq_setpoint_control_w_ramp__first_step = 1;
    _diesel_gen4_control_read_control_mode_state__Vf = 0;
    _diesel_gen4_control_read_control_mode_state__PV = 0;
    _diesel_gen4_control_read_control_mode_state__PQ = 0;
    _diesel_gen4_control_pf_control_pi_integrator1__state = 0.0;
    _diesel_gen4_control_pf_control_pi_integrator1__reset_state = 2;
    _diesel_gen3_control_freq_setpoint_control_w_ramp__state = 0;
    _diesel_gen3_control_freq_setpoint_control_w_ramp__first_step = 1;
    _diesel_gen3_control_read_control_mode_state__Vf = 0;
    _diesel_gen3_control_read_control_mode_state__PV = 0;
    _diesel_gen3_control_read_control_mode_state__PQ = 0;
    _diesel_gen3_control_pf_control_pi_integrator1__state = 0.0;
    _diesel_gen3_control_pf_control_pi_integrator1__reset_state = 2;
    X_UnInt32 _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__i;
    for (_diesel_gen1_sync_check_plls_pll_grid_lpf_vt__i = 0; _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__i < 1; _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__i++) {
        _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__states[_diesel_gen1_sync_check_plls_pll_grid_lpf_vt__i] = 0;
    }
    _diesel_gen1_measurements_3ph_pll_gen_pll_rate_limiter1__state = 0;
    _diesel_gen1_measurements_3ph_pll_gen_pll_rate_limiter1__first_step = 1;
    _diesel_gen1_measurements_3ph_pll_gen_pll_integrator__out = 0;
    _diesel_gen1_measurements_3ph_pll_gen_pll_integrator__in = 0;
    HIL_OutAO(0x4004, 0.0f);
    HIL_OutAO(0x400b, 0.0f);
    HIL_OutFloat(137101312, 0.0);
    X_UnInt32 _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__i;
    for (_diesel_gen2_sync_check_plls_pll_grid_lpf_vt__i = 0; _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__i < 1; _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__i++) {
        _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__states[_diesel_gen2_sync_check_plls_pll_grid_lpf_vt__i] = 0;
    }
    _diesel_gen2_measurements_3ph_pll_gen_pll_rate_limiter1__state = 0;
    _diesel_gen2_measurements_3ph_pll_gen_pll_rate_limiter1__first_step = 1;
    _diesel_gen2_measurements_3ph_pll_gen_pll_integrator__out = 0;
    _diesel_gen2_measurements_3ph_pll_gen_pll_integrator__in = 0;
    HIL_OutAO(0x4024, 0.0f);
    HIL_OutAO(0x402b, 0.0f);
    HIL_OutFloat(137101313, 0.0);
    X_UnInt32 _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__i;
    for (_diesel_gen3_sync_check_plls_pll_grid_lpf_vt__i = 0; _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__i < 1; _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__i++) {
        _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__states[_diesel_gen3_sync_check_plls_pll_grid_lpf_vt__i] = 0;
    }
    _diesel_gen3_measurements_3ph_pll_gen_pll_rate_limiter1__state = 0;
    _diesel_gen3_measurements_3ph_pll_gen_pll_rate_limiter1__first_step = 1;
    _diesel_gen3_measurements_3ph_pll_gen_pll_integrator__out = 0;
    _diesel_gen3_measurements_3ph_pll_gen_pll_integrator__in = 0;
    HIL_OutAO(0x4044, 0.0f);
    HIL_OutAO(0x404b, 0.0f);
    HIL_OutFloat(137101314, 0.0);
    X_UnInt32 _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__i;
    for (_diesel_gen4_sync_check_plls_pll_grid_lpf_vt__i = 0; _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__i < 1; _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__i++) {
        _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__states[_diesel_gen4_sync_check_plls_pll_grid_lpf_vt__i] = 0;
    }
    _diesel_gen4_measurements_3ph_pll_gen_pll_rate_limiter1__state = 0;
    _diesel_gen4_measurements_3ph_pll_gen_pll_rate_limiter1__first_step = 1;
    _diesel_gen4_measurements_3ph_pll_gen_pll_integrator__out = 0;
    _diesel_gen4_measurements_3ph_pll_gen_pll_integrator__in = 0;
    HIL_OutAO(0x4064, 0.0f);
    HIL_OutAO(0x406b, 0.0f);
    HIL_OutFloat(137101315, 0.0);
    HIL_OutAO(0x4005, 0.0f);
    _diesel_gen1_control_pf_control_rate_limiter1__state = 0;
    _diesel_gen1_control_pf_control_rate_limiter1__first_step = 1;
    HIL_OutAO(0x4025, 0.0f);
    _diesel_gen2_control_pf_control_rate_limiter1__state = 0;
    _diesel_gen2_control_pf_control_rate_limiter1__first_step = 1;
    HIL_OutAO(0x4065, 0.0f);
    _diesel_gen4_control_pf_control_rate_limiter1__state = 0;
    _diesel_gen4_control_pf_control_rate_limiter1__first_step = 1;
    HIL_OutAO(0x4045, 0.0f);
    _diesel_gen3_control_pf_control_rate_limiter1__state = 0;
    _diesel_gen3_control_pf_control_rate_limiter1__first_step = 1;
    X_UnInt32 _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__i;
    for (_diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__i = 0; _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__i < 2; _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__i++) {
        _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__states[_diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__i] = 0;
    }
    HIL_OutAO(0x4007, 0.0f);
    X_UnInt32 _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__i;
    for (_diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__i = 0; _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__i < 2; _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__i++) {
        _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__states[_diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__i] = 0;
    }
    HIL_OutAO(0x4027, 0.0f);
    X_UnInt32 _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__i;
    for (_diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__i = 0; _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__i < 2; _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__i++) {
        _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__states[_diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__i] = 0;
    }
    HIL_OutAO(0x4047, 0.0f);
    X_UnInt32 _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__i;
    for (_diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__i = 0; _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__i < 2; _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__i++) {
        _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__states[_diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__i] = 0;
    }
    HIL_OutAO(0x4067, 0.0f);
    HIL_OutAO(0x4006, 0.0f);
    HIL_OutAO(0x4026, 0.0f);
    HIL_OutAO(0x4066, 0.0f);
    HIL_OutAO(0x4046, 0.0f);
    _diesel_gen1_sync_check_check_phase_diff_pi_integrator1__state = 0.0;
    _diesel_gen1_sync_check_check_phase_diff_pi_integrator1__reset_state = 2;
    _diesel_gen2_sync_check_check_phase_diff_pi_integrator1__state = 0.0;
    _diesel_gen2_sync_check_check_phase_diff_pi_integrator1__reset_state = 2;
    _diesel_gen4_sync_check_check_phase_diff_pi_integrator1__state = 0.0;
    _diesel_gen4_sync_check_check_phase_diff_pi_integrator1__reset_state = 2;
    _diesel_gen3_sync_check_check_phase_diff_pi_integrator1__state = 0.0;
    _diesel_gen3_sync_check_check_phase_diff_pi_integrator1__reset_state = 2;
    _diesel_gen1_sync_check_plls_pll_grid_pll_integrator__out = 0;
    _diesel_gen1_sync_check_plls_pll_grid_pll_integrator__in = 0;
    HIL_OutAO(0x4014, 0.0f);
    HIL_OutAO(0x4016, 0.0f);
    _diesel_gen2_sync_check_plls_pll_grid_pll_integrator__out = 0;
    _diesel_gen2_sync_check_plls_pll_grid_pll_integrator__in = 0;
    HIL_OutAO(0x4034, 0.0f);
    HIL_OutAO(0x4036, 0.0f);
    _diesel_gen3_sync_check_plls_pll_grid_pll_integrator__out = 0;
    _diesel_gen3_sync_check_plls_pll_grid_pll_integrator__in = 0;
    HIL_OutAO(0x4054, 0.0f);
    HIL_OutAO(0x4056, 0.0f);
    _diesel_gen4_sync_check_plls_pll_grid_pll_integrator__out = 0;
    _diesel_gen4_sync_check_plls_pll_grid_pll_integrator__in = 0;
    HIL_OutAO(0x4074, 0.0f);
    HIL_OutAO(0x4076, 0.0f);
    _diesel_gen1_sync_check_contactor_control_wait_to_trip__time_acc = 0;
    _diesel_gen1_sync_check_contactor_control_wait_to_trip__Trip = 0;
    _diesel_gen2_sync_check_contactor_control_wait_to_trip__time_acc = 0;
    _diesel_gen2_sync_check_contactor_control_wait_to_trip__Trip = 0;
    _diesel_gen4_sync_check_contactor_control_wait_to_trip__time_acc = 0;
    _diesel_gen4_sync_check_contactor_control_wait_to_trip__Trip = 0;
    _diesel_gen3_sync_check_contactor_control_wait_to_trip__time_acc = 0;
    _diesel_gen3_sync_check_contactor_control_wait_to_trip__Trip = 0;
    HIL_OutAO(0x4017, 0.0f);
    X_UnInt32 _diesel_gen1_sync_check_plls_pll_grid_lpf_f__i;
    for (_diesel_gen1_sync_check_plls_pll_grid_lpf_f__i = 0; _diesel_gen1_sync_check_plls_pll_grid_lpf_f__i < 1; _diesel_gen1_sync_check_plls_pll_grid_lpf_f__i++) {
        _diesel_gen1_sync_check_plls_pll_grid_lpf_f__states[_diesel_gen1_sync_check_plls_pll_grid_lpf_f__i] = 0;
    }
    HIL_OutAO(0x4003, 0.0f);
    HIL_OutAO(0x4037, 0.0f);
    X_UnInt32 _diesel_gen2_sync_check_plls_pll_grid_lpf_f__i;
    for (_diesel_gen2_sync_check_plls_pll_grid_lpf_f__i = 0; _diesel_gen2_sync_check_plls_pll_grid_lpf_f__i < 1; _diesel_gen2_sync_check_plls_pll_grid_lpf_f__i++) {
        _diesel_gen2_sync_check_plls_pll_grid_lpf_f__states[_diesel_gen2_sync_check_plls_pll_grid_lpf_f__i] = 0;
    }
    HIL_OutAO(0x4023, 0.0f);
    HIL_OutAO(0x4057, 0.0f);
    X_UnInt32 _diesel_gen3_sync_check_plls_pll_grid_lpf_f__i;
    for (_diesel_gen3_sync_check_plls_pll_grid_lpf_f__i = 0; _diesel_gen3_sync_check_plls_pll_grid_lpf_f__i < 1; _diesel_gen3_sync_check_plls_pll_grid_lpf_f__i++) {
        _diesel_gen3_sync_check_plls_pll_grid_lpf_f__states[_diesel_gen3_sync_check_plls_pll_grid_lpf_f__i] = 0;
    }
    HIL_OutAO(0x4043, 0.0f);
    HIL_OutAO(0x4077, 0.0f);
    X_UnInt32 _diesel_gen4_sync_check_plls_pll_grid_lpf_f__i;
    for (_diesel_gen4_sync_check_plls_pll_grid_lpf_f__i = 0; _diesel_gen4_sync_check_plls_pll_grid_lpf_f__i < 1; _diesel_gen4_sync_check_plls_pll_grid_lpf_f__i++) {
        _diesel_gen4_sync_check_plls_pll_grid_lpf_f__states[_diesel_gen4_sync_check_plls_pll_grid_lpf_f__i] = 0;
    }
    HIL_OutAO(0x4063, 0.0f);
    _three_phase_at_load_7__area_1__pll_rate_limiter1__state = 0;
    _three_phase_at_load_7__area_1__pll_rate_limiter1__first_step = 1;
    _three_phase_at_load_7__area_1__pll_integrator__out = 0;
    _three_phase_at_load_8__mid__pll_rate_limiter1__state = 0;
    _three_phase_at_load_8__mid__pll_rate_limiter1__first_step = 1;
    _three_phase_at_load_8__mid__pll_integrator__out = 0;
    _three_phase_at_load_9__area_2__pll_rate_limiter1__state = 0;
    _three_phase_at_load_9__area_2__pll_rate_limiter1__first_step = 1;
    _three_phase_at_load_9__area_2__pll_integrator__out = 0;
    _diesel_gen1_sync_check_check_phase_diff_confine_phase__dtheta = 0;
    _diesel_gen1_sync_check_check_phase_diff_confine_phase__dtheta_confined = 0;
    X_UnInt32 _diesel_gen1_sync_check_check_f_diff_lpf_dwf__i;
    for (_diesel_gen1_sync_check_check_f_diff_lpf_dwf__i = 0; _diesel_gen1_sync_check_check_f_diff_lpf_dwf__i < 1; _diesel_gen1_sync_check_check_f_diff_lpf_dwf__i++) {
        _diesel_gen1_sync_check_check_f_diff_lpf_dwf__states[_diesel_gen1_sync_check_check_f_diff_lpf_dwf__i] = 0;
    }
    HIL_OutAO(0x4018, 0.0f);
    _diesel_gen2_sync_check_check_phase_diff_confine_phase__dtheta = 0;
    _diesel_gen2_sync_check_check_phase_diff_confine_phase__dtheta_confined = 0;
    X_UnInt32 _diesel_gen2_sync_check_check_f_diff_lpf_dwf__i;
    for (_diesel_gen2_sync_check_check_f_diff_lpf_dwf__i = 0; _diesel_gen2_sync_check_check_f_diff_lpf_dwf__i < 1; _diesel_gen2_sync_check_check_f_diff_lpf_dwf__i++) {
        _diesel_gen2_sync_check_check_f_diff_lpf_dwf__states[_diesel_gen2_sync_check_check_f_diff_lpf_dwf__i] = 0;
    }
    HIL_OutAO(0x4038, 0.0f);
    _diesel_gen3_sync_check_check_phase_diff_confine_phase__dtheta = 0;
    _diesel_gen3_sync_check_check_phase_diff_confine_phase__dtheta_confined = 0;
    X_UnInt32 _diesel_gen3_sync_check_check_f_diff_lpf_dwf__i;
    for (_diesel_gen3_sync_check_check_f_diff_lpf_dwf__i = 0; _diesel_gen3_sync_check_check_f_diff_lpf_dwf__i < 1; _diesel_gen3_sync_check_check_f_diff_lpf_dwf__i++) {
        _diesel_gen3_sync_check_check_f_diff_lpf_dwf__states[_diesel_gen3_sync_check_check_f_diff_lpf_dwf__i] = 0;
    }
    HIL_OutAO(0x4058, 0.0f);
    _diesel_gen4_sync_check_check_phase_diff_confine_phase__dtheta = 0;
    _diesel_gen4_sync_check_check_phase_diff_confine_phase__dtheta_confined = 0;
    X_UnInt32 _diesel_gen4_sync_check_check_f_diff_lpf_dwf__i;
    for (_diesel_gen4_sync_check_check_f_diff_lpf_dwf__i = 0; _diesel_gen4_sync_check_check_f_diff_lpf_dwf__i < 1; _diesel_gen4_sync_check_check_f_diff_lpf_dwf__i++) {
        _diesel_gen4_sync_check_check_f_diff_lpf_dwf__states[_diesel_gen4_sync_check_check_f_diff_lpf_dwf__i] = 0;
    }
    HIL_OutAO(0x4078, 0.0f);
    X_UnInt32 _three_phase_at_load_7__area_1__pll_lpf_lpf__i;
    for (_three_phase_at_load_7__area_1__pll_lpf_lpf__i = 0; _three_phase_at_load_7__area_1__pll_lpf_lpf__i < 2; _three_phase_at_load_7__area_1__pll_lpf_lpf__i++) {
        _three_phase_at_load_7__area_1__pll_lpf_lpf__states[_three_phase_at_load_7__area_1__pll_lpf_lpf__i] = 0;
    }
    X_UnInt32 _three_phase_at_load_8__mid__pll_lpf_lpf__i;
    for (_three_phase_at_load_8__mid__pll_lpf_lpf__i = 0; _three_phase_at_load_8__mid__pll_lpf_lpf__i < 2; _three_phase_at_load_8__mid__pll_lpf_lpf__i++) {
        _three_phase_at_load_8__mid__pll_lpf_lpf__states[_three_phase_at_load_8__mid__pll_lpf_lpf__i] = 0;
    }
    X_UnInt32 _three_phase_at_load_9__area_2__pll_lpf_lpf__i;
    for (_three_phase_at_load_9__area_2__pll_lpf_lpf__i = 0; _three_phase_at_load_9__area_2__pll_lpf_lpf__i < 2; _three_phase_at_load_9__area_2__pll_lpf_lpf__i++) {
        _three_phase_at_load_9__area_2__pll_lpf_lpf__states[_three_phase_at_load_9__area_2__pll_lpf_lpf__i] = 0;
    }
    _diesel_gen1_sync_check_check_phase_diff_offset_phase__phase_out = 0;
    _diesel_gen1_sync_check_check_phase_diff_offset_phase__off1 = 0.0002 * 6.2831853071 * 60.0;
    _diesel_gen1_sync_check_check_phase_diff_offset_phase__off2 = 0.0 * 3.141592653589793 / 180.0;
    _diesel_gen1_sync_check_check_v_diff_comparator1__state = 0.0f;
    _diesel_gen2_sync_check_check_phase_diff_offset_phase__phase_out = 0;
    _diesel_gen2_sync_check_check_phase_diff_offset_phase__off1 = 0.0002 * 6.2831853071 * 60.0;
    _diesel_gen2_sync_check_check_phase_diff_offset_phase__off2 = 0.0 * 3.141592653589793 / 180.0;
    _diesel_gen2_sync_check_check_v_diff_comparator1__state = 0.0f;
    _diesel_gen3_sync_check_check_phase_diff_offset_phase__phase_out = 0;
    _diesel_gen3_sync_check_check_phase_diff_offset_phase__off1 = 0.0002 * 6.2831853071 * 60.0;
    _diesel_gen3_sync_check_check_phase_diff_offset_phase__off2 = 0.0 * 3.141592653589793 / 180.0;
    _diesel_gen3_sync_check_check_v_diff_comparator1__state = 0.0f;
    _diesel_gen4_sync_check_check_phase_diff_offset_phase__phase_out = 0;
    _diesel_gen4_sync_check_check_phase_diff_offset_phase__off1 = 0.0002 * 6.2831853071 * 60.0;
    _diesel_gen4_sync_check_check_phase_diff_offset_phase__off2 = 0.0 * 3.141592653589793 / 180.0;
    _diesel_gen4_sync_check_check_v_diff_comparator1__state = 0.0f;
    HIL_OutAO(0x401e, 0.0f);
    HIL_OutAO(0x400c, 0.0f);
    HIL_OutAO(0x403e, 0.0f);
    HIL_OutAO(0x402c, 0.0f);
    HIL_OutAO(0x407e, 0.0f);
    HIL_OutAO(0x406c, 0.0f);
    HIL_OutAO(0x405e, 0.0f);
    HIL_OutAO(0x404c, 0.0f);
    X_UnInt32 _diesel_gen1_sync_check_check_phase_diff_lpf__i;
    for (_diesel_gen1_sync_check_check_phase_diff_lpf__i = 0; _diesel_gen1_sync_check_check_phase_diff_lpf__i < 1; _diesel_gen1_sync_check_check_phase_diff_lpf__i++) {
        _diesel_gen1_sync_check_check_phase_diff_lpf__states[_diesel_gen1_sync_check_check_phase_diff_lpf__i] = 0;
    }
    HIL_OutAO(0x401a, 0.0f);
    X_UnInt32 _diesel_gen2_sync_check_check_phase_diff_lpf__i;
    for (_diesel_gen2_sync_check_check_phase_diff_lpf__i = 0; _diesel_gen2_sync_check_check_phase_diff_lpf__i < 1; _diesel_gen2_sync_check_check_phase_diff_lpf__i++) {
        _diesel_gen2_sync_check_check_phase_diff_lpf__states[_diesel_gen2_sync_check_check_phase_diff_lpf__i] = 0;
    }
    HIL_OutAO(0x403a, 0.0f);
    X_UnInt32 _diesel_gen3_sync_check_check_phase_diff_lpf__i;
    for (_diesel_gen3_sync_check_check_phase_diff_lpf__i = 0; _diesel_gen3_sync_check_check_phase_diff_lpf__i < 1; _diesel_gen3_sync_check_check_phase_diff_lpf__i++) {
        _diesel_gen3_sync_check_check_phase_diff_lpf__states[_diesel_gen3_sync_check_check_phase_diff_lpf__i] = 0;
    }
    HIL_OutAO(0x405a, 0.0f);
    X_UnInt32 _diesel_gen4_sync_check_check_phase_diff_lpf__i;
    for (_diesel_gen4_sync_check_check_phase_diff_lpf__i = 0; _diesel_gen4_sync_check_check_phase_diff_lpf__i < 1; _diesel_gen4_sync_check_check_phase_diff_lpf__i++) {
        _diesel_gen4_sync_check_check_phase_diff_lpf__states[_diesel_gen4_sync_check_check_phase_diff_lpf__i] = 0;
    }
    HIL_OutAO(0x407a, 0.0f);
    X_UnInt32 _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__i;
    for (_diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__i = 0; _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__i < 1; _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__i++) {
        _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__states[_diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__i] = 0;
    }
    X_UnInt32 _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__i;
    for (_diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__i = 0; _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__i < 1; _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__i++) {
        _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__states[_diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__i] = 0;
    }
    X_UnInt32 _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__i;
    for (_diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__i = 0; _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__i < 1; _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__i++) {
        _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__states[_diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__i] = 0;
    }
    X_UnInt32 _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__i;
    for (_diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__i = 0; _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__i < 1; _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__i++) {
        _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__states[_diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__i] = 0;
    }
    HIL_OutAO(0x401c, 0.0f);
    HIL_OutAO(0x403c, 0.0f);
    HIL_OutAO(0x405c, 0.0f);
    HIL_OutAO(0x407c, 0.0f);
    HIL_OutAO(0x4001, 0.0f);
    HIL_OutAO(0x4009, 0.0f);
    HIL_OutAO(0x4021, 0.0f);
    HIL_OutAO(0x4029, 0.0f);
    HIL_OutAO(0x4041, 0.0f);
    HIL_OutAO(0x4049, 0.0f);
    HIL_OutAO(0x4061, 0.0f);
    HIL_OutAO(0x4069, 0.0f);
    X_UnInt32 _diesel_gen1_control_governor_and_engine_degov_tf1__i;
    for (_diesel_gen1_control_governor_and_engine_degov_tf1__i = 0; _diesel_gen1_control_governor_and_engine_degov_tf1__i < 2; _diesel_gen1_control_governor_and_engine_degov_tf1__i++) {
        _diesel_gen1_control_governor_and_engine_degov_tf1__states[_diesel_gen1_control_governor_and_engine_degov_tf1__i] = 0;
    }
    X_UnInt32 _diesel_gen2_control_governor_and_engine_degov_tf1__i;
    for (_diesel_gen2_control_governor_and_engine_degov_tf1__i = 0; _diesel_gen2_control_governor_and_engine_degov_tf1__i < 2; _diesel_gen2_control_governor_and_engine_degov_tf1__i++) {
        _diesel_gen2_control_governor_and_engine_degov_tf1__states[_diesel_gen2_control_governor_and_engine_degov_tf1__i] = 0;
    }
    X_UnInt32 _diesel_gen3_control_governor_and_engine_degov_tf1__i;
    for (_diesel_gen3_control_governor_and_engine_degov_tf1__i = 0; _diesel_gen3_control_governor_and_engine_degov_tf1__i < 2; _diesel_gen3_control_governor_and_engine_degov_tf1__i++) {
        _diesel_gen3_control_governor_and_engine_degov_tf1__states[_diesel_gen3_control_governor_and_engine_degov_tf1__i] = 0;
    }
    X_UnInt32 _diesel_gen4_control_governor_and_engine_degov_tf1__i;
    for (_diesel_gen4_control_governor_and_engine_degov_tf1__i = 0; _diesel_gen4_control_governor_and_engine_degov_tf1__i < 2; _diesel_gen4_control_governor_and_engine_degov_tf1__i++) {
        _diesel_gen4_control_governor_and_engine_degov_tf1__states[_diesel_gen4_control_governor_and_engine_degov_tf1__i] = 0;
    }
    HIL_OutAO(0x4000, 0.0f);
    HIL_OutAO(0x4020, 0.0f);
    HIL_OutAO(0x4040, 0.0f);
    HIL_OutAO(0x4060, 0.0f);
    X_UnInt32 _diesel_gen1_control_exciter_dc4b_tf2__i;
    for (_diesel_gen1_control_exciter_dc4b_tf2__i = 0; _diesel_gen1_control_exciter_dc4b_tf2__i < 1; _diesel_gen1_control_exciter_dc4b_tf2__i++) {
        _diesel_gen1_control_exciter_dc4b_tf2__states[_diesel_gen1_control_exciter_dc4b_tf2__i] = 0;
    }
    X_UnInt32 _diesel_gen2_control_exciter_dc4b_tf2__i;
    for (_diesel_gen2_control_exciter_dc4b_tf2__i = 0; _diesel_gen2_control_exciter_dc4b_tf2__i < 1; _diesel_gen2_control_exciter_dc4b_tf2__i++) {
        _diesel_gen2_control_exciter_dc4b_tf2__states[_diesel_gen2_control_exciter_dc4b_tf2__i] = 0;
    }
    X_UnInt32 _diesel_gen3_control_exciter_dc4b_tf2__i;
    for (_diesel_gen3_control_exciter_dc4b_tf2__i = 0; _diesel_gen3_control_exciter_dc4b_tf2__i < 1; _diesel_gen3_control_exciter_dc4b_tf2__i++) {
        _diesel_gen3_control_exciter_dc4b_tf2__states[_diesel_gen3_control_exciter_dc4b_tf2__i] = 0;
    }
    X_UnInt32 _diesel_gen4_control_exciter_dc4b_tf2__i;
    for (_diesel_gen4_control_exciter_dc4b_tf2__i = 0; _diesel_gen4_control_exciter_dc4b_tf2__i < 1; _diesel_gen4_control_exciter_dc4b_tf2__i++) {
        _diesel_gen4_control_exciter_dc4b_tf2__states[_diesel_gen4_control_exciter_dc4b_tf2__i] = 0;
    }
    //@cmp.init.block.end
}


// Dll function pointers and dll reload function
#if defined(_WIN64)
// Define method for reloading dll functions
void ReloadDllFunctions_user_sp_cpu0_dev0(void) {
    // Load each library and setup function pointers
}

void FreeDllFunctions_user_sp_cpu0_dev0(void) {
}

#else
// Define method for reloading dll functions
void ReloadDllFunctions_user_sp_cpu0_dev0(void) {
    // Load each library and setup function pointers
}

void FreeDllFunctions_user_sp_cpu0_dev0(void) {
}
#endif

void load_fmi_libraries_user_sp_cpu0_dev0(void) {
#if defined(_WIN64)
#else
#endif
}


void ReInit_sp_scope_user_sp_cpu0_dev0() {
    // initialise SP Scope buffer pointer
}
// generated using template: common_timer_counter_handler.template-------------------------

/*****************************************************************************************/
/**
* This function is the handler which performs processing for the timer counter.
* It is called from an interrupt context such that the amount of processing
* performed should be minimized.  It is called when the timer counter expires
* if interrupts are enabled.
*
*
* @param    None
*
* @return   None
*
* @note     None
*
*****************************************************************************************/

void TimerCounterHandler_0_user_sp_cpu0_dev0() {
#if DEBUG_MODE
    printf("\n\rTimerCounterHandler_0");
#endif
    //////////////////////////////////////////////////////////////////////////
    // Set tunable parameters
    //////////////////////////////////////////////////////////////////////////
    // Generated from the component: Three-phase at load 7 (area 1).zero
    // Generated from the component: Three-phase at load 8 (mid).zero
    // Generated from the component: Three-phase at load 9 (area 2).zero
    // Generated from the component: Voltage gen 1.zero
    // Generated from the component: Voltage gen 2.zero
    // Generated from the component: Voltage gen 3.zero
    // Generated from the component: Voltage gen 4.zero
//////////////////////////////////////////////////////////////////////////
    // Output block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.out.block.start
    // Generated from the component: Three-phase at load 7 (area 1).IA.Ia1
    _three_phase_at_load_7__area_1__ia_ia1__out = (HIL_InFloat(0xc80000 + 0xd5));
    // Generated from the component: Three-phase at load 7 (area 1).IB.Ia1
    _three_phase_at_load_7__area_1__ib_ia1__out = (HIL_InFloat(0xc80000 + 0xd6));
    // Generated from the component: Three-phase at load 7 (area 1).IC.Ia1
    _three_phase_at_load_7__area_1__ic_ia1__out = (HIL_InFloat(0xc80000 + 0xd7));
    // Generated from the component: Three-phase at load 7 (area 1).PLL.PID.Integrator1
    _three_phase_at_load_7__area_1__pll_pid_integrator1__out = _three_phase_at_load_7__area_1__pll_pid_integrator1__state;
    // Generated from the component: Three-phase at load 7 (area 1).PLL.PID.Integrator2
    _three_phase_at_load_7__area_1__pll_pid_integrator2__out = _three_phase_at_load_7__area_1__pll_pid_integrator2__state;
    // Generated from the component: Three-phase at load 7 (area 1).PLL.Unit Delay1
    _three_phase_at_load_7__area_1__pll_unit_delay1__out = _three_phase_at_load_7__area_1__pll_unit_delay1__state;
    // Generated from the component: Three-phase at load 7 (area 1).PLL.to_Hz
    _three_phase_at_load_7__area_1__pll_to_hz__out = 0.15915494309189535 * _three_phase_at_load_7__area_1__pll_lpf_lpf__out;
    // Generated from the component: Three-phase at load 7 (area 1).VAB.Va1
    _three_phase_at_load_7__area_1__vab_va1__out = (HIL_InFloat(0xc80000 + 0x6d));
    // Generated from the component: Three-phase at load 7 (area 1).VAn.Va1
    _three_phase_at_load_7__area_1__van_va1__out = (HIL_InFloat(0xc80000 + 0x6e));
    // Generated from the component: Three-phase at load 7 (area 1).VBC.Va1
    _three_phase_at_load_7__area_1__vbc_va1__out = (HIL_InFloat(0xc80000 + 0x6f));
    // Generated from the component: Three-phase at load 7 (area 1).VBn.Va1
    _three_phase_at_load_7__area_1__vbn_va1__out = (HIL_InFloat(0xc80000 + 0x70));
    // Generated from the component: Three-phase at load 7 (area 1).VCA.Va1
    _three_phase_at_load_7__area_1__vca_va1__out = (HIL_InFloat(0xc80000 + 0x71));
    // Generated from the component: Three-phase at load 7 (area 1).VCn.Va1
    _three_phase_at_load_7__area_1__vcn_va1__out = (HIL_InFloat(0xc80000 + 0x72));
    // Generated from the component: Three-phase at load 8 (mid).IA.Ia1
    _three_phase_at_load_8__mid__ia_ia1__out = (HIL_InFloat(0xc80000 + 0xd8));
    // Generated from the component: Three-phase at load 8 (mid).IB.Ia1
    _three_phase_at_load_8__mid__ib_ia1__out = (HIL_InFloat(0xc80000 + 0xd9));
    // Generated from the component: Three-phase at load 8 (mid).IC.Ia1
    _three_phase_at_load_8__mid__ic_ia1__out = (HIL_InFloat(0xc80000 + 0xda));
    // Generated from the component: Three-phase at load 8 (mid).PLL.PID.Integrator1
    _three_phase_at_load_8__mid__pll_pid_integrator1__out = _three_phase_at_load_8__mid__pll_pid_integrator1__state;
    // Generated from the component: Three-phase at load 8 (mid).PLL.PID.Integrator2
    _three_phase_at_load_8__mid__pll_pid_integrator2__out = _three_phase_at_load_8__mid__pll_pid_integrator2__state;
    // Generated from the component: Three-phase at load 8 (mid).PLL.Unit Delay1
    _three_phase_at_load_8__mid__pll_unit_delay1__out = _three_phase_at_load_8__mid__pll_unit_delay1__state;
    // Generated from the component: Three-phase at load 8 (mid).PLL.to_Hz
    _three_phase_at_load_8__mid__pll_to_hz__out = 0.15915494309189535 * _three_phase_at_load_8__mid__pll_lpf_lpf__out;
    // Generated from the component: Three-phase at load 8 (mid).VAB.Va1
    _three_phase_at_load_8__mid__vab_va1__out = (HIL_InFloat(0xc80000 + 0x73));
    // Generated from the component: Three-phase at load 8 (mid).VAn.Va1
    _three_phase_at_load_8__mid__van_va1__out = (HIL_InFloat(0xc80000 + 0x74));
    // Generated from the component: Three-phase at load 8 (mid).VBC.Va1
    _three_phase_at_load_8__mid__vbc_va1__out = (HIL_InFloat(0xc80000 + 0x75));
    // Generated from the component: Three-phase at load 8 (mid).VBn.Va1
    _three_phase_at_load_8__mid__vbn_va1__out = (HIL_InFloat(0xc80000 + 0x76));
    // Generated from the component: Three-phase at load 8 (mid).VCA.Va1
    _three_phase_at_load_8__mid__vca_va1__out = (HIL_InFloat(0xc80000 + 0x77));
    // Generated from the component: Three-phase at load 8 (mid).VCn.Va1
    _three_phase_at_load_8__mid__vcn_va1__out = (HIL_InFloat(0xc80000 + 0x78));
    // Generated from the component: Three-phase at load 9 (area 2).IA.Ia1
    _three_phase_at_load_9__area_2__ia_ia1__out = (HIL_InFloat(0xc80000 + 0xdb));
    // Generated from the component: Three-phase at load 9 (area 2).IB.Ia1
    _three_phase_at_load_9__area_2__ib_ia1__out = (HIL_InFloat(0xc80000 + 0xdc));
    // Generated from the component: Three-phase at load 9 (area 2).IC.Ia1
    _three_phase_at_load_9__area_2__ic_ia1__out = (HIL_InFloat(0xc80000 + 0xdd));
    // Generated from the component: Three-phase at load 9 (area 2).PLL.PID.Integrator1
    _three_phase_at_load_9__area_2__pll_pid_integrator1__out = _three_phase_at_load_9__area_2__pll_pid_integrator1__state;
    // Generated from the component: Three-phase at load 9 (area 2).PLL.PID.Integrator2
    _three_phase_at_load_9__area_2__pll_pid_integrator2__out = _three_phase_at_load_9__area_2__pll_pid_integrator2__state;
    // Generated from the component: Three-phase at load 9 (area 2).PLL.Unit Delay1
    _three_phase_at_load_9__area_2__pll_unit_delay1__out = _three_phase_at_load_9__area_2__pll_unit_delay1__state;
    // Generated from the component: Three-phase at load 9 (area 2).PLL.to_Hz
    _three_phase_at_load_9__area_2__pll_to_hz__out = 0.15915494309189535 * _three_phase_at_load_9__area_2__pll_lpf_lpf__out;
    // Generated from the component: Three-phase at load 9 (area 2).VAB.Va1
    _three_phase_at_load_9__area_2__vab_va1__out = (HIL_InFloat(0xc80000 + 0x79));
    // Generated from the component: Three-phase at load 9 (area 2).VAn.Va1
    _three_phase_at_load_9__area_2__van_va1__out = (HIL_InFloat(0xc80000 + 0x7a));
    // Generated from the component: Three-phase at load 9 (area 2).VBC.Va1
    _three_phase_at_load_9__area_2__vbc_va1__out = (HIL_InFloat(0xc80000 + 0x7b));
    // Generated from the component: Three-phase at load 9 (area 2).VBn.Va1
    _three_phase_at_load_9__area_2__vbn_va1__out = (HIL_InFloat(0xc80000 + 0x7c));
    // Generated from the component: Three-phase at load 9 (area 2).VCA.Va1
    _three_phase_at_load_9__area_2__vca_va1__out = (HIL_InFloat(0xc80000 + 0x7d));
    // Generated from the component: Three-phase at load 9 (area 2).VCn.Va1
    _three_phase_at_load_9__area_2__vcn_va1__out = (HIL_InFloat(0xc80000 + 0x7e));
    // Generated from the component: Voltage gen 1.IA.Ia1
    _voltage_gen_1_ia_ia1__out = (HIL_InFloat(0xc80000 + 0xde));
    // Generated from the component: Voltage gen 1.IB.Ia1
    _voltage_gen_1_ib_ia1__out = (HIL_InFloat(0xc80000 + 0xdf));
    // Generated from the component: Voltage gen 1.IC.Ia1
    _voltage_gen_1_ic_ia1__out = (HIL_InFloat(0xc80000 + 0xe0));
    // Generated from the component: Voltage gen 1.VAB.Va1
    _voltage_gen_1_vab_va1__out = (HIL_InFloat(0xc80000 + 0x81));
    // Generated from the component: Voltage gen 1.VAn.Va1
    _voltage_gen_1_van_va1__out = (HIL_InFloat(0xc80000 + 0x82));
    // Generated from the component: Voltage gen 1.VBC.Va1
    _voltage_gen_1_vbc_va1__out = (HIL_InFloat(0xc80000 + 0x83));
    // Generated from the component: Voltage gen 1.VBn.Va1
    _voltage_gen_1_vbn_va1__out = (HIL_InFloat(0xc80000 + 0x84));
    // Generated from the component: Voltage gen 1.VCA.Va1
    _voltage_gen_1_vca_va1__out = (HIL_InFloat(0xc80000 + 0x85));
    // Generated from the component: Voltage gen 1.VCn.Va1
    _voltage_gen_1_vcn_va1__out = (HIL_InFloat(0xc80000 + 0x86));
    // Generated from the component: Voltage gen 2.IA.Ia1
    _voltage_gen_2_ia_ia1__out = (HIL_InFloat(0xc80000 + 0xe1));
    // Generated from the component: Voltage gen 2.IB.Ia1
    _voltage_gen_2_ib_ia1__out = (HIL_InFloat(0xc80000 + 0xe2));
    // Generated from the component: Voltage gen 2.IC.Ia1
    _voltage_gen_2_ic_ia1__out = (HIL_InFloat(0xc80000 + 0xe3));
    // Generated from the component: Voltage gen 2.VAB.Va1
    _voltage_gen_2_vab_va1__out = (HIL_InFloat(0xc80000 + 0x87));
    // Generated from the component: Voltage gen 2.VAn.Va1
    _voltage_gen_2_van_va1__out = (HIL_InFloat(0xc80000 + 0x88));
    // Generated from the component: Voltage gen 2.VBC.Va1
    _voltage_gen_2_vbc_va1__out = (HIL_InFloat(0xc80000 + 0x89));
    // Generated from the component: Voltage gen 2.VBn.Va1
    _voltage_gen_2_vbn_va1__out = (HIL_InFloat(0xc80000 + 0x8a));
    // Generated from the component: Voltage gen 2.VCA.Va1
    _voltage_gen_2_vca_va1__out = (HIL_InFloat(0xc80000 + 0x8b));
    // Generated from the component: Voltage gen 2.VCn.Va1
    _voltage_gen_2_vcn_va1__out = (HIL_InFloat(0xc80000 + 0x8c));
    // Generated from the component: Voltage gen 3.IA.Ia1
    _voltage_gen_3_ia_ia1__out = (HIL_InFloat(0xc80000 + 0xe4));
    // Generated from the component: Voltage gen 3.IB.Ia1
    _voltage_gen_3_ib_ia1__out = (HIL_InFloat(0xc80000 + 0xe5));
    // Generated from the component: Voltage gen 3.IC.Ia1
    _voltage_gen_3_ic_ia1__out = (HIL_InFloat(0xc80000 + 0xe6));
    // Generated from the component: Voltage gen 3.VAB.Va1
    _voltage_gen_3_vab_va1__out = (HIL_InFloat(0xc80000 + 0x8d));
    // Generated from the component: Voltage gen 3.VAn.Va1
    _voltage_gen_3_van_va1__out = (HIL_InFloat(0xc80000 + 0x8e));
    // Generated from the component: Voltage gen 3.VBC.Va1
    _voltage_gen_3_vbc_va1__out = (HIL_InFloat(0xc80000 + 0x8f));
    // Generated from the component: Voltage gen 3.VBn.Va1
    _voltage_gen_3_vbn_va1__out = (HIL_InFloat(0xc80000 + 0x90));
    // Generated from the component: Voltage gen 3.VCA.Va1
    _voltage_gen_3_vca_va1__out = (HIL_InFloat(0xc80000 + 0x91));
    // Generated from the component: Voltage gen 3.VCn.Va1
    _voltage_gen_3_vcn_va1__out = (HIL_InFloat(0xc80000 + 0x92));
    // Generated from the component: Voltage gen 4.IA.Ia1
    _voltage_gen_4_ia_ia1__out = (HIL_InFloat(0xc80000 + 0xe7));
    // Generated from the component: Voltage gen 4.IB.Ia1
    _voltage_gen_4_ib_ia1__out = (HIL_InFloat(0xc80000 + 0xe8));
    // Generated from the component: Voltage gen 4.IC.Ia1
    _voltage_gen_4_ic_ia1__out = (HIL_InFloat(0xc80000 + 0xe9));
    // Generated from the component: Voltage gen 4.VAB.Va1
    _voltage_gen_4_vab_va1__out = (HIL_InFloat(0xc80000 + 0x93));
    // Generated from the component: Voltage gen 4.VAn.Va1
    _voltage_gen_4_van_va1__out = (HIL_InFloat(0xc80000 + 0x94));
    // Generated from the component: Voltage gen 4.VBC.Va1
    _voltage_gen_4_vbc_va1__out = (HIL_InFloat(0xc80000 + 0x95));
    // Generated from the component: Voltage gen 4.VBn.Va1
    _voltage_gen_4_vbn_va1__out = (HIL_InFloat(0xc80000 + 0x96));
    // Generated from the component: Voltage gen 4.VCA.Va1
    _voltage_gen_4_vca_va1__out = (HIL_InFloat(0xc80000 + 0x97));
    // Generated from the component: Voltage gen 4.VCn.Va1
    _voltage_gen_4_vcn_va1__out = (HIL_InFloat(0xc80000 + 0x98));
    // Generated from the component: Three-phase at load 7 (area 1).PLL.sin
    _three_phase_at_load_7__area_1__pll_sin__out = sin(_three_phase_at_load_7__area_1__pll_unit_delay1__out);
    // Generated from the component: Three-phase at load 7 (area 1).TRMwt
    // Generated from the component: Three-phase at load 7 (area 1).Freq
    HIL_OutAO(0x4080, (float)_three_phase_at_load_7__area_1__pll_to_hz__out);
    // Generated from the component: Three-phase at load 7 (area 1).measSM.mode_and_dFract
    _three_phase_at_load_7__area_1__meassm_mode_and_dfract__Freq = _three_phase_at_load_7__area_1__pll_to_hz__out;
    _three_phase_at_load_7__area_1__meassm_mode_and_dfract__freqAbs = fabs(_three_phase_at_load_7__area_1__meassm_mode_and_dfract__Freq);
    if (_three_phase_at_load_7__area_1__meassm_mode_and_dfract__reset == 1) {
        _three_phase_at_load_7__area_1__meassm_mode_and_dfract__mode = 1;
        _three_phase_at_load_7__area_1__meassm_mode_and_dfract__Tfract = 0.0;
        _three_phase_at_load_7__area_1__meassm_mode_and_dfract__cycle_counter = 0;
        _three_phase_at_load_7__area_1__meassm_mode_and_dfract__reset = 0;
    }
    else if (_three_phase_at_load_7__area_1__meassm_mode_and_dfract__freqAbs < 1.0) {
        _three_phase_at_load_7__area_1__meassm_mode_and_dfract__mode = 2;
        if (_three_phase_at_load_7__area_1__meassm_mode_and_dfract__Tfract > 0.0) {
            _three_phase_at_load_7__area_1__meassm_mode_and_dfract__reset = 1;
        }
    }
    else if ((_three_phase_at_load_7__area_1__meassm_mode_and_dfract__Tfract < 1.0) && (_three_phase_at_load_7__area_1__meassm_mode_and_dfract__freqAbs < _three_phase_at_load_7__area_1__meassm_mode_and_dfract__fMax)) {
        _three_phase_at_load_7__area_1__meassm_mode_and_dfract__dFract = 0.0001 * _three_phase_at_load_7__area_1__meassm_mode_and_dfract__freqAbs;
        _three_phase_at_load_7__area_1__meassm_mode_and_dfract__Tfract += _three_phase_at_load_7__area_1__meassm_mode_and_dfract__dFract;
        if (_three_phase_at_load_7__area_1__meassm_mode_and_dfract__Tfract >= 1.0) {
            _three_phase_at_load_7__area_1__meassm_mode_and_dfract__cycle_counter += 1;
            if (_three_phase_at_load_7__area_1__meassm_mode_and_dfract__cycle_counter >= 1) {
                _three_phase_at_load_7__area_1__meassm_mode_and_dfract__dFract = 1.0 - (_three_phase_at_load_7__area_1__meassm_mode_and_dfract__Tfract - _three_phase_at_load_7__area_1__meassm_mode_and_dfract__dFract);
            }
            else {
                _three_phase_at_load_7__area_1__meassm_mode_and_dfract__Tfract -= 1.0;
            }
        }
        _three_phase_at_load_7__area_1__meassm_mode_and_dfract__dFract /= 1;
        _three_phase_at_load_7__area_1__meassm_mode_and_dfract__mode = 3;
        if (_three_phase_at_load_7__area_1__meassm_mode_and_dfract__Tfract < 0.25) {
            _three_phase_at_load_7__area_1__meassm_mode_and_dfract__submode = 1;
        }
        else if (_three_phase_at_load_7__area_1__meassm_mode_and_dfract__Tfract < 0.5) {
            _three_phase_at_load_7__area_1__meassm_mode_and_dfract__submode = 2;
        }
        else if (_three_phase_at_load_7__area_1__meassm_mode_and_dfract__Tfract < 0.75) {
            _three_phase_at_load_7__area_1__meassm_mode_and_dfract__submode = 3;
        }
        else {
            _three_phase_at_load_7__area_1__meassm_mode_and_dfract__submode = 4;
        }
    }
    else if (_three_phase_at_load_7__area_1__meassm_mode_and_dfract__Tfract >= 1.0) {
        _three_phase_at_load_7__area_1__meassm_mode_and_dfract__mode = 4;
        _three_phase_at_load_7__area_1__meassm_mode_and_dfract__reset = 1;
    }
    else {
        _three_phase_at_load_7__area_1__meassm_mode_and_dfract__mode = 5;
        _three_phase_at_load_7__area_1__meassm_mode_and_dfract__reset = 1;
    }
    // Generated from the component: Three-phase at load 7 (area 1).PLL.abc to dq.abc to alpha beta
    _three_phase_at_load_7__area_1__pll_abc_to_dq_abc_to_alpha_beta__alpha = (2.0 * _three_phase_at_load_7__area_1__van_va1__out - _three_phase_at_load_7__area_1__vbn_va1__out - _three_phase_at_load_7__area_1__vcn_va1__out) * 0.3333333333333333;
    _three_phase_at_load_7__area_1__pll_abc_to_dq_abc_to_alpha_beta__beta = (_three_phase_at_load_7__area_1__vbn_va1__out - _three_phase_at_load_7__area_1__vcn_va1__out) * 0.5773502691896258;
    _three_phase_at_load_7__area_1__pll_abc_to_dq_abc_to_alpha_beta__gamma = (_three_phase_at_load_7__area_1__van_va1__out + _three_phase_at_load_7__area_1__vbn_va1__out + _three_phase_at_load_7__area_1__vcn_va1__out) * 0.3333333333333333;
    // Generated from the component: Three-phase at load 7 (area 1).IN
    // Generated from the component: Three-phase at load 7 (area 1).IN_RMS
    // Generated from the component: Three-phase at load 7 (area 1).I_RMS
    // Generated from the component: Three-phase at load 7 (area 1).VLL_RMS
    // Generated from the component: Three-phase at load 7 (area 1).VLn_RMS
    // Generated from the component: Three-phase at load 7 (area 1).VN
    // Generated from the component: Three-phase at load 7 (area 1).VN_RMS
    // Generated from the component: Three-phase at load 8 (mid).PLL.sin
    _three_phase_at_load_8__mid__pll_sin__out = sin(_three_phase_at_load_8__mid__pll_unit_delay1__out);
    // Generated from the component: Three-phase at load 8 (mid).TRMwt
    // Generated from the component: Three-phase at load 8 (mid).Freq
    HIL_OutAO(0x409a, (float)_three_phase_at_load_8__mid__pll_to_hz__out);
    // Generated from the component: Three-phase at load 8 (mid).measSM.mode_and_dFract
    _three_phase_at_load_8__mid__meassm_mode_and_dfract__Freq = _three_phase_at_load_8__mid__pll_to_hz__out;
    _three_phase_at_load_8__mid__meassm_mode_and_dfract__freqAbs = fabs(_three_phase_at_load_8__mid__meassm_mode_and_dfract__Freq);
    if (_three_phase_at_load_8__mid__meassm_mode_and_dfract__reset == 1) {
        _three_phase_at_load_8__mid__meassm_mode_and_dfract__mode = 1;
        _three_phase_at_load_8__mid__meassm_mode_and_dfract__Tfract = 0.0;
        _three_phase_at_load_8__mid__meassm_mode_and_dfract__cycle_counter = 0;
        _three_phase_at_load_8__mid__meassm_mode_and_dfract__reset = 0;
    }
    else if (_three_phase_at_load_8__mid__meassm_mode_and_dfract__freqAbs < 1.0) {
        _three_phase_at_load_8__mid__meassm_mode_and_dfract__mode = 2;
        if (_three_phase_at_load_8__mid__meassm_mode_and_dfract__Tfract > 0.0) {
            _three_phase_at_load_8__mid__meassm_mode_and_dfract__reset = 1;
        }
    }
    else if ((_three_phase_at_load_8__mid__meassm_mode_and_dfract__Tfract < 1.0) && (_three_phase_at_load_8__mid__meassm_mode_and_dfract__freqAbs < _three_phase_at_load_8__mid__meassm_mode_and_dfract__fMax)) {
        _three_phase_at_load_8__mid__meassm_mode_and_dfract__dFract = 0.0001 * _three_phase_at_load_8__mid__meassm_mode_and_dfract__freqAbs;
        _three_phase_at_load_8__mid__meassm_mode_and_dfract__Tfract += _three_phase_at_load_8__mid__meassm_mode_and_dfract__dFract;
        if (_three_phase_at_load_8__mid__meassm_mode_and_dfract__Tfract >= 1.0) {
            _three_phase_at_load_8__mid__meassm_mode_and_dfract__cycle_counter += 1;
            if (_three_phase_at_load_8__mid__meassm_mode_and_dfract__cycle_counter >= 1) {
                _three_phase_at_load_8__mid__meassm_mode_and_dfract__dFract = 1.0 - (_three_phase_at_load_8__mid__meassm_mode_and_dfract__Tfract - _three_phase_at_load_8__mid__meassm_mode_and_dfract__dFract);
            }
            else {
                _three_phase_at_load_8__mid__meassm_mode_and_dfract__Tfract -= 1.0;
            }
        }
        _three_phase_at_load_8__mid__meassm_mode_and_dfract__dFract /= 1;
        _three_phase_at_load_8__mid__meassm_mode_and_dfract__mode = 3;
        if (_three_phase_at_load_8__mid__meassm_mode_and_dfract__Tfract < 0.25) {
            _three_phase_at_load_8__mid__meassm_mode_and_dfract__submode = 1;
        }
        else if (_three_phase_at_load_8__mid__meassm_mode_and_dfract__Tfract < 0.5) {
            _three_phase_at_load_8__mid__meassm_mode_and_dfract__submode = 2;
        }
        else if (_three_phase_at_load_8__mid__meassm_mode_and_dfract__Tfract < 0.75) {
            _three_phase_at_load_8__mid__meassm_mode_and_dfract__submode = 3;
        }
        else {
            _three_phase_at_load_8__mid__meassm_mode_and_dfract__submode = 4;
        }
    }
    else if (_three_phase_at_load_8__mid__meassm_mode_and_dfract__Tfract >= 1.0) {
        _three_phase_at_load_8__mid__meassm_mode_and_dfract__mode = 4;
        _three_phase_at_load_8__mid__meassm_mode_and_dfract__reset = 1;
    }
    else {
        _three_phase_at_load_8__mid__meassm_mode_and_dfract__mode = 5;
        _three_phase_at_load_8__mid__meassm_mode_and_dfract__reset = 1;
    }
    // Generated from the component: Three-phase at load 8 (mid).PLL.abc to dq.abc to alpha beta
    _three_phase_at_load_8__mid__pll_abc_to_dq_abc_to_alpha_beta__alpha = (2.0 * _three_phase_at_load_8__mid__van_va1__out - _three_phase_at_load_8__mid__vbn_va1__out - _three_phase_at_load_8__mid__vcn_va1__out) * 0.3333333333333333;
    _three_phase_at_load_8__mid__pll_abc_to_dq_abc_to_alpha_beta__beta = (_three_phase_at_load_8__mid__vbn_va1__out - _three_phase_at_load_8__mid__vcn_va1__out) * 0.5773502691896258;
    _three_phase_at_load_8__mid__pll_abc_to_dq_abc_to_alpha_beta__gamma = (_three_phase_at_load_8__mid__van_va1__out + _three_phase_at_load_8__mid__vbn_va1__out + _three_phase_at_load_8__mid__vcn_va1__out) * 0.3333333333333333;
    // Generated from the component: Three-phase at load 8 (mid).IN
    // Generated from the component: Three-phase at load 8 (mid).IN_RMS
    // Generated from the component: Three-phase at load 8 (mid).I_RMS
    // Generated from the component: Three-phase at load 8 (mid).VAB_RMS
    // Generated from the component: Three-phase at load 8 (mid).VBC_RMS
    // Generated from the component: Three-phase at load 8 (mid).VCA_RMS
    // Generated from the component: Three-phase at load 8 (mid).VLL_RMS
    // Generated from the component: Three-phase at load 8 (mid).VLn_RMS
    // Generated from the component: Three-phase at load 8 (mid).VN
    // Generated from the component: Three-phase at load 8 (mid).VN_RMS
    // Generated from the component: Three-phase at load 9 (area 2).PLL.sin
    _three_phase_at_load_9__area_2__pll_sin__out = sin(_three_phase_at_load_9__area_2__pll_unit_delay1__out);
    // Generated from the component: Three-phase at load 9 (area 2).TRMwt
    // Generated from the component: Three-phase at load 9 (area 2).Freq
    HIL_OutAO(0x40b1, (float)_three_phase_at_load_9__area_2__pll_to_hz__out);
    // Generated from the component: Three-phase at load 9 (area 2).measSM.mode_and_dFract
    _three_phase_at_load_9__area_2__meassm_mode_and_dfract__Freq = _three_phase_at_load_9__area_2__pll_to_hz__out;
    _three_phase_at_load_9__area_2__meassm_mode_and_dfract__freqAbs = fabs(_three_phase_at_load_9__area_2__meassm_mode_and_dfract__Freq);
    if (_three_phase_at_load_9__area_2__meassm_mode_and_dfract__reset == 1) {
        _three_phase_at_load_9__area_2__meassm_mode_and_dfract__mode = 1;
        _three_phase_at_load_9__area_2__meassm_mode_and_dfract__Tfract = 0.0;
        _three_phase_at_load_9__area_2__meassm_mode_and_dfract__cycle_counter = 0;
        _three_phase_at_load_9__area_2__meassm_mode_and_dfract__reset = 0;
    }
    else if (_three_phase_at_load_9__area_2__meassm_mode_and_dfract__freqAbs < 1.0) {
        _three_phase_at_load_9__area_2__meassm_mode_and_dfract__mode = 2;
        if (_three_phase_at_load_9__area_2__meassm_mode_and_dfract__Tfract > 0.0) {
            _three_phase_at_load_9__area_2__meassm_mode_and_dfract__reset = 1;
        }
    }
    else if ((_three_phase_at_load_9__area_2__meassm_mode_and_dfract__Tfract < 1.0) && (_three_phase_at_load_9__area_2__meassm_mode_and_dfract__freqAbs < _three_phase_at_load_9__area_2__meassm_mode_and_dfract__fMax)) {
        _three_phase_at_load_9__area_2__meassm_mode_and_dfract__dFract = 0.0001 * _three_phase_at_load_9__area_2__meassm_mode_and_dfract__freqAbs;
        _three_phase_at_load_9__area_2__meassm_mode_and_dfract__Tfract += _three_phase_at_load_9__area_2__meassm_mode_and_dfract__dFract;
        if (_three_phase_at_load_9__area_2__meassm_mode_and_dfract__Tfract >= 1.0) {
            _three_phase_at_load_9__area_2__meassm_mode_and_dfract__cycle_counter += 1;
            if (_three_phase_at_load_9__area_2__meassm_mode_and_dfract__cycle_counter >= 1) {
                _three_phase_at_load_9__area_2__meassm_mode_and_dfract__dFract = 1.0 - (_three_phase_at_load_9__area_2__meassm_mode_and_dfract__Tfract - _three_phase_at_load_9__area_2__meassm_mode_and_dfract__dFract);
            }
            else {
                _three_phase_at_load_9__area_2__meassm_mode_and_dfract__Tfract -= 1.0;
            }
        }
        _three_phase_at_load_9__area_2__meassm_mode_and_dfract__dFract /= 1;
        _three_phase_at_load_9__area_2__meassm_mode_and_dfract__mode = 3;
        if (_three_phase_at_load_9__area_2__meassm_mode_and_dfract__Tfract < 0.25) {
            _three_phase_at_load_9__area_2__meassm_mode_and_dfract__submode = 1;
        }
        else if (_three_phase_at_load_9__area_2__meassm_mode_and_dfract__Tfract < 0.5) {
            _three_phase_at_load_9__area_2__meassm_mode_and_dfract__submode = 2;
        }
        else if (_three_phase_at_load_9__area_2__meassm_mode_and_dfract__Tfract < 0.75) {
            _three_phase_at_load_9__area_2__meassm_mode_and_dfract__submode = 3;
        }
        else {
            _three_phase_at_load_9__area_2__meassm_mode_and_dfract__submode = 4;
        }
    }
    else if (_three_phase_at_load_9__area_2__meassm_mode_and_dfract__Tfract >= 1.0) {
        _three_phase_at_load_9__area_2__meassm_mode_and_dfract__mode = 4;
        _three_phase_at_load_9__area_2__meassm_mode_and_dfract__reset = 1;
    }
    else {
        _three_phase_at_load_9__area_2__meassm_mode_and_dfract__mode = 5;
        _three_phase_at_load_9__area_2__meassm_mode_and_dfract__reset = 1;
    }
    // Generated from the component: Three-phase at load 9 (area 2).PLL.abc to dq.abc to alpha beta
    _three_phase_at_load_9__area_2__pll_abc_to_dq_abc_to_alpha_beta__alpha = (2.0 * _three_phase_at_load_9__area_2__van_va1__out - _three_phase_at_load_9__area_2__vbn_va1__out - _three_phase_at_load_9__area_2__vcn_va1__out) * 0.3333333333333333;
    _three_phase_at_load_9__area_2__pll_abc_to_dq_abc_to_alpha_beta__beta = (_three_phase_at_load_9__area_2__vbn_va1__out - _three_phase_at_load_9__area_2__vcn_va1__out) * 0.5773502691896258;
    _three_phase_at_load_9__area_2__pll_abc_to_dq_abc_to_alpha_beta__gamma = (_three_phase_at_load_9__area_2__van_va1__out + _three_phase_at_load_9__area_2__vbn_va1__out + _three_phase_at_load_9__area_2__vcn_va1__out) * 0.3333333333333333;
    // Generated from the component: Three-phase at load 9 (area 2).IN
    // Generated from the component: Three-phase at load 9 (area 2).IN_RMS
    // Generated from the component: Three-phase at load 9 (area 2).I_RMS
    // Generated from the component: Three-phase at load 9 (area 2).VLL_RMS
    // Generated from the component: Three-phase at load 9 (area 2).VLn_RMS
    // Generated from the component: Three-phase at load 9 (area 2).VN
    // Generated from the component: Three-phase at load 9 (area 2).VN_RMS
    // Generated from the component: Voltage gen 1.Freq
    // Generated from the component: Voltage gen 1.IA_RMS
    // Generated from the component: Voltage gen 1.IB_RMS
    // Generated from the component: Voltage gen 1.IC_RMS
    // Generated from the component: Voltage gen 1.IN
    // Generated from the component: Voltage gen 1.IN_RMS
    // Generated from the component: Voltage gen 1.I_RMS
    // Generated from the component: Voltage gen 1.POWER_P
    // Generated from the component: Voltage gen 1.POWER_PA
    // Generated from the component: Voltage gen 1.POWER_PB
    // Generated from the component: Voltage gen 1.POWER_PC
    // Generated from the component: Voltage gen 1.POWER_PF
    // Generated from the component: Voltage gen 1.POWER_PFA
    // Generated from the component: Voltage gen 1.POWER_PFB
    // Generated from the component: Voltage gen 1.POWER_PFC
    // Generated from the component: Voltage gen 1.POWER_Q
    // Generated from the component: Voltage gen 1.POWER_QA
    // Generated from the component: Voltage gen 1.POWER_QB
    // Generated from the component: Voltage gen 1.POWER_QC
    // Generated from the component: Voltage gen 1.POWER_S
    // Generated from the component: Voltage gen 1.POWER_SA
    // Generated from the component: Voltage gen 1.POWER_SB
    // Generated from the component: Voltage gen 1.POWER_SC
    // Generated from the component: Voltage gen 1.VAB_RMS
    // Generated from the component: Voltage gen 1.VAn_RMS
    // Generated from the component: Voltage gen 1.VBC_RMS
    // Generated from the component: Voltage gen 1.VBn_RMS
    // Generated from the component: Voltage gen 1.VCA_RMS
    // Generated from the component: Voltage gen 1.VCn_RMS
    // Generated from the component: Voltage gen 1.VLL_RMS
    // Generated from the component: Voltage gen 1.VLn_RMS
    // Generated from the component: Voltage gen 1.VN
    // Generated from the component: Voltage gen 1.VN_RMS
    // Generated from the component: Voltage gen 1.extra_output_bus
    _voltage_gen_1_extra_output_bus__out[0] = _voltage_gen_1_zero__out;
    _voltage_gen_1_extra_output_bus__out[1] = _voltage_gen_1_zero__out;
    _voltage_gen_1_extra_output_bus__out[2] = _voltage_gen_1_zero__out;
    _voltage_gen_1_extra_output_bus__out[3] = _voltage_gen_1_zero__out;
    _voltage_gen_1_extra_output_bus__out[4] = _voltage_gen_1_zero__out;
    _voltage_gen_1_extra_output_bus__out[5] = _voltage_gen_1_zero__out;
    _voltage_gen_1_extra_output_bus__out[6] = _voltage_gen_1_zero__out;
    _voltage_gen_1_extra_output_bus__out[7] = _voltage_gen_1_zero__out;
    _voltage_gen_1_extra_output_bus__out[8] = _voltage_gen_1_zero__out;
    _voltage_gen_1_extra_output_bus__out[9] = _voltage_gen_1_zero__out;
    _voltage_gen_1_extra_output_bus__out[10] = _voltage_gen_1_zero__out;
    _voltage_gen_1_extra_output_bus__out[11] = _voltage_gen_1_zero__out;
    // Generated from the component: Voltage gen 1.output_bus
    _voltage_gen_1_output_bus__out[0] = _voltage_gen_1_van_va1__out;
    _voltage_gen_1_output_bus__out[1] = _voltage_gen_1_vbn_va1__out;
    _voltage_gen_1_output_bus__out[2] = _voltage_gen_1_vcn_va1__out;
    _voltage_gen_1_output_bus__out[3] = _voltage_gen_1_vab_va1__out;
    _voltage_gen_1_output_bus__out[4] = _voltage_gen_1_vbc_va1__out;
    _voltage_gen_1_output_bus__out[5] = _voltage_gen_1_vca_va1__out;
    _voltage_gen_1_output_bus__out[6] = _voltage_gen_1_ia_ia1__out;
    _voltage_gen_1_output_bus__out[7] = _voltage_gen_1_ib_ia1__out;
    _voltage_gen_1_output_bus__out[8] = _voltage_gen_1_ic_ia1__out;
    _voltage_gen_1_output_bus__out[9] = _voltage_gen_1_zero__out;
    _voltage_gen_1_output_bus__out[10] = _voltage_gen_1_zero__out;
    _voltage_gen_1_output_bus__out[11] = _voltage_gen_1_zero__out;
    _voltage_gen_1_output_bus__out[12] = _voltage_gen_1_zero__out;
    _voltage_gen_1_output_bus__out[13] = _voltage_gen_1_zero__out;
    _voltage_gen_1_output_bus__out[14] = _voltage_gen_1_zero__out;
    _voltage_gen_1_output_bus__out[15] = _voltage_gen_1_zero__out;
    _voltage_gen_1_output_bus__out[16] = _voltage_gen_1_zero__out;
    _voltage_gen_1_output_bus__out[17] = _voltage_gen_1_zero__out;
    _voltage_gen_1_output_bus__out[18] = _voltage_gen_1_zero__out;
    _voltage_gen_1_output_bus__out[19] = _voltage_gen_1_zero__out;
    _voltage_gen_1_output_bus__out[20] = _voltage_gen_1_zero__out;
    _voltage_gen_1_output_bus__out[21] = _voltage_gen_1_zero__out;
    _voltage_gen_1_output_bus__out[22] = _voltage_gen_1_zero__out;
    _voltage_gen_1_output_bus__out[23] = _voltage_gen_1_zero__out;
    _voltage_gen_1_output_bus__out[24] = _voltage_gen_1_zero__out;
    _voltage_gen_1_output_bus__out[25] = _voltage_gen_1_zero__out;
    _voltage_gen_1_output_bus__out[26] = _voltage_gen_1_zero__out;
    _voltage_gen_1_output_bus__out[27] = _voltage_gen_1_zero__out;
    _voltage_gen_1_output_bus__out[28] = _voltage_gen_1_zero__out;
    _voltage_gen_1_output_bus__out[29] = _voltage_gen_1_zero__out;
    // Generated from the component: Voltage gen 2.Freq
    // Generated from the component: Voltage gen 2.IA_RMS
    // Generated from the component: Voltage gen 2.IB_RMS
    // Generated from the component: Voltage gen 2.IC_RMS
    // Generated from the component: Voltage gen 2.IN
    // Generated from the component: Voltage gen 2.IN_RMS
    // Generated from the component: Voltage gen 2.I_RMS
    // Generated from the component: Voltage gen 2.POWER_P
    // Generated from the component: Voltage gen 2.POWER_PA
    // Generated from the component: Voltage gen 2.POWER_PB
    // Generated from the component: Voltage gen 2.POWER_PC
    // Generated from the component: Voltage gen 2.POWER_PF
    // Generated from the component: Voltage gen 2.POWER_PFA
    // Generated from the component: Voltage gen 2.POWER_PFB
    // Generated from the component: Voltage gen 2.POWER_PFC
    // Generated from the component: Voltage gen 2.POWER_Q
    // Generated from the component: Voltage gen 2.POWER_QA
    // Generated from the component: Voltage gen 2.POWER_QB
    // Generated from the component: Voltage gen 2.POWER_QC
    // Generated from the component: Voltage gen 2.POWER_S
    // Generated from the component: Voltage gen 2.POWER_SA
    // Generated from the component: Voltage gen 2.POWER_SB
    // Generated from the component: Voltage gen 2.POWER_SC
    // Generated from the component: Voltage gen 2.VAB_RMS
    // Generated from the component: Voltage gen 2.VAn_RMS
    // Generated from the component: Voltage gen 2.VBC_RMS
    // Generated from the component: Voltage gen 2.VBn_RMS
    // Generated from the component: Voltage gen 2.VCA_RMS
    // Generated from the component: Voltage gen 2.VCn_RMS
    // Generated from the component: Voltage gen 2.VLL_RMS
    // Generated from the component: Voltage gen 2.VLn_RMS
    // Generated from the component: Voltage gen 2.VN
    // Generated from the component: Voltage gen 2.VN_RMS
    // Generated from the component: Voltage gen 2.extra_output_bus
    _voltage_gen_2_extra_output_bus__out[0] = _voltage_gen_2_zero__out;
    _voltage_gen_2_extra_output_bus__out[1] = _voltage_gen_2_zero__out;
    _voltage_gen_2_extra_output_bus__out[2] = _voltage_gen_2_zero__out;
    _voltage_gen_2_extra_output_bus__out[3] = _voltage_gen_2_zero__out;
    _voltage_gen_2_extra_output_bus__out[4] = _voltage_gen_2_zero__out;
    _voltage_gen_2_extra_output_bus__out[5] = _voltage_gen_2_zero__out;
    _voltage_gen_2_extra_output_bus__out[6] = _voltage_gen_2_zero__out;
    _voltage_gen_2_extra_output_bus__out[7] = _voltage_gen_2_zero__out;
    _voltage_gen_2_extra_output_bus__out[8] = _voltage_gen_2_zero__out;
    _voltage_gen_2_extra_output_bus__out[9] = _voltage_gen_2_zero__out;
    _voltage_gen_2_extra_output_bus__out[10] = _voltage_gen_2_zero__out;
    _voltage_gen_2_extra_output_bus__out[11] = _voltage_gen_2_zero__out;
    // Generated from the component: Voltage gen 2.output_bus
    _voltage_gen_2_output_bus__out[0] = _voltage_gen_2_van_va1__out;
    _voltage_gen_2_output_bus__out[1] = _voltage_gen_2_vbn_va1__out;
    _voltage_gen_2_output_bus__out[2] = _voltage_gen_2_vcn_va1__out;
    _voltage_gen_2_output_bus__out[3] = _voltage_gen_2_vab_va1__out;
    _voltage_gen_2_output_bus__out[4] = _voltage_gen_2_vbc_va1__out;
    _voltage_gen_2_output_bus__out[5] = _voltage_gen_2_vca_va1__out;
    _voltage_gen_2_output_bus__out[6] = _voltage_gen_2_ia_ia1__out;
    _voltage_gen_2_output_bus__out[7] = _voltage_gen_2_ib_ia1__out;
    _voltage_gen_2_output_bus__out[8] = _voltage_gen_2_ic_ia1__out;
    _voltage_gen_2_output_bus__out[9] = _voltage_gen_2_zero__out;
    _voltage_gen_2_output_bus__out[10] = _voltage_gen_2_zero__out;
    _voltage_gen_2_output_bus__out[11] = _voltage_gen_2_zero__out;
    _voltage_gen_2_output_bus__out[12] = _voltage_gen_2_zero__out;
    _voltage_gen_2_output_bus__out[13] = _voltage_gen_2_zero__out;
    _voltage_gen_2_output_bus__out[14] = _voltage_gen_2_zero__out;
    _voltage_gen_2_output_bus__out[15] = _voltage_gen_2_zero__out;
    _voltage_gen_2_output_bus__out[16] = _voltage_gen_2_zero__out;
    _voltage_gen_2_output_bus__out[17] = _voltage_gen_2_zero__out;
    _voltage_gen_2_output_bus__out[18] = _voltage_gen_2_zero__out;
    _voltage_gen_2_output_bus__out[19] = _voltage_gen_2_zero__out;
    _voltage_gen_2_output_bus__out[20] = _voltage_gen_2_zero__out;
    _voltage_gen_2_output_bus__out[21] = _voltage_gen_2_zero__out;
    _voltage_gen_2_output_bus__out[22] = _voltage_gen_2_zero__out;
    _voltage_gen_2_output_bus__out[23] = _voltage_gen_2_zero__out;
    _voltage_gen_2_output_bus__out[24] = _voltage_gen_2_zero__out;
    _voltage_gen_2_output_bus__out[25] = _voltage_gen_2_zero__out;
    _voltage_gen_2_output_bus__out[26] = _voltage_gen_2_zero__out;
    _voltage_gen_2_output_bus__out[27] = _voltage_gen_2_zero__out;
    _voltage_gen_2_output_bus__out[28] = _voltage_gen_2_zero__out;
    _voltage_gen_2_output_bus__out[29] = _voltage_gen_2_zero__out;
    // Generated from the component: Voltage gen 3.Freq
    // Generated from the component: Voltage gen 3.IA_RMS
    // Generated from the component: Voltage gen 3.IB_RMS
    // Generated from the component: Voltage gen 3.IC_RMS
    // Generated from the component: Voltage gen 3.IN
    // Generated from the component: Voltage gen 3.IN_RMS
    // Generated from the component: Voltage gen 3.I_RMS
    // Generated from the component: Voltage gen 3.POWER_P
    // Generated from the component: Voltage gen 3.POWER_PA
    // Generated from the component: Voltage gen 3.POWER_PB
    // Generated from the component: Voltage gen 3.POWER_PC
    // Generated from the component: Voltage gen 3.POWER_PF
    // Generated from the component: Voltage gen 3.POWER_PFA
    // Generated from the component: Voltage gen 3.POWER_PFB
    // Generated from the component: Voltage gen 3.POWER_PFC
    // Generated from the component: Voltage gen 3.POWER_Q
    // Generated from the component: Voltage gen 3.POWER_QA
    // Generated from the component: Voltage gen 3.POWER_QB
    // Generated from the component: Voltage gen 3.POWER_QC
    // Generated from the component: Voltage gen 3.POWER_S
    // Generated from the component: Voltage gen 3.POWER_SA
    // Generated from the component: Voltage gen 3.POWER_SB
    // Generated from the component: Voltage gen 3.POWER_SC
    // Generated from the component: Voltage gen 3.VAB_RMS
    // Generated from the component: Voltage gen 3.VAn_RMS
    // Generated from the component: Voltage gen 3.VBC_RMS
    // Generated from the component: Voltage gen 3.VBn_RMS
    // Generated from the component: Voltage gen 3.VCA_RMS
    // Generated from the component: Voltage gen 3.VCn_RMS
    // Generated from the component: Voltage gen 3.VLL_RMS
    // Generated from the component: Voltage gen 3.VLn_RMS
    // Generated from the component: Voltage gen 3.VN
    // Generated from the component: Voltage gen 3.VN_RMS
    // Generated from the component: Voltage gen 3.extra_output_bus
    _voltage_gen_3_extra_output_bus__out[0] = _voltage_gen_3_zero__out;
    _voltage_gen_3_extra_output_bus__out[1] = _voltage_gen_3_zero__out;
    _voltage_gen_3_extra_output_bus__out[2] = _voltage_gen_3_zero__out;
    _voltage_gen_3_extra_output_bus__out[3] = _voltage_gen_3_zero__out;
    _voltage_gen_3_extra_output_bus__out[4] = _voltage_gen_3_zero__out;
    _voltage_gen_3_extra_output_bus__out[5] = _voltage_gen_3_zero__out;
    _voltage_gen_3_extra_output_bus__out[6] = _voltage_gen_3_zero__out;
    _voltage_gen_3_extra_output_bus__out[7] = _voltage_gen_3_zero__out;
    _voltage_gen_3_extra_output_bus__out[8] = _voltage_gen_3_zero__out;
    _voltage_gen_3_extra_output_bus__out[9] = _voltage_gen_3_zero__out;
    _voltage_gen_3_extra_output_bus__out[10] = _voltage_gen_3_zero__out;
    _voltage_gen_3_extra_output_bus__out[11] = _voltage_gen_3_zero__out;
    // Generated from the component: Voltage gen 3.output_bus
    _voltage_gen_3_output_bus__out[0] = _voltage_gen_3_van_va1__out;
    _voltage_gen_3_output_bus__out[1] = _voltage_gen_3_vbn_va1__out;
    _voltage_gen_3_output_bus__out[2] = _voltage_gen_3_vcn_va1__out;
    _voltage_gen_3_output_bus__out[3] = _voltage_gen_3_vab_va1__out;
    _voltage_gen_3_output_bus__out[4] = _voltage_gen_3_vbc_va1__out;
    _voltage_gen_3_output_bus__out[5] = _voltage_gen_3_vca_va1__out;
    _voltage_gen_3_output_bus__out[6] = _voltage_gen_3_ia_ia1__out;
    _voltage_gen_3_output_bus__out[7] = _voltage_gen_3_ib_ia1__out;
    _voltage_gen_3_output_bus__out[8] = _voltage_gen_3_ic_ia1__out;
    _voltage_gen_3_output_bus__out[9] = _voltage_gen_3_zero__out;
    _voltage_gen_3_output_bus__out[10] = _voltage_gen_3_zero__out;
    _voltage_gen_3_output_bus__out[11] = _voltage_gen_3_zero__out;
    _voltage_gen_3_output_bus__out[12] = _voltage_gen_3_zero__out;
    _voltage_gen_3_output_bus__out[13] = _voltage_gen_3_zero__out;
    _voltage_gen_3_output_bus__out[14] = _voltage_gen_3_zero__out;
    _voltage_gen_3_output_bus__out[15] = _voltage_gen_3_zero__out;
    _voltage_gen_3_output_bus__out[16] = _voltage_gen_3_zero__out;
    _voltage_gen_3_output_bus__out[17] = _voltage_gen_3_zero__out;
    _voltage_gen_3_output_bus__out[18] = _voltage_gen_3_zero__out;
    _voltage_gen_3_output_bus__out[19] = _voltage_gen_3_zero__out;
    _voltage_gen_3_output_bus__out[20] = _voltage_gen_3_zero__out;
    _voltage_gen_3_output_bus__out[21] = _voltage_gen_3_zero__out;
    _voltage_gen_3_output_bus__out[22] = _voltage_gen_3_zero__out;
    _voltage_gen_3_output_bus__out[23] = _voltage_gen_3_zero__out;
    _voltage_gen_3_output_bus__out[24] = _voltage_gen_3_zero__out;
    _voltage_gen_3_output_bus__out[25] = _voltage_gen_3_zero__out;
    _voltage_gen_3_output_bus__out[26] = _voltage_gen_3_zero__out;
    _voltage_gen_3_output_bus__out[27] = _voltage_gen_3_zero__out;
    _voltage_gen_3_output_bus__out[28] = _voltage_gen_3_zero__out;
    _voltage_gen_3_output_bus__out[29] = _voltage_gen_3_zero__out;
    // Generated from the component: Voltage gen 4.Freq
    // Generated from the component: Voltage gen 4.IA_RMS
    // Generated from the component: Voltage gen 4.IB_RMS
    // Generated from the component: Voltage gen 4.IC_RMS
    // Generated from the component: Voltage gen 4.IN
    // Generated from the component: Voltage gen 4.IN_RMS
    // Generated from the component: Voltage gen 4.I_RMS
    // Generated from the component: Voltage gen 4.POWER_P
    // Generated from the component: Voltage gen 4.POWER_PA
    // Generated from the component: Voltage gen 4.POWER_PB
    // Generated from the component: Voltage gen 4.POWER_PC
    // Generated from the component: Voltage gen 4.POWER_PF
    // Generated from the component: Voltage gen 4.POWER_PFA
    // Generated from the component: Voltage gen 4.POWER_PFB
    // Generated from the component: Voltage gen 4.POWER_PFC
    // Generated from the component: Voltage gen 4.POWER_Q
    // Generated from the component: Voltage gen 4.POWER_QA
    // Generated from the component: Voltage gen 4.POWER_QB
    // Generated from the component: Voltage gen 4.POWER_QC
    // Generated from the component: Voltage gen 4.POWER_S
    // Generated from the component: Voltage gen 4.POWER_SA
    // Generated from the component: Voltage gen 4.POWER_SB
    // Generated from the component: Voltage gen 4.POWER_SC
    // Generated from the component: Voltage gen 4.VAB_RMS
    // Generated from the component: Voltage gen 4.VAn_RMS
    // Generated from the component: Voltage gen 4.VBC_RMS
    // Generated from the component: Voltage gen 4.VBn_RMS
    // Generated from the component: Voltage gen 4.VCA_RMS
    // Generated from the component: Voltage gen 4.VCn_RMS
    // Generated from the component: Voltage gen 4.VLL_RMS
    // Generated from the component: Voltage gen 4.VLn_RMS
    // Generated from the component: Voltage gen 4.VN
    // Generated from the component: Voltage gen 4.VN_RMS
    // Generated from the component: Voltage gen 4.extra_output_bus
    _voltage_gen_4_extra_output_bus__out[0] = _voltage_gen_4_zero__out;
    _voltage_gen_4_extra_output_bus__out[1] = _voltage_gen_4_zero__out;
    _voltage_gen_4_extra_output_bus__out[2] = _voltage_gen_4_zero__out;
    _voltage_gen_4_extra_output_bus__out[3] = _voltage_gen_4_zero__out;
    _voltage_gen_4_extra_output_bus__out[4] = _voltage_gen_4_zero__out;
    _voltage_gen_4_extra_output_bus__out[5] = _voltage_gen_4_zero__out;
    _voltage_gen_4_extra_output_bus__out[6] = _voltage_gen_4_zero__out;
    _voltage_gen_4_extra_output_bus__out[7] = _voltage_gen_4_zero__out;
    _voltage_gen_4_extra_output_bus__out[8] = _voltage_gen_4_zero__out;
    _voltage_gen_4_extra_output_bus__out[9] = _voltage_gen_4_zero__out;
    _voltage_gen_4_extra_output_bus__out[10] = _voltage_gen_4_zero__out;
    _voltage_gen_4_extra_output_bus__out[11] = _voltage_gen_4_zero__out;
    // Generated from the component: Voltage gen 4.output_bus
    _voltage_gen_4_output_bus__out[0] = _voltage_gen_4_van_va1__out;
    _voltage_gen_4_output_bus__out[1] = _voltage_gen_4_vbn_va1__out;
    _voltage_gen_4_output_bus__out[2] = _voltage_gen_4_vcn_va1__out;
    _voltage_gen_4_output_bus__out[3] = _voltage_gen_4_vab_va1__out;
    _voltage_gen_4_output_bus__out[4] = _voltage_gen_4_vbc_va1__out;
    _voltage_gen_4_output_bus__out[5] = _voltage_gen_4_vca_va1__out;
    _voltage_gen_4_output_bus__out[6] = _voltage_gen_4_ia_ia1__out;
    _voltage_gen_4_output_bus__out[7] = _voltage_gen_4_ib_ia1__out;
    _voltage_gen_4_output_bus__out[8] = _voltage_gen_4_ic_ia1__out;
    _voltage_gen_4_output_bus__out[9] = _voltage_gen_4_zero__out;
    _voltage_gen_4_output_bus__out[10] = _voltage_gen_4_zero__out;
    _voltage_gen_4_output_bus__out[11] = _voltage_gen_4_zero__out;
    _voltage_gen_4_output_bus__out[12] = _voltage_gen_4_zero__out;
    _voltage_gen_4_output_bus__out[13] = _voltage_gen_4_zero__out;
    _voltage_gen_4_output_bus__out[14] = _voltage_gen_4_zero__out;
    _voltage_gen_4_output_bus__out[15] = _voltage_gen_4_zero__out;
    _voltage_gen_4_output_bus__out[16] = _voltage_gen_4_zero__out;
    _voltage_gen_4_output_bus__out[17] = _voltage_gen_4_zero__out;
    _voltage_gen_4_output_bus__out[18] = _voltage_gen_4_zero__out;
    _voltage_gen_4_output_bus__out[19] = _voltage_gen_4_zero__out;
    _voltage_gen_4_output_bus__out[20] = _voltage_gen_4_zero__out;
    _voltage_gen_4_output_bus__out[21] = _voltage_gen_4_zero__out;
    _voltage_gen_4_output_bus__out[22] = _voltage_gen_4_zero__out;
    _voltage_gen_4_output_bus__out[23] = _voltage_gen_4_zero__out;
    _voltage_gen_4_output_bus__out[24] = _voltage_gen_4_zero__out;
    _voltage_gen_4_output_bus__out[25] = _voltage_gen_4_zero__out;
    _voltage_gen_4_output_bus__out[26] = _voltage_gen_4_zero__out;
    _voltage_gen_4_output_bus__out[27] = _voltage_gen_4_zero__out;
    _voltage_gen_4_output_bus__out[28] = _voltage_gen_4_zero__out;
    _voltage_gen_4_output_bus__out[29] = _voltage_gen_4_zero__out;
    // Generated from the component: Three-phase at load 7 (area 1).TRMsin
    // Generated from the component: Three-phase at load 7 (area 1).I_RMS_calc.RMS
    _three_phase_at_load_7__area_1__i_rms_calc_rms__IN1 = _three_phase_at_load_7__area_1__ia_ia1__out;
    _three_phase_at_load_7__area_1__i_rms_calc_rms__IN2 = _three_phase_at_load_7__area_1__ib_ia1__out;
    _three_phase_at_load_7__area_1__i_rms_calc_rms__IN3 = _three_phase_at_load_7__area_1__ic_ia1__out;
    _three_phase_at_load_7__area_1__i_rms_calc_rms__dFract = _three_phase_at_load_7__area_1__meassm_mode_and_dfract__dFract;
    _three_phase_at_load_7__area_1__i_rms_calc_rms__mode = _three_phase_at_load_7__area_1__meassm_mode_and_dfract__mode;
    switch (_three_phase_at_load_7__area_1__i_rms_calc_rms__mode) {
    case 1:
        _three_phase_at_load_7__area_1__i_rms_calc_rms__rmsSum1 = 0.0;
        _three_phase_at_load_7__area_1__i_rms_calc_rms__rmsSum2 = 0.0;
        _three_phase_at_load_7__area_1__i_rms_calc_rms__rmsSum3 = 0.0;
        break ;
    case 2:
        _three_phase_at_load_7__area_1__i_rms_calc_rms__RMS1 = _three_phase_at_load_7__area_1__i_rms_calc_rms__IN1;
        _three_phase_at_load_7__area_1__i_rms_calc_rms__RMS2 = _three_phase_at_load_7__area_1__i_rms_calc_rms__IN2;
        _three_phase_at_load_7__area_1__i_rms_calc_rms__RMS3 = _three_phase_at_load_7__area_1__i_rms_calc_rms__IN3;
        break ;
    case 3:
        _three_phase_at_load_7__area_1__i_rms_calc_rms__rmsSum1 += _three_phase_at_load_7__area_1__i_rms_calc_rms__dFract * (_three_phase_at_load_7__area_1__i_rms_calc_rms__IN1 * _three_phase_at_load_7__area_1__i_rms_calc_rms__IN1);
        _three_phase_at_load_7__area_1__i_rms_calc_rms__rmsSum2 += _three_phase_at_load_7__area_1__i_rms_calc_rms__dFract * (_three_phase_at_load_7__area_1__i_rms_calc_rms__IN2 * _three_phase_at_load_7__area_1__i_rms_calc_rms__IN2);
        _three_phase_at_load_7__area_1__i_rms_calc_rms__rmsSum3 += _three_phase_at_load_7__area_1__i_rms_calc_rms__dFract * (_three_phase_at_load_7__area_1__i_rms_calc_rms__IN3 * _three_phase_at_load_7__area_1__i_rms_calc_rms__IN3);
        break ;
    case 4:
        _three_phase_at_load_7__area_1__i_rms_calc_rms__RMS1 = sqrt(_three_phase_at_load_7__area_1__i_rms_calc_rms__rmsSum1);
        _three_phase_at_load_7__area_1__i_rms_calc_rms__RMS2 = sqrt(_three_phase_at_load_7__area_1__i_rms_calc_rms__rmsSum2);
        _three_phase_at_load_7__area_1__i_rms_calc_rms__RMS3 = sqrt(_three_phase_at_load_7__area_1__i_rms_calc_rms__rmsSum3);
        break ;
    case 5:
        _three_phase_at_load_7__area_1__i_rms_calc_rms__RMS1 = fabs(_three_phase_at_load_7__area_1__i_rms_calc_rms__IN1);
        _three_phase_at_load_7__area_1__i_rms_calc_rms__RMS2 = fabs(_three_phase_at_load_7__area_1__i_rms_calc_rms__IN2);
        _three_phase_at_load_7__area_1__i_rms_calc_rms__RMS3 = fabs(_three_phase_at_load_7__area_1__i_rms_calc_rms__IN3);
        break ;
    }
    // Generated from the component: Three-phase at load 7 (area 1).VLL_RMS_calc.RMS
    _three_phase_at_load_7__area_1__vll_rms_calc_rms__IN1 = _three_phase_at_load_7__area_1__vab_va1__out;
    _three_phase_at_load_7__area_1__vll_rms_calc_rms__IN2 = _three_phase_at_load_7__area_1__vbc_va1__out;
    _three_phase_at_load_7__area_1__vll_rms_calc_rms__IN3 = _three_phase_at_load_7__area_1__vca_va1__out;
    _three_phase_at_load_7__area_1__vll_rms_calc_rms__dFract = _three_phase_at_load_7__area_1__meassm_mode_and_dfract__dFract;
    _three_phase_at_load_7__area_1__vll_rms_calc_rms__mode = _three_phase_at_load_7__area_1__meassm_mode_and_dfract__mode;
    switch (_three_phase_at_load_7__area_1__vll_rms_calc_rms__mode) {
    case 1:
        _three_phase_at_load_7__area_1__vll_rms_calc_rms__rmsSum1 = 0.0;
        _three_phase_at_load_7__area_1__vll_rms_calc_rms__rmsSum2 = 0.0;
        _three_phase_at_load_7__area_1__vll_rms_calc_rms__rmsSum3 = 0.0;
        break ;
    case 2:
        _three_phase_at_load_7__area_1__vll_rms_calc_rms__RMS1 = _three_phase_at_load_7__area_1__vll_rms_calc_rms__IN1;
        _three_phase_at_load_7__area_1__vll_rms_calc_rms__RMS2 = _three_phase_at_load_7__area_1__vll_rms_calc_rms__IN2;
        _three_phase_at_load_7__area_1__vll_rms_calc_rms__RMS3 = _three_phase_at_load_7__area_1__vll_rms_calc_rms__IN3;
        break ;
    case 3:
        _three_phase_at_load_7__area_1__vll_rms_calc_rms__rmsSum1 += _three_phase_at_load_7__area_1__vll_rms_calc_rms__dFract * (_three_phase_at_load_7__area_1__vll_rms_calc_rms__IN1 * _three_phase_at_load_7__area_1__vll_rms_calc_rms__IN1);
        _three_phase_at_load_7__area_1__vll_rms_calc_rms__rmsSum2 += _three_phase_at_load_7__area_1__vll_rms_calc_rms__dFract * (_three_phase_at_load_7__area_1__vll_rms_calc_rms__IN2 * _three_phase_at_load_7__area_1__vll_rms_calc_rms__IN2);
        _three_phase_at_load_7__area_1__vll_rms_calc_rms__rmsSum3 += _three_phase_at_load_7__area_1__vll_rms_calc_rms__dFract * (_three_phase_at_load_7__area_1__vll_rms_calc_rms__IN3 * _three_phase_at_load_7__area_1__vll_rms_calc_rms__IN3);
        break ;
    case 4:
        _three_phase_at_load_7__area_1__vll_rms_calc_rms__RMS1 = sqrt(_three_phase_at_load_7__area_1__vll_rms_calc_rms__rmsSum1);
        _three_phase_at_load_7__area_1__vll_rms_calc_rms__RMS2 = sqrt(_three_phase_at_load_7__area_1__vll_rms_calc_rms__rmsSum2);
        _three_phase_at_load_7__area_1__vll_rms_calc_rms__RMS3 = sqrt(_three_phase_at_load_7__area_1__vll_rms_calc_rms__rmsSum3);
        break ;
    case 5:
        _three_phase_at_load_7__area_1__vll_rms_calc_rms__RMS1 = fabs(_three_phase_at_load_7__area_1__vll_rms_calc_rms__IN1);
        _three_phase_at_load_7__area_1__vll_rms_calc_rms__RMS2 = fabs(_three_phase_at_load_7__area_1__vll_rms_calc_rms__IN2);
        _three_phase_at_load_7__area_1__vll_rms_calc_rms__RMS3 = fabs(_three_phase_at_load_7__area_1__vll_rms_calc_rms__IN3);
        break ;
    }
    // Generated from the component: Three-phase at load 7 (area 1).VLn_RMS_calc.RMS
    _three_phase_at_load_7__area_1__vln_rms_calc_rms__IN1 = _three_phase_at_load_7__area_1__van_va1__out;
    _three_phase_at_load_7__area_1__vln_rms_calc_rms__IN2 = _three_phase_at_load_7__area_1__vbn_va1__out;
    _three_phase_at_load_7__area_1__vln_rms_calc_rms__IN3 = _three_phase_at_load_7__area_1__vcn_va1__out;
    _three_phase_at_load_7__area_1__vln_rms_calc_rms__dFract = _three_phase_at_load_7__area_1__meassm_mode_and_dfract__dFract;
    _three_phase_at_load_7__area_1__vln_rms_calc_rms__mode = _three_phase_at_load_7__area_1__meassm_mode_and_dfract__mode;
    switch (_three_phase_at_load_7__area_1__vln_rms_calc_rms__mode) {
    case 1:
        _three_phase_at_load_7__area_1__vln_rms_calc_rms__rmsSum1 = 0.0;
        _three_phase_at_load_7__area_1__vln_rms_calc_rms__rmsSum2 = 0.0;
        _three_phase_at_load_7__area_1__vln_rms_calc_rms__rmsSum3 = 0.0;
        break ;
    case 2:
        _three_phase_at_load_7__area_1__vln_rms_calc_rms__RMS1 = _three_phase_at_load_7__area_1__vln_rms_calc_rms__IN1;
        _three_phase_at_load_7__area_1__vln_rms_calc_rms__RMS2 = _three_phase_at_load_7__area_1__vln_rms_calc_rms__IN2;
        _three_phase_at_load_7__area_1__vln_rms_calc_rms__RMS3 = _three_phase_at_load_7__area_1__vln_rms_calc_rms__IN3;
        break ;
    case 3:
        _three_phase_at_load_7__area_1__vln_rms_calc_rms__rmsSum1 += _three_phase_at_load_7__area_1__vln_rms_calc_rms__dFract * (_three_phase_at_load_7__area_1__vln_rms_calc_rms__IN1 * _three_phase_at_load_7__area_1__vln_rms_calc_rms__IN1);
        _three_phase_at_load_7__area_1__vln_rms_calc_rms__rmsSum2 += _three_phase_at_load_7__area_1__vln_rms_calc_rms__dFract * (_three_phase_at_load_7__area_1__vln_rms_calc_rms__IN2 * _three_phase_at_load_7__area_1__vln_rms_calc_rms__IN2);
        _three_phase_at_load_7__area_1__vln_rms_calc_rms__rmsSum3 += _three_phase_at_load_7__area_1__vln_rms_calc_rms__dFract * (_three_phase_at_load_7__area_1__vln_rms_calc_rms__IN3 * _three_phase_at_load_7__area_1__vln_rms_calc_rms__IN3);
        break ;
    case 4:
        _three_phase_at_load_7__area_1__vln_rms_calc_rms__RMS1 = sqrt(_three_phase_at_load_7__area_1__vln_rms_calc_rms__rmsSum1);
        _three_phase_at_load_7__area_1__vln_rms_calc_rms__RMS2 = sqrt(_three_phase_at_load_7__area_1__vln_rms_calc_rms__rmsSum2);
        _three_phase_at_load_7__area_1__vln_rms_calc_rms__RMS3 = sqrt(_three_phase_at_load_7__area_1__vln_rms_calc_rms__rmsSum3);
        break ;
    case 5:
        _three_phase_at_load_7__area_1__vln_rms_calc_rms__RMS1 = fabs(_three_phase_at_load_7__area_1__vln_rms_calc_rms__IN1);
        _three_phase_at_load_7__area_1__vln_rms_calc_rms__RMS2 = fabs(_three_phase_at_load_7__area_1__vln_rms_calc_rms__IN2);
        _three_phase_at_load_7__area_1__vln_rms_calc_rms__RMS3 = fabs(_three_phase_at_load_7__area_1__vln_rms_calc_rms__IN3);
        break ;
    }
    // Generated from the component: Three-phase at load 7 (area 1).PLL.abc to dq.alpha beta to dq
    _three_phase_at_load_7__area_1__pll_abc_to_dq_alpha_beta_to_dq__k1 = cos(_three_phase_at_load_7__area_1__pll_unit_delay1__out);
    _three_phase_at_load_7__area_1__pll_abc_to_dq_alpha_beta_to_dq__k2 = sin(_three_phase_at_load_7__area_1__pll_unit_delay1__out);
    _three_phase_at_load_7__area_1__pll_abc_to_dq_alpha_beta_to_dq__d = _three_phase_at_load_7__area_1__pll_abc_to_dq_alpha_beta_to_dq__k2 * _three_phase_at_load_7__area_1__pll_abc_to_dq_abc_to_alpha_beta__alpha - _three_phase_at_load_7__area_1__pll_abc_to_dq_alpha_beta_to_dq__k1 * _three_phase_at_load_7__area_1__pll_abc_to_dq_abc_to_alpha_beta__beta;
    _three_phase_at_load_7__area_1__pll_abc_to_dq_alpha_beta_to_dq__q = _three_phase_at_load_7__area_1__pll_abc_to_dq_alpha_beta_to_dq__k1 * _three_phase_at_load_7__area_1__pll_abc_to_dq_abc_to_alpha_beta__alpha + _three_phase_at_load_7__area_1__pll_abc_to_dq_alpha_beta_to_dq__k2 * _three_phase_at_load_7__area_1__pll_abc_to_dq_abc_to_alpha_beta__beta;
    // Generated from the component: Three-phase at load 7 (area 1).TRMz
    // Generated from the component: Three-phase at load 8 (mid).TRMsin
    // Generated from the component: Three-phase at load 8 (mid).I_RMS_calc.RMS
    _three_phase_at_load_8__mid__i_rms_calc_rms__IN1 = _three_phase_at_load_8__mid__ia_ia1__out;
    _three_phase_at_load_8__mid__i_rms_calc_rms__IN2 = _three_phase_at_load_8__mid__ib_ia1__out;
    _three_phase_at_load_8__mid__i_rms_calc_rms__IN3 = _three_phase_at_load_8__mid__ic_ia1__out;
    _three_phase_at_load_8__mid__i_rms_calc_rms__dFract = _three_phase_at_load_8__mid__meassm_mode_and_dfract__dFract;
    _three_phase_at_load_8__mid__i_rms_calc_rms__mode = _three_phase_at_load_8__mid__meassm_mode_and_dfract__mode;
    switch (_three_phase_at_load_8__mid__i_rms_calc_rms__mode) {
    case 1:
        _three_phase_at_load_8__mid__i_rms_calc_rms__rmsSum1 = 0.0;
        _three_phase_at_load_8__mid__i_rms_calc_rms__rmsSum2 = 0.0;
        _three_phase_at_load_8__mid__i_rms_calc_rms__rmsSum3 = 0.0;
        break ;
    case 2:
        _three_phase_at_load_8__mid__i_rms_calc_rms__RMS1 = _three_phase_at_load_8__mid__i_rms_calc_rms__IN1;
        _three_phase_at_load_8__mid__i_rms_calc_rms__RMS2 = _three_phase_at_load_8__mid__i_rms_calc_rms__IN2;
        _three_phase_at_load_8__mid__i_rms_calc_rms__RMS3 = _three_phase_at_load_8__mid__i_rms_calc_rms__IN3;
        break ;
    case 3:
        _three_phase_at_load_8__mid__i_rms_calc_rms__rmsSum1 += _three_phase_at_load_8__mid__i_rms_calc_rms__dFract * (_three_phase_at_load_8__mid__i_rms_calc_rms__IN1 * _three_phase_at_load_8__mid__i_rms_calc_rms__IN1);
        _three_phase_at_load_8__mid__i_rms_calc_rms__rmsSum2 += _three_phase_at_load_8__mid__i_rms_calc_rms__dFract * (_three_phase_at_load_8__mid__i_rms_calc_rms__IN2 * _three_phase_at_load_8__mid__i_rms_calc_rms__IN2);
        _three_phase_at_load_8__mid__i_rms_calc_rms__rmsSum3 += _three_phase_at_load_8__mid__i_rms_calc_rms__dFract * (_three_phase_at_load_8__mid__i_rms_calc_rms__IN3 * _three_phase_at_load_8__mid__i_rms_calc_rms__IN3);
        break ;
    case 4:
        _three_phase_at_load_8__mid__i_rms_calc_rms__RMS1 = sqrt(_three_phase_at_load_8__mid__i_rms_calc_rms__rmsSum1);
        _three_phase_at_load_8__mid__i_rms_calc_rms__RMS2 = sqrt(_three_phase_at_load_8__mid__i_rms_calc_rms__rmsSum2);
        _three_phase_at_load_8__mid__i_rms_calc_rms__RMS3 = sqrt(_three_phase_at_load_8__mid__i_rms_calc_rms__rmsSum3);
        break ;
    case 5:
        _three_phase_at_load_8__mid__i_rms_calc_rms__RMS1 = fabs(_three_phase_at_load_8__mid__i_rms_calc_rms__IN1);
        _three_phase_at_load_8__mid__i_rms_calc_rms__RMS2 = fabs(_three_phase_at_load_8__mid__i_rms_calc_rms__IN2);
        _three_phase_at_load_8__mid__i_rms_calc_rms__RMS3 = fabs(_three_phase_at_load_8__mid__i_rms_calc_rms__IN3);
        break ;
    }
    // Generated from the component: Three-phase at load 8 (mid).VLn_RMS_calc.RMS
    _three_phase_at_load_8__mid__vln_rms_calc_rms__IN1 = _three_phase_at_load_8__mid__van_va1__out;
    _three_phase_at_load_8__mid__vln_rms_calc_rms__IN2 = _three_phase_at_load_8__mid__vbn_va1__out;
    _three_phase_at_load_8__mid__vln_rms_calc_rms__IN3 = _three_phase_at_load_8__mid__vcn_va1__out;
    _three_phase_at_load_8__mid__vln_rms_calc_rms__dFract = _three_phase_at_load_8__mid__meassm_mode_and_dfract__dFract;
    _three_phase_at_load_8__mid__vln_rms_calc_rms__mode = _three_phase_at_load_8__mid__meassm_mode_and_dfract__mode;
    switch (_three_phase_at_load_8__mid__vln_rms_calc_rms__mode) {
    case 1:
        _three_phase_at_load_8__mid__vln_rms_calc_rms__rmsSum1 = 0.0;
        _three_phase_at_load_8__mid__vln_rms_calc_rms__rmsSum2 = 0.0;
        _three_phase_at_load_8__mid__vln_rms_calc_rms__rmsSum3 = 0.0;
        break ;
    case 2:
        _three_phase_at_load_8__mid__vln_rms_calc_rms__RMS1 = _three_phase_at_load_8__mid__vln_rms_calc_rms__IN1;
        _three_phase_at_load_8__mid__vln_rms_calc_rms__RMS2 = _three_phase_at_load_8__mid__vln_rms_calc_rms__IN2;
        _three_phase_at_load_8__mid__vln_rms_calc_rms__RMS3 = _three_phase_at_load_8__mid__vln_rms_calc_rms__IN3;
        break ;
    case 3:
        _three_phase_at_load_8__mid__vln_rms_calc_rms__rmsSum1 += _three_phase_at_load_8__mid__vln_rms_calc_rms__dFract * (_three_phase_at_load_8__mid__vln_rms_calc_rms__IN1 * _three_phase_at_load_8__mid__vln_rms_calc_rms__IN1);
        _three_phase_at_load_8__mid__vln_rms_calc_rms__rmsSum2 += _three_phase_at_load_8__mid__vln_rms_calc_rms__dFract * (_three_phase_at_load_8__mid__vln_rms_calc_rms__IN2 * _three_phase_at_load_8__mid__vln_rms_calc_rms__IN2);
        _three_phase_at_load_8__mid__vln_rms_calc_rms__rmsSum3 += _three_phase_at_load_8__mid__vln_rms_calc_rms__dFract * (_three_phase_at_load_8__mid__vln_rms_calc_rms__IN3 * _three_phase_at_load_8__mid__vln_rms_calc_rms__IN3);
        break ;
    case 4:
        _three_phase_at_load_8__mid__vln_rms_calc_rms__RMS1 = sqrt(_three_phase_at_load_8__mid__vln_rms_calc_rms__rmsSum1);
        _three_phase_at_load_8__mid__vln_rms_calc_rms__RMS2 = sqrt(_three_phase_at_load_8__mid__vln_rms_calc_rms__rmsSum2);
        _three_phase_at_load_8__mid__vln_rms_calc_rms__RMS3 = sqrt(_three_phase_at_load_8__mid__vln_rms_calc_rms__rmsSum3);
        break ;
    case 5:
        _three_phase_at_load_8__mid__vln_rms_calc_rms__RMS1 = fabs(_three_phase_at_load_8__mid__vln_rms_calc_rms__IN1);
        _three_phase_at_load_8__mid__vln_rms_calc_rms__RMS2 = fabs(_three_phase_at_load_8__mid__vln_rms_calc_rms__IN2);
        _three_phase_at_load_8__mid__vln_rms_calc_rms__RMS3 = fabs(_three_phase_at_load_8__mid__vln_rms_calc_rms__IN3);
        break ;
    }
    // Generated from the component: Three-phase at load 8 (mid).PLL.abc to dq.alpha beta to dq
    _three_phase_at_load_8__mid__pll_abc_to_dq_alpha_beta_to_dq__k1 = cos(_three_phase_at_load_8__mid__pll_unit_delay1__out);
    _three_phase_at_load_8__mid__pll_abc_to_dq_alpha_beta_to_dq__k2 = sin(_three_phase_at_load_8__mid__pll_unit_delay1__out);
    _three_phase_at_load_8__mid__pll_abc_to_dq_alpha_beta_to_dq__d = _three_phase_at_load_8__mid__pll_abc_to_dq_alpha_beta_to_dq__k2 * _three_phase_at_load_8__mid__pll_abc_to_dq_abc_to_alpha_beta__alpha - _three_phase_at_load_8__mid__pll_abc_to_dq_alpha_beta_to_dq__k1 * _three_phase_at_load_8__mid__pll_abc_to_dq_abc_to_alpha_beta__beta;
    _three_phase_at_load_8__mid__pll_abc_to_dq_alpha_beta_to_dq__q = _three_phase_at_load_8__mid__pll_abc_to_dq_alpha_beta_to_dq__k1 * _three_phase_at_load_8__mid__pll_abc_to_dq_abc_to_alpha_beta__alpha + _three_phase_at_load_8__mid__pll_abc_to_dq_alpha_beta_to_dq__k2 * _three_phase_at_load_8__mid__pll_abc_to_dq_abc_to_alpha_beta__beta;
    // Generated from the component: Three-phase at load 8 (mid).TRMz
    // Generated from the component: Three-phase at load 9 (area 2).TRMsin
    // Generated from the component: Three-phase at load 9 (area 2).I_RMS_calc.RMS
    _three_phase_at_load_9__area_2__i_rms_calc_rms__IN1 = _three_phase_at_load_9__area_2__ia_ia1__out;
    _three_phase_at_load_9__area_2__i_rms_calc_rms__IN2 = _three_phase_at_load_9__area_2__ib_ia1__out;
    _three_phase_at_load_9__area_2__i_rms_calc_rms__IN3 = _three_phase_at_load_9__area_2__ic_ia1__out;
    _three_phase_at_load_9__area_2__i_rms_calc_rms__dFract = _three_phase_at_load_9__area_2__meassm_mode_and_dfract__dFract;
    _three_phase_at_load_9__area_2__i_rms_calc_rms__mode = _three_phase_at_load_9__area_2__meassm_mode_and_dfract__mode;
    switch (_three_phase_at_load_9__area_2__i_rms_calc_rms__mode) {
    case 1:
        _three_phase_at_load_9__area_2__i_rms_calc_rms__rmsSum1 = 0.0;
        _three_phase_at_load_9__area_2__i_rms_calc_rms__rmsSum2 = 0.0;
        _three_phase_at_load_9__area_2__i_rms_calc_rms__rmsSum3 = 0.0;
        break ;
    case 2:
        _three_phase_at_load_9__area_2__i_rms_calc_rms__RMS1 = _three_phase_at_load_9__area_2__i_rms_calc_rms__IN1;
        _three_phase_at_load_9__area_2__i_rms_calc_rms__RMS2 = _three_phase_at_load_9__area_2__i_rms_calc_rms__IN2;
        _three_phase_at_load_9__area_2__i_rms_calc_rms__RMS3 = _three_phase_at_load_9__area_2__i_rms_calc_rms__IN3;
        break ;
    case 3:
        _three_phase_at_load_9__area_2__i_rms_calc_rms__rmsSum1 += _three_phase_at_load_9__area_2__i_rms_calc_rms__dFract * (_three_phase_at_load_9__area_2__i_rms_calc_rms__IN1 * _three_phase_at_load_9__area_2__i_rms_calc_rms__IN1);
        _three_phase_at_load_9__area_2__i_rms_calc_rms__rmsSum2 += _three_phase_at_load_9__area_2__i_rms_calc_rms__dFract * (_three_phase_at_load_9__area_2__i_rms_calc_rms__IN2 * _three_phase_at_load_9__area_2__i_rms_calc_rms__IN2);
        _three_phase_at_load_9__area_2__i_rms_calc_rms__rmsSum3 += _three_phase_at_load_9__area_2__i_rms_calc_rms__dFract * (_three_phase_at_load_9__area_2__i_rms_calc_rms__IN3 * _three_phase_at_load_9__area_2__i_rms_calc_rms__IN3);
        break ;
    case 4:
        _three_phase_at_load_9__area_2__i_rms_calc_rms__RMS1 = sqrt(_three_phase_at_load_9__area_2__i_rms_calc_rms__rmsSum1);
        _three_phase_at_load_9__area_2__i_rms_calc_rms__RMS2 = sqrt(_three_phase_at_load_9__area_2__i_rms_calc_rms__rmsSum2);
        _three_phase_at_load_9__area_2__i_rms_calc_rms__RMS3 = sqrt(_three_phase_at_load_9__area_2__i_rms_calc_rms__rmsSum3);
        break ;
    case 5:
        _three_phase_at_load_9__area_2__i_rms_calc_rms__RMS1 = fabs(_three_phase_at_load_9__area_2__i_rms_calc_rms__IN1);
        _three_phase_at_load_9__area_2__i_rms_calc_rms__RMS2 = fabs(_three_phase_at_load_9__area_2__i_rms_calc_rms__IN2);
        _three_phase_at_load_9__area_2__i_rms_calc_rms__RMS3 = fabs(_three_phase_at_load_9__area_2__i_rms_calc_rms__IN3);
        break ;
    }
    // Generated from the component: Three-phase at load 9 (area 2).VLL_RMS_calc.RMS
    _three_phase_at_load_9__area_2__vll_rms_calc_rms__IN1 = _three_phase_at_load_9__area_2__vab_va1__out;
    _three_phase_at_load_9__area_2__vll_rms_calc_rms__IN2 = _three_phase_at_load_9__area_2__vbc_va1__out;
    _three_phase_at_load_9__area_2__vll_rms_calc_rms__IN3 = _three_phase_at_load_9__area_2__vca_va1__out;
    _three_phase_at_load_9__area_2__vll_rms_calc_rms__dFract = _three_phase_at_load_9__area_2__meassm_mode_and_dfract__dFract;
    _three_phase_at_load_9__area_2__vll_rms_calc_rms__mode = _three_phase_at_load_9__area_2__meassm_mode_and_dfract__mode;
    switch (_three_phase_at_load_9__area_2__vll_rms_calc_rms__mode) {
    case 1:
        _three_phase_at_load_9__area_2__vll_rms_calc_rms__rmsSum1 = 0.0;
        _three_phase_at_load_9__area_2__vll_rms_calc_rms__rmsSum2 = 0.0;
        _three_phase_at_load_9__area_2__vll_rms_calc_rms__rmsSum3 = 0.0;
        break ;
    case 2:
        _three_phase_at_load_9__area_2__vll_rms_calc_rms__RMS1 = _three_phase_at_load_9__area_2__vll_rms_calc_rms__IN1;
        _three_phase_at_load_9__area_2__vll_rms_calc_rms__RMS2 = _three_phase_at_load_9__area_2__vll_rms_calc_rms__IN2;
        _three_phase_at_load_9__area_2__vll_rms_calc_rms__RMS3 = _three_phase_at_load_9__area_2__vll_rms_calc_rms__IN3;
        break ;
    case 3:
        _three_phase_at_load_9__area_2__vll_rms_calc_rms__rmsSum1 += _three_phase_at_load_9__area_2__vll_rms_calc_rms__dFract * (_three_phase_at_load_9__area_2__vll_rms_calc_rms__IN1 * _three_phase_at_load_9__area_2__vll_rms_calc_rms__IN1);
        _three_phase_at_load_9__area_2__vll_rms_calc_rms__rmsSum2 += _three_phase_at_load_9__area_2__vll_rms_calc_rms__dFract * (_three_phase_at_load_9__area_2__vll_rms_calc_rms__IN2 * _three_phase_at_load_9__area_2__vll_rms_calc_rms__IN2);
        _three_phase_at_load_9__area_2__vll_rms_calc_rms__rmsSum3 += _three_phase_at_load_9__area_2__vll_rms_calc_rms__dFract * (_three_phase_at_load_9__area_2__vll_rms_calc_rms__IN3 * _three_phase_at_load_9__area_2__vll_rms_calc_rms__IN3);
        break ;
    case 4:
        _three_phase_at_load_9__area_2__vll_rms_calc_rms__RMS1 = sqrt(_three_phase_at_load_9__area_2__vll_rms_calc_rms__rmsSum1);
        _three_phase_at_load_9__area_2__vll_rms_calc_rms__RMS2 = sqrt(_three_phase_at_load_9__area_2__vll_rms_calc_rms__rmsSum2);
        _three_phase_at_load_9__area_2__vll_rms_calc_rms__RMS3 = sqrt(_three_phase_at_load_9__area_2__vll_rms_calc_rms__rmsSum3);
        break ;
    case 5:
        _three_phase_at_load_9__area_2__vll_rms_calc_rms__RMS1 = fabs(_three_phase_at_load_9__area_2__vll_rms_calc_rms__IN1);
        _three_phase_at_load_9__area_2__vll_rms_calc_rms__RMS2 = fabs(_three_phase_at_load_9__area_2__vll_rms_calc_rms__IN2);
        _three_phase_at_load_9__area_2__vll_rms_calc_rms__RMS3 = fabs(_three_phase_at_load_9__area_2__vll_rms_calc_rms__IN3);
        break ;
    }
    // Generated from the component: Three-phase at load 9 (area 2).VLn_RMS_calc.RMS
    _three_phase_at_load_9__area_2__vln_rms_calc_rms__IN1 = _three_phase_at_load_9__area_2__van_va1__out;
    _three_phase_at_load_9__area_2__vln_rms_calc_rms__IN2 = _three_phase_at_load_9__area_2__vbn_va1__out;
    _three_phase_at_load_9__area_2__vln_rms_calc_rms__IN3 = _three_phase_at_load_9__area_2__vcn_va1__out;
    _three_phase_at_load_9__area_2__vln_rms_calc_rms__dFract = _three_phase_at_load_9__area_2__meassm_mode_and_dfract__dFract;
    _three_phase_at_load_9__area_2__vln_rms_calc_rms__mode = _three_phase_at_load_9__area_2__meassm_mode_and_dfract__mode;
    switch (_three_phase_at_load_9__area_2__vln_rms_calc_rms__mode) {
    case 1:
        _three_phase_at_load_9__area_2__vln_rms_calc_rms__rmsSum1 = 0.0;
        _three_phase_at_load_9__area_2__vln_rms_calc_rms__rmsSum2 = 0.0;
        _three_phase_at_load_9__area_2__vln_rms_calc_rms__rmsSum3 = 0.0;
        break ;
    case 2:
        _three_phase_at_load_9__area_2__vln_rms_calc_rms__RMS1 = _three_phase_at_load_9__area_2__vln_rms_calc_rms__IN1;
        _three_phase_at_load_9__area_2__vln_rms_calc_rms__RMS2 = _three_phase_at_load_9__area_2__vln_rms_calc_rms__IN2;
        _three_phase_at_load_9__area_2__vln_rms_calc_rms__RMS3 = _three_phase_at_load_9__area_2__vln_rms_calc_rms__IN3;
        break ;
    case 3:
        _three_phase_at_load_9__area_2__vln_rms_calc_rms__rmsSum1 += _three_phase_at_load_9__area_2__vln_rms_calc_rms__dFract * (_three_phase_at_load_9__area_2__vln_rms_calc_rms__IN1 * _three_phase_at_load_9__area_2__vln_rms_calc_rms__IN1);
        _three_phase_at_load_9__area_2__vln_rms_calc_rms__rmsSum2 += _three_phase_at_load_9__area_2__vln_rms_calc_rms__dFract * (_three_phase_at_load_9__area_2__vln_rms_calc_rms__IN2 * _three_phase_at_load_9__area_2__vln_rms_calc_rms__IN2);
        _three_phase_at_load_9__area_2__vln_rms_calc_rms__rmsSum3 += _three_phase_at_load_9__area_2__vln_rms_calc_rms__dFract * (_three_phase_at_load_9__area_2__vln_rms_calc_rms__IN3 * _three_phase_at_load_9__area_2__vln_rms_calc_rms__IN3);
        break ;
    case 4:
        _three_phase_at_load_9__area_2__vln_rms_calc_rms__RMS1 = sqrt(_three_phase_at_load_9__area_2__vln_rms_calc_rms__rmsSum1);
        _three_phase_at_load_9__area_2__vln_rms_calc_rms__RMS2 = sqrt(_three_phase_at_load_9__area_2__vln_rms_calc_rms__rmsSum2);
        _three_phase_at_load_9__area_2__vln_rms_calc_rms__RMS3 = sqrt(_three_phase_at_load_9__area_2__vln_rms_calc_rms__rmsSum3);
        break ;
    case 5:
        _three_phase_at_load_9__area_2__vln_rms_calc_rms__RMS1 = fabs(_three_phase_at_load_9__area_2__vln_rms_calc_rms__IN1);
        _three_phase_at_load_9__area_2__vln_rms_calc_rms__RMS2 = fabs(_three_phase_at_load_9__area_2__vln_rms_calc_rms__IN2);
        _three_phase_at_load_9__area_2__vln_rms_calc_rms__RMS3 = fabs(_three_phase_at_load_9__area_2__vln_rms_calc_rms__IN3);
        break ;
    }
    // Generated from the component: Three-phase at load 9 (area 2).PLL.abc to dq.alpha beta to dq
    _three_phase_at_load_9__area_2__pll_abc_to_dq_alpha_beta_to_dq__k1 = cos(_three_phase_at_load_9__area_2__pll_unit_delay1__out);
    _three_phase_at_load_9__area_2__pll_abc_to_dq_alpha_beta_to_dq__k2 = sin(_three_phase_at_load_9__area_2__pll_unit_delay1__out);
    _three_phase_at_load_9__area_2__pll_abc_to_dq_alpha_beta_to_dq__d = _three_phase_at_load_9__area_2__pll_abc_to_dq_alpha_beta_to_dq__k2 * _three_phase_at_load_9__area_2__pll_abc_to_dq_abc_to_alpha_beta__alpha - _three_phase_at_load_9__area_2__pll_abc_to_dq_alpha_beta_to_dq__k1 * _three_phase_at_load_9__area_2__pll_abc_to_dq_abc_to_alpha_beta__beta;
    _three_phase_at_load_9__area_2__pll_abc_to_dq_alpha_beta_to_dq__q = _three_phase_at_load_9__area_2__pll_abc_to_dq_alpha_beta_to_dq__k1 * _three_phase_at_load_9__area_2__pll_abc_to_dq_abc_to_alpha_beta__alpha + _three_phase_at_load_9__area_2__pll_abc_to_dq_alpha_beta_to_dq__k2 * _three_phase_at_load_9__area_2__pll_abc_to_dq_abc_to_alpha_beta__beta;
    // Generated from the component: Three-phase at load 9 (area 2).TRMz
    // Generated from the component: Voltage gen 1.extra_out
    // Generated from the component: Voltage gen 2.extra_out
    // Generated from the component: Voltage gen 3.extra_out
    // Generated from the component: Voltage gen 4.extra_out
    // Generated from the component: Three-phase at load 7 (area 1).IA_RMS
    HIL_OutAO(0x4081, (float)_three_phase_at_load_7__area_1__i_rms_calc_rms__RMS1);
    // Generated from the component: Three-phase at load 7 (area 1).IB_RMS
    HIL_OutAO(0x4082, (float)_three_phase_at_load_7__area_1__i_rms_calc_rms__RMS2);
    // Generated from the component: Three-phase at load 7 (area 1).IC_RMS
    HIL_OutAO(0x4083, (float)_three_phase_at_load_7__area_1__i_rms_calc_rms__RMS3);
    // Generated from the component: Three-phase at load 7 (area 1).VAB_RMS
    HIL_OutAO(0x4094, (float)_three_phase_at_load_7__area_1__vll_rms_calc_rms__RMS1);
    // Generated from the component: Three-phase at load 7 (area 1).VBC_RMS
    HIL_OutAO(0x4096, (float)_three_phase_at_load_7__area_1__vll_rms_calc_rms__RMS2);
    // Generated from the component: Three-phase at load 7 (area 1).VCA_RMS
    HIL_OutAO(0x4098, (float)_three_phase_at_load_7__area_1__vll_rms_calc_rms__RMS3);
    // Generated from the component: Three-phase at load 7 (area 1).Power Meter.POWER
    _three_phase_at_load_7__area_1__power_meter_power__Ia = _three_phase_at_load_7__area_1__ia_ia1__out;
    _three_phase_at_load_7__area_1__power_meter_power__Ib = _three_phase_at_load_7__area_1__ib_ia1__out;
    _three_phase_at_load_7__area_1__power_meter_power__Ic = _three_phase_at_load_7__area_1__ic_ia1__out;
    _three_phase_at_load_7__area_1__power_meter_power__IrmsA = _three_phase_at_load_7__area_1__i_rms_calc_rms__RMS1;
    _three_phase_at_load_7__area_1__power_meter_power__IrmsB = _three_phase_at_load_7__area_1__i_rms_calc_rms__RMS2;
    _three_phase_at_load_7__area_1__power_meter_power__IrmsC = _three_phase_at_load_7__area_1__i_rms_calc_rms__RMS3;
    _three_phase_at_load_7__area_1__power_meter_power__Va = _three_phase_at_load_7__area_1__van_va1__out;
    _three_phase_at_load_7__area_1__power_meter_power__Vb = _three_phase_at_load_7__area_1__vbn_va1__out;
    _three_phase_at_load_7__area_1__power_meter_power__Vc = _three_phase_at_load_7__area_1__vcn_va1__out;
    _three_phase_at_load_7__area_1__power_meter_power__VrmsA = _three_phase_at_load_7__area_1__vln_rms_calc_rms__RMS1;
    _three_phase_at_load_7__area_1__power_meter_power__VrmsB = _three_phase_at_load_7__area_1__vln_rms_calc_rms__RMS2;
    _three_phase_at_load_7__area_1__power_meter_power__VrmsC = _three_phase_at_load_7__area_1__vln_rms_calc_rms__RMS3;
    _three_phase_at_load_7__area_1__power_meter_power__dFract = _three_phase_at_load_7__area_1__meassm_mode_and_dfract__dFract;
    _three_phase_at_load_7__area_1__power_meter_power__mode = _three_phase_at_load_7__area_1__meassm_mode_and_dfract__mode;
    _three_phase_at_load_7__area_1__power_meter_power__submode = _three_phase_at_load_7__area_1__meassm_mode_and_dfract__submode;
    switch (_three_phase_at_load_7__area_1__power_meter_power__mode) {
    case 1:
        _three_phase_at_load_7__area_1__power_meter_power__VevenSumA = 0.0;
        _three_phase_at_load_7__area_1__power_meter_power__VoddSumA = 0.0;
        _three_phase_at_load_7__area_1__power_meter_power__VevenSumB = 0.0;
        _three_phase_at_load_7__area_1__power_meter_power__VoddSumB = 0.0;
        _three_phase_at_load_7__area_1__power_meter_power__VevenSumC = 0.0;
        _three_phase_at_load_7__area_1__power_meter_power__VoddSumC = 0.0;
        _three_phase_at_load_7__area_1__power_meter_power__IevenSumA = 0.0;
        _three_phase_at_load_7__area_1__power_meter_power__IoddSumA = 0.0;
        _three_phase_at_load_7__area_1__power_meter_power__IevenSumB = 0.0;
        _three_phase_at_load_7__area_1__power_meter_power__IoddSumB = 0.0;
        _three_phase_at_load_7__area_1__power_meter_power__IevenSumC = 0.0;
        _three_phase_at_load_7__area_1__power_meter_power__IoddSumC = 0.0;
        _three_phase_at_load_7__area_1__power_meter_power__PsumA = 0.0;
        _three_phase_at_load_7__area_1__power_meter_power__PsumB = 0.0;
        _three_phase_at_load_7__area_1__power_meter_power__PsumC = 0.0;
        break ;
    case 2:
        _three_phase_at_load_7__area_1__power_meter_power__Pa = _three_phase_at_load_7__area_1__power_meter_power__Va * _three_phase_at_load_7__area_1__power_meter_power__Ia;
        _three_phase_at_load_7__area_1__power_meter_power__Pb = _three_phase_at_load_7__area_1__power_meter_power__Vb * _three_phase_at_load_7__area_1__power_meter_power__Ib;
        _three_phase_at_load_7__area_1__power_meter_power__Pc = _three_phase_at_load_7__area_1__power_meter_power__Vc * _three_phase_at_load_7__area_1__power_meter_power__Ic;
        _three_phase_at_load_7__area_1__power_meter_power__P = _three_phase_at_load_7__area_1__power_meter_power__Pa + _three_phase_at_load_7__area_1__power_meter_power__Pb + _three_phase_at_load_7__area_1__power_meter_power__Pc;
        _three_phase_at_load_7__area_1__power_meter_power__Qa = 0;
        _three_phase_at_load_7__area_1__power_meter_power__Qb = 0;
        _three_phase_at_load_7__area_1__power_meter_power__Qc = 0;
        _three_phase_at_load_7__area_1__power_meter_power__Q = _three_phase_at_load_7__area_1__power_meter_power__Qa + _three_phase_at_load_7__area_1__power_meter_power__Qb + _three_phase_at_load_7__area_1__power_meter_power__Qc;
        _three_phase_at_load_7__area_1__power_meter_power__Sa = _three_phase_at_load_7__area_1__power_meter_power__Pa;
        _three_phase_at_load_7__area_1__power_meter_power__Sb = _three_phase_at_load_7__area_1__power_meter_power__Pb;
        _three_phase_at_load_7__area_1__power_meter_power__Sc = _three_phase_at_load_7__area_1__power_meter_power__Pc;
        _three_phase_at_load_7__area_1__power_meter_power__S = _three_phase_at_load_7__area_1__power_meter_power__Sa + _three_phase_at_load_7__area_1__power_meter_power__Sb + _three_phase_at_load_7__area_1__power_meter_power__Sc;
        _three_phase_at_load_7__area_1__power_meter_power__PFa = 1.0;
        _three_phase_at_load_7__area_1__power_meter_power__PFb = 1.0;
        _three_phase_at_load_7__area_1__power_meter_power__PFc = 1.0;
        _three_phase_at_load_7__area_1__power_meter_power__PF = 1.0;
        break ;
    case 3:
        _three_phase_at_load_7__area_1__power_meter_power__PsumA += _three_phase_at_load_7__area_1__power_meter_power__dFract * (_three_phase_at_load_7__area_1__power_meter_power__Va * _three_phase_at_load_7__area_1__power_meter_power__Ia);
        _three_phase_at_load_7__area_1__power_meter_power__PsumB += _three_phase_at_load_7__area_1__power_meter_power__dFract * (_three_phase_at_load_7__area_1__power_meter_power__Vb * _three_phase_at_load_7__area_1__power_meter_power__Ib);
        _three_phase_at_load_7__area_1__power_meter_power__PsumC += _three_phase_at_load_7__area_1__power_meter_power__dFract * (_three_phase_at_load_7__area_1__power_meter_power__Vc * _three_phase_at_load_7__area_1__power_meter_power__Ic);
        switch (_three_phase_at_load_7__area_1__power_meter_power__submode) {
        case 1:
            _three_phase_at_load_7__area_1__power_meter_power__VevenSumA += _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Va;
            _three_phase_at_load_7__area_1__power_meter_power__VevenSumB += _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Vb;
            _three_phase_at_load_7__area_1__power_meter_power__VevenSumC += _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Vc;
            _three_phase_at_load_7__area_1__power_meter_power__IevenSumA += _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Ia;
            _three_phase_at_load_7__area_1__power_meter_power__IevenSumB += _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Ib;
            _three_phase_at_load_7__area_1__power_meter_power__IevenSumC += _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Ic;
            _three_phase_at_load_7__area_1__power_meter_power__VoddSumA += _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Va;
            _three_phase_at_load_7__area_1__power_meter_power__VoddSumB += _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Vb;
            _three_phase_at_load_7__area_1__power_meter_power__VoddSumC += _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Vc;
            _three_phase_at_load_7__area_1__power_meter_power__IoddSumA += _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Ia;
            _three_phase_at_load_7__area_1__power_meter_power__IoddSumB += _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Ib;
            _three_phase_at_load_7__area_1__power_meter_power__IoddSumC += _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Ic;
            break ;
        case 2:
            _three_phase_at_load_7__area_1__power_meter_power__VevenSumA -= _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Va;
            _three_phase_at_load_7__area_1__power_meter_power__VevenSumB -= _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Vb;
            _three_phase_at_load_7__area_1__power_meter_power__VevenSumC -= _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Vc;
            _three_phase_at_load_7__area_1__power_meter_power__IevenSumA -= _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Ia;
            _three_phase_at_load_7__area_1__power_meter_power__IevenSumB -= _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Ib;
            _three_phase_at_load_7__area_1__power_meter_power__IevenSumC -= _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Ic;
            _three_phase_at_load_7__area_1__power_meter_power__VoddSumA += _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Va;
            _three_phase_at_load_7__area_1__power_meter_power__VoddSumB += _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Vb;
            _three_phase_at_load_7__area_1__power_meter_power__VoddSumC += _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Vc;
            _three_phase_at_load_7__area_1__power_meter_power__IoddSumA += _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Ia;
            _three_phase_at_load_7__area_1__power_meter_power__IoddSumB += _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Ib;
            _three_phase_at_load_7__area_1__power_meter_power__IoddSumC += _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Ic;
            break ;
        case 3:
            _three_phase_at_load_7__area_1__power_meter_power__VevenSumA -= _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Va;
            _three_phase_at_load_7__area_1__power_meter_power__VevenSumB -= _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Vb;
            _three_phase_at_load_7__area_1__power_meter_power__VevenSumC -= _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Vc;
            _three_phase_at_load_7__area_1__power_meter_power__IevenSumA -= _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Ia;
            _three_phase_at_load_7__area_1__power_meter_power__IevenSumB -= _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Ib;
            _three_phase_at_load_7__area_1__power_meter_power__IevenSumC -= _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Ic;
            _three_phase_at_load_7__area_1__power_meter_power__VoddSumA -= _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Va;
            _three_phase_at_load_7__area_1__power_meter_power__VoddSumB -= _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Vb;
            _three_phase_at_load_7__area_1__power_meter_power__VoddSumC -= _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Vc;
            _three_phase_at_load_7__area_1__power_meter_power__IoddSumA -= _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Ia;
            _three_phase_at_load_7__area_1__power_meter_power__IoddSumB -= _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Ib;
            _three_phase_at_load_7__area_1__power_meter_power__IoddSumC -= _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Ic;
            break ;
        case 4:
            _three_phase_at_load_7__area_1__power_meter_power__VevenSumA += _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Va;
            _three_phase_at_load_7__area_1__power_meter_power__VevenSumB += _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Vb;
            _three_phase_at_load_7__area_1__power_meter_power__VevenSumC += _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Vc;
            _three_phase_at_load_7__area_1__power_meter_power__IevenSumA += _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Ia;
            _three_phase_at_load_7__area_1__power_meter_power__IevenSumB += _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Ib;
            _three_phase_at_load_7__area_1__power_meter_power__IevenSumC += _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Ic;
            _three_phase_at_load_7__area_1__power_meter_power__VoddSumA -= _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Va;
            _three_phase_at_load_7__area_1__power_meter_power__VoddSumB -= _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Vb;
            _three_phase_at_load_7__area_1__power_meter_power__VoddSumC -= _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Vc;
            _three_phase_at_load_7__area_1__power_meter_power__IoddSumA -= _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Ia;
            _three_phase_at_load_7__area_1__power_meter_power__IoddSumB -= _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Ib;
            _three_phase_at_load_7__area_1__power_meter_power__IoddSumC -= _three_phase_at_load_7__area_1__power_meter_power__dFract * _three_phase_at_load_7__area_1__power_meter_power__Ic;
            break ;
        }
        break ;
    case 4:
        _three_phase_at_load_7__area_1__power_meter_power__Pa = _three_phase_at_load_7__area_1__power_meter_power__PsumA;
        _three_phase_at_load_7__area_1__power_meter_power__Pb = _three_phase_at_load_7__area_1__power_meter_power__PsumB;
        _three_phase_at_load_7__area_1__power_meter_power__Pc = _three_phase_at_load_7__area_1__power_meter_power__PsumC;
        _three_phase_at_load_7__area_1__power_meter_power__P = _three_phase_at_load_7__area_1__power_meter_power__Pa + _three_phase_at_load_7__area_1__power_meter_power__Pb + _three_phase_at_load_7__area_1__power_meter_power__Pc;
        _three_phase_at_load_7__area_1__power_meter_power__Sa = _three_phase_at_load_7__area_1__power_meter_power__VrmsA * _three_phase_at_load_7__area_1__power_meter_power__IrmsA;
        _three_phase_at_load_7__area_1__power_meter_power__Sb = _three_phase_at_load_7__area_1__power_meter_power__VrmsB * _three_phase_at_load_7__area_1__power_meter_power__IrmsB;
        _three_phase_at_load_7__area_1__power_meter_power__Sc = _three_phase_at_load_7__area_1__power_meter_power__VrmsC * _three_phase_at_load_7__area_1__power_meter_power__IrmsC;
        _three_phase_at_load_7__area_1__power_meter_power__S = _three_phase_at_load_7__area_1__power_meter_power__Sa + _three_phase_at_load_7__area_1__power_meter_power__Sb + _three_phase_at_load_7__area_1__power_meter_power__Sc;
        _three_phase_at_load_7__area_1__power_meter_power__Qa = _three_phase_at_load_7__area_1__power_meter_power__Sa * _three_phase_at_load_7__area_1__power_meter_power__Sa - _three_phase_at_load_7__area_1__power_meter_power__Pa * _three_phase_at_load_7__area_1__power_meter_power__Pa;
        if (_three_phase_at_load_7__area_1__power_meter_power__Qa < 0.0) {
            _three_phase_at_load_7__area_1__power_meter_power__Qa = 0.0;
        }
        else {
            _three_phase_at_load_7__area_1__power_meter_power__Qa = sqrt(_three_phase_at_load_7__area_1__power_meter_power__Qa);
            if (atan2f((_three_phase_at_load_7__area_1__power_meter_power__VoddSumA * _three_phase_at_load_7__area_1__power_meter_power__IevenSumA - _three_phase_at_load_7__area_1__power_meter_power__IoddSumA * _three_phase_at_load_7__area_1__power_meter_power__VevenSumA), (_three_phase_at_load_7__area_1__power_meter_power__VevenSumA * _three_phase_at_load_7__area_1__power_meter_power__IevenSumA + _three_phase_at_load_7__area_1__power_meter_power__VoddSumA * _three_phase_at_load_7__area_1__power_meter_power__IoddSumA)) > 0.0) {
                _three_phase_at_load_7__area_1__power_meter_power__Qa *= -1;
            }
        }
        _three_phase_at_load_7__area_1__power_meter_power__Qb = _three_phase_at_load_7__area_1__power_meter_power__Sb * _three_phase_at_load_7__area_1__power_meter_power__Sb - _three_phase_at_load_7__area_1__power_meter_power__Pb * _three_phase_at_load_7__area_1__power_meter_power__Pb;
        if (_three_phase_at_load_7__area_1__power_meter_power__Qb < 0.0) {
            _three_phase_at_load_7__area_1__power_meter_power__Qb = 0.0;
        }
        else {
            _three_phase_at_load_7__area_1__power_meter_power__Qb = sqrt(_three_phase_at_load_7__area_1__power_meter_power__Qb);
            if (atan2f((_three_phase_at_load_7__area_1__power_meter_power__VoddSumB * _three_phase_at_load_7__area_1__power_meter_power__IevenSumB - _three_phase_at_load_7__area_1__power_meter_power__IoddSumB * _three_phase_at_load_7__area_1__power_meter_power__VevenSumB), (_three_phase_at_load_7__area_1__power_meter_power__VevenSumB * _three_phase_at_load_7__area_1__power_meter_power__IevenSumB + _three_phase_at_load_7__area_1__power_meter_power__VoddSumB * _three_phase_at_load_7__area_1__power_meter_power__IoddSumB)) > 0.0) {
                _three_phase_at_load_7__area_1__power_meter_power__Qb *= -1;
            }
        }
        _three_phase_at_load_7__area_1__power_meter_power__Qc = _three_phase_at_load_7__area_1__power_meter_power__Sc * _three_phase_at_load_7__area_1__power_meter_power__Sc - _three_phase_at_load_7__area_1__power_meter_power__Pc * _three_phase_at_load_7__area_1__power_meter_power__Pc;
        if (_three_phase_at_load_7__area_1__power_meter_power__Qc < 0.0) {
            _three_phase_at_load_7__area_1__power_meter_power__Qc = 0.0;
        }
        else {
            _three_phase_at_load_7__area_1__power_meter_power__Qc = sqrt(_three_phase_at_load_7__area_1__power_meter_power__Qc);
            if (atan2f((_three_phase_at_load_7__area_1__power_meter_power__VoddSumC * _three_phase_at_load_7__area_1__power_meter_power__IevenSumC - _three_phase_at_load_7__area_1__power_meter_power__IoddSumC * _three_phase_at_load_7__area_1__power_meter_power__VevenSumC), (_three_phase_at_load_7__area_1__power_meter_power__VevenSumC * _three_phase_at_load_7__area_1__power_meter_power__IevenSumC + _three_phase_at_load_7__area_1__power_meter_power__VoddSumC * _three_phase_at_load_7__area_1__power_meter_power__IoddSumC)) > 0.0) {
                _three_phase_at_load_7__area_1__power_meter_power__Qc *= -1;
            }
        }
        _three_phase_at_load_7__area_1__power_meter_power__Q = _three_phase_at_load_7__area_1__power_meter_power__Qa + _three_phase_at_load_7__area_1__power_meter_power__Qb + _three_phase_at_load_7__area_1__power_meter_power__Qc;
        if (_three_phase_at_load_7__area_1__power_meter_power__Sa > 0) {
            _three_phase_at_load_7__area_1__power_meter_power__PFa = _three_phase_at_load_7__area_1__power_meter_power__Pa / _three_phase_at_load_7__area_1__power_meter_power__Sa;
        }
        else {
            _three_phase_at_load_7__area_1__power_meter_power__PFa = 0.0;
        }
        if (_three_phase_at_load_7__area_1__power_meter_power__Sb > 0) {
            _three_phase_at_load_7__area_1__power_meter_power__PFb = _three_phase_at_load_7__area_1__power_meter_power__Pb / _three_phase_at_load_7__area_1__power_meter_power__Sb;
        }
        else {
            _three_phase_at_load_7__area_1__power_meter_power__PFb = 0.0;
        }
        if (_three_phase_at_load_7__area_1__power_meter_power__Sc > 0) {
            _three_phase_at_load_7__area_1__power_meter_power__PFc = _three_phase_at_load_7__area_1__power_meter_power__Pc / _three_phase_at_load_7__area_1__power_meter_power__Sc;
        }
        else {
            _three_phase_at_load_7__area_1__power_meter_power__PFc = 0.0;
        }
        if (_three_phase_at_load_7__area_1__power_meter_power__S > 0) {
            _three_phase_at_load_7__area_1__power_meter_power__PF = _three_phase_at_load_7__area_1__power_meter_power__P / _three_phase_at_load_7__area_1__power_meter_power__S;
        }
        else {
            _three_phase_at_load_7__area_1__power_meter_power__PF = 0.0;
        }
        break ;
    case 5:
        _three_phase_at_load_7__area_1__power_meter_power__Pa = _three_phase_at_load_7__area_1__power_meter_power__Va * _three_phase_at_load_7__area_1__power_meter_power__Ia;
        _three_phase_at_load_7__area_1__power_meter_power__Pb = _three_phase_at_load_7__area_1__power_meter_power__Vb * _three_phase_at_load_7__area_1__power_meter_power__Ib;
        _three_phase_at_load_7__area_1__power_meter_power__Pc = _three_phase_at_load_7__area_1__power_meter_power__Vc * _three_phase_at_load_7__area_1__power_meter_power__Ic;
        _three_phase_at_load_7__area_1__power_meter_power__P = _three_phase_at_load_7__area_1__power_meter_power__Pa + _three_phase_at_load_7__area_1__power_meter_power__Pb + _three_phase_at_load_7__area_1__power_meter_power__Pc;
        _three_phase_at_load_7__area_1__power_meter_power__Qa = 0;
        _three_phase_at_load_7__area_1__power_meter_power__Qb = 0;
        _three_phase_at_load_7__area_1__power_meter_power__Qc = 0;
        _three_phase_at_load_7__area_1__power_meter_power__Q = 0.0;
        _three_phase_at_load_7__area_1__power_meter_power__Sa = 0;
        _three_phase_at_load_7__area_1__power_meter_power__Sb = 0;
        _three_phase_at_load_7__area_1__power_meter_power__Sc = 0;
        _three_phase_at_load_7__area_1__power_meter_power__S = 0;
        _three_phase_at_load_7__area_1__power_meter_power__PFa = 0.0;
        _three_phase_at_load_7__area_1__power_meter_power__PFb = 0.0;
        _three_phase_at_load_7__area_1__power_meter_power__PFc = 0.0;
        _three_phase_at_load_7__area_1__power_meter_power__PF = 0.0;
        break ;
    }
    // Generated from the component: Three-phase at load 7 (area 1).VAn_RMS
    HIL_OutAO(0x4095, (float)_three_phase_at_load_7__area_1__vln_rms_calc_rms__RMS1);
    // Generated from the component: Three-phase at load 7 (area 1).VBn_RMS
    HIL_OutAO(0x4097, (float)_three_phase_at_load_7__area_1__vln_rms_calc_rms__RMS2);
    // Generated from the component: Three-phase at load 7 (area 1).VCn_RMS
    HIL_OutAO(0x4099, (float)_three_phase_at_load_7__area_1__vln_rms_calc_rms__RMS3);
    // Generated from the component: Three-phase at load 7 (area 1).PLL.abc to dq.LPF_d
    _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_d__previous_filtered_value = _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_d__filtered_value;
    _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_d__filtered_value = _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_d__previous_in * (1.0 * 62.83185307 * 0.0001) + _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_d__previous_filtered_value * (1 - 1.0 * 62.83185307 * 0.0001 );
    _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_d__out = _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_d__filtered_value;
    _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_d__previous_in = _three_phase_at_load_7__area_1__pll_abc_to_dq_alpha_beta_to_dq__d;
    // Generated from the component: Three-phase at load 7 (area 1).PLL.abc to dq.LPF_q
    _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_q__previous_filtered_value = _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_q__filtered_value;
    _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_q__filtered_value = _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_q__previous_in * (1.0 * 62.83185307 * 0.0001) + _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_q__previous_filtered_value * (1 - 1.0 * 62.83185307 * 0.0001 );
    _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_q__out = _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_q__filtered_value;
    _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_q__previous_in = _three_phase_at_load_7__area_1__pll_abc_to_dq_alpha_beta_to_dq__q;
    // Generated from the component: Three-phase at load 8 (mid).IA_RMS
    HIL_OutAO(0x409b, (float)_three_phase_at_load_8__mid__i_rms_calc_rms__RMS1);
    // Generated from the component: Three-phase at load 8 (mid).IB_RMS
    HIL_OutAO(0x409c, (float)_three_phase_at_load_8__mid__i_rms_calc_rms__RMS2);
    // Generated from the component: Three-phase at load 8 (mid).IC_RMS
    HIL_OutAO(0x409d, (float)_three_phase_at_load_8__mid__i_rms_calc_rms__RMS3);
    // Generated from the component: Three-phase at load 8 (mid).Power Meter.POWER
    _three_phase_at_load_8__mid__power_meter_power__Ia = _three_phase_at_load_8__mid__ia_ia1__out;
    _three_phase_at_load_8__mid__power_meter_power__Ib = _three_phase_at_load_8__mid__ib_ia1__out;
    _three_phase_at_load_8__mid__power_meter_power__Ic = _three_phase_at_load_8__mid__ic_ia1__out;
    _three_phase_at_load_8__mid__power_meter_power__IrmsA = _three_phase_at_load_8__mid__i_rms_calc_rms__RMS1;
    _three_phase_at_load_8__mid__power_meter_power__IrmsB = _three_phase_at_load_8__mid__i_rms_calc_rms__RMS2;
    _three_phase_at_load_8__mid__power_meter_power__IrmsC = _three_phase_at_load_8__mid__i_rms_calc_rms__RMS3;
    _three_phase_at_load_8__mid__power_meter_power__Va = _three_phase_at_load_8__mid__van_va1__out;
    _three_phase_at_load_8__mid__power_meter_power__Vb = _three_phase_at_load_8__mid__vbn_va1__out;
    _three_phase_at_load_8__mid__power_meter_power__Vc = _three_phase_at_load_8__mid__vcn_va1__out;
    _three_phase_at_load_8__mid__power_meter_power__VrmsA = _three_phase_at_load_8__mid__vln_rms_calc_rms__RMS1;
    _three_phase_at_load_8__mid__power_meter_power__VrmsB = _three_phase_at_load_8__mid__vln_rms_calc_rms__RMS2;
    _three_phase_at_load_8__mid__power_meter_power__VrmsC = _three_phase_at_load_8__mid__vln_rms_calc_rms__RMS3;
    _three_phase_at_load_8__mid__power_meter_power__dFract = _three_phase_at_load_8__mid__meassm_mode_and_dfract__dFract;
    _three_phase_at_load_8__mid__power_meter_power__mode = _three_phase_at_load_8__mid__meassm_mode_and_dfract__mode;
    _three_phase_at_load_8__mid__power_meter_power__submode = _three_phase_at_load_8__mid__meassm_mode_and_dfract__submode;
    switch (_three_phase_at_load_8__mid__power_meter_power__mode) {
    case 1:
        _three_phase_at_load_8__mid__power_meter_power__VevenSumA = 0.0;
        _three_phase_at_load_8__mid__power_meter_power__VoddSumA = 0.0;
        _three_phase_at_load_8__mid__power_meter_power__VevenSumB = 0.0;
        _three_phase_at_load_8__mid__power_meter_power__VoddSumB = 0.0;
        _three_phase_at_load_8__mid__power_meter_power__VevenSumC = 0.0;
        _three_phase_at_load_8__mid__power_meter_power__VoddSumC = 0.0;
        _three_phase_at_load_8__mid__power_meter_power__IevenSumA = 0.0;
        _three_phase_at_load_8__mid__power_meter_power__IoddSumA = 0.0;
        _three_phase_at_load_8__mid__power_meter_power__IevenSumB = 0.0;
        _three_phase_at_load_8__mid__power_meter_power__IoddSumB = 0.0;
        _three_phase_at_load_8__mid__power_meter_power__IevenSumC = 0.0;
        _three_phase_at_load_8__mid__power_meter_power__IoddSumC = 0.0;
        _three_phase_at_load_8__mid__power_meter_power__PsumA = 0.0;
        _three_phase_at_load_8__mid__power_meter_power__PsumB = 0.0;
        _three_phase_at_load_8__mid__power_meter_power__PsumC = 0.0;
        break ;
    case 2:
        _three_phase_at_load_8__mid__power_meter_power__Pa = _three_phase_at_load_8__mid__power_meter_power__Va * _three_phase_at_load_8__mid__power_meter_power__Ia;
        _three_phase_at_load_8__mid__power_meter_power__Pb = _three_phase_at_load_8__mid__power_meter_power__Vb * _three_phase_at_load_8__mid__power_meter_power__Ib;
        _three_phase_at_load_8__mid__power_meter_power__Pc = _three_phase_at_load_8__mid__power_meter_power__Vc * _three_phase_at_load_8__mid__power_meter_power__Ic;
        _three_phase_at_load_8__mid__power_meter_power__P = _three_phase_at_load_8__mid__power_meter_power__Pa + _three_phase_at_load_8__mid__power_meter_power__Pb + _three_phase_at_load_8__mid__power_meter_power__Pc;
        _three_phase_at_load_8__mid__power_meter_power__Qa = 0;
        _three_phase_at_load_8__mid__power_meter_power__Qb = 0;
        _three_phase_at_load_8__mid__power_meter_power__Qc = 0;
        _three_phase_at_load_8__mid__power_meter_power__Q = _three_phase_at_load_8__mid__power_meter_power__Qa + _three_phase_at_load_8__mid__power_meter_power__Qb + _three_phase_at_load_8__mid__power_meter_power__Qc;
        _three_phase_at_load_8__mid__power_meter_power__Sa = _three_phase_at_load_8__mid__power_meter_power__Pa;
        _three_phase_at_load_8__mid__power_meter_power__Sb = _three_phase_at_load_8__mid__power_meter_power__Pb;
        _three_phase_at_load_8__mid__power_meter_power__Sc = _three_phase_at_load_8__mid__power_meter_power__Pc;
        _three_phase_at_load_8__mid__power_meter_power__S = _three_phase_at_load_8__mid__power_meter_power__Sa + _three_phase_at_load_8__mid__power_meter_power__Sb + _three_phase_at_load_8__mid__power_meter_power__Sc;
        _three_phase_at_load_8__mid__power_meter_power__PFa = 1.0;
        _three_phase_at_load_8__mid__power_meter_power__PFb = 1.0;
        _three_phase_at_load_8__mid__power_meter_power__PFc = 1.0;
        _three_phase_at_load_8__mid__power_meter_power__PF = 1.0;
        break ;
    case 3:
        _three_phase_at_load_8__mid__power_meter_power__PsumA += _three_phase_at_load_8__mid__power_meter_power__dFract * (_three_phase_at_load_8__mid__power_meter_power__Va * _three_phase_at_load_8__mid__power_meter_power__Ia);
        _three_phase_at_load_8__mid__power_meter_power__PsumB += _three_phase_at_load_8__mid__power_meter_power__dFract * (_three_phase_at_load_8__mid__power_meter_power__Vb * _three_phase_at_load_8__mid__power_meter_power__Ib);
        _three_phase_at_load_8__mid__power_meter_power__PsumC += _three_phase_at_load_8__mid__power_meter_power__dFract * (_three_phase_at_load_8__mid__power_meter_power__Vc * _three_phase_at_load_8__mid__power_meter_power__Ic);
        switch (_three_phase_at_load_8__mid__power_meter_power__submode) {
        case 1:
            _three_phase_at_load_8__mid__power_meter_power__VevenSumA += _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Va;
            _three_phase_at_load_8__mid__power_meter_power__VevenSumB += _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Vb;
            _three_phase_at_load_8__mid__power_meter_power__VevenSumC += _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Vc;
            _three_phase_at_load_8__mid__power_meter_power__IevenSumA += _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Ia;
            _three_phase_at_load_8__mid__power_meter_power__IevenSumB += _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Ib;
            _three_phase_at_load_8__mid__power_meter_power__IevenSumC += _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Ic;
            _three_phase_at_load_8__mid__power_meter_power__VoddSumA += _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Va;
            _three_phase_at_load_8__mid__power_meter_power__VoddSumB += _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Vb;
            _three_phase_at_load_8__mid__power_meter_power__VoddSumC += _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Vc;
            _three_phase_at_load_8__mid__power_meter_power__IoddSumA += _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Ia;
            _three_phase_at_load_8__mid__power_meter_power__IoddSumB += _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Ib;
            _three_phase_at_load_8__mid__power_meter_power__IoddSumC += _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Ic;
            break ;
        case 2:
            _three_phase_at_load_8__mid__power_meter_power__VevenSumA -= _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Va;
            _three_phase_at_load_8__mid__power_meter_power__VevenSumB -= _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Vb;
            _three_phase_at_load_8__mid__power_meter_power__VevenSumC -= _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Vc;
            _three_phase_at_load_8__mid__power_meter_power__IevenSumA -= _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Ia;
            _three_phase_at_load_8__mid__power_meter_power__IevenSumB -= _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Ib;
            _three_phase_at_load_8__mid__power_meter_power__IevenSumC -= _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Ic;
            _three_phase_at_load_8__mid__power_meter_power__VoddSumA += _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Va;
            _three_phase_at_load_8__mid__power_meter_power__VoddSumB += _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Vb;
            _three_phase_at_load_8__mid__power_meter_power__VoddSumC += _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Vc;
            _three_phase_at_load_8__mid__power_meter_power__IoddSumA += _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Ia;
            _three_phase_at_load_8__mid__power_meter_power__IoddSumB += _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Ib;
            _three_phase_at_load_8__mid__power_meter_power__IoddSumC += _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Ic;
            break ;
        case 3:
            _three_phase_at_load_8__mid__power_meter_power__VevenSumA -= _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Va;
            _three_phase_at_load_8__mid__power_meter_power__VevenSumB -= _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Vb;
            _three_phase_at_load_8__mid__power_meter_power__VevenSumC -= _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Vc;
            _three_phase_at_load_8__mid__power_meter_power__IevenSumA -= _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Ia;
            _three_phase_at_load_8__mid__power_meter_power__IevenSumB -= _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Ib;
            _three_phase_at_load_8__mid__power_meter_power__IevenSumC -= _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Ic;
            _three_phase_at_load_8__mid__power_meter_power__VoddSumA -= _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Va;
            _three_phase_at_load_8__mid__power_meter_power__VoddSumB -= _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Vb;
            _three_phase_at_load_8__mid__power_meter_power__VoddSumC -= _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Vc;
            _three_phase_at_load_8__mid__power_meter_power__IoddSumA -= _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Ia;
            _three_phase_at_load_8__mid__power_meter_power__IoddSumB -= _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Ib;
            _three_phase_at_load_8__mid__power_meter_power__IoddSumC -= _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Ic;
            break ;
        case 4:
            _three_phase_at_load_8__mid__power_meter_power__VevenSumA += _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Va;
            _three_phase_at_load_8__mid__power_meter_power__VevenSumB += _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Vb;
            _three_phase_at_load_8__mid__power_meter_power__VevenSumC += _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Vc;
            _three_phase_at_load_8__mid__power_meter_power__IevenSumA += _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Ia;
            _three_phase_at_load_8__mid__power_meter_power__IevenSumB += _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Ib;
            _three_phase_at_load_8__mid__power_meter_power__IevenSumC += _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Ic;
            _three_phase_at_load_8__mid__power_meter_power__VoddSumA -= _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Va;
            _three_phase_at_load_8__mid__power_meter_power__VoddSumB -= _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Vb;
            _three_phase_at_load_8__mid__power_meter_power__VoddSumC -= _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Vc;
            _three_phase_at_load_8__mid__power_meter_power__IoddSumA -= _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Ia;
            _three_phase_at_load_8__mid__power_meter_power__IoddSumB -= _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Ib;
            _three_phase_at_load_8__mid__power_meter_power__IoddSumC -= _three_phase_at_load_8__mid__power_meter_power__dFract * _three_phase_at_load_8__mid__power_meter_power__Ic;
            break ;
        }
        break ;
    case 4:
        _three_phase_at_load_8__mid__power_meter_power__Pa = _three_phase_at_load_8__mid__power_meter_power__PsumA;
        _three_phase_at_load_8__mid__power_meter_power__Pb = _three_phase_at_load_8__mid__power_meter_power__PsumB;
        _three_phase_at_load_8__mid__power_meter_power__Pc = _three_phase_at_load_8__mid__power_meter_power__PsumC;
        _three_phase_at_load_8__mid__power_meter_power__P = _three_phase_at_load_8__mid__power_meter_power__Pa + _three_phase_at_load_8__mid__power_meter_power__Pb + _three_phase_at_load_8__mid__power_meter_power__Pc;
        _three_phase_at_load_8__mid__power_meter_power__Sa = _three_phase_at_load_8__mid__power_meter_power__VrmsA * _three_phase_at_load_8__mid__power_meter_power__IrmsA;
        _three_phase_at_load_8__mid__power_meter_power__Sb = _three_phase_at_load_8__mid__power_meter_power__VrmsB * _three_phase_at_load_8__mid__power_meter_power__IrmsB;
        _three_phase_at_load_8__mid__power_meter_power__Sc = _three_phase_at_load_8__mid__power_meter_power__VrmsC * _three_phase_at_load_8__mid__power_meter_power__IrmsC;
        _three_phase_at_load_8__mid__power_meter_power__S = _three_phase_at_load_8__mid__power_meter_power__Sa + _three_phase_at_load_8__mid__power_meter_power__Sb + _three_phase_at_load_8__mid__power_meter_power__Sc;
        _three_phase_at_load_8__mid__power_meter_power__Qa = _three_phase_at_load_8__mid__power_meter_power__Sa * _three_phase_at_load_8__mid__power_meter_power__Sa - _three_phase_at_load_8__mid__power_meter_power__Pa * _three_phase_at_load_8__mid__power_meter_power__Pa;
        if (_three_phase_at_load_8__mid__power_meter_power__Qa < 0.0) {
            _three_phase_at_load_8__mid__power_meter_power__Qa = 0.0;
        }
        else {
            _three_phase_at_load_8__mid__power_meter_power__Qa = sqrt(_three_phase_at_load_8__mid__power_meter_power__Qa);
            if (atan2f((_three_phase_at_load_8__mid__power_meter_power__VoddSumA * _three_phase_at_load_8__mid__power_meter_power__IevenSumA - _three_phase_at_load_8__mid__power_meter_power__IoddSumA * _three_phase_at_load_8__mid__power_meter_power__VevenSumA), (_three_phase_at_load_8__mid__power_meter_power__VevenSumA * _three_phase_at_load_8__mid__power_meter_power__IevenSumA + _three_phase_at_load_8__mid__power_meter_power__VoddSumA * _three_phase_at_load_8__mid__power_meter_power__IoddSumA)) > 0.0) {
                _three_phase_at_load_8__mid__power_meter_power__Qa *= -1;
            }
        }
        _three_phase_at_load_8__mid__power_meter_power__Qb = _three_phase_at_load_8__mid__power_meter_power__Sb * _three_phase_at_load_8__mid__power_meter_power__Sb - _three_phase_at_load_8__mid__power_meter_power__Pb * _three_phase_at_load_8__mid__power_meter_power__Pb;
        if (_three_phase_at_load_8__mid__power_meter_power__Qb < 0.0) {
            _three_phase_at_load_8__mid__power_meter_power__Qb = 0.0;
        }
        else {
            _three_phase_at_load_8__mid__power_meter_power__Qb = sqrt(_three_phase_at_load_8__mid__power_meter_power__Qb);
            if (atan2f((_three_phase_at_load_8__mid__power_meter_power__VoddSumB * _three_phase_at_load_8__mid__power_meter_power__IevenSumB - _three_phase_at_load_8__mid__power_meter_power__IoddSumB * _three_phase_at_load_8__mid__power_meter_power__VevenSumB), (_three_phase_at_load_8__mid__power_meter_power__VevenSumB * _three_phase_at_load_8__mid__power_meter_power__IevenSumB + _three_phase_at_load_8__mid__power_meter_power__VoddSumB * _three_phase_at_load_8__mid__power_meter_power__IoddSumB)) > 0.0) {
                _three_phase_at_load_8__mid__power_meter_power__Qb *= -1;
            }
        }
        _three_phase_at_load_8__mid__power_meter_power__Qc = _three_phase_at_load_8__mid__power_meter_power__Sc * _three_phase_at_load_8__mid__power_meter_power__Sc - _three_phase_at_load_8__mid__power_meter_power__Pc * _three_phase_at_load_8__mid__power_meter_power__Pc;
        if (_three_phase_at_load_8__mid__power_meter_power__Qc < 0.0) {
            _three_phase_at_load_8__mid__power_meter_power__Qc = 0.0;
        }
        else {
            _three_phase_at_load_8__mid__power_meter_power__Qc = sqrt(_three_phase_at_load_8__mid__power_meter_power__Qc);
            if (atan2f((_three_phase_at_load_8__mid__power_meter_power__VoddSumC * _three_phase_at_load_8__mid__power_meter_power__IevenSumC - _three_phase_at_load_8__mid__power_meter_power__IoddSumC * _three_phase_at_load_8__mid__power_meter_power__VevenSumC), (_three_phase_at_load_8__mid__power_meter_power__VevenSumC * _three_phase_at_load_8__mid__power_meter_power__IevenSumC + _three_phase_at_load_8__mid__power_meter_power__VoddSumC * _three_phase_at_load_8__mid__power_meter_power__IoddSumC)) > 0.0) {
                _three_phase_at_load_8__mid__power_meter_power__Qc *= -1;
            }
        }
        _three_phase_at_load_8__mid__power_meter_power__Q = _three_phase_at_load_8__mid__power_meter_power__Qa + _three_phase_at_load_8__mid__power_meter_power__Qb + _three_phase_at_load_8__mid__power_meter_power__Qc;
        if (_three_phase_at_load_8__mid__power_meter_power__Sa > 0) {
            _three_phase_at_load_8__mid__power_meter_power__PFa = _three_phase_at_load_8__mid__power_meter_power__Pa / _three_phase_at_load_8__mid__power_meter_power__Sa;
        }
        else {
            _three_phase_at_load_8__mid__power_meter_power__PFa = 0.0;
        }
        if (_three_phase_at_load_8__mid__power_meter_power__Sb > 0) {
            _three_phase_at_load_8__mid__power_meter_power__PFb = _three_phase_at_load_8__mid__power_meter_power__Pb / _three_phase_at_load_8__mid__power_meter_power__Sb;
        }
        else {
            _three_phase_at_load_8__mid__power_meter_power__PFb = 0.0;
        }
        if (_three_phase_at_load_8__mid__power_meter_power__Sc > 0) {
            _three_phase_at_load_8__mid__power_meter_power__PFc = _three_phase_at_load_8__mid__power_meter_power__Pc / _three_phase_at_load_8__mid__power_meter_power__Sc;
        }
        else {
            _three_phase_at_load_8__mid__power_meter_power__PFc = 0.0;
        }
        if (_three_phase_at_load_8__mid__power_meter_power__S > 0) {
            _three_phase_at_load_8__mid__power_meter_power__PF = _three_phase_at_load_8__mid__power_meter_power__P / _three_phase_at_load_8__mid__power_meter_power__S;
        }
        else {
            _three_phase_at_load_8__mid__power_meter_power__PF = 0.0;
        }
        break ;
    case 5:
        _three_phase_at_load_8__mid__power_meter_power__Pa = _three_phase_at_load_8__mid__power_meter_power__Va * _three_phase_at_load_8__mid__power_meter_power__Ia;
        _three_phase_at_load_8__mid__power_meter_power__Pb = _three_phase_at_load_8__mid__power_meter_power__Vb * _three_phase_at_load_8__mid__power_meter_power__Ib;
        _three_phase_at_load_8__mid__power_meter_power__Pc = _three_phase_at_load_8__mid__power_meter_power__Vc * _three_phase_at_load_8__mid__power_meter_power__Ic;
        _three_phase_at_load_8__mid__power_meter_power__P = _three_phase_at_load_8__mid__power_meter_power__Pa + _three_phase_at_load_8__mid__power_meter_power__Pb + _three_phase_at_load_8__mid__power_meter_power__Pc;
        _three_phase_at_load_8__mid__power_meter_power__Qa = 0;
        _three_phase_at_load_8__mid__power_meter_power__Qb = 0;
        _three_phase_at_load_8__mid__power_meter_power__Qc = 0;
        _three_phase_at_load_8__mid__power_meter_power__Q = 0.0;
        _three_phase_at_load_8__mid__power_meter_power__Sa = 0;
        _three_phase_at_load_8__mid__power_meter_power__Sb = 0;
        _three_phase_at_load_8__mid__power_meter_power__Sc = 0;
        _three_phase_at_load_8__mid__power_meter_power__S = 0;
        _three_phase_at_load_8__mid__power_meter_power__PFa = 0.0;
        _three_phase_at_load_8__mid__power_meter_power__PFb = 0.0;
        _three_phase_at_load_8__mid__power_meter_power__PFc = 0.0;
        _three_phase_at_load_8__mid__power_meter_power__PF = 0.0;
        break ;
    }
    // Generated from the component: Three-phase at load 8 (mid).VAn_RMS
    HIL_OutAO(0x40ae, (float)_three_phase_at_load_8__mid__vln_rms_calc_rms__RMS1);
    // Generated from the component: Three-phase at load 8 (mid).VBn_RMS
    HIL_OutAO(0x40af, (float)_three_phase_at_load_8__mid__vln_rms_calc_rms__RMS2);
    // Generated from the component: Three-phase at load 8 (mid).VCn_RMS
    HIL_OutAO(0x40b0, (float)_three_phase_at_load_8__mid__vln_rms_calc_rms__RMS3);
    // Generated from the component: Three-phase at load 8 (mid).PLL.abc to dq.LPF_d
    _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_d__previous_filtered_value = _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_d__filtered_value;
    _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_d__filtered_value = _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_d__previous_in * (1.0 * 62.83185307 * 0.0001) + _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_d__previous_filtered_value * (1 - 1.0 * 62.83185307 * 0.0001 );
    _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_d__out = _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_d__filtered_value;
    _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_d__previous_in = _three_phase_at_load_8__mid__pll_abc_to_dq_alpha_beta_to_dq__d;
    // Generated from the component: Three-phase at load 8 (mid).PLL.abc to dq.LPF_q
    _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_q__previous_filtered_value = _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_q__filtered_value;
    _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_q__filtered_value = _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_q__previous_in * (1.0 * 62.83185307 * 0.0001) + _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_q__previous_filtered_value * (1 - 1.0 * 62.83185307 * 0.0001 );
    _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_q__out = _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_q__filtered_value;
    _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_q__previous_in = _three_phase_at_load_8__mid__pll_abc_to_dq_alpha_beta_to_dq__q;
    // Generated from the component: Three-phase at load 9 (area 2).IA_RMS
    HIL_OutAO(0x40b2, (float)_three_phase_at_load_9__area_2__i_rms_calc_rms__RMS1);
    // Generated from the component: Three-phase at load 9 (area 2).IB_RMS
    HIL_OutAO(0x40b3, (float)_three_phase_at_load_9__area_2__i_rms_calc_rms__RMS2);
    // Generated from the component: Three-phase at load 9 (area 2).IC_RMS
    HIL_OutAO(0x40b4, (float)_three_phase_at_load_9__area_2__i_rms_calc_rms__RMS3);
    // Generated from the component: Three-phase at load 9 (area 2).VAB_RMS
    HIL_OutAO(0x40c5, (float)_three_phase_at_load_9__area_2__vll_rms_calc_rms__RMS1);
    // Generated from the component: Three-phase at load 9 (area 2).VBC_RMS
    HIL_OutAO(0x40c7, (float)_three_phase_at_load_9__area_2__vll_rms_calc_rms__RMS2);
    // Generated from the component: Three-phase at load 9 (area 2).VCA_RMS
    HIL_OutAO(0x40c9, (float)_three_phase_at_load_9__area_2__vll_rms_calc_rms__RMS3);
    // Generated from the component: Three-phase at load 9 (area 2).Power Meter.POWER
    _three_phase_at_load_9__area_2__power_meter_power__Ia = _three_phase_at_load_9__area_2__ia_ia1__out;
    _three_phase_at_load_9__area_2__power_meter_power__Ib = _three_phase_at_load_9__area_2__ib_ia1__out;
    _three_phase_at_load_9__area_2__power_meter_power__Ic = _three_phase_at_load_9__area_2__ic_ia1__out;
    _three_phase_at_load_9__area_2__power_meter_power__IrmsA = _three_phase_at_load_9__area_2__i_rms_calc_rms__RMS1;
    _three_phase_at_load_9__area_2__power_meter_power__IrmsB = _three_phase_at_load_9__area_2__i_rms_calc_rms__RMS2;
    _three_phase_at_load_9__area_2__power_meter_power__IrmsC = _three_phase_at_load_9__area_2__i_rms_calc_rms__RMS3;
    _three_phase_at_load_9__area_2__power_meter_power__Va = _three_phase_at_load_9__area_2__van_va1__out;
    _three_phase_at_load_9__area_2__power_meter_power__Vb = _three_phase_at_load_9__area_2__vbn_va1__out;
    _three_phase_at_load_9__area_2__power_meter_power__Vc = _three_phase_at_load_9__area_2__vcn_va1__out;
    _three_phase_at_load_9__area_2__power_meter_power__VrmsA = _three_phase_at_load_9__area_2__vln_rms_calc_rms__RMS1;
    _three_phase_at_load_9__area_2__power_meter_power__VrmsB = _three_phase_at_load_9__area_2__vln_rms_calc_rms__RMS2;
    _three_phase_at_load_9__area_2__power_meter_power__VrmsC = _three_phase_at_load_9__area_2__vln_rms_calc_rms__RMS3;
    _three_phase_at_load_9__area_2__power_meter_power__dFract = _three_phase_at_load_9__area_2__meassm_mode_and_dfract__dFract;
    _three_phase_at_load_9__area_2__power_meter_power__mode = _three_phase_at_load_9__area_2__meassm_mode_and_dfract__mode;
    _three_phase_at_load_9__area_2__power_meter_power__submode = _three_phase_at_load_9__area_2__meassm_mode_and_dfract__submode;
    switch (_three_phase_at_load_9__area_2__power_meter_power__mode) {
    case 1:
        _three_phase_at_load_9__area_2__power_meter_power__VevenSumA = 0.0;
        _three_phase_at_load_9__area_2__power_meter_power__VoddSumA = 0.0;
        _three_phase_at_load_9__area_2__power_meter_power__VevenSumB = 0.0;
        _three_phase_at_load_9__area_2__power_meter_power__VoddSumB = 0.0;
        _three_phase_at_load_9__area_2__power_meter_power__VevenSumC = 0.0;
        _three_phase_at_load_9__area_2__power_meter_power__VoddSumC = 0.0;
        _three_phase_at_load_9__area_2__power_meter_power__IevenSumA = 0.0;
        _three_phase_at_load_9__area_2__power_meter_power__IoddSumA = 0.0;
        _three_phase_at_load_9__area_2__power_meter_power__IevenSumB = 0.0;
        _three_phase_at_load_9__area_2__power_meter_power__IoddSumB = 0.0;
        _three_phase_at_load_9__area_2__power_meter_power__IevenSumC = 0.0;
        _three_phase_at_load_9__area_2__power_meter_power__IoddSumC = 0.0;
        _three_phase_at_load_9__area_2__power_meter_power__PsumA = 0.0;
        _three_phase_at_load_9__area_2__power_meter_power__PsumB = 0.0;
        _three_phase_at_load_9__area_2__power_meter_power__PsumC = 0.0;
        break ;
    case 2:
        _three_phase_at_load_9__area_2__power_meter_power__Pa = _three_phase_at_load_9__area_2__power_meter_power__Va * _three_phase_at_load_9__area_2__power_meter_power__Ia;
        _three_phase_at_load_9__area_2__power_meter_power__Pb = _three_phase_at_load_9__area_2__power_meter_power__Vb * _three_phase_at_load_9__area_2__power_meter_power__Ib;
        _three_phase_at_load_9__area_2__power_meter_power__Pc = _three_phase_at_load_9__area_2__power_meter_power__Vc * _three_phase_at_load_9__area_2__power_meter_power__Ic;
        _three_phase_at_load_9__area_2__power_meter_power__P = _three_phase_at_load_9__area_2__power_meter_power__Pa + _three_phase_at_load_9__area_2__power_meter_power__Pb + _three_phase_at_load_9__area_2__power_meter_power__Pc;
        _three_phase_at_load_9__area_2__power_meter_power__Qa = 0;
        _three_phase_at_load_9__area_2__power_meter_power__Qb = 0;
        _three_phase_at_load_9__area_2__power_meter_power__Qc = 0;
        _three_phase_at_load_9__area_2__power_meter_power__Q = _three_phase_at_load_9__area_2__power_meter_power__Qa + _three_phase_at_load_9__area_2__power_meter_power__Qb + _three_phase_at_load_9__area_2__power_meter_power__Qc;
        _three_phase_at_load_9__area_2__power_meter_power__Sa = _three_phase_at_load_9__area_2__power_meter_power__Pa;
        _three_phase_at_load_9__area_2__power_meter_power__Sb = _three_phase_at_load_9__area_2__power_meter_power__Pb;
        _three_phase_at_load_9__area_2__power_meter_power__Sc = _three_phase_at_load_9__area_2__power_meter_power__Pc;
        _three_phase_at_load_9__area_2__power_meter_power__S = _three_phase_at_load_9__area_2__power_meter_power__Sa + _three_phase_at_load_9__area_2__power_meter_power__Sb + _three_phase_at_load_9__area_2__power_meter_power__Sc;
        _three_phase_at_load_9__area_2__power_meter_power__PFa = 1.0;
        _three_phase_at_load_9__area_2__power_meter_power__PFb = 1.0;
        _three_phase_at_load_9__area_2__power_meter_power__PFc = 1.0;
        _three_phase_at_load_9__area_2__power_meter_power__PF = 1.0;
        break ;
    case 3:
        _three_phase_at_load_9__area_2__power_meter_power__PsumA += _three_phase_at_load_9__area_2__power_meter_power__dFract * (_three_phase_at_load_9__area_2__power_meter_power__Va * _three_phase_at_load_9__area_2__power_meter_power__Ia);
        _three_phase_at_load_9__area_2__power_meter_power__PsumB += _three_phase_at_load_9__area_2__power_meter_power__dFract * (_three_phase_at_load_9__area_2__power_meter_power__Vb * _three_phase_at_load_9__area_2__power_meter_power__Ib);
        _three_phase_at_load_9__area_2__power_meter_power__PsumC += _three_phase_at_load_9__area_2__power_meter_power__dFract * (_three_phase_at_load_9__area_2__power_meter_power__Vc * _three_phase_at_load_9__area_2__power_meter_power__Ic);
        switch (_three_phase_at_load_9__area_2__power_meter_power__submode) {
        case 1:
            _three_phase_at_load_9__area_2__power_meter_power__VevenSumA += _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Va;
            _three_phase_at_load_9__area_2__power_meter_power__VevenSumB += _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Vb;
            _three_phase_at_load_9__area_2__power_meter_power__VevenSumC += _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Vc;
            _three_phase_at_load_9__area_2__power_meter_power__IevenSumA += _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Ia;
            _three_phase_at_load_9__area_2__power_meter_power__IevenSumB += _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Ib;
            _three_phase_at_load_9__area_2__power_meter_power__IevenSumC += _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Ic;
            _three_phase_at_load_9__area_2__power_meter_power__VoddSumA += _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Va;
            _three_phase_at_load_9__area_2__power_meter_power__VoddSumB += _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Vb;
            _three_phase_at_load_9__area_2__power_meter_power__VoddSumC += _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Vc;
            _three_phase_at_load_9__area_2__power_meter_power__IoddSumA += _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Ia;
            _three_phase_at_load_9__area_2__power_meter_power__IoddSumB += _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Ib;
            _three_phase_at_load_9__area_2__power_meter_power__IoddSumC += _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Ic;
            break ;
        case 2:
            _three_phase_at_load_9__area_2__power_meter_power__VevenSumA -= _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Va;
            _three_phase_at_load_9__area_2__power_meter_power__VevenSumB -= _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Vb;
            _three_phase_at_load_9__area_2__power_meter_power__VevenSumC -= _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Vc;
            _three_phase_at_load_9__area_2__power_meter_power__IevenSumA -= _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Ia;
            _three_phase_at_load_9__area_2__power_meter_power__IevenSumB -= _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Ib;
            _three_phase_at_load_9__area_2__power_meter_power__IevenSumC -= _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Ic;
            _three_phase_at_load_9__area_2__power_meter_power__VoddSumA += _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Va;
            _three_phase_at_load_9__area_2__power_meter_power__VoddSumB += _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Vb;
            _three_phase_at_load_9__area_2__power_meter_power__VoddSumC += _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Vc;
            _three_phase_at_load_9__area_2__power_meter_power__IoddSumA += _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Ia;
            _three_phase_at_load_9__area_2__power_meter_power__IoddSumB += _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Ib;
            _three_phase_at_load_9__area_2__power_meter_power__IoddSumC += _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Ic;
            break ;
        case 3:
            _three_phase_at_load_9__area_2__power_meter_power__VevenSumA -= _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Va;
            _three_phase_at_load_9__area_2__power_meter_power__VevenSumB -= _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Vb;
            _three_phase_at_load_9__area_2__power_meter_power__VevenSumC -= _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Vc;
            _three_phase_at_load_9__area_2__power_meter_power__IevenSumA -= _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Ia;
            _three_phase_at_load_9__area_2__power_meter_power__IevenSumB -= _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Ib;
            _three_phase_at_load_9__area_2__power_meter_power__IevenSumC -= _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Ic;
            _three_phase_at_load_9__area_2__power_meter_power__VoddSumA -= _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Va;
            _three_phase_at_load_9__area_2__power_meter_power__VoddSumB -= _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Vb;
            _three_phase_at_load_9__area_2__power_meter_power__VoddSumC -= _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Vc;
            _three_phase_at_load_9__area_2__power_meter_power__IoddSumA -= _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Ia;
            _three_phase_at_load_9__area_2__power_meter_power__IoddSumB -= _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Ib;
            _three_phase_at_load_9__area_2__power_meter_power__IoddSumC -= _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Ic;
            break ;
        case 4:
            _three_phase_at_load_9__area_2__power_meter_power__VevenSumA += _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Va;
            _three_phase_at_load_9__area_2__power_meter_power__VevenSumB += _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Vb;
            _three_phase_at_load_9__area_2__power_meter_power__VevenSumC += _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Vc;
            _three_phase_at_load_9__area_2__power_meter_power__IevenSumA += _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Ia;
            _three_phase_at_load_9__area_2__power_meter_power__IevenSumB += _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Ib;
            _three_phase_at_load_9__area_2__power_meter_power__IevenSumC += _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Ic;
            _three_phase_at_load_9__area_2__power_meter_power__VoddSumA -= _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Va;
            _three_phase_at_load_9__area_2__power_meter_power__VoddSumB -= _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Vb;
            _three_phase_at_load_9__area_2__power_meter_power__VoddSumC -= _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Vc;
            _three_phase_at_load_9__area_2__power_meter_power__IoddSumA -= _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Ia;
            _three_phase_at_load_9__area_2__power_meter_power__IoddSumB -= _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Ib;
            _three_phase_at_load_9__area_2__power_meter_power__IoddSumC -= _three_phase_at_load_9__area_2__power_meter_power__dFract * _three_phase_at_load_9__area_2__power_meter_power__Ic;
            break ;
        }
        break ;
    case 4:
        _three_phase_at_load_9__area_2__power_meter_power__Pa = _three_phase_at_load_9__area_2__power_meter_power__PsumA;
        _three_phase_at_load_9__area_2__power_meter_power__Pb = _three_phase_at_load_9__area_2__power_meter_power__PsumB;
        _three_phase_at_load_9__area_2__power_meter_power__Pc = _three_phase_at_load_9__area_2__power_meter_power__PsumC;
        _three_phase_at_load_9__area_2__power_meter_power__P = _three_phase_at_load_9__area_2__power_meter_power__Pa + _three_phase_at_load_9__area_2__power_meter_power__Pb + _three_phase_at_load_9__area_2__power_meter_power__Pc;
        _three_phase_at_load_9__area_2__power_meter_power__Sa = _three_phase_at_load_9__area_2__power_meter_power__VrmsA * _three_phase_at_load_9__area_2__power_meter_power__IrmsA;
        _three_phase_at_load_9__area_2__power_meter_power__Sb = _three_phase_at_load_9__area_2__power_meter_power__VrmsB * _three_phase_at_load_9__area_2__power_meter_power__IrmsB;
        _three_phase_at_load_9__area_2__power_meter_power__Sc = _three_phase_at_load_9__area_2__power_meter_power__VrmsC * _three_phase_at_load_9__area_2__power_meter_power__IrmsC;
        _three_phase_at_load_9__area_2__power_meter_power__S = _three_phase_at_load_9__area_2__power_meter_power__Sa + _three_phase_at_load_9__area_2__power_meter_power__Sb + _three_phase_at_load_9__area_2__power_meter_power__Sc;
        _three_phase_at_load_9__area_2__power_meter_power__Qa = _three_phase_at_load_9__area_2__power_meter_power__Sa * _three_phase_at_load_9__area_2__power_meter_power__Sa - _three_phase_at_load_9__area_2__power_meter_power__Pa * _three_phase_at_load_9__area_2__power_meter_power__Pa;
        if (_three_phase_at_load_9__area_2__power_meter_power__Qa < 0.0) {
            _three_phase_at_load_9__area_2__power_meter_power__Qa = 0.0;
        }
        else {
            _three_phase_at_load_9__area_2__power_meter_power__Qa = sqrt(_three_phase_at_load_9__area_2__power_meter_power__Qa);
            if (atan2f((_three_phase_at_load_9__area_2__power_meter_power__VoddSumA * _three_phase_at_load_9__area_2__power_meter_power__IevenSumA - _three_phase_at_load_9__area_2__power_meter_power__IoddSumA * _three_phase_at_load_9__area_2__power_meter_power__VevenSumA), (_three_phase_at_load_9__area_2__power_meter_power__VevenSumA * _three_phase_at_load_9__area_2__power_meter_power__IevenSumA + _three_phase_at_load_9__area_2__power_meter_power__VoddSumA * _three_phase_at_load_9__area_2__power_meter_power__IoddSumA)) > 0.0) {
                _three_phase_at_load_9__area_2__power_meter_power__Qa *= -1;
            }
        }
        _three_phase_at_load_9__area_2__power_meter_power__Qb = _three_phase_at_load_9__area_2__power_meter_power__Sb * _three_phase_at_load_9__area_2__power_meter_power__Sb - _three_phase_at_load_9__area_2__power_meter_power__Pb * _three_phase_at_load_9__area_2__power_meter_power__Pb;
        if (_three_phase_at_load_9__area_2__power_meter_power__Qb < 0.0) {
            _three_phase_at_load_9__area_2__power_meter_power__Qb = 0.0;
        }
        else {
            _three_phase_at_load_9__area_2__power_meter_power__Qb = sqrt(_three_phase_at_load_9__area_2__power_meter_power__Qb);
            if (atan2f((_three_phase_at_load_9__area_2__power_meter_power__VoddSumB * _three_phase_at_load_9__area_2__power_meter_power__IevenSumB - _three_phase_at_load_9__area_2__power_meter_power__IoddSumB * _three_phase_at_load_9__area_2__power_meter_power__VevenSumB), (_three_phase_at_load_9__area_2__power_meter_power__VevenSumB * _three_phase_at_load_9__area_2__power_meter_power__IevenSumB + _three_phase_at_load_9__area_2__power_meter_power__VoddSumB * _three_phase_at_load_9__area_2__power_meter_power__IoddSumB)) > 0.0) {
                _three_phase_at_load_9__area_2__power_meter_power__Qb *= -1;
            }
        }
        _three_phase_at_load_9__area_2__power_meter_power__Qc = _three_phase_at_load_9__area_2__power_meter_power__Sc * _three_phase_at_load_9__area_2__power_meter_power__Sc - _three_phase_at_load_9__area_2__power_meter_power__Pc * _three_phase_at_load_9__area_2__power_meter_power__Pc;
        if (_three_phase_at_load_9__area_2__power_meter_power__Qc < 0.0) {
            _three_phase_at_load_9__area_2__power_meter_power__Qc = 0.0;
        }
        else {
            _three_phase_at_load_9__area_2__power_meter_power__Qc = sqrt(_three_phase_at_load_9__area_2__power_meter_power__Qc);
            if (atan2f((_three_phase_at_load_9__area_2__power_meter_power__VoddSumC * _three_phase_at_load_9__area_2__power_meter_power__IevenSumC - _three_phase_at_load_9__area_2__power_meter_power__IoddSumC * _three_phase_at_load_9__area_2__power_meter_power__VevenSumC), (_three_phase_at_load_9__area_2__power_meter_power__VevenSumC * _three_phase_at_load_9__area_2__power_meter_power__IevenSumC + _three_phase_at_load_9__area_2__power_meter_power__VoddSumC * _three_phase_at_load_9__area_2__power_meter_power__IoddSumC)) > 0.0) {
                _three_phase_at_load_9__area_2__power_meter_power__Qc *= -1;
            }
        }
        _three_phase_at_load_9__area_2__power_meter_power__Q = _three_phase_at_load_9__area_2__power_meter_power__Qa + _three_phase_at_load_9__area_2__power_meter_power__Qb + _three_phase_at_load_9__area_2__power_meter_power__Qc;
        if (_three_phase_at_load_9__area_2__power_meter_power__Sa > 0) {
            _three_phase_at_load_9__area_2__power_meter_power__PFa = _three_phase_at_load_9__area_2__power_meter_power__Pa / _three_phase_at_load_9__area_2__power_meter_power__Sa;
        }
        else {
            _three_phase_at_load_9__area_2__power_meter_power__PFa = 0.0;
        }
        if (_three_phase_at_load_9__area_2__power_meter_power__Sb > 0) {
            _three_phase_at_load_9__area_2__power_meter_power__PFb = _three_phase_at_load_9__area_2__power_meter_power__Pb / _three_phase_at_load_9__area_2__power_meter_power__Sb;
        }
        else {
            _three_phase_at_load_9__area_2__power_meter_power__PFb = 0.0;
        }
        if (_three_phase_at_load_9__area_2__power_meter_power__Sc > 0) {
            _three_phase_at_load_9__area_2__power_meter_power__PFc = _three_phase_at_load_9__area_2__power_meter_power__Pc / _three_phase_at_load_9__area_2__power_meter_power__Sc;
        }
        else {
            _three_phase_at_load_9__area_2__power_meter_power__PFc = 0.0;
        }
        if (_three_phase_at_load_9__area_2__power_meter_power__S > 0) {
            _three_phase_at_load_9__area_2__power_meter_power__PF = _three_phase_at_load_9__area_2__power_meter_power__P / _three_phase_at_load_9__area_2__power_meter_power__S;
        }
        else {
            _three_phase_at_load_9__area_2__power_meter_power__PF = 0.0;
        }
        break ;
    case 5:
        _three_phase_at_load_9__area_2__power_meter_power__Pa = _three_phase_at_load_9__area_2__power_meter_power__Va * _three_phase_at_load_9__area_2__power_meter_power__Ia;
        _three_phase_at_load_9__area_2__power_meter_power__Pb = _three_phase_at_load_9__area_2__power_meter_power__Vb * _three_phase_at_load_9__area_2__power_meter_power__Ib;
        _three_phase_at_load_9__area_2__power_meter_power__Pc = _three_phase_at_load_9__area_2__power_meter_power__Vc * _three_phase_at_load_9__area_2__power_meter_power__Ic;
        _three_phase_at_load_9__area_2__power_meter_power__P = _three_phase_at_load_9__area_2__power_meter_power__Pa + _three_phase_at_load_9__area_2__power_meter_power__Pb + _three_phase_at_load_9__area_2__power_meter_power__Pc;
        _three_phase_at_load_9__area_2__power_meter_power__Qa = 0;
        _three_phase_at_load_9__area_2__power_meter_power__Qb = 0;
        _three_phase_at_load_9__area_2__power_meter_power__Qc = 0;
        _three_phase_at_load_9__area_2__power_meter_power__Q = 0.0;
        _three_phase_at_load_9__area_2__power_meter_power__Sa = 0;
        _three_phase_at_load_9__area_2__power_meter_power__Sb = 0;
        _three_phase_at_load_9__area_2__power_meter_power__Sc = 0;
        _three_phase_at_load_9__area_2__power_meter_power__S = 0;
        _three_phase_at_load_9__area_2__power_meter_power__PFa = 0.0;
        _three_phase_at_load_9__area_2__power_meter_power__PFb = 0.0;
        _three_phase_at_load_9__area_2__power_meter_power__PFc = 0.0;
        _three_phase_at_load_9__area_2__power_meter_power__PF = 0.0;
        break ;
    }
    // Generated from the component: Three-phase at load 9 (area 2).VAn_RMS
    HIL_OutAO(0x40c6, (float)_three_phase_at_load_9__area_2__vln_rms_calc_rms__RMS1);
    // Generated from the component: Three-phase at load 9 (area 2).VBn_RMS
    HIL_OutAO(0x40c8, (float)_three_phase_at_load_9__area_2__vln_rms_calc_rms__RMS2);
    // Generated from the component: Three-phase at load 9 (area 2).VCn_RMS
    HIL_OutAO(0x40ca, (float)_three_phase_at_load_9__area_2__vln_rms_calc_rms__RMS3);
    // Generated from the component: Three-phase at load 9 (area 2).PLL.abc to dq.LPF_d
    _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_d__previous_filtered_value = _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_d__filtered_value;
    _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_d__filtered_value = _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_d__previous_in * (1.0 * 62.83185307 * 0.0001) + _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_d__previous_filtered_value * (1 - 1.0 * 62.83185307 * 0.0001 );
    _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_d__out = _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_d__filtered_value;
    _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_d__previous_in = _three_phase_at_load_9__area_2__pll_abc_to_dq_alpha_beta_to_dq__d;
    // Generated from the component: Three-phase at load 9 (area 2).PLL.abc to dq.LPF_q
    _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_q__previous_filtered_value = _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_q__filtered_value;
    _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_q__filtered_value = _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_q__previous_in * (1.0 * 62.83185307 * 0.0001) + _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_q__previous_filtered_value * (1 - 1.0 * 62.83185307 * 0.0001 );
    _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_q__out = _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_q__filtered_value;
    _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_q__previous_in = _three_phase_at_load_9__area_2__pll_abc_to_dq_alpha_beta_to_dq__q;
    // Generated from the component: Three-phase at load 7 (area 1).POWER_P
    HIL_OutAO(0x4084, (float)_three_phase_at_load_7__area_1__power_meter_power__P);
    // Generated from the component: Three-phase at load 7 (area 1).POWER_PA
    HIL_OutAO(0x4085, (float)_three_phase_at_load_7__area_1__power_meter_power__Pa);
    // Generated from the component: Three-phase at load 7 (area 1).POWER_PB
    HIL_OutAO(0x4086, (float)_three_phase_at_load_7__area_1__power_meter_power__Pb);
    // Generated from the component: Three-phase at load 7 (area 1).POWER_PC
    HIL_OutAO(0x4087, (float)_three_phase_at_load_7__area_1__power_meter_power__Pc);
    // Generated from the component: Three-phase at load 7 (area 1).POWER_PF
    HIL_OutAO(0x4088, (float)_three_phase_at_load_7__area_1__power_meter_power__PF);
    // Generated from the component: Three-phase at load 7 (area 1).POWER_PFA
    HIL_OutAO(0x4089, (float)_three_phase_at_load_7__area_1__power_meter_power__PFa);
    // Generated from the component: Three-phase at load 7 (area 1).POWER_PFB
    HIL_OutAO(0x408a, (float)_three_phase_at_load_7__area_1__power_meter_power__PFb);
    // Generated from the component: Three-phase at load 7 (area 1).POWER_PFC
    HIL_OutAO(0x408b, (float)_three_phase_at_load_7__area_1__power_meter_power__PFc);
    // Generated from the component: Three-phase at load 7 (area 1).POWER_Q
    HIL_OutAO(0x408c, (float)_three_phase_at_load_7__area_1__power_meter_power__Q);
    // Generated from the component: Three-phase at load 7 (area 1).POWER_QA
    HIL_OutAO(0x408d, (float)_three_phase_at_load_7__area_1__power_meter_power__Qa);
    // Generated from the component: Three-phase at load 7 (area 1).POWER_QB
    HIL_OutAO(0x408e, (float)_three_phase_at_load_7__area_1__power_meter_power__Qb);
    // Generated from the component: Three-phase at load 7 (area 1).POWER_QC
    HIL_OutAO(0x408f, (float)_three_phase_at_load_7__area_1__power_meter_power__Qc);
    // Generated from the component: Three-phase at load 7 (area 1).POWER_S
    HIL_OutAO(0x4090, (float)_three_phase_at_load_7__area_1__power_meter_power__S);
    // Generated from the component: Three-phase at load 7 (area 1).POWER_SA
    HIL_OutAO(0x4091, (float)_three_phase_at_load_7__area_1__power_meter_power__Sa);
    // Generated from the component: Three-phase at load 7 (area 1).POWER_SB
    HIL_OutAO(0x4092, (float)_three_phase_at_load_7__area_1__power_meter_power__Sb);
    // Generated from the component: Three-phase at load 7 (area 1).POWER_SC
    HIL_OutAO(0x4093, (float)_three_phase_at_load_7__area_1__power_meter_power__Sc);
    // Generated from the component: Three-phase at load 7 (area 1).extra_output_bus
    _three_phase_at_load_7__area_1__extra_output_bus__out[0] = _three_phase_at_load_7__area_1__power_meter_power__Pa;
    _three_phase_at_load_7__area_1__extra_output_bus__out[1] = _three_phase_at_load_7__area_1__power_meter_power__Pb;
    _three_phase_at_load_7__area_1__extra_output_bus__out[2] = _three_phase_at_load_7__area_1__power_meter_power__Pc;
    _three_phase_at_load_7__area_1__extra_output_bus__out[3] = _three_phase_at_load_7__area_1__power_meter_power__Qa;
    _three_phase_at_load_7__area_1__extra_output_bus__out[4] = _three_phase_at_load_7__area_1__power_meter_power__Qb;
    _three_phase_at_load_7__area_1__extra_output_bus__out[5] = _three_phase_at_load_7__area_1__power_meter_power__Qc;
    _three_phase_at_load_7__area_1__extra_output_bus__out[6] = _three_phase_at_load_7__area_1__power_meter_power__Sa;
    _three_phase_at_load_7__area_1__extra_output_bus__out[7] = _three_phase_at_load_7__area_1__power_meter_power__Sb;
    _three_phase_at_load_7__area_1__extra_output_bus__out[8] = _three_phase_at_load_7__area_1__power_meter_power__Sc;
    _three_phase_at_load_7__area_1__extra_output_bus__out[9] = _three_phase_at_load_7__area_1__power_meter_power__PFa;
    _three_phase_at_load_7__area_1__extra_output_bus__out[10] = _three_phase_at_load_7__area_1__power_meter_power__PFb;
    _three_phase_at_load_7__area_1__extra_output_bus__out[11] = _three_phase_at_load_7__area_1__power_meter_power__PFc;
    // Generated from the component: Three-phase at load 7 (area 1).output_bus
    _three_phase_at_load_7__area_1__output_bus__out[0] = _three_phase_at_load_7__area_1__van_va1__out;
    _three_phase_at_load_7__area_1__output_bus__out[1] = _three_phase_at_load_7__area_1__vbn_va1__out;
    _three_phase_at_load_7__area_1__output_bus__out[2] = _three_phase_at_load_7__area_1__vcn_va1__out;
    _three_phase_at_load_7__area_1__output_bus__out[3] = _three_phase_at_load_7__area_1__vab_va1__out;
    _three_phase_at_load_7__area_1__output_bus__out[4] = _three_phase_at_load_7__area_1__vbc_va1__out;
    _three_phase_at_load_7__area_1__output_bus__out[5] = _three_phase_at_load_7__area_1__vca_va1__out;
    _three_phase_at_load_7__area_1__output_bus__out[6] = _three_phase_at_load_7__area_1__ia_ia1__out;
    _three_phase_at_load_7__area_1__output_bus__out[7] = _three_phase_at_load_7__area_1__ib_ia1__out;
    _three_phase_at_load_7__area_1__output_bus__out[8] = _three_phase_at_load_7__area_1__ic_ia1__out;
    _three_phase_at_load_7__area_1__output_bus__out[9] = _three_phase_at_load_7__area_1__pll_to_hz__out;
    _three_phase_at_load_7__area_1__output_bus__out[10] = _three_phase_at_load_7__area_1__vln_rms_calc_rms__RMS1;
    _three_phase_at_load_7__area_1__output_bus__out[11] = _three_phase_at_load_7__area_1__vln_rms_calc_rms__RMS2;
    _three_phase_at_load_7__area_1__output_bus__out[12] = _three_phase_at_load_7__area_1__vln_rms_calc_rms__RMS3;
    _three_phase_at_load_7__area_1__output_bus__out[13] = _three_phase_at_load_7__area_1__zero__out;
    _three_phase_at_load_7__area_1__output_bus__out[14] = _three_phase_at_load_7__area_1__vll_rms_calc_rms__RMS1;
    _three_phase_at_load_7__area_1__output_bus__out[15] = _three_phase_at_load_7__area_1__vll_rms_calc_rms__RMS2;
    _three_phase_at_load_7__area_1__output_bus__out[16] = _three_phase_at_load_7__area_1__vll_rms_calc_rms__RMS3;
    _three_phase_at_load_7__area_1__output_bus__out[17] = _three_phase_at_load_7__area_1__zero__out;
    _three_phase_at_load_7__area_1__output_bus__out[18] = _three_phase_at_load_7__area_1__i_rms_calc_rms__RMS1;
    _three_phase_at_load_7__area_1__output_bus__out[19] = _three_phase_at_load_7__area_1__i_rms_calc_rms__RMS2;
    _three_phase_at_load_7__area_1__output_bus__out[20] = _three_phase_at_load_7__area_1__i_rms_calc_rms__RMS3;
    _three_phase_at_load_7__area_1__output_bus__out[21] = _three_phase_at_load_7__area_1__zero__out;
    _three_phase_at_load_7__area_1__output_bus__out[22] = _three_phase_at_load_7__area_1__power_meter_power__P;
    _three_phase_at_load_7__area_1__output_bus__out[23] = _three_phase_at_load_7__area_1__power_meter_power__Q;
    _three_phase_at_load_7__area_1__output_bus__out[24] = _three_phase_at_load_7__area_1__power_meter_power__S;
    _three_phase_at_load_7__area_1__output_bus__out[25] = _three_phase_at_load_7__area_1__power_meter_power__PF;
    _three_phase_at_load_7__area_1__output_bus__out[26] = _three_phase_at_load_7__area_1__zero__out;
    _three_phase_at_load_7__area_1__output_bus__out[27] = _three_phase_at_load_7__area_1__zero__out;
    _three_phase_at_load_7__area_1__output_bus__out[28] = _three_phase_at_load_7__area_1__zero__out;
    _three_phase_at_load_7__area_1__output_bus__out[29] = _three_phase_at_load_7__area_1__zero__out;
    // Generated from the component: Three-phase at load 7 (area 1).TRMd
    // Generated from the component: Three-phase at load 7 (area 1).PLL.normalize
    _three_phase_at_load_7__area_1__pll_normalize__in1 = _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_d__out;
    _three_phase_at_load_7__area_1__pll_normalize__in2 = _three_phase_at_load_7__area_1__pll_abc_to_dq_lpf_q__out;
    _three_phase_at_load_7__area_1__pll_normalize__pk = (powf(_three_phase_at_load_7__area_1__pll_normalize__in1, 2.0) + powf(_three_phase_at_load_7__area_1__pll_normalize__in2, 2.0));
    _three_phase_at_load_7__area_1__pll_normalize__pk = sqrt(_three_phase_at_load_7__area_1__pll_normalize__pk);
    if (_three_phase_at_load_7__area_1__pll_normalize__pk < 0.1) {
        _three_phase_at_load_7__area_1__pll_normalize__in2_pu = _three_phase_at_load_7__area_1__pll_normalize__in2 / 0.1;
    }
    else {
        _three_phase_at_load_7__area_1__pll_normalize__in2_pu = _three_phase_at_load_7__area_1__pll_normalize__in2 / _three_phase_at_load_7__area_1__pll_normalize__pk;
    }
    // Generated from the component: Three-phase at load 7 (area 1).TRMq
    // Generated from the component: Three-phase at load 8 (mid).POWER_P
    HIL_OutAO(0x409e, (float)_three_phase_at_load_8__mid__power_meter_power__P);
    // Generated from the component: Three-phase at load 8 (mid).POWER_PA
    HIL_OutAO(0x409f, (float)_three_phase_at_load_8__mid__power_meter_power__Pa);
    // Generated from the component: Three-phase at load 8 (mid).POWER_PB
    HIL_OutAO(0x40a0, (float)_three_phase_at_load_8__mid__power_meter_power__Pb);
    // Generated from the component: Three-phase at load 8 (mid).POWER_PC
    HIL_OutAO(0x40a1, (float)_three_phase_at_load_8__mid__power_meter_power__Pc);
    // Generated from the component: Three-phase at load 8 (mid).POWER_PF
    HIL_OutAO(0x40a2, (float)_three_phase_at_load_8__mid__power_meter_power__PF);
    // Generated from the component: Three-phase at load 8 (mid).POWER_PFA
    HIL_OutAO(0x40a3, (float)_three_phase_at_load_8__mid__power_meter_power__PFa);
    // Generated from the component: Three-phase at load 8 (mid).POWER_PFB
    HIL_OutAO(0x40a4, (float)_three_phase_at_load_8__mid__power_meter_power__PFb);
    // Generated from the component: Three-phase at load 8 (mid).POWER_PFC
    HIL_OutAO(0x40a5, (float)_three_phase_at_load_8__mid__power_meter_power__PFc);
    // Generated from the component: Three-phase at load 8 (mid).POWER_Q
    HIL_OutAO(0x40a6, (float)_three_phase_at_load_8__mid__power_meter_power__Q);
    // Generated from the component: Three-phase at load 8 (mid).POWER_QA
    HIL_OutAO(0x40a7, (float)_three_phase_at_load_8__mid__power_meter_power__Qa);
    // Generated from the component: Three-phase at load 8 (mid).POWER_QB
    HIL_OutAO(0x40a8, (float)_three_phase_at_load_8__mid__power_meter_power__Qb);
    // Generated from the component: Three-phase at load 8 (mid).POWER_QC
    HIL_OutAO(0x40a9, (float)_three_phase_at_load_8__mid__power_meter_power__Qc);
    // Generated from the component: Three-phase at load 8 (mid).POWER_S
    HIL_OutAO(0x40aa, (float)_three_phase_at_load_8__mid__power_meter_power__S);
    // Generated from the component: Three-phase at load 8 (mid).POWER_SA
    HIL_OutAO(0x40ab, (float)_three_phase_at_load_8__mid__power_meter_power__Sa);
    // Generated from the component: Three-phase at load 8 (mid).POWER_SB
    HIL_OutAO(0x40ac, (float)_three_phase_at_load_8__mid__power_meter_power__Sb);
    // Generated from the component: Three-phase at load 8 (mid).POWER_SC
    HIL_OutAO(0x40ad, (float)_three_phase_at_load_8__mid__power_meter_power__Sc);
    // Generated from the component: Three-phase at load 8 (mid).extra_output_bus
    _three_phase_at_load_8__mid__extra_output_bus__out[0] = _three_phase_at_load_8__mid__power_meter_power__Pa;
    _three_phase_at_load_8__mid__extra_output_bus__out[1] = _three_phase_at_load_8__mid__power_meter_power__Pb;
    _three_phase_at_load_8__mid__extra_output_bus__out[2] = _three_phase_at_load_8__mid__power_meter_power__Pc;
    _three_phase_at_load_8__mid__extra_output_bus__out[3] = _three_phase_at_load_8__mid__power_meter_power__Qa;
    _three_phase_at_load_8__mid__extra_output_bus__out[4] = _three_phase_at_load_8__mid__power_meter_power__Qb;
    _three_phase_at_load_8__mid__extra_output_bus__out[5] = _three_phase_at_load_8__mid__power_meter_power__Qc;
    _three_phase_at_load_8__mid__extra_output_bus__out[6] = _three_phase_at_load_8__mid__power_meter_power__Sa;
    _three_phase_at_load_8__mid__extra_output_bus__out[7] = _three_phase_at_load_8__mid__power_meter_power__Sb;
    _three_phase_at_load_8__mid__extra_output_bus__out[8] = _three_phase_at_load_8__mid__power_meter_power__Sc;
    _three_phase_at_load_8__mid__extra_output_bus__out[9] = _three_phase_at_load_8__mid__power_meter_power__PFa;
    _three_phase_at_load_8__mid__extra_output_bus__out[10] = _three_phase_at_load_8__mid__power_meter_power__PFb;
    _three_phase_at_load_8__mid__extra_output_bus__out[11] = _three_phase_at_load_8__mid__power_meter_power__PFc;
    // Generated from the component: Three-phase at load 8 (mid).output_bus
    _three_phase_at_load_8__mid__output_bus__out[0] = _three_phase_at_load_8__mid__van_va1__out;
    _three_phase_at_load_8__mid__output_bus__out[1] = _three_phase_at_load_8__mid__vbn_va1__out;
    _three_phase_at_load_8__mid__output_bus__out[2] = _three_phase_at_load_8__mid__vcn_va1__out;
    _three_phase_at_load_8__mid__output_bus__out[3] = _three_phase_at_load_8__mid__vab_va1__out;
    _three_phase_at_load_8__mid__output_bus__out[4] = _three_phase_at_load_8__mid__vbc_va1__out;
    _three_phase_at_load_8__mid__output_bus__out[5] = _three_phase_at_load_8__mid__vca_va1__out;
    _three_phase_at_load_8__mid__output_bus__out[6] = _three_phase_at_load_8__mid__ia_ia1__out;
    _three_phase_at_load_8__mid__output_bus__out[7] = _three_phase_at_load_8__mid__ib_ia1__out;
    _three_phase_at_load_8__mid__output_bus__out[8] = _three_phase_at_load_8__mid__ic_ia1__out;
    _three_phase_at_load_8__mid__output_bus__out[9] = _three_phase_at_load_8__mid__pll_to_hz__out;
    _three_phase_at_load_8__mid__output_bus__out[10] = _three_phase_at_load_8__mid__vln_rms_calc_rms__RMS1;
    _three_phase_at_load_8__mid__output_bus__out[11] = _three_phase_at_load_8__mid__vln_rms_calc_rms__RMS2;
    _three_phase_at_load_8__mid__output_bus__out[12] = _three_phase_at_load_8__mid__vln_rms_calc_rms__RMS3;
    _three_phase_at_load_8__mid__output_bus__out[13] = _three_phase_at_load_8__mid__zero__out;
    _three_phase_at_load_8__mid__output_bus__out[14] = _three_phase_at_load_8__mid__zero__out;
    _three_phase_at_load_8__mid__output_bus__out[15] = _three_phase_at_load_8__mid__zero__out;
    _three_phase_at_load_8__mid__output_bus__out[16] = _three_phase_at_load_8__mid__zero__out;
    _three_phase_at_load_8__mid__output_bus__out[17] = _three_phase_at_load_8__mid__zero__out;
    _three_phase_at_load_8__mid__output_bus__out[18] = _three_phase_at_load_8__mid__i_rms_calc_rms__RMS1;
    _three_phase_at_load_8__mid__output_bus__out[19] = _three_phase_at_load_8__mid__i_rms_calc_rms__RMS2;
    _three_phase_at_load_8__mid__output_bus__out[20] = _three_phase_at_load_8__mid__i_rms_calc_rms__RMS3;
    _three_phase_at_load_8__mid__output_bus__out[21] = _three_phase_at_load_8__mid__zero__out;
    _three_phase_at_load_8__mid__output_bus__out[22] = _three_phase_at_load_8__mid__power_meter_power__P;
    _three_phase_at_load_8__mid__output_bus__out[23] = _three_phase_at_load_8__mid__power_meter_power__Q;
    _three_phase_at_load_8__mid__output_bus__out[24] = _three_phase_at_load_8__mid__power_meter_power__S;
    _three_phase_at_load_8__mid__output_bus__out[25] = _three_phase_at_load_8__mid__power_meter_power__PF;
    _three_phase_at_load_8__mid__output_bus__out[26] = _three_phase_at_load_8__mid__zero__out;
    _three_phase_at_load_8__mid__output_bus__out[27] = _three_phase_at_load_8__mid__zero__out;
    _three_phase_at_load_8__mid__output_bus__out[28] = _three_phase_at_load_8__mid__zero__out;
    _three_phase_at_load_8__mid__output_bus__out[29] = _three_phase_at_load_8__mid__zero__out;
    // Generated from the component: Three-phase at load 8 (mid).TRMd
    // Generated from the component: Three-phase at load 8 (mid).PLL.normalize
    _three_phase_at_load_8__mid__pll_normalize__in1 = _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_d__out;
    _three_phase_at_load_8__mid__pll_normalize__in2 = _three_phase_at_load_8__mid__pll_abc_to_dq_lpf_q__out;
    _three_phase_at_load_8__mid__pll_normalize__pk = (powf(_three_phase_at_load_8__mid__pll_normalize__in1, 2.0) + powf(_three_phase_at_load_8__mid__pll_normalize__in2, 2.0));
    _three_phase_at_load_8__mid__pll_normalize__pk = sqrt(_three_phase_at_load_8__mid__pll_normalize__pk);
    if (_three_phase_at_load_8__mid__pll_normalize__pk < 0.1) {
        _three_phase_at_load_8__mid__pll_normalize__in2_pu = _three_phase_at_load_8__mid__pll_normalize__in2 / 0.1;
    }
    else {
        _three_phase_at_load_8__mid__pll_normalize__in2_pu = _three_phase_at_load_8__mid__pll_normalize__in2 / _three_phase_at_load_8__mid__pll_normalize__pk;
    }
    // Generated from the component: Three-phase at load 8 (mid).TRMq
    // Generated from the component: Three-phase at load 9 (area 2).POWER_P
    HIL_OutAO(0x40b5, (float)_three_phase_at_load_9__area_2__power_meter_power__P);
    // Generated from the component: Three-phase at load 9 (area 2).POWER_PA
    HIL_OutAO(0x40b6, (float)_three_phase_at_load_9__area_2__power_meter_power__Pa);
    // Generated from the component: Three-phase at load 9 (area 2).POWER_PB
    HIL_OutAO(0x40b7, (float)_three_phase_at_load_9__area_2__power_meter_power__Pb);
    // Generated from the component: Three-phase at load 9 (area 2).POWER_PC
    HIL_OutAO(0x40b8, (float)_three_phase_at_load_9__area_2__power_meter_power__Pc);
    // Generated from the component: Three-phase at load 9 (area 2).POWER_PF
    HIL_OutAO(0x40b9, (float)_three_phase_at_load_9__area_2__power_meter_power__PF);
    // Generated from the component: Three-phase at load 9 (area 2).POWER_PFA
    HIL_OutAO(0x40ba, (float)_three_phase_at_load_9__area_2__power_meter_power__PFa);
    // Generated from the component: Three-phase at load 9 (area 2).POWER_PFB
    HIL_OutAO(0x40bb, (float)_three_phase_at_load_9__area_2__power_meter_power__PFb);
    // Generated from the component: Three-phase at load 9 (area 2).POWER_PFC
    HIL_OutAO(0x40bc, (float)_three_phase_at_load_9__area_2__power_meter_power__PFc);
    // Generated from the component: Three-phase at load 9 (area 2).POWER_Q
    HIL_OutAO(0x40bd, (float)_three_phase_at_load_9__area_2__power_meter_power__Q);
    // Generated from the component: Three-phase at load 9 (area 2).POWER_QA
    HIL_OutAO(0x40be, (float)_three_phase_at_load_9__area_2__power_meter_power__Qa);
    // Generated from the component: Three-phase at load 9 (area 2).POWER_QB
    HIL_OutAO(0x40bf, (float)_three_phase_at_load_9__area_2__power_meter_power__Qb);
    // Generated from the component: Three-phase at load 9 (area 2).POWER_QC
    HIL_OutAO(0x40c0, (float)_three_phase_at_load_9__area_2__power_meter_power__Qc);
    // Generated from the component: Three-phase at load 9 (area 2).POWER_S
    HIL_OutAO(0x40c1, (float)_three_phase_at_load_9__area_2__power_meter_power__S);
    // Generated from the component: Three-phase at load 9 (area 2).POWER_SA
    HIL_OutAO(0x40c2, (float)_three_phase_at_load_9__area_2__power_meter_power__Sa);
    // Generated from the component: Three-phase at load 9 (area 2).POWER_SB
    HIL_OutAO(0x40c3, (float)_three_phase_at_load_9__area_2__power_meter_power__Sb);
    // Generated from the component: Three-phase at load 9 (area 2).POWER_SC
    HIL_OutAO(0x40c4, (float)_three_phase_at_load_9__area_2__power_meter_power__Sc);
    // Generated from the component: Three-phase at load 9 (area 2).extra_output_bus
    _three_phase_at_load_9__area_2__extra_output_bus__out[0] = _three_phase_at_load_9__area_2__power_meter_power__Pa;
    _three_phase_at_load_9__area_2__extra_output_bus__out[1] = _three_phase_at_load_9__area_2__power_meter_power__Pb;
    _three_phase_at_load_9__area_2__extra_output_bus__out[2] = _three_phase_at_load_9__area_2__power_meter_power__Pc;
    _three_phase_at_load_9__area_2__extra_output_bus__out[3] = _three_phase_at_load_9__area_2__power_meter_power__Qa;
    _three_phase_at_load_9__area_2__extra_output_bus__out[4] = _three_phase_at_load_9__area_2__power_meter_power__Qb;
    _three_phase_at_load_9__area_2__extra_output_bus__out[5] = _three_phase_at_load_9__area_2__power_meter_power__Qc;
    _three_phase_at_load_9__area_2__extra_output_bus__out[6] = _three_phase_at_load_9__area_2__power_meter_power__Sa;
    _three_phase_at_load_9__area_2__extra_output_bus__out[7] = _three_phase_at_load_9__area_2__power_meter_power__Sb;
    _three_phase_at_load_9__area_2__extra_output_bus__out[8] = _three_phase_at_load_9__area_2__power_meter_power__Sc;
    _three_phase_at_load_9__area_2__extra_output_bus__out[9] = _three_phase_at_load_9__area_2__power_meter_power__PFa;
    _three_phase_at_load_9__area_2__extra_output_bus__out[10] = _three_phase_at_load_9__area_2__power_meter_power__PFb;
    _three_phase_at_load_9__area_2__extra_output_bus__out[11] = _three_phase_at_load_9__area_2__power_meter_power__PFc;
    // Generated from the component: Three-phase at load 9 (area 2).output_bus
    _three_phase_at_load_9__area_2__output_bus__out[0] = _three_phase_at_load_9__area_2__van_va1__out;
    _three_phase_at_load_9__area_2__output_bus__out[1] = _three_phase_at_load_9__area_2__vbn_va1__out;
    _three_phase_at_load_9__area_2__output_bus__out[2] = _three_phase_at_load_9__area_2__vcn_va1__out;
    _three_phase_at_load_9__area_2__output_bus__out[3] = _three_phase_at_load_9__area_2__vab_va1__out;
    _three_phase_at_load_9__area_2__output_bus__out[4] = _three_phase_at_load_9__area_2__vbc_va1__out;
    _three_phase_at_load_9__area_2__output_bus__out[5] = _three_phase_at_load_9__area_2__vca_va1__out;
    _three_phase_at_load_9__area_2__output_bus__out[6] = _three_phase_at_load_9__area_2__ia_ia1__out;
    _three_phase_at_load_9__area_2__output_bus__out[7] = _three_phase_at_load_9__area_2__ib_ia1__out;
    _three_phase_at_load_9__area_2__output_bus__out[8] = _three_phase_at_load_9__area_2__ic_ia1__out;
    _three_phase_at_load_9__area_2__output_bus__out[9] = _three_phase_at_load_9__area_2__pll_to_hz__out;
    _three_phase_at_load_9__area_2__output_bus__out[10] = _three_phase_at_load_9__area_2__vln_rms_calc_rms__RMS1;
    _three_phase_at_load_9__area_2__output_bus__out[11] = _three_phase_at_load_9__area_2__vln_rms_calc_rms__RMS2;
    _three_phase_at_load_9__area_2__output_bus__out[12] = _three_phase_at_load_9__area_2__vln_rms_calc_rms__RMS3;
    _three_phase_at_load_9__area_2__output_bus__out[13] = _three_phase_at_load_9__area_2__zero__out;
    _three_phase_at_load_9__area_2__output_bus__out[14] = _three_phase_at_load_9__area_2__vll_rms_calc_rms__RMS1;
    _three_phase_at_load_9__area_2__output_bus__out[15] = _three_phase_at_load_9__area_2__vll_rms_calc_rms__RMS2;
    _three_phase_at_load_9__area_2__output_bus__out[16] = _three_phase_at_load_9__area_2__vll_rms_calc_rms__RMS3;
    _three_phase_at_load_9__area_2__output_bus__out[17] = _three_phase_at_load_9__area_2__zero__out;
    _three_phase_at_load_9__area_2__output_bus__out[18] = _three_phase_at_load_9__area_2__i_rms_calc_rms__RMS1;
    _three_phase_at_load_9__area_2__output_bus__out[19] = _three_phase_at_load_9__area_2__i_rms_calc_rms__RMS2;
    _three_phase_at_load_9__area_2__output_bus__out[20] = _three_phase_at_load_9__area_2__i_rms_calc_rms__RMS3;
    _three_phase_at_load_9__area_2__output_bus__out[21] = _three_phase_at_load_9__area_2__zero__out;
    _three_phase_at_load_9__area_2__output_bus__out[22] = _three_phase_at_load_9__area_2__power_meter_power__P;
    _three_phase_at_load_9__area_2__output_bus__out[23] = _three_phase_at_load_9__area_2__power_meter_power__Q;
    _three_phase_at_load_9__area_2__output_bus__out[24] = _three_phase_at_load_9__area_2__power_meter_power__S;
    _three_phase_at_load_9__area_2__output_bus__out[25] = _three_phase_at_load_9__area_2__power_meter_power__PF;
    _three_phase_at_load_9__area_2__output_bus__out[26] = _three_phase_at_load_9__area_2__zero__out;
    _three_phase_at_load_9__area_2__output_bus__out[27] = _three_phase_at_load_9__area_2__zero__out;
    _three_phase_at_load_9__area_2__output_bus__out[28] = _three_phase_at_load_9__area_2__zero__out;
    _three_phase_at_load_9__area_2__output_bus__out[29] = _three_phase_at_load_9__area_2__zero__out;
    // Generated from the component: Three-phase at load 9 (area 2).TRMd
    // Generated from the component: Three-phase at load 9 (area 2).PLL.normalize
    _three_phase_at_load_9__area_2__pll_normalize__in1 = _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_d__out;
    _three_phase_at_load_9__area_2__pll_normalize__in2 = _three_phase_at_load_9__area_2__pll_abc_to_dq_lpf_q__out;
    _three_phase_at_load_9__area_2__pll_normalize__pk = (powf(_three_phase_at_load_9__area_2__pll_normalize__in1, 2.0) + powf(_three_phase_at_load_9__area_2__pll_normalize__in2, 2.0));
    _three_phase_at_load_9__area_2__pll_normalize__pk = sqrt(_three_phase_at_load_9__area_2__pll_normalize__pk);
    if (_three_phase_at_load_9__area_2__pll_normalize__pk < 0.1) {
        _three_phase_at_load_9__area_2__pll_normalize__in2_pu = _three_phase_at_load_9__area_2__pll_normalize__in2 / 0.1;
    }
    else {
        _three_phase_at_load_9__area_2__pll_normalize__in2_pu = _three_phase_at_load_9__area_2__pll_normalize__in2 / _three_phase_at_load_9__area_2__pll_normalize__pk;
    }
    // Generated from the component: Three-phase at load 9 (area 2).TRMq
    // Generated from the component: Three-phase at load 7 (area 1).extra_out
    // Generated from the component: Three-phase at load 7 (area 1).PLL.PID.Kd
    _three_phase_at_load_7__area_1__pll_pid_kd__out = 1.0 * _three_phase_at_load_7__area_1__pll_normalize__in2_pu;
    // Generated from the component: Three-phase at load 7 (area 1).PLL.PID.Ki
    _three_phase_at_load_7__area_1__pll_pid_ki__out = 3200.0 * _three_phase_at_load_7__area_1__pll_normalize__in2_pu;
    // Generated from the component: Three-phase at load 7 (area 1).PLL.PID.Kp
    _three_phase_at_load_7__area_1__pll_pid_kp__out = 100.0 * _three_phase_at_load_7__area_1__pll_normalize__in2_pu;
    // Generated from the component: Three-phase at load 7 (area 1).PLL.term_pk
    // Generated from the component: Three-phase at load 8 (mid).extra_out
    // Generated from the component: Three-phase at load 8 (mid).PLL.PID.Kd
    _three_phase_at_load_8__mid__pll_pid_kd__out = 1.0 * _three_phase_at_load_8__mid__pll_normalize__in2_pu;
    // Generated from the component: Three-phase at load 8 (mid).PLL.PID.Ki
    _three_phase_at_load_8__mid__pll_pid_ki__out = 3200.0 * _three_phase_at_load_8__mid__pll_normalize__in2_pu;
    // Generated from the component: Three-phase at load 8 (mid).PLL.PID.Kp
    _three_phase_at_load_8__mid__pll_pid_kp__out = 100.0 * _three_phase_at_load_8__mid__pll_normalize__in2_pu;
    // Generated from the component: Three-phase at load 8 (mid).PLL.term_pk
    // Generated from the component: Three-phase at load 9 (area 2).extra_out
    // Generated from the component: Three-phase at load 9 (area 2).PLL.PID.Kd
    _three_phase_at_load_9__area_2__pll_pid_kd__out = 1.0 * _three_phase_at_load_9__area_2__pll_normalize__in2_pu;
    // Generated from the component: Three-phase at load 9 (area 2).PLL.PID.Ki
    _three_phase_at_load_9__area_2__pll_pid_ki__out = 3200.0 * _three_phase_at_load_9__area_2__pll_normalize__in2_pu;
    // Generated from the component: Three-phase at load 9 (area 2).PLL.PID.Kp
    _three_phase_at_load_9__area_2__pll_pid_kp__out = 100.0 * _three_phase_at_load_9__area_2__pll_normalize__in2_pu;
    // Generated from the component: Three-phase at load 9 (area 2).PLL.term_pk
    // Generated from the component: Three-phase at load 7 (area 1).PLL.PID.Sum8
    _three_phase_at_load_7__area_1__pll_pid_sum8__out = _three_phase_at_load_7__area_1__pll_pid_kd__out - _three_phase_at_load_7__area_1__pll_pid_integrator2__out;
    // Generated from the component: Three-phase at load 8 (mid).PLL.PID.Sum8
    _three_phase_at_load_8__mid__pll_pid_sum8__out = _three_phase_at_load_8__mid__pll_pid_kd__out - _three_phase_at_load_8__mid__pll_pid_integrator2__out;
    // Generated from the component: Three-phase at load 9 (area 2).PLL.PID.Sum8
    _three_phase_at_load_9__area_2__pll_pid_sum8__out = _three_phase_at_load_9__area_2__pll_pid_kd__out - _three_phase_at_load_9__area_2__pll_pid_integrator2__out;
    // Generated from the component: Three-phase at load 7 (area 1).PLL.PID.Gain1
    _three_phase_at_load_7__area_1__pll_pid_gain1__out = 714.2857 * _three_phase_at_load_7__area_1__pll_pid_sum8__out;
    // Generated from the component: Three-phase at load 8 (mid).PLL.PID.Gain1
    _three_phase_at_load_8__mid__pll_pid_gain1__out = 714.2857 * _three_phase_at_load_8__mid__pll_pid_sum8__out;
    // Generated from the component: Three-phase at load 9 (area 2).PLL.PID.Gain1
    _three_phase_at_load_9__area_2__pll_pid_gain1__out = 714.2857 * _three_phase_at_load_9__area_2__pll_pid_sum8__out;
    // Generated from the component: Three-phase at load 7 (area 1).PLL.PID.Sum5
    _three_phase_at_load_7__area_1__pll_pid_sum5__out = _three_phase_at_load_7__area_1__pll_pid_kp__out + _three_phase_at_load_7__area_1__pll_pid_gain1__out + _three_phase_at_load_7__area_1__pll_pid_integrator1__out;
    // Generated from the component: Three-phase at load 8 (mid).PLL.PID.Sum5
    _three_phase_at_load_8__mid__pll_pid_sum5__out = _three_phase_at_load_8__mid__pll_pid_kp__out + _three_phase_at_load_8__mid__pll_pid_gain1__out + _three_phase_at_load_8__mid__pll_pid_integrator1__out;
    // Generated from the component: Three-phase at load 9 (area 2).PLL.PID.Sum5
    _three_phase_at_load_9__area_2__pll_pid_sum5__out = _three_phase_at_load_9__area_2__pll_pid_kp__out + _three_phase_at_load_9__area_2__pll_pid_gain1__out + _three_phase_at_load_9__area_2__pll_pid_integrator1__out;
    // Generated from the component: Three-phase at load 7 (area 1).PLL.PID.Limit1
    _three_phase_at_load_7__area_1__pll_pid_limit1__out = MIN(MAX(_three_phase_at_load_7__area_1__pll_pid_sum5__out, -10000.0), 10000.0);
    // Generated from the component: Three-phase at load 8 (mid).PLL.PID.Limit1
    _three_phase_at_load_8__mid__pll_pid_limit1__out = MIN(MAX(_three_phase_at_load_8__mid__pll_pid_sum5__out, -10000.0), 10000.0);
    // Generated from the component: Three-phase at load 9 (area 2).PLL.PID.Limit1
    _three_phase_at_load_9__area_2__pll_pid_limit1__out = MIN(MAX(_three_phase_at_load_9__area_2__pll_pid_sum5__out, -10000.0), 10000.0);
    // Generated from the component: Three-phase at load 7 (area 1).PLL.PID.Sum6
    _three_phase_at_load_7__area_1__pll_pid_sum6__out =  - _three_phase_at_load_7__area_1__pll_pid_sum5__out + _three_phase_at_load_7__area_1__pll_pid_limit1__out;
    // Generated from the component: Three-phase at load 7 (area 1).PLL.Rate Limiter1
    if (_three_phase_at_load_7__area_1__pll_rate_limiter1__first_step) {
        _three_phase_at_load_7__area_1__pll_rate_limiter1__out = _three_phase_at_load_7__area_1__pll_pid_limit1__out;
        _three_phase_at_load_7__area_1__pll_rate_limiter1__state = _three_phase_at_load_7__area_1__pll_pid_limit1__out;
    } else {
        _three_phase_at_load_7__area_1__pll_rate_limiter1__out = _three_phase_at_load_7__area_1__pll_pid_limit1__out;
        if (_three_phase_at_load_7__area_1__pll_pid_limit1__out - _three_phase_at_load_7__area_1__pll_rate_limiter1__state > 0.007539822368615503)
            _three_phase_at_load_7__area_1__pll_rate_limiter1__out = _three_phase_at_load_7__area_1__pll_rate_limiter1__state + (0.007539822368615503);
        if (_three_phase_at_load_7__area_1__pll_pid_limit1__out - _three_phase_at_load_7__area_1__pll_rate_limiter1__state < -0.007539822368615503)
            _three_phase_at_load_7__area_1__pll_rate_limiter1__out = _three_phase_at_load_7__area_1__pll_rate_limiter1__state + (-0.007539822368615503);
    }
    // Generated from the component: Three-phase at load 7 (area 1).PLL.integrator
    _three_phase_at_load_7__area_1__pll_integrator__in = _three_phase_at_load_7__area_1__pll_pid_limit1__out;
    _three_phase_at_load_7__area_1__pll_integrator__out += 0.0001 * _three_phase_at_load_7__area_1__pll_integrator__in;
    if (_three_phase_at_load_7__area_1__pll_integrator__in >= 0.0) {
        if (_three_phase_at_load_7__area_1__pll_integrator__out >= 6.283185307179586) {
            _three_phase_at_load_7__area_1__pll_integrator__out -= 6.283185307179586;
        }
    }
    else {
        if (_three_phase_at_load_7__area_1__pll_integrator__out <= -6.283185307179586) {
            _three_phase_at_load_7__area_1__pll_integrator__out += 6.283185307179586;
        }
    }
    // Generated from the component: Three-phase at load 8 (mid).PLL.PID.Sum6
    _three_phase_at_load_8__mid__pll_pid_sum6__out =  - _three_phase_at_load_8__mid__pll_pid_sum5__out + _three_phase_at_load_8__mid__pll_pid_limit1__out;
    // Generated from the component: Three-phase at load 8 (mid).PLL.Rate Limiter1
    if (_three_phase_at_load_8__mid__pll_rate_limiter1__first_step) {
        _three_phase_at_load_8__mid__pll_rate_limiter1__out = _three_phase_at_load_8__mid__pll_pid_limit1__out;
        _three_phase_at_load_8__mid__pll_rate_limiter1__state = _three_phase_at_load_8__mid__pll_pid_limit1__out;
    } else {
        _three_phase_at_load_8__mid__pll_rate_limiter1__out = _three_phase_at_load_8__mid__pll_pid_limit1__out;
        if (_three_phase_at_load_8__mid__pll_pid_limit1__out - _three_phase_at_load_8__mid__pll_rate_limiter1__state > 0.007539822368615503)
            _three_phase_at_load_8__mid__pll_rate_limiter1__out = _three_phase_at_load_8__mid__pll_rate_limiter1__state + (0.007539822368615503);
        if (_three_phase_at_load_8__mid__pll_pid_limit1__out - _three_phase_at_load_8__mid__pll_rate_limiter1__state < -0.007539822368615503)
            _three_phase_at_load_8__mid__pll_rate_limiter1__out = _three_phase_at_load_8__mid__pll_rate_limiter1__state + (-0.007539822368615503);
    }
    // Generated from the component: Three-phase at load 8 (mid).PLL.integrator
    _three_phase_at_load_8__mid__pll_integrator__in = _three_phase_at_load_8__mid__pll_pid_limit1__out;
    _three_phase_at_load_8__mid__pll_integrator__out += 0.0001 * _three_phase_at_load_8__mid__pll_integrator__in;
    if (_three_phase_at_load_8__mid__pll_integrator__in >= 0.0) {
        if (_three_phase_at_load_8__mid__pll_integrator__out >= 6.283185307179586) {
            _three_phase_at_load_8__mid__pll_integrator__out -= 6.283185307179586;
        }
    }
    else {
        if (_three_phase_at_load_8__mid__pll_integrator__out <= -6.283185307179586) {
            _three_phase_at_load_8__mid__pll_integrator__out += 6.283185307179586;
        }
    }
    // Generated from the component: Three-phase at load 9 (area 2).PLL.PID.Sum6
    _three_phase_at_load_9__area_2__pll_pid_sum6__out =  - _three_phase_at_load_9__area_2__pll_pid_sum5__out + _three_phase_at_load_9__area_2__pll_pid_limit1__out;
    // Generated from the component: Three-phase at load 9 (area 2).PLL.Rate Limiter1
    if (_three_phase_at_load_9__area_2__pll_rate_limiter1__first_step) {
        _three_phase_at_load_9__area_2__pll_rate_limiter1__out = _three_phase_at_load_9__area_2__pll_pid_limit1__out;
        _three_phase_at_load_9__area_2__pll_rate_limiter1__state = _three_phase_at_load_9__area_2__pll_pid_limit1__out;
    } else {
        _three_phase_at_load_9__area_2__pll_rate_limiter1__out = _three_phase_at_load_9__area_2__pll_pid_limit1__out;
        if (_three_phase_at_load_9__area_2__pll_pid_limit1__out - _three_phase_at_load_9__area_2__pll_rate_limiter1__state > 0.007539822368615503)
            _three_phase_at_load_9__area_2__pll_rate_limiter1__out = _three_phase_at_load_9__area_2__pll_rate_limiter1__state + (0.007539822368615503);
        if (_three_phase_at_load_9__area_2__pll_pid_limit1__out - _three_phase_at_load_9__area_2__pll_rate_limiter1__state < -0.007539822368615503)
            _three_phase_at_load_9__area_2__pll_rate_limiter1__out = _three_phase_at_load_9__area_2__pll_rate_limiter1__state + (-0.007539822368615503);
    }
    // Generated from the component: Three-phase at load 9 (area 2).PLL.integrator
    _three_phase_at_load_9__area_2__pll_integrator__in = _three_phase_at_load_9__area_2__pll_pid_limit1__out;
    _three_phase_at_load_9__area_2__pll_integrator__out += 0.0001 * _three_phase_at_load_9__area_2__pll_integrator__in;
    if (_three_phase_at_load_9__area_2__pll_integrator__in >= 0.0) {
        if (_three_phase_at_load_9__area_2__pll_integrator__out >= 6.283185307179586) {
            _three_phase_at_load_9__area_2__pll_integrator__out -= 6.283185307179586;
        }
    }
    else {
        if (_three_phase_at_load_9__area_2__pll_integrator__out <= -6.283185307179586) {
            _three_phase_at_load_9__area_2__pll_integrator__out += 6.283185307179586;
        }
    }
    // Generated from the component: Three-phase at load 7 (area 1).PLL.PID.Kb
    _three_phase_at_load_7__area_1__pll_pid_kb__out = 1.0 * _three_phase_at_load_7__area_1__pll_pid_sum6__out;
    // Generated from the component: Three-phase at load 7 (area 1).PLL.LPF.LPF
    X_UnInt32 _three_phase_at_load_7__area_1__pll_lpf_lpf__i;
    _three_phase_at_load_7__area_1__pll_lpf_lpf__a_sum = 0.0f;
    _three_phase_at_load_7__area_1__pll_lpf_lpf__b_sum = 0.0f;
    _three_phase_at_load_7__area_1__pll_lpf_lpf__delay_line_in = 0.0f;
    for (_three_phase_at_load_7__area_1__pll_lpf_lpf__i = 0; _three_phase_at_load_7__area_1__pll_lpf_lpf__i < 2; _three_phase_at_load_7__area_1__pll_lpf_lpf__i++) {
        _three_phase_at_load_7__area_1__pll_lpf_lpf__b_sum += _three_phase_at_load_7__area_1__pll_lpf_lpf__b_coeff[_three_phase_at_load_7__area_1__pll_lpf_lpf__i] * _three_phase_at_load_7__area_1__pll_lpf_lpf__states[_three_phase_at_load_7__area_1__pll_lpf_lpf__i + 0];
    }
    for (_three_phase_at_load_7__area_1__pll_lpf_lpf__i = 1; _three_phase_at_load_7__area_1__pll_lpf_lpf__i > 0; _three_phase_at_load_7__area_1__pll_lpf_lpf__i--) {
        _three_phase_at_load_7__area_1__pll_lpf_lpf__a_sum += _three_phase_at_load_7__area_1__pll_lpf_lpf__a_coeff[_three_phase_at_load_7__area_1__pll_lpf_lpf__i + 1] * _three_phase_at_load_7__area_1__pll_lpf_lpf__states[_three_phase_at_load_7__area_1__pll_lpf_lpf__i];
    }
    _three_phase_at_load_7__area_1__pll_lpf_lpf__a_sum += _three_phase_at_load_7__area_1__pll_lpf_lpf__states[0] * _three_phase_at_load_7__area_1__pll_lpf_lpf__a_coeff[1];
    _three_phase_at_load_7__area_1__pll_lpf_lpf__delay_line_in = _three_phase_at_load_7__area_1__pll_rate_limiter1__out - _three_phase_at_load_7__area_1__pll_lpf_lpf__a_sum;
    _three_phase_at_load_7__area_1__pll_lpf_lpf__out = _three_phase_at_load_7__area_1__pll_lpf_lpf__b_sum;
    // Generated from the component: Three-phase at load 8 (mid).PLL.PID.Kb
    _three_phase_at_load_8__mid__pll_pid_kb__out = 1.0 * _three_phase_at_load_8__mid__pll_pid_sum6__out;
    // Generated from the component: Three-phase at load 8 (mid).PLL.LPF.LPF
    X_UnInt32 _three_phase_at_load_8__mid__pll_lpf_lpf__i;
    _three_phase_at_load_8__mid__pll_lpf_lpf__a_sum = 0.0f;
    _three_phase_at_load_8__mid__pll_lpf_lpf__b_sum = 0.0f;
    _three_phase_at_load_8__mid__pll_lpf_lpf__delay_line_in = 0.0f;
    for (_three_phase_at_load_8__mid__pll_lpf_lpf__i = 0; _three_phase_at_load_8__mid__pll_lpf_lpf__i < 2; _three_phase_at_load_8__mid__pll_lpf_lpf__i++) {
        _three_phase_at_load_8__mid__pll_lpf_lpf__b_sum += _three_phase_at_load_8__mid__pll_lpf_lpf__b_coeff[_three_phase_at_load_8__mid__pll_lpf_lpf__i] * _three_phase_at_load_8__mid__pll_lpf_lpf__states[_three_phase_at_load_8__mid__pll_lpf_lpf__i + 0];
    }
    for (_three_phase_at_load_8__mid__pll_lpf_lpf__i = 1; _three_phase_at_load_8__mid__pll_lpf_lpf__i > 0; _three_phase_at_load_8__mid__pll_lpf_lpf__i--) {
        _three_phase_at_load_8__mid__pll_lpf_lpf__a_sum += _three_phase_at_load_8__mid__pll_lpf_lpf__a_coeff[_three_phase_at_load_8__mid__pll_lpf_lpf__i + 1] * _three_phase_at_load_8__mid__pll_lpf_lpf__states[_three_phase_at_load_8__mid__pll_lpf_lpf__i];
    }
    _three_phase_at_load_8__mid__pll_lpf_lpf__a_sum += _three_phase_at_load_8__mid__pll_lpf_lpf__states[0] * _three_phase_at_load_8__mid__pll_lpf_lpf__a_coeff[1];
    _three_phase_at_load_8__mid__pll_lpf_lpf__delay_line_in = _three_phase_at_load_8__mid__pll_rate_limiter1__out - _three_phase_at_load_8__mid__pll_lpf_lpf__a_sum;
    _three_phase_at_load_8__mid__pll_lpf_lpf__out = _three_phase_at_load_8__mid__pll_lpf_lpf__b_sum;
    // Generated from the component: Three-phase at load 9 (area 2).PLL.PID.Kb
    _three_phase_at_load_9__area_2__pll_pid_kb__out = 1.0 * _three_phase_at_load_9__area_2__pll_pid_sum6__out;
    // Generated from the component: Three-phase at load 9 (area 2).PLL.LPF.LPF
    X_UnInt32 _three_phase_at_load_9__area_2__pll_lpf_lpf__i;
    _three_phase_at_load_9__area_2__pll_lpf_lpf__a_sum = 0.0f;
    _three_phase_at_load_9__area_2__pll_lpf_lpf__b_sum = 0.0f;
    _three_phase_at_load_9__area_2__pll_lpf_lpf__delay_line_in = 0.0f;
    for (_three_phase_at_load_9__area_2__pll_lpf_lpf__i = 0; _three_phase_at_load_9__area_2__pll_lpf_lpf__i < 2; _three_phase_at_load_9__area_2__pll_lpf_lpf__i++) {
        _three_phase_at_load_9__area_2__pll_lpf_lpf__b_sum += _three_phase_at_load_9__area_2__pll_lpf_lpf__b_coeff[_three_phase_at_load_9__area_2__pll_lpf_lpf__i] * _three_phase_at_load_9__area_2__pll_lpf_lpf__states[_three_phase_at_load_9__area_2__pll_lpf_lpf__i + 0];
    }
    for (_three_phase_at_load_9__area_2__pll_lpf_lpf__i = 1; _three_phase_at_load_9__area_2__pll_lpf_lpf__i > 0; _three_phase_at_load_9__area_2__pll_lpf_lpf__i--) {
        _three_phase_at_load_9__area_2__pll_lpf_lpf__a_sum += _three_phase_at_load_9__area_2__pll_lpf_lpf__a_coeff[_three_phase_at_load_9__area_2__pll_lpf_lpf__i + 1] * _three_phase_at_load_9__area_2__pll_lpf_lpf__states[_three_phase_at_load_9__area_2__pll_lpf_lpf__i];
    }
    _three_phase_at_load_9__area_2__pll_lpf_lpf__a_sum += _three_phase_at_load_9__area_2__pll_lpf_lpf__states[0] * _three_phase_at_load_9__area_2__pll_lpf_lpf__a_coeff[1];
    _three_phase_at_load_9__area_2__pll_lpf_lpf__delay_line_in = _three_phase_at_load_9__area_2__pll_rate_limiter1__out - _three_phase_at_load_9__area_2__pll_lpf_lpf__a_sum;
    _three_phase_at_load_9__area_2__pll_lpf_lpf__out = _three_phase_at_load_9__area_2__pll_lpf_lpf__b_sum;
    // Generated from the component: Three-phase at load 7 (area 1).PLL.PID.Sum7
    _three_phase_at_load_7__area_1__pll_pid_sum7__out = _three_phase_at_load_7__area_1__pll_pid_ki__out + _three_phase_at_load_7__area_1__pll_pid_kb__out;
    // Generated from the component: Three-phase at load 8 (mid).PLL.PID.Sum7
    _three_phase_at_load_8__mid__pll_pid_sum7__out = _three_phase_at_load_8__mid__pll_pid_ki__out + _three_phase_at_load_8__mid__pll_pid_kb__out;
    // Generated from the component: Three-phase at load 9 (area 2).PLL.PID.Sum7
    _three_phase_at_load_9__area_2__pll_pid_sum7__out = _three_phase_at_load_9__area_2__pll_pid_ki__out + _three_phase_at_load_9__area_2__pll_pid_kb__out;
//@cmp.out.block.end
    //////////////////////////////////////////////////////////////////////////
    // Update block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.update.block.start
    // Generated from the component: Three-phase at load 7 (area 1).PLL.PID.Integrator1
    _three_phase_at_load_7__area_1__pll_pid_integrator1__state += _three_phase_at_load_7__area_1__pll_pid_sum7__out * 0.0001;
    // Generated from the component: Three-phase at load 7 (area 1).PLL.PID.Integrator2
    _three_phase_at_load_7__area_1__pll_pid_integrator2__state += _three_phase_at_load_7__area_1__pll_pid_gain1__out * 0.0001;
    // Generated from the component: Three-phase at load 7 (area 1).PLL.Unit Delay1
    _three_phase_at_load_7__area_1__pll_unit_delay1__state = _three_phase_at_load_7__area_1__pll_integrator__out;
    // Generated from the component: Three-phase at load 8 (mid).PLL.PID.Integrator1
    _three_phase_at_load_8__mid__pll_pid_integrator1__state += _three_phase_at_load_8__mid__pll_pid_sum7__out * 0.0001;
    // Generated from the component: Three-phase at load 8 (mid).PLL.PID.Integrator2
    _three_phase_at_load_8__mid__pll_pid_integrator2__state += _three_phase_at_load_8__mid__pll_pid_gain1__out * 0.0001;
    // Generated from the component: Three-phase at load 8 (mid).PLL.Unit Delay1
    _three_phase_at_load_8__mid__pll_unit_delay1__state = _three_phase_at_load_8__mid__pll_integrator__out;
    // Generated from the component: Three-phase at load 9 (area 2).PLL.PID.Integrator1
    _three_phase_at_load_9__area_2__pll_pid_integrator1__state += _three_phase_at_load_9__area_2__pll_pid_sum7__out * 0.0001;
    // Generated from the component: Three-phase at load 9 (area 2).PLL.PID.Integrator2
    _three_phase_at_load_9__area_2__pll_pid_integrator2__state += _three_phase_at_load_9__area_2__pll_pid_gain1__out * 0.0001;
    // Generated from the component: Three-phase at load 9 (area 2).PLL.Unit Delay1
    _three_phase_at_load_9__area_2__pll_unit_delay1__state = _three_phase_at_load_9__area_2__pll_integrator__out;
    // Generated from the component: Three-phase at load 7 (area 1).measSM.mode_and_dFract
    // Generated from the component: Three-phase at load 8 (mid).measSM.mode_and_dFract
    // Generated from the component: Three-phase at load 9 (area 2).measSM.mode_and_dFract
    // Generated from the component: Three-phase at load 7 (area 1).I_RMS_calc.RMS
    // Generated from the component: Three-phase at load 7 (area 1).VLL_RMS_calc.RMS
    // Generated from the component: Three-phase at load 7 (area 1).VLn_RMS_calc.RMS
    // Generated from the component: Three-phase at load 8 (mid).I_RMS_calc.RMS
    // Generated from the component: Three-phase at load 8 (mid).VLn_RMS_calc.RMS
    // Generated from the component: Three-phase at load 9 (area 2).I_RMS_calc.RMS
    // Generated from the component: Three-phase at load 9 (area 2).VLL_RMS_calc.RMS
    // Generated from the component: Three-phase at load 9 (area 2).VLn_RMS_calc.RMS
    // Generated from the component: Three-phase at load 7 (area 1).Power Meter.POWER
    // Generated from the component: Three-phase at load 8 (mid).Power Meter.POWER
    // Generated from the component: Three-phase at load 9 (area 2).Power Meter.POWER
    // Generated from the component: Three-phase at load 7 (area 1).PLL.normalize
    // Generated from the component: Three-phase at load 8 (mid).PLL.normalize
    // Generated from the component: Three-phase at load 9 (area 2).PLL.normalize
    // Generated from the component: Three-phase at load 7 (area 1).PLL.Rate Limiter1
    if (_three_phase_at_load_7__area_1__pll_pid_limit1__out - _three_phase_at_load_7__area_1__pll_rate_limiter1__state > 0.007539822368615503)
        _three_phase_at_load_7__area_1__pll_rate_limiter1__state += (0.007539822368615503);
    else  if (_three_phase_at_load_7__area_1__pll_pid_limit1__out - _three_phase_at_load_7__area_1__pll_rate_limiter1__state < -0.007539822368615503)
        _three_phase_at_load_7__area_1__pll_rate_limiter1__state += (-0.007539822368615503);
    else
        _three_phase_at_load_7__area_1__pll_rate_limiter1__state = _three_phase_at_load_7__area_1__pll_pid_limit1__out;
    _three_phase_at_load_7__area_1__pll_rate_limiter1__first_step = 0;
    // Generated from the component: Three-phase at load 7 (area 1).PLL.integrator
    // Generated from the component: Three-phase at load 8 (mid).PLL.Rate Limiter1
    if (_three_phase_at_load_8__mid__pll_pid_limit1__out - _three_phase_at_load_8__mid__pll_rate_limiter1__state > 0.007539822368615503)
        _three_phase_at_load_8__mid__pll_rate_limiter1__state += (0.007539822368615503);
    else  if (_three_phase_at_load_8__mid__pll_pid_limit1__out - _three_phase_at_load_8__mid__pll_rate_limiter1__state < -0.007539822368615503)
        _three_phase_at_load_8__mid__pll_rate_limiter1__state += (-0.007539822368615503);
    else
        _three_phase_at_load_8__mid__pll_rate_limiter1__state = _three_phase_at_load_8__mid__pll_pid_limit1__out;
    _three_phase_at_load_8__mid__pll_rate_limiter1__first_step = 0;
    // Generated from the component: Three-phase at load 8 (mid).PLL.integrator
    // Generated from the component: Three-phase at load 9 (area 2).PLL.Rate Limiter1
    if (_three_phase_at_load_9__area_2__pll_pid_limit1__out - _three_phase_at_load_9__area_2__pll_rate_limiter1__state > 0.007539822368615503)
        _three_phase_at_load_9__area_2__pll_rate_limiter1__state += (0.007539822368615503);
    else  if (_three_phase_at_load_9__area_2__pll_pid_limit1__out - _three_phase_at_load_9__area_2__pll_rate_limiter1__state < -0.007539822368615503)
        _three_phase_at_load_9__area_2__pll_rate_limiter1__state += (-0.007539822368615503);
    else
        _three_phase_at_load_9__area_2__pll_rate_limiter1__state = _three_phase_at_load_9__area_2__pll_pid_limit1__out;
    _three_phase_at_load_9__area_2__pll_rate_limiter1__first_step = 0;
    // Generated from the component: Three-phase at load 9 (area 2).PLL.integrator
    // Generated from the component: Three-phase at load 7 (area 1).PLL.LPF.LPF
    for (_three_phase_at_load_7__area_1__pll_lpf_lpf__i = 1; _three_phase_at_load_7__area_1__pll_lpf_lpf__i > 0; _three_phase_at_load_7__area_1__pll_lpf_lpf__i--) {
        _three_phase_at_load_7__area_1__pll_lpf_lpf__states[_three_phase_at_load_7__area_1__pll_lpf_lpf__i] = _three_phase_at_load_7__area_1__pll_lpf_lpf__states[_three_phase_at_load_7__area_1__pll_lpf_lpf__i - 1];
    }
    _three_phase_at_load_7__area_1__pll_lpf_lpf__states[0] = _three_phase_at_load_7__area_1__pll_lpf_lpf__delay_line_in;
    // Generated from the component: Three-phase at load 8 (mid).PLL.LPF.LPF
    for (_three_phase_at_load_8__mid__pll_lpf_lpf__i = 1; _three_phase_at_load_8__mid__pll_lpf_lpf__i > 0; _three_phase_at_load_8__mid__pll_lpf_lpf__i--) {
        _three_phase_at_load_8__mid__pll_lpf_lpf__states[_three_phase_at_load_8__mid__pll_lpf_lpf__i] = _three_phase_at_load_8__mid__pll_lpf_lpf__states[_three_phase_at_load_8__mid__pll_lpf_lpf__i - 1];
    }
    _three_phase_at_load_8__mid__pll_lpf_lpf__states[0] = _three_phase_at_load_8__mid__pll_lpf_lpf__delay_line_in;
    // Generated from the component: Three-phase at load 9 (area 2).PLL.LPF.LPF
    for (_three_phase_at_load_9__area_2__pll_lpf_lpf__i = 1; _three_phase_at_load_9__area_2__pll_lpf_lpf__i > 0; _three_phase_at_load_9__area_2__pll_lpf_lpf__i--) {
        _three_phase_at_load_9__area_2__pll_lpf_lpf__states[_three_phase_at_load_9__area_2__pll_lpf_lpf__i] = _three_phase_at_load_9__area_2__pll_lpf_lpf__states[_three_phase_at_load_9__area_2__pll_lpf_lpf__i - 1];
    }
    _three_phase_at_load_9__area_2__pll_lpf_lpf__states[0] = _three_phase_at_load_9__area_2__pll_lpf_lpf__delay_line_in;
    //@cmp.update.block.end
}
void TimerCounterHandler_1_user_sp_cpu0_dev0() {
#if DEBUG_MODE
    printf("\n\rTimerCounterHandler_1");
#endif
    //////////////////////////////////////////////////////////////////////////
    // Set tunable parameters
    //////////////////////////////////////////////////////////////////////////
    // Generated from the component: Diesel_Gen1.Control.Exciter.Const
    // Generated from the component: Diesel_Gen1.Control.Exciter.DC4B.One
    // Generated from the component: Diesel_Gen1.Control.Exciter.One
    // Generated from the component: Diesel_Gen1.Control.Exciter.V_inner_droop
    // Generated from the component: Diesel_Gen1.Control.Exciter.Vpss
    // Generated from the component: Diesel_Gen1.Control.Exciter.Zero
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.P_Droop
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.w_Droop
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.zero1
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.Inner_w_droop
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.zero
    // Generated from the component: Diesel_Gen1.Control.Start_Exciter.steadyState_w
    // Generated from the component: Diesel_Gen1.Control.check_steady_state_w.Constant3
    // Generated from the component: Diesel_Gen1.Control.pf Control.Constant1
    // Generated from the component: Diesel_Gen1.Control.pf Control.zero1
    // Generated from the component: Diesel_Gen1.Sync_Check.Calculate_dw_synch.zero
    // Generated from the component: Diesel_Gen1.Sync_Check.Contactor_Control.Close
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.one
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.one1
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.zero
    // Generated from the component: Diesel_Gen1.Sync_Check.check_f_diff.Constant1
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.Counter.Counter1.const_value_0
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.Counter.Counter1.const_value_1
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.One
    // Generated from the component: Diesel_Gen2.Control.Exciter.Const
    // Generated from the component: Diesel_Gen2.Control.Exciter.DC4B.One
    // Generated from the component: Diesel_Gen2.Control.Exciter.One
    // Generated from the component: Diesel_Gen2.Control.Exciter.V_inner_droop
    // Generated from the component: Diesel_Gen2.Control.Exciter.Vpss
    // Generated from the component: Diesel_Gen2.Control.Exciter.Zero
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.P_Droop
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.w_Droop
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.zero1
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.Inner_w_droop
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.zero
    // Generated from the component: Diesel_Gen2.Control.Start_Exciter.steadyState_w
    // Generated from the component: Diesel_Gen2.Control.check_steady_state_w.Constant3
    // Generated from the component: Diesel_Gen2.Control.pf Control.Constant1
    // Generated from the component: Diesel_Gen2.Control.pf Control.zero1
    // Generated from the component: Diesel_Gen2.Sync_Check.Calculate_dw_synch.zero
    // Generated from the component: Diesel_Gen2.Sync_Check.Contactor_Control.Close
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.one
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.one1
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.zero
    // Generated from the component: Diesel_Gen2.Sync_Check.check_f_diff.Constant1
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.Counter.Counter1.const_value_0
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.Counter.Counter1.const_value_1
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.One
    // Generated from the component: Diesel_Gen3.Control.Exciter.Const
    // Generated from the component: Diesel_Gen3.Control.Exciter.DC4B.One
    // Generated from the component: Diesel_Gen3.Control.Exciter.One
    // Generated from the component: Diesel_Gen3.Control.Exciter.V_inner_droop
    // Generated from the component: Diesel_Gen3.Control.Exciter.Vpss
    // Generated from the component: Diesel_Gen3.Control.Exciter.Zero
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.P_Droop
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.w_Droop
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.zero1
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.Inner_w_droop
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.zero
    // Generated from the component: Diesel_Gen3.Control.Start_Exciter.steadyState_w
    // Generated from the component: Diesel_Gen3.Control.check_steady_state_w.Constant3
    // Generated from the component: Diesel_Gen3.Control.pf Control.Constant1
    // Generated from the component: Diesel_Gen3.Control.pf Control.zero1
    // Generated from the component: Diesel_Gen3.Sync_Check.Calculate_dw_synch.zero
    // Generated from the component: Diesel_Gen3.Sync_Check.Contactor_Control.Close
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.one
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.one1
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.zero
    // Generated from the component: Diesel_Gen3.Sync_Check.check_f_diff.Constant1
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.Counter.Counter1.const_value_0
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.Counter.Counter1.const_value_1
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.One
    // Generated from the component: Diesel_Gen4.Control.Exciter.Const
    // Generated from the component: Diesel_Gen4.Control.Exciter.DC4B.One
    // Generated from the component: Diesel_Gen4.Control.Exciter.One
    // Generated from the component: Diesel_Gen4.Control.Exciter.V_inner_droop
    // Generated from the component: Diesel_Gen4.Control.Exciter.Vpss
    // Generated from the component: Diesel_Gen4.Control.Exciter.Zero
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.P_Droop
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.w_Droop
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.zero1
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.Inner_w_droop
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.zero
    // Generated from the component: Diesel_Gen4.Control.Start_Exciter.steadyState_w
    // Generated from the component: Diesel_Gen4.Control.check_steady_state_w.Constant3
    // Generated from the component: Diesel_Gen4.Control.pf Control.Constant1
    // Generated from the component: Diesel_Gen4.Control.pf Control.zero1
    // Generated from the component: Diesel_Gen4.Sync_Check.Calculate_dw_synch.zero
    // Generated from the component: Diesel_Gen4.Sync_Check.Contactor_Control.Close
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.one
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.one1
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.zero
    // Generated from the component: Diesel_Gen4.Sync_Check.check_f_diff.Constant1
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.Counter.Counter1.const_value_0
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.Counter.Counter1.const_value_1
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.One
//////////////////////////////////////////////////////////////////////////
    // Output block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.out.block.start
    // Generated from the component: DG_in.Gen_Control_Mode
    _dg_in_gen_control_mode__out = XIo_InFloat(0x55000100);
    // Generated from the component: DG_in.Gen_OP_mode
    _dg_in_gen_op_mode__out = XIo_InFloat(0x55000104);
    // Generated from the component: DG_in.Gen_On
    _dg_in_gen_on__out = XIo_InFloat(0x55000108);
    // Generated from the component: DG_in.Load_share
    _dg_in_load_share__out = XIo_InFloat(0x5500010c);
    // Generated from the component: DG_in.Load_share_on
    _dg_in_load_share_on__out = XIo_InFloat(0x55000110);
    // Generated from the component: DG_in.Pref
    _dg_in_pref__out = XIo_InFloat(0x55000114);
    // Generated from the component: DG_in.Vref
    _dg_in_vref__out = XIo_InFloat(0x55000118);
    // Generated from the component: DG_in.pf_ref
    _dg_in_pf_ref__out = XIo_InFloat(0x5500011c);
    // Generated from the component: DG_in.wref
    _dg_in_wref__out = XIo_InFloat(0x55000120);
    // Generated from the component: DG_in1.Gen_Control_Mode
    _dg_in1_gen_control_mode__out = XIo_InFloat(0x55000124);
    // Generated from the component: DG_in1.Gen_OP_mode
    _dg_in1_gen_op_mode__out = XIo_InFloat(0x55000128);
    // Generated from the component: DG_in1.Gen_On
    _dg_in1_gen_on__out = XIo_InFloat(0x5500012c);
    // Generated from the component: DG_in1.Load_share
    _dg_in1_load_share__out = XIo_InFloat(0x55000130);
    // Generated from the component: DG_in1.Load_share_on
    _dg_in1_load_share_on__out = XIo_InFloat(0x55000134);
    // Generated from the component: DG_in1.Pref
    _dg_in1_pref__out = XIo_InFloat(0x55000138);
    // Generated from the component: DG_in1.Vref
    _dg_in1_vref__out = XIo_InFloat(0x5500013c);
    // Generated from the component: DG_in1.pf_ref
    _dg_in1_pf_ref__out = XIo_InFloat(0x55000140);
    // Generated from the component: DG_in1.wref
    _dg_in1_wref__out = XIo_InFloat(0x55000144);
    // Generated from the component: DG_in3.Gen_Control_Mode
    _dg_in3_gen_control_mode__out = XIo_InFloat(0x55000148);
    // Generated from the component: DG_in3.Gen_OP_mode
    _dg_in3_gen_op_mode__out = XIo_InFloat(0x5500014c);
    // Generated from the component: DG_in3.Gen_On
    _dg_in3_gen_on__out = XIo_InFloat(0x55000150);
    // Generated from the component: DG_in3.Load_share
    _dg_in3_load_share__out = XIo_InFloat(0x55000154);
    // Generated from the component: DG_in3.Load_share_on
    _dg_in3_load_share_on__out = XIo_InFloat(0x55000158);
    // Generated from the component: DG_in3.Pref
    _dg_in3_pref__out = XIo_InFloat(0x5500015c);
    // Generated from the component: DG_in3.Vref
    _dg_in3_vref__out = XIo_InFloat(0x55000160);
    // Generated from the component: DG_in3.pf_ref
    _dg_in3_pf_ref__out = XIo_InFloat(0x55000164);
    // Generated from the component: DG_in3.wref
    _dg_in3_wref__out = XIo_InFloat(0x55000168);
    // Generated from the component: DG_in4.Gen_Control_Mode
    _dg_in4_gen_control_mode__out = XIo_InFloat(0x5500016c);
    // Generated from the component: DG_in4.Gen_OP_mode
    _dg_in4_gen_op_mode__out = XIo_InFloat(0x55000170);
    // Generated from the component: DG_in4.Gen_On
    _dg_in4_gen_on__out = XIo_InFloat(0x55000174);
    // Generated from the component: DG_in4.Load_share
    _dg_in4_load_share__out = XIo_InFloat(0x55000178);
    // Generated from the component: DG_in4.Load_share_on
    _dg_in4_load_share_on__out = XIo_InFloat(0x5500017c);
    // Generated from the component: DG_in4.Pref
    _dg_in4_pref__out = XIo_InFloat(0x55000180);
    // Generated from the component: DG_in4.Vref
    _dg_in4_vref__out = XIo_InFloat(0x55000184);
    // Generated from the component: DG_in4.pf_ref
    _dg_in4_pf_ref__out = XIo_InFloat(0x55000188);
    // Generated from the component: DG_in4.wref
    _dg_in4_wref__out = XIo_InFloat(0x5500018c);
    // Generated from the component: Diesel_Gen1.Control.Exciter.DC4B.Kf
    _diesel_gen1_control_exciter_dc4b_kf__out = 0.01 * _diesel_gen1_control_exciter_dc4b_tf3__out;
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.DEGOV.Kp
    _diesel_gen1_control_governor_and_engine_degov_kp__out = 0.5 * _diesel_gen1_control_governor_and_engine_degov_tf1__out;
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.DEGOV.Transport Delay1
    _diesel_gen1_control_governor_and_engine_degov_transport_delay1__out = _diesel_gen1_control_governor_and_engine_degov_transport_delay1__state[_diesel_gen1_control_governor_and_engine_degov_transport_delay1__cbi];
    // Generated from the component: Diesel_Gen1.Control.Unit Delay1
    _diesel_gen1_control_unit_delay1__out = _diesel_gen1_control_unit_delay1__state;
    // Generated from the component: Diesel_Gen1.Control.Unit Delay2
    _diesel_gen1_control_unit_delay2__out = _diesel_gen1_control_unit_delay2__state;
    // Generated from the component: Diesel_Gen1.Control.Unit Delay3
    _diesel_gen1_control_unit_delay3__out = _diesel_gen1_control_unit_delay3__state;
    // Generated from the component: Diesel_Gen1.Gen.Machine Wrapper1
    HIL_OutFloat((0x800000 + 0x40000 * 0x0 + 0x18),  _diesel_gen1_gen_machine_wrapper1__model_load);
    _diesel_gen1_gen_machine_wrapper1__out[0] = HIL_InFloat(0xc80000 + 32776);
    _diesel_gen1_gen_machine_wrapper1__out[1] = HIL_InFloat(0xc80000 + 32778);
    // Generated from the component: Diesel_Gen1.Ggrid_meas.Va.Va1
    _diesel_gen1_ggrid_meas_va_va1__out = (HIL_InFloat(0xc80000 + 0x3f));
    // Generated from the component: Diesel_Gen1.Ggrid_meas.Vb.Va1
    _diesel_gen1_ggrid_meas_vb_va1__out = (HIL_InFloat(0xc80000 + 0x40));
    // Generated from the component: Diesel_Gen1.Ggrid_meas.Vc.Va1
    _diesel_gen1_ggrid_meas_vc_va1__out = (HIL_InFloat(0xc80000 + 0x41));
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.Normalize.V_terminal
    _diesel_gen1_measurements_3ph_pll_gen_pll_normalize_v_terminal__d = _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__out;
    _diesel_gen1_measurements_3ph_pll_gen_pll_normalize_v_terminal__q = _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__out;
    _diesel_gen1_measurements_3ph_pll_gen_pll_normalize_v_terminal__t = (powf(_diesel_gen1_measurements_3ph_pll_gen_pll_normalize_v_terminal__d, 2.0) + powf(_diesel_gen1_measurements_3ph_pll_gen_pll_normalize_v_terminal__q, 2.0));
    _diesel_gen1_measurements_3ph_pll_gen_pll_normalize_v_terminal__t = sqrt(_diesel_gen1_measurements_3ph_pll_gen_pll_normalize_v_terminal__t);
    if (_diesel_gen1_measurements_3ph_pll_gen_pll_normalize_v_terminal__t < 0.1) {
        _diesel_gen1_measurements_3ph_pll_gen_pll_normalize_v_terminal__q_pu = _diesel_gen1_measurements_3ph_pll_gen_pll_normalize_v_terminal__q / 0.1;
    }
    else {
        _diesel_gen1_measurements_3ph_pll_gen_pll_normalize_v_terminal__q_pu = _diesel_gen1_measurements_3ph_pll_gen_pll_normalize_v_terminal__q / _diesel_gen1_measurements_3ph_pll_gen_pll_normalize_v_terminal__t;
    }
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.PI.Integrator1
    _diesel_gen1_measurements_3ph_pll_gen_pll_pi_integrator1__out = _diesel_gen1_measurements_3ph_pll_gen_pll_pi_integrator1__state;
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.PI.Integrator2
    _diesel_gen1_measurements_3ph_pll_gen_pll_pi_integrator2__out = _diesel_gen1_measurements_3ph_pll_gen_pll_pi_integrator2__state;
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.Unit Delay1
    _diesel_gen1_measurements_3ph_pll_gen_pll_unit_delay1__out = _diesel_gen1_measurements_3ph_pll_gen_pll_unit_delay1__state;
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.Term
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.Term1
    // Generated from the component: Diesel_Gen1.Measurements.Gain10
    _diesel_gen1_measurements_gain10__out = 0.0026525823848649226 * _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__out;
    // Generated from the component: Diesel_Gen1.Measurements.Ia.Ia1
    _diesel_gen1_measurements_ia_ia1__out = (HIL_InFloat(0xc80000 + 0xa5));
    // Generated from the component: Diesel_Gen1.Measurements.Ib.Ia1
    _diesel_gen1_measurements_ib_ia1__out = (HIL_InFloat(0xc80000 + 0xa6));
    // Generated from the component: Diesel_Gen1.Measurements.Ic.Ia1
    _diesel_gen1_measurements_ic_ia1__out = (HIL_InFloat(0xc80000 + 0xa7));
    // Generated from the component: Diesel_Gen1.Measurements.Va.Va1
    _diesel_gen1_measurements_va_va1__out = (HIL_InFloat(0xc80000 + 0x42));
    // Generated from the component: Diesel_Gen1.Measurements.Vb.Va1
    _diesel_gen1_measurements_vb_va1__out = (HIL_InFloat(0xc80000 + 0x43));
    // Generated from the component: Diesel_Gen1.Measurements.Vc.Va1
    _diesel_gen1_measurements_vc_va1__out = (HIL_InFloat(0xc80000 + 0x44));
    // Generated from the component: Diesel_Gen1.Sync_Check.Calculate_dw_synch.Unit Delay1
    _diesel_gen1_sync_check_calculate_dw_synch_unit_delay1__out = _diesel_gen1_sync_check_calculate_dw_synch_unit_delay1__state;
    // Generated from the component: Diesel_Gen1.Sync_Check.Calculate_dw_synch.dw_K
    _diesel_gen1_sync_check_calculate_dw_synch_dw_k__out = 1.0 * _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.Contactor_Control.Edge Detection1.Unit Delay1
    _diesel_gen1_sync_check_contactor_control_edge_detection1_unit_delay1__out = _diesel_gen1_sync_check_contactor_control_edge_detection1_unit_delay1__state;
    // Generated from the component: Diesel_Gen1.Sync_Check.Contactor_Control.SR Flip Flop1
    _diesel_gen1_sync_check_contactor_control_sr_flip_flop1__out = _diesel_gen1_sync_check_contactor_control_sr_flip_flop1__state;
    _diesel_gen1_sync_check_contactor_control_sr_flip_flop1__out_n = _diesel_gen1_sync_check_contactor_control_sr_flip_flop1__state != -1 ? !_diesel_gen1_sync_check_contactor_control_sr_flip_flop1__state : -1;
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.PLL_Grid.PLL.PI.Integrator1
    _diesel_gen1_sync_check_plls_pll_grid_pll_pi_integrator1__out = _diesel_gen1_sync_check_plls_pll_grid_pll_pi_integrator1__state;
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.PLL_Grid.PLL.Unit Delay1
    _diesel_gen1_sync_check_plls_pll_grid_pll_unit_delay1__out = _diesel_gen1_sync_check_plls_pll_grid_pll_unit_delay1__state;
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.V_grid
    HIL_OutAO(0x4015, (float)_diesel_gen1_sync_check_plls_pll_grid_lpf_vt__out);
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.Abs4
    _diesel_gen1_sync_check_check_v_diff_abs4__out = fabs(_diesel_gen1_sync_check_plls_pll_grid_lpf_vt__out);
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.Unit Delay1
    _diesel_gen1_sync_check_check_v_diff_unit_delay1__out = _diesel_gen1_sync_check_check_v_diff_unit_delay1__state;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_f_diff.Abs3
    _diesel_gen1_sync_check_check_f_diff_abs3__out = fabs(_diesel_gen1_sync_check_check_f_diff_lpf_dwf__out);
    // Generated from the component: Diesel_Gen1.Sync_Check.check_f_diff.f_diff
    HIL_OutAO(0x4019, (float)_diesel_gen1_sync_check_check_f_diff_lpf_dwf__out);
    // Generated from the component: Diesel_Gen1.Sync_Check.check_f_diff.toPU
    _diesel_gen1_sync_check_check_f_diff_topu__out = 0.008333333333333333 * _diesel_gen1_sync_check_check_f_diff_lpf_dwf__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.Abs2
    _diesel_gen1_sync_check_check_phase_diff_abs2__out = fabs(_diesel_gen1_sync_check_check_phase_diff_lpf__out);
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.Counter.Counter1.Accumulator1
    _diesel_gen1_sync_check_check_phase_diff_counter_counter1_accumulator1__out = _diesel_gen1_sync_check_check_phase_diff_counter_counter1_accumulator1__state;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.phase_filter
    HIL_OutAO(0x401b, (float)_diesel_gen1_sync_check_check_phase_diff_lpf__out);
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.to_pu
    _diesel_gen1_sync_check_check_phase_diff_to_pu__out = 0.15915494309189535 * _diesel_gen1_sync_check_check_phase_diff_lpf__out;
    // Generated from the component: Diesel_Gen1.bus_split
    _diesel_gen1_bus_split__out = _diesel_gen1_gen_machine_wrapper1__out[0];
    _diesel_gen1_bus_split__out1 = _diesel_gen1_gen_machine_wrapper1__out[1];
    // Generated from the component: Diesel_Gen2.Control.Exciter.DC4B.Kf
    _diesel_gen2_control_exciter_dc4b_kf__out = 0.01 * _diesel_gen2_control_exciter_dc4b_tf3__out;
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.DEGOV.Kp
    _diesel_gen2_control_governor_and_engine_degov_kp__out = 0.5 * _diesel_gen2_control_governor_and_engine_degov_tf1__out;
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.DEGOV.Transport Delay1
    _diesel_gen2_control_governor_and_engine_degov_transport_delay1__out = _diesel_gen2_control_governor_and_engine_degov_transport_delay1__state[_diesel_gen2_control_governor_and_engine_degov_transport_delay1__cbi];
    // Generated from the component: Diesel_Gen2.Control.Unit Delay1
    _diesel_gen2_control_unit_delay1__out = _diesel_gen2_control_unit_delay1__state;
    // Generated from the component: Diesel_Gen2.Control.Unit Delay2
    _diesel_gen2_control_unit_delay2__out = _diesel_gen2_control_unit_delay2__state;
    // Generated from the component: Diesel_Gen2.Control.Unit Delay3
    _diesel_gen2_control_unit_delay3__out = _diesel_gen2_control_unit_delay3__state;
    // Generated from the component: Diesel_Gen2.Gen.Machine Wrapper1
    HIL_OutFloat((0x800000 + 0x40000 * 0x1 + 0x18),  _diesel_gen2_gen_machine_wrapper1__model_load);
    _diesel_gen2_gen_machine_wrapper1__out[0] = HIL_InFloat(0xc80000 + 32792);
    _diesel_gen2_gen_machine_wrapper1__out[1] = HIL_InFloat(0xc80000 + 32794);
    // Generated from the component: Diesel_Gen2.Ggrid_meas.Va.Va1
    _diesel_gen2_ggrid_meas_va_va1__out = (HIL_InFloat(0xc80000 + 0x4c));
    // Generated from the component: Diesel_Gen2.Ggrid_meas.Vb.Va1
    _diesel_gen2_ggrid_meas_vb_va1__out = (HIL_InFloat(0xc80000 + 0x4d));
    // Generated from the component: Diesel_Gen2.Ggrid_meas.Vc.Va1
    _diesel_gen2_ggrid_meas_vc_va1__out = (HIL_InFloat(0xc80000 + 0x4e));
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.Normalize.V_terminal
    _diesel_gen2_measurements_3ph_pll_gen_pll_normalize_v_terminal__d = _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__out;
    _diesel_gen2_measurements_3ph_pll_gen_pll_normalize_v_terminal__q = _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__out;
    _diesel_gen2_measurements_3ph_pll_gen_pll_normalize_v_terminal__t = (powf(_diesel_gen2_measurements_3ph_pll_gen_pll_normalize_v_terminal__d, 2.0) + powf(_diesel_gen2_measurements_3ph_pll_gen_pll_normalize_v_terminal__q, 2.0));
    _diesel_gen2_measurements_3ph_pll_gen_pll_normalize_v_terminal__t = sqrt(_diesel_gen2_measurements_3ph_pll_gen_pll_normalize_v_terminal__t);
    if (_diesel_gen2_measurements_3ph_pll_gen_pll_normalize_v_terminal__t < 0.1) {
        _diesel_gen2_measurements_3ph_pll_gen_pll_normalize_v_terminal__q_pu = _diesel_gen2_measurements_3ph_pll_gen_pll_normalize_v_terminal__q / 0.1;
    }
    else {
        _diesel_gen2_measurements_3ph_pll_gen_pll_normalize_v_terminal__q_pu = _diesel_gen2_measurements_3ph_pll_gen_pll_normalize_v_terminal__q / _diesel_gen2_measurements_3ph_pll_gen_pll_normalize_v_terminal__t;
    }
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.PI.Integrator1
    _diesel_gen2_measurements_3ph_pll_gen_pll_pi_integrator1__out = _diesel_gen2_measurements_3ph_pll_gen_pll_pi_integrator1__state;
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.PI.Integrator2
    _diesel_gen2_measurements_3ph_pll_gen_pll_pi_integrator2__out = _diesel_gen2_measurements_3ph_pll_gen_pll_pi_integrator2__state;
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.Unit Delay1
    _diesel_gen2_measurements_3ph_pll_gen_pll_unit_delay1__out = _diesel_gen2_measurements_3ph_pll_gen_pll_unit_delay1__state;
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.Term
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.Term1
    // Generated from the component: Diesel_Gen2.Measurements.Gain10
    _diesel_gen2_measurements_gain10__out = 0.0026525823848649226 * _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__out;
    // Generated from the component: Diesel_Gen2.Measurements.Ia.Ia1
    _diesel_gen2_measurements_ia_ia1__out = (HIL_InFloat(0xc80000 + 0xb4));
    // Generated from the component: Diesel_Gen2.Measurements.Ib.Ia1
    _diesel_gen2_measurements_ib_ia1__out = (HIL_InFloat(0xc80000 + 0xb5));
    // Generated from the component: Diesel_Gen2.Measurements.Ic.Ia1
    _diesel_gen2_measurements_ic_ia1__out = (HIL_InFloat(0xc80000 + 0xb6));
    // Generated from the component: Diesel_Gen2.Measurements.Va.Va1
    _diesel_gen2_measurements_va_va1__out = (HIL_InFloat(0xc80000 + 0x4f));
    // Generated from the component: Diesel_Gen2.Measurements.Vb.Va1
    _diesel_gen2_measurements_vb_va1__out = (HIL_InFloat(0xc80000 + 0x50));
    // Generated from the component: Diesel_Gen2.Measurements.Vc.Va1
    _diesel_gen2_measurements_vc_va1__out = (HIL_InFloat(0xc80000 + 0x51));
    // Generated from the component: Diesel_Gen2.Sync_Check.Calculate_dw_synch.Unit Delay1
    _diesel_gen2_sync_check_calculate_dw_synch_unit_delay1__out = _diesel_gen2_sync_check_calculate_dw_synch_unit_delay1__state;
    // Generated from the component: Diesel_Gen2.Sync_Check.Calculate_dw_synch.dw_K
    _diesel_gen2_sync_check_calculate_dw_synch_dw_k__out = 1.0 * _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.Contactor_Control.Edge Detection1.Unit Delay1
    _diesel_gen2_sync_check_contactor_control_edge_detection1_unit_delay1__out = _diesel_gen2_sync_check_contactor_control_edge_detection1_unit_delay1__state;
    // Generated from the component: Diesel_Gen2.Sync_Check.Contactor_Control.SR Flip Flop1
    _diesel_gen2_sync_check_contactor_control_sr_flip_flop1__out = _diesel_gen2_sync_check_contactor_control_sr_flip_flop1__state;
    _diesel_gen2_sync_check_contactor_control_sr_flip_flop1__out_n = _diesel_gen2_sync_check_contactor_control_sr_flip_flop1__state != -1 ? !_diesel_gen2_sync_check_contactor_control_sr_flip_flop1__state : -1;
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.PLL_Grid.PLL.PI.Integrator1
    _diesel_gen2_sync_check_plls_pll_grid_pll_pi_integrator1__out = _diesel_gen2_sync_check_plls_pll_grid_pll_pi_integrator1__state;
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.PLL_Grid.PLL.Unit Delay1
    _diesel_gen2_sync_check_plls_pll_grid_pll_unit_delay1__out = _diesel_gen2_sync_check_plls_pll_grid_pll_unit_delay1__state;
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.V_grid
    HIL_OutAO(0x4035, (float)_diesel_gen2_sync_check_plls_pll_grid_lpf_vt__out);
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.Abs4
    _diesel_gen2_sync_check_check_v_diff_abs4__out = fabs(_diesel_gen2_sync_check_plls_pll_grid_lpf_vt__out);
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.Unit Delay1
    _diesel_gen2_sync_check_check_v_diff_unit_delay1__out = _diesel_gen2_sync_check_check_v_diff_unit_delay1__state;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_f_diff.Abs3
    _diesel_gen2_sync_check_check_f_diff_abs3__out = fabs(_diesel_gen2_sync_check_check_f_diff_lpf_dwf__out);
    // Generated from the component: Diesel_Gen2.Sync_Check.check_f_diff.f_diff
    HIL_OutAO(0x4039, (float)_diesel_gen2_sync_check_check_f_diff_lpf_dwf__out);
    // Generated from the component: Diesel_Gen2.Sync_Check.check_f_diff.toPU
    _diesel_gen2_sync_check_check_f_diff_topu__out = 0.008333333333333333 * _diesel_gen2_sync_check_check_f_diff_lpf_dwf__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.Abs2
    _diesel_gen2_sync_check_check_phase_diff_abs2__out = fabs(_diesel_gen2_sync_check_check_phase_diff_lpf__out);
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.Counter.Counter1.Accumulator1
    _diesel_gen2_sync_check_check_phase_diff_counter_counter1_accumulator1__out = _diesel_gen2_sync_check_check_phase_diff_counter_counter1_accumulator1__state;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.phase_filter
    HIL_OutAO(0x403b, (float)_diesel_gen2_sync_check_check_phase_diff_lpf__out);
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.to_pu
    _diesel_gen2_sync_check_check_phase_diff_to_pu__out = 0.15915494309189535 * _diesel_gen2_sync_check_check_phase_diff_lpf__out;
    // Generated from the component: Diesel_Gen2.bus_split
    _diesel_gen2_bus_split__out = _diesel_gen2_gen_machine_wrapper1__out[0];
    _diesel_gen2_bus_split__out1 = _diesel_gen2_gen_machine_wrapper1__out[1];
    // Generated from the component: Diesel_Gen3.Control.Exciter.DC4B.Kf
    _diesel_gen3_control_exciter_dc4b_kf__out = 0.01 * _diesel_gen3_control_exciter_dc4b_tf3__out;
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.DEGOV.Kp
    _diesel_gen3_control_governor_and_engine_degov_kp__out = 0.5 * _diesel_gen3_control_governor_and_engine_degov_tf1__out;
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.DEGOV.Transport Delay1
    _diesel_gen3_control_governor_and_engine_degov_transport_delay1__out = _diesel_gen3_control_governor_and_engine_degov_transport_delay1__state[_diesel_gen3_control_governor_and_engine_degov_transport_delay1__cbi];
    // Generated from the component: Diesel_Gen3.Control.Unit Delay1
    _diesel_gen3_control_unit_delay1__out = _diesel_gen3_control_unit_delay1__state;
    // Generated from the component: Diesel_Gen3.Control.Unit Delay2
    _diesel_gen3_control_unit_delay2__out = _diesel_gen3_control_unit_delay2__state;
    // Generated from the component: Diesel_Gen3.Control.Unit Delay3
    _diesel_gen3_control_unit_delay3__out = _diesel_gen3_control_unit_delay3__state;
    // Generated from the component: Diesel_Gen3.Gen.Machine Wrapper1
    HIL_OutFloat((0x800000 + 0x40000 * 0x2 + 0x18),  _diesel_gen3_gen_machine_wrapper1__model_load);
    _diesel_gen3_gen_machine_wrapper1__out[0] = HIL_InFloat(0xc80000 + 32808);
    _diesel_gen3_gen_machine_wrapper1__out[1] = HIL_InFloat(0xc80000 + 32810);
    // Generated from the component: Diesel_Gen3.Ggrid_meas.Va.Va1
    _diesel_gen3_ggrid_meas_va_va1__out = (HIL_InFloat(0xc80000 + 0x59));
    // Generated from the component: Diesel_Gen3.Ggrid_meas.Vb.Va1
    _diesel_gen3_ggrid_meas_vb_va1__out = (HIL_InFloat(0xc80000 + 0x5a));
    // Generated from the component: Diesel_Gen3.Ggrid_meas.Vc.Va1
    _diesel_gen3_ggrid_meas_vc_va1__out = (HIL_InFloat(0xc80000 + 0x5b));
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.Normalize.V_terminal
    _diesel_gen3_measurements_3ph_pll_gen_pll_normalize_v_terminal__d = _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__out;
    _diesel_gen3_measurements_3ph_pll_gen_pll_normalize_v_terminal__q = _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__out;
    _diesel_gen3_measurements_3ph_pll_gen_pll_normalize_v_terminal__t = (powf(_diesel_gen3_measurements_3ph_pll_gen_pll_normalize_v_terminal__d, 2.0) + powf(_diesel_gen3_measurements_3ph_pll_gen_pll_normalize_v_terminal__q, 2.0));
    _diesel_gen3_measurements_3ph_pll_gen_pll_normalize_v_terminal__t = sqrt(_diesel_gen3_measurements_3ph_pll_gen_pll_normalize_v_terminal__t);
    if (_diesel_gen3_measurements_3ph_pll_gen_pll_normalize_v_terminal__t < 0.1) {
        _diesel_gen3_measurements_3ph_pll_gen_pll_normalize_v_terminal__q_pu = _diesel_gen3_measurements_3ph_pll_gen_pll_normalize_v_terminal__q / 0.1;
    }
    else {
        _diesel_gen3_measurements_3ph_pll_gen_pll_normalize_v_terminal__q_pu = _diesel_gen3_measurements_3ph_pll_gen_pll_normalize_v_terminal__q / _diesel_gen3_measurements_3ph_pll_gen_pll_normalize_v_terminal__t;
    }
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.PI.Integrator1
    _diesel_gen3_measurements_3ph_pll_gen_pll_pi_integrator1__out = _diesel_gen3_measurements_3ph_pll_gen_pll_pi_integrator1__state;
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.PI.Integrator2
    _diesel_gen3_measurements_3ph_pll_gen_pll_pi_integrator2__out = _diesel_gen3_measurements_3ph_pll_gen_pll_pi_integrator2__state;
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.Unit Delay1
    _diesel_gen3_measurements_3ph_pll_gen_pll_unit_delay1__out = _diesel_gen3_measurements_3ph_pll_gen_pll_unit_delay1__state;
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.Term
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.Term1
    // Generated from the component: Diesel_Gen3.Measurements.Gain10
    _diesel_gen3_measurements_gain10__out = 0.0026525823848649226 * _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__out;
    // Generated from the component: Diesel_Gen3.Measurements.Ia.Ia1
    _diesel_gen3_measurements_ia_ia1__out = (HIL_InFloat(0xc80000 + 0xc3));
    // Generated from the component: Diesel_Gen3.Measurements.Ib.Ia1
    _diesel_gen3_measurements_ib_ia1__out = (HIL_InFloat(0xc80000 + 0xc4));
    // Generated from the component: Diesel_Gen3.Measurements.Ic.Ia1
    _diesel_gen3_measurements_ic_ia1__out = (HIL_InFloat(0xc80000 + 0xc5));
    // Generated from the component: Diesel_Gen3.Measurements.Va.Va1
    _diesel_gen3_measurements_va_va1__out = (HIL_InFloat(0xc80000 + 0x5c));
    // Generated from the component: Diesel_Gen3.Measurements.Vb.Va1
    _diesel_gen3_measurements_vb_va1__out = (HIL_InFloat(0xc80000 + 0x5d));
    // Generated from the component: Diesel_Gen3.Measurements.Vc.Va1
    _diesel_gen3_measurements_vc_va1__out = (HIL_InFloat(0xc80000 + 0x5e));
    // Generated from the component: Diesel_Gen3.Sync_Check.Calculate_dw_synch.Unit Delay1
    _diesel_gen3_sync_check_calculate_dw_synch_unit_delay1__out = _diesel_gen3_sync_check_calculate_dw_synch_unit_delay1__state;
    // Generated from the component: Diesel_Gen3.Sync_Check.Calculate_dw_synch.dw_K
    _diesel_gen3_sync_check_calculate_dw_synch_dw_k__out = 1.0 * _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.Contactor_Control.Edge Detection1.Unit Delay1
    _diesel_gen3_sync_check_contactor_control_edge_detection1_unit_delay1__out = _diesel_gen3_sync_check_contactor_control_edge_detection1_unit_delay1__state;
    // Generated from the component: Diesel_Gen3.Sync_Check.Contactor_Control.SR Flip Flop1
    _diesel_gen3_sync_check_contactor_control_sr_flip_flop1__out = _diesel_gen3_sync_check_contactor_control_sr_flip_flop1__state;
    _diesel_gen3_sync_check_contactor_control_sr_flip_flop1__out_n = _diesel_gen3_sync_check_contactor_control_sr_flip_flop1__state != -1 ? !_diesel_gen3_sync_check_contactor_control_sr_flip_flop1__state : -1;
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.PLL_Grid.PLL.PI.Integrator1
    _diesel_gen3_sync_check_plls_pll_grid_pll_pi_integrator1__out = _diesel_gen3_sync_check_plls_pll_grid_pll_pi_integrator1__state;
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.PLL_Grid.PLL.Unit Delay1
    _diesel_gen3_sync_check_plls_pll_grid_pll_unit_delay1__out = _diesel_gen3_sync_check_plls_pll_grid_pll_unit_delay1__state;
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.V_grid
    HIL_OutAO(0x4055, (float)_diesel_gen3_sync_check_plls_pll_grid_lpf_vt__out);
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.Abs4
    _diesel_gen3_sync_check_check_v_diff_abs4__out = fabs(_diesel_gen3_sync_check_plls_pll_grid_lpf_vt__out);
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.Unit Delay1
    _diesel_gen3_sync_check_check_v_diff_unit_delay1__out = _diesel_gen3_sync_check_check_v_diff_unit_delay1__state;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_f_diff.Abs3
    _diesel_gen3_sync_check_check_f_diff_abs3__out = fabs(_diesel_gen3_sync_check_check_f_diff_lpf_dwf__out);
    // Generated from the component: Diesel_Gen3.Sync_Check.check_f_diff.f_diff
    HIL_OutAO(0x4059, (float)_diesel_gen3_sync_check_check_f_diff_lpf_dwf__out);
    // Generated from the component: Diesel_Gen3.Sync_Check.check_f_diff.toPU
    _diesel_gen3_sync_check_check_f_diff_topu__out = 0.008333333333333333 * _diesel_gen3_sync_check_check_f_diff_lpf_dwf__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.Abs2
    _diesel_gen3_sync_check_check_phase_diff_abs2__out = fabs(_diesel_gen3_sync_check_check_phase_diff_lpf__out);
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.Counter.Counter1.Accumulator1
    _diesel_gen3_sync_check_check_phase_diff_counter_counter1_accumulator1__out = _diesel_gen3_sync_check_check_phase_diff_counter_counter1_accumulator1__state;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.phase_filter
    HIL_OutAO(0x405b, (float)_diesel_gen3_sync_check_check_phase_diff_lpf__out);
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.to_pu
    _diesel_gen3_sync_check_check_phase_diff_to_pu__out = 0.15915494309189535 * _diesel_gen3_sync_check_check_phase_diff_lpf__out;
    // Generated from the component: Diesel_Gen3.bus_split
    _diesel_gen3_bus_split__out = _diesel_gen3_gen_machine_wrapper1__out[0];
    _diesel_gen3_bus_split__out1 = _diesel_gen3_gen_machine_wrapper1__out[1];
    // Generated from the component: Diesel_Gen4.Control.Exciter.DC4B.Kf
    _diesel_gen4_control_exciter_dc4b_kf__out = 0.01 * _diesel_gen4_control_exciter_dc4b_tf3__out;
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.DEGOV.Kp
    _diesel_gen4_control_governor_and_engine_degov_kp__out = 0.5 * _diesel_gen4_control_governor_and_engine_degov_tf1__out;
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.DEGOV.Transport Delay1
    _diesel_gen4_control_governor_and_engine_degov_transport_delay1__out = _diesel_gen4_control_governor_and_engine_degov_transport_delay1__state[_diesel_gen4_control_governor_and_engine_degov_transport_delay1__cbi];
    // Generated from the component: Diesel_Gen4.Control.Unit Delay1
    _diesel_gen4_control_unit_delay1__out = _diesel_gen4_control_unit_delay1__state;
    // Generated from the component: Diesel_Gen4.Control.Unit Delay2
    _diesel_gen4_control_unit_delay2__out = _diesel_gen4_control_unit_delay2__state;
    // Generated from the component: Diesel_Gen4.Control.Unit Delay3
    _diesel_gen4_control_unit_delay3__out = _diesel_gen4_control_unit_delay3__state;
    // Generated from the component: Diesel_Gen4.Gen.Machine Wrapper1
    HIL_OutFloat((0x800000 + 0x40000 * 0x3 + 0x18),  _diesel_gen4_gen_machine_wrapper1__model_load);
    _diesel_gen4_gen_machine_wrapper1__out[0] = HIL_InFloat(0xc80000 + 32824);
    _diesel_gen4_gen_machine_wrapper1__out[1] = HIL_InFloat(0xc80000 + 32826);
    // Generated from the component: Diesel_Gen4.Ggrid_meas.Va.Va1
    _diesel_gen4_ggrid_meas_va_va1__out = (HIL_InFloat(0xc80000 + 0x66));
    // Generated from the component: Diesel_Gen4.Ggrid_meas.Vb.Va1
    _diesel_gen4_ggrid_meas_vb_va1__out = (HIL_InFloat(0xc80000 + 0x67));
    // Generated from the component: Diesel_Gen4.Ggrid_meas.Vc.Va1
    _diesel_gen4_ggrid_meas_vc_va1__out = (HIL_InFloat(0xc80000 + 0x68));
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.Normalize.V_terminal
    _diesel_gen4_measurements_3ph_pll_gen_pll_normalize_v_terminal__d = _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__out;
    _diesel_gen4_measurements_3ph_pll_gen_pll_normalize_v_terminal__q = _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__out;
    _diesel_gen4_measurements_3ph_pll_gen_pll_normalize_v_terminal__t = (powf(_diesel_gen4_measurements_3ph_pll_gen_pll_normalize_v_terminal__d, 2.0) + powf(_diesel_gen4_measurements_3ph_pll_gen_pll_normalize_v_terminal__q, 2.0));
    _diesel_gen4_measurements_3ph_pll_gen_pll_normalize_v_terminal__t = sqrt(_diesel_gen4_measurements_3ph_pll_gen_pll_normalize_v_terminal__t);
    if (_diesel_gen4_measurements_3ph_pll_gen_pll_normalize_v_terminal__t < 0.1) {
        _diesel_gen4_measurements_3ph_pll_gen_pll_normalize_v_terminal__q_pu = _diesel_gen4_measurements_3ph_pll_gen_pll_normalize_v_terminal__q / 0.1;
    }
    else {
        _diesel_gen4_measurements_3ph_pll_gen_pll_normalize_v_terminal__q_pu = _diesel_gen4_measurements_3ph_pll_gen_pll_normalize_v_terminal__q / _diesel_gen4_measurements_3ph_pll_gen_pll_normalize_v_terminal__t;
    }
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.PI.Integrator1
    _diesel_gen4_measurements_3ph_pll_gen_pll_pi_integrator1__out = _diesel_gen4_measurements_3ph_pll_gen_pll_pi_integrator1__state;
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.PI.Integrator2
    _diesel_gen4_measurements_3ph_pll_gen_pll_pi_integrator2__out = _diesel_gen4_measurements_3ph_pll_gen_pll_pi_integrator2__state;
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.Unit Delay1
    _diesel_gen4_measurements_3ph_pll_gen_pll_unit_delay1__out = _diesel_gen4_measurements_3ph_pll_gen_pll_unit_delay1__state;
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.Term
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.Term1
    // Generated from the component: Diesel_Gen4.Measurements.Gain10
    _diesel_gen4_measurements_gain10__out = 0.0026525823848649226 * _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__out;
    // Generated from the component: Diesel_Gen4.Measurements.Ia.Ia1
    _diesel_gen4_measurements_ia_ia1__out = (HIL_InFloat(0xc80000 + 0xd2));
    // Generated from the component: Diesel_Gen4.Measurements.Ib.Ia1
    _diesel_gen4_measurements_ib_ia1__out = (HIL_InFloat(0xc80000 + 0xd3));
    // Generated from the component: Diesel_Gen4.Measurements.Ic.Ia1
    _diesel_gen4_measurements_ic_ia1__out = (HIL_InFloat(0xc80000 + 0xd4));
    // Generated from the component: Diesel_Gen4.Measurements.Va.Va1
    _diesel_gen4_measurements_va_va1__out = (HIL_InFloat(0xc80000 + 0x69));
    // Generated from the component: Diesel_Gen4.Measurements.Vb.Va1
    _diesel_gen4_measurements_vb_va1__out = (HIL_InFloat(0xc80000 + 0x6a));
    // Generated from the component: Diesel_Gen4.Measurements.Vc.Va1
    _diesel_gen4_measurements_vc_va1__out = (HIL_InFloat(0xc80000 + 0x6b));
    // Generated from the component: Diesel_Gen4.Sync_Check.Calculate_dw_synch.Unit Delay1
    _diesel_gen4_sync_check_calculate_dw_synch_unit_delay1__out = _diesel_gen4_sync_check_calculate_dw_synch_unit_delay1__state;
    // Generated from the component: Diesel_Gen4.Sync_Check.Calculate_dw_synch.dw_K
    _diesel_gen4_sync_check_calculate_dw_synch_dw_k__out = 1.0 * _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.Contactor_Control.Edge Detection1.Unit Delay1
    _diesel_gen4_sync_check_contactor_control_edge_detection1_unit_delay1__out = _diesel_gen4_sync_check_contactor_control_edge_detection1_unit_delay1__state;
    // Generated from the component: Diesel_Gen4.Sync_Check.Contactor_Control.SR Flip Flop1
    _diesel_gen4_sync_check_contactor_control_sr_flip_flop1__out = _diesel_gen4_sync_check_contactor_control_sr_flip_flop1__state;
    _diesel_gen4_sync_check_contactor_control_sr_flip_flop1__out_n = _diesel_gen4_sync_check_contactor_control_sr_flip_flop1__state != -1 ? !_diesel_gen4_sync_check_contactor_control_sr_flip_flop1__state : -1;
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.PLL_Grid.PLL.PI.Integrator1
    _diesel_gen4_sync_check_plls_pll_grid_pll_pi_integrator1__out = _diesel_gen4_sync_check_plls_pll_grid_pll_pi_integrator1__state;
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.PLL_Grid.PLL.Unit Delay1
    _diesel_gen4_sync_check_plls_pll_grid_pll_unit_delay1__out = _diesel_gen4_sync_check_plls_pll_grid_pll_unit_delay1__state;
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.V_grid
    HIL_OutAO(0x4075, (float)_diesel_gen4_sync_check_plls_pll_grid_lpf_vt__out);
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.Abs4
    _diesel_gen4_sync_check_check_v_diff_abs4__out = fabs(_diesel_gen4_sync_check_plls_pll_grid_lpf_vt__out);
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.Unit Delay1
    _diesel_gen4_sync_check_check_v_diff_unit_delay1__out = _diesel_gen4_sync_check_check_v_diff_unit_delay1__state;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_f_diff.Abs3
    _diesel_gen4_sync_check_check_f_diff_abs3__out = fabs(_diesel_gen4_sync_check_check_f_diff_lpf_dwf__out);
    // Generated from the component: Diesel_Gen4.Sync_Check.check_f_diff.f_diff
    HIL_OutAO(0x4079, (float)_diesel_gen4_sync_check_check_f_diff_lpf_dwf__out);
    // Generated from the component: Diesel_Gen4.Sync_Check.check_f_diff.toPU
    _diesel_gen4_sync_check_check_f_diff_topu__out = 0.008333333333333333 * _diesel_gen4_sync_check_check_f_diff_lpf_dwf__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.Abs2
    _diesel_gen4_sync_check_check_phase_diff_abs2__out = fabs(_diesel_gen4_sync_check_check_phase_diff_lpf__out);
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.Counter.Counter1.Accumulator1
    _diesel_gen4_sync_check_check_phase_diff_counter_counter1_accumulator1__out = _diesel_gen4_sync_check_check_phase_diff_counter_counter1_accumulator1__state;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.phase_filter
    HIL_OutAO(0x407b, (float)_diesel_gen4_sync_check_check_phase_diff_lpf__out);
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.to_pu
    _diesel_gen4_sync_check_check_phase_diff_to_pu__out = 0.15915494309189535 * _diesel_gen4_sync_check_check_phase_diff_lpf__out;
    // Generated from the component: Diesel_Gen4.bus_split
    _diesel_gen4_bus_split__out = _diesel_gen4_gen_machine_wrapper1__out[0];
    _diesel_gen4_bus_split__out1 = _diesel_gen4_gen_machine_wrapper1__out[1];
    // Generated from the component: DG_in.Bus Join2
    _dg_in_bus_join2__out[0] = _dg_in_gen_on__out;
    _dg_in_bus_join2__out[1] = _dg_in_vref__out;
    _dg_in_bus_join2__out[2] = _dg_in_wref__out;
    _dg_in_bus_join2__out[3] = _dg_in_pref__out;
    _dg_in_bus_join2__out[4] = _dg_in_pf_ref__out;
    _dg_in_bus_join2__out[5] = _dg_in_gen_op_mode__out;
    _dg_in_bus_join2__out[6] = _dg_in_gen_control_mode__out;
    _dg_in_bus_join2__out[7] = _dg_in_load_share_on__out;
    _dg_in_bus_join2__out[8] = _dg_in_load_share__out;
    // Generated from the component: DG_in1.Bus Join2
    _dg_in1_bus_join2__out[0] = _dg_in1_gen_on__out;
    _dg_in1_bus_join2__out[1] = _dg_in1_vref__out;
    _dg_in1_bus_join2__out[2] = _dg_in1_wref__out;
    _dg_in1_bus_join2__out[3] = _dg_in1_pref__out;
    _dg_in1_bus_join2__out[4] = _dg_in1_pf_ref__out;
    _dg_in1_bus_join2__out[5] = _dg_in1_gen_op_mode__out;
    _dg_in1_bus_join2__out[6] = _dg_in1_gen_control_mode__out;
    _dg_in1_bus_join2__out[7] = _dg_in1_load_share_on__out;
    _dg_in1_bus_join2__out[8] = _dg_in1_load_share__out;
    // Generated from the component: DG_in3.Bus Join2
    _dg_in3_bus_join2__out[0] = _dg_in3_gen_on__out;
    _dg_in3_bus_join2__out[1] = _dg_in3_vref__out;
    _dg_in3_bus_join2__out[2] = _dg_in3_wref__out;
    _dg_in3_bus_join2__out[3] = _dg_in3_pref__out;
    _dg_in3_bus_join2__out[4] = _dg_in3_pf_ref__out;
    _dg_in3_bus_join2__out[5] = _dg_in3_gen_op_mode__out;
    _dg_in3_bus_join2__out[6] = _dg_in3_gen_control_mode__out;
    _dg_in3_bus_join2__out[7] = _dg_in3_load_share_on__out;
    _dg_in3_bus_join2__out[8] = _dg_in3_load_share__out;
    // Generated from the component: DG_in4.Bus Join2
    _dg_in4_bus_join2__out[0] = _dg_in4_gen_on__out;
    _dg_in4_bus_join2__out[1] = _dg_in4_vref__out;
    _dg_in4_bus_join2__out[2] = _dg_in4_wref__out;
    _dg_in4_bus_join2__out[3] = _dg_in4_pref__out;
    _dg_in4_bus_join2__out[4] = _dg_in4_pf_ref__out;
    _dg_in4_bus_join2__out[5] = _dg_in4_gen_op_mode__out;
    _dg_in4_bus_join2__out[6] = _dg_in4_gen_control_mode__out;
    _dg_in4_bus_join2__out[7] = _dg_in4_load_share_on__out;
    _dg_in4_bus_join2__out[8] = _dg_in4_load_share__out;
    // Generated from the component: Diesel_Gen1.Control.Exciter.DC4B.TF4
    X_UnInt32 _diesel_gen1_control_exciter_dc4b_tf4__i;
    _diesel_gen1_control_exciter_dc4b_tf4__a_sum = 0.0f;
    _diesel_gen1_control_exciter_dc4b_tf4__b_sum = 0.0f;
    _diesel_gen1_control_exciter_dc4b_tf4__delay_line_in = 0.0f;
    for (_diesel_gen1_control_exciter_dc4b_tf4__i = 0; _diesel_gen1_control_exciter_dc4b_tf4__i < 1; _diesel_gen1_control_exciter_dc4b_tf4__i++) {
        _diesel_gen1_control_exciter_dc4b_tf4__b_sum += _diesel_gen1_control_exciter_dc4b_tf4__b_coeff[_diesel_gen1_control_exciter_dc4b_tf4__i + 1] * _diesel_gen1_control_exciter_dc4b_tf4__states[_diesel_gen1_control_exciter_dc4b_tf4__i];
    }
    _diesel_gen1_control_exciter_dc4b_tf4__a_sum += _diesel_gen1_control_exciter_dc4b_tf4__states[0] * _diesel_gen1_control_exciter_dc4b_tf4__a_coeff[1];
    _diesel_gen1_control_exciter_dc4b_tf4__delay_line_in = _diesel_gen1_control_exciter_dc4b_kf__out - _diesel_gen1_control_exciter_dc4b_tf4__a_sum;
    _diesel_gen1_control_exciter_dc4b_tf4__b_sum += _diesel_gen1_control_exciter_dc4b_tf4__b_coeff[0] * _diesel_gen1_control_exciter_dc4b_tf4__delay_line_in;
    _diesel_gen1_control_exciter_dc4b_tf4__out = _diesel_gen1_control_exciter_dc4b_tf4__b_sum;
    // Generated from the component: Diesel_Gen1.Control.Exciter.DC4B.switch
    _diesel_gen1_control_exciter_dc4b_switch__out = (_diesel_gen1_control_exciter_one__out > 0.5f) ? _diesel_gen1_control_exciter_dc4b_one__out : _diesel_gen1_control_exciter_dc4b_tf1__out;
    // Generated from the component: Diesel_Gen1.Control.Exciter.one_ov_sqrt_3
    _diesel_gen1_control_exciter_one_ov_sqrt_3__out = 0.5773502691896258 * _diesel_gen1_control_exciter_v_inner_droop__out;
    // Generated from the component: Diesel_Gen1.Control.Exciter.Sum1
    _diesel_gen1_control_exciter_sum1__out = _diesel_gen1_control_exciter_const__out + _diesel_gen1_control_exciter_vpss__out;
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.DEGOV.K
    _diesel_gen1_control_governor_and_engine_degov_k__out = 10.0 * _diesel_gen1_control_governor_and_engine_degov_kp__out;
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.Tpu to T
    _diesel_gen1_control_governor_and_engine_tpu_to_t__out = -5305.164769729845 * _diesel_gen1_control_governor_and_engine_degov_transport_delay1__out;
    // Generated from the component: Diesel_Gen1.Control.Start_Exciter.Exciter_start_speed
    _diesel_gen1_control_start_exciter_exciter_start_speed__out = 0.75 * _diesel_gen1_control_start_exciter_steadystate_w__out;
    // Generated from the component: Diesel_Gen1.Control.check_steady_state_w.speed_diff
    _diesel_gen1_control_check_steady_state_w_speed_diff__out = 0.001 * _diesel_gen1_control_check_steady_state_w_constant3__out;
    // Generated from the component: Diesel_Gen1.Ggrid_meas.Bus Join1
    _diesel_gen1_ggrid_meas_bus_join1__out[0] = _diesel_gen1_ggrid_meas_va_va1__out;
    _diesel_gen1_ggrid_meas_bus_join1__out[1] = _diesel_gen1_ggrid_meas_vb_va1__out;
    _diesel_gen1_ggrid_meas_bus_join1__out[2] = _diesel_gen1_ggrid_meas_vc_va1__out;
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.PI.Kd
    _diesel_gen1_measurements_3ph_pll_gen_pll_pi_kd__out = 1.0 * _diesel_gen1_measurements_3ph_pll_gen_pll_normalize_v_terminal__q_pu;
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.PI.Ki
    _diesel_gen1_measurements_3ph_pll_gen_pll_pi_ki__out = 3200.0 * _diesel_gen1_measurements_3ph_pll_gen_pll_normalize_v_terminal__q_pu;
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.PI.Kp
    _diesel_gen1_measurements_3ph_pll_gen_pll_pi_kp__out = 100.0 * _diesel_gen1_measurements_3ph_pll_gen_pll_normalize_v_terminal__q_pu;
    // Generated from the component: Diesel_Gen1.Measurements.e_f
    HIL_OutAO(0x4012, (float)_diesel_gen1_measurements_gain10__out);
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.ABC_dqz.abc to alpha beta
    _diesel_gen1_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__alpha = (2.0 * _diesel_gen1_measurements_va_va1__out - _diesel_gen1_measurements_vb_va1__out - _diesel_gen1_measurements_vc_va1__out) * 0.3333333333333333;
    _diesel_gen1_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__beta = (_diesel_gen1_measurements_vb_va1__out - _diesel_gen1_measurements_vc_va1__out) * 0.5773502691896258;
    _diesel_gen1_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__gamma = (_diesel_gen1_measurements_va_va1__out + _diesel_gen1_measurements_vb_va1__out + _diesel_gen1_measurements_vc_va1__out) * 0.3333333333333333;
    // Generated from the component: Diesel_Gen1.Measurements.PQ measure.PQ Power Meter1
    _diesel_gen1_measurements_pq_measure_pq_power_meter1__v_alpha = SQRT_2OVER3 * ( _diesel_gen1_measurements_va_va1__out - 0.5f * _diesel_gen1_measurements_vb_va1__out - 0.5f * _diesel_gen1_measurements_vc_va1__out);
    _diesel_gen1_measurements_pq_measure_pq_power_meter1__v_beta = SQRT_2OVER3 * (SQRT3_OVER_2 * _diesel_gen1_measurements_vb_va1__out - SQRT3_OVER_2 * _diesel_gen1_measurements_vc_va1__out);
    _diesel_gen1_measurements_pq_measure_pq_power_meter1__i_alpha = SQRT_2OVER3 * ( _diesel_gen1_measurements_ia_ia1__out - 0.5f * _diesel_gen1_measurements_ib_ia1__out - 0.5f * _diesel_gen1_measurements_ic_ia1__out);
    _diesel_gen1_measurements_pq_measure_pq_power_meter1__i_beta = SQRT_2OVER3 * (SQRT3_OVER_2 * _diesel_gen1_measurements_ib_ia1__out - SQRT3_OVER_2 * _diesel_gen1_measurements_ic_ia1__out);
    _diesel_gen1_measurements_pq_measure_pq_power_meter1__v_zero = ONE_DIV_BY_SQRT_3 * (_diesel_gen1_measurements_va_va1__out + _diesel_gen1_measurements_vb_va1__out + _diesel_gen1_measurements_vc_va1__out);
    _diesel_gen1_measurements_pq_measure_pq_power_meter1__i_zero = ONE_DIV_BY_SQRT_3 * (_diesel_gen1_measurements_ia_ia1__out + _diesel_gen1_measurements_ib_ia1__out + _diesel_gen1_measurements_ic_ia1__out);
    _diesel_gen1_measurements_pq_measure_pq_power_meter1__Pac = _diesel_gen1_measurements_pq_measure_pq_power_meter1__v_alpha * _diesel_gen1_measurements_pq_measure_pq_power_meter1__i_alpha + _diesel_gen1_measurements_pq_measure_pq_power_meter1__v_beta * _diesel_gen1_measurements_pq_measure_pq_power_meter1__i_beta;
    _diesel_gen1_measurements_pq_measure_pq_power_meter1__Qac = _diesel_gen1_measurements_pq_measure_pq_power_meter1__v_beta * _diesel_gen1_measurements_pq_measure_pq_power_meter1__i_alpha - _diesel_gen1_measurements_pq_measure_pq_power_meter1__v_alpha * _diesel_gen1_measurements_pq_measure_pq_power_meter1__i_beta;
    _diesel_gen1_measurements_pq_measure_pq_power_meter1__P0ac = _diesel_gen1_measurements_pq_measure_pq_power_meter1__v_zero * _diesel_gen1_measurements_pq_measure_pq_power_meter1__i_zero;
    _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_output = 0.018500823612264846 * (_diesel_gen1_measurements_pq_measure_pq_power_meter1__Pac + _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1) - (-0.9629983527754703) * _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1;
    _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_outputQ = 0.018500823612264846 * (_diesel_gen1_measurements_pq_measure_pq_power_meter1__Qac + _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1Q) - (-0.9629983527754703) * _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1Q;
    _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_outputP0 = 0.018500823612264846 * (_diesel_gen1_measurements_pq_measure_pq_power_meter1__P0ac + _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1P0) - (-0.9629983527754703) * _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1P0;
    _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1 = _diesel_gen1_measurements_pq_measure_pq_power_meter1__Pac;
    _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1 = _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_output;
    _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1Q = _diesel_gen1_measurements_pq_measure_pq_power_meter1__Qac;;
    _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1Q = _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_outputQ;
    _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1P0 = _diesel_gen1_measurements_pq_measure_pq_power_meter1__P0ac;
    _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1P0 = _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_outputP0;
    _diesel_gen1_measurements_pq_measure_pq_power_meter1__Pdc = _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_output;
    _diesel_gen1_measurements_pq_measure_pq_power_meter1__Qdc = _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_outputQ;
    _diesel_gen1_measurements_pq_measure_pq_power_meter1__P0dc = _diesel_gen1_measurements_pq_measure_pq_power_meter1__filter_1_outputP0;
    _diesel_gen1_measurements_pq_measure_pq_power_meter1__apparent = sqrt(pow(_diesel_gen1_measurements_pq_measure_pq_power_meter1__Pdc, 2) + pow(_diesel_gen1_measurements_pq_measure_pq_power_meter1__Qdc, 2));
    if (_diesel_gen1_measurements_pq_measure_pq_power_meter1__apparent > 0)
        _diesel_gen1_measurements_pq_measure_pq_power_meter1__k_factor = _diesel_gen1_measurements_pq_measure_pq_power_meter1__Pdc / _diesel_gen1_measurements_pq_measure_pq_power_meter1__apparent;
    else
        _diesel_gen1_measurements_pq_measure_pq_power_meter1__k_factor = 0;
    // Generated from the component: Diesel_Gen1.Sync_Check.Calculate_dw_synch.Signal switch1
    _diesel_gen1_sync_check_calculate_dw_synch_signal_switch1__out = (_diesel_gen1_sync_check_calculate_dw_synch_unit_delay1__out > 0.5f) ? _diesel_gen1_sync_check_calculate_dw_synch_dw_k__out : _diesel_gen1_sync_check_calculate_dw_synch_zero__out;
    // Generated from the component: Diesel_Gen1.MCB.CTC_Wrapper
    if (_diesel_gen1_sync_check_contactor_control_sr_flip_flop1__out == 0x0) {
        HIL_OutInt32(0x8240480, 0x0);
    }
    else {
        HIL_OutInt32(0x8240480, 0x1);
    }
    // Generated from the component: Diesel_Gen1.Sync_Check.Contactor_Control.GCB_cmd
    HIL_OutInt32(0xf00409, _diesel_gen1_sync_check_contactor_control_sr_flip_flop1__out != 0x0);
    // Generated from the component: Diesel_Gen1.Sync_Check.Contactor_Control.Termination12
    // Generated from the component: Diesel_Gen1.Sync_Check.not
    _diesel_gen1_sync_check_not__out = !_diesel_gen1_sync_check_contactor_control_sr_flip_flop1__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.pu1
    _diesel_gen1_sync_check_check_v_diff_pu1__out = 0.0025515518153991436 * _diesel_gen1_sync_check_check_v_diff_abs4__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.PI.Integrator1
    if (((_diesel_gen1_sync_check_check_v_diff_unit_delay1__out > 0.0) && (_diesel_gen1_sync_check_check_v_diff_pi_integrator1__reset_state <= 0)) || ((_diesel_gen1_sync_check_check_v_diff_unit_delay1__out <= 0.0) && (_diesel_gen1_sync_check_check_v_diff_pi_integrator1__reset_state == 1))) {
        _diesel_gen1_sync_check_check_v_diff_pi_integrator1__state = 0.0;
    }
    _diesel_gen1_sync_check_check_v_diff_pi_integrator1__out = _diesel_gen1_sync_check_check_v_diff_pi_integrator1__state;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.Volt_diff
    _diesel_gen1_sync_check_check_v_diff_volt_diff__out = 0.01 * _diesel_gen1_sync_check_check_v_diff_one__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.Vgrid_lowLim
    _diesel_gen1_sync_check_check_v_diff_vgrid_lowlim__out = 0.9 * _diesel_gen1_sync_check_check_v_diff_one1__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.Vgrid_upLim
    _diesel_gen1_sync_check_check_v_diff_vgrid_uplim__out = 1.1 * _diesel_gen1_sync_check_check_v_diff_one1__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_f_diff.Freq_diff
    _diesel_gen1_sync_check_check_f_diff_freq_diff__out = 0.005 * _diesel_gen1_sync_check_check_f_diff_constant1__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.dw_f
    HIL_OutAO(0x401d, (float)_diesel_gen1_sync_check_check_f_diff_topu__out);
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.Counter.c_function
    _diesel_gen1_sync_check_check_phase_diff_counter_c_function__counter = _diesel_gen1_sync_check_check_phase_diff_counter_counter1_accumulator1__out;
    if (_diesel_gen1_sync_check_check_phase_diff_counter_c_function__counter >= 0.1 / 0.0002) {
        _diesel_gen1_sync_check_check_phase_diff_counter_c_function__out = 1;
    }
    else {
        _diesel_gen1_sync_check_check_phase_diff_counter_c_function__out = 0;
    }
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.Phase_diff
    _diesel_gen1_sync_check_check_phase_diff_phase_diff__out = 0.017453292519943295 * _diesel_gen1_sync_check_check_phase_diff_one__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.PI.Ki
    _diesel_gen1_sync_check_check_phase_diff_pi_ki__out = 0.00012 * _diesel_gen1_sync_check_check_phase_diff_to_pu__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.PI.Kp
    _diesel_gen1_sync_check_check_phase_diff_pi_kp__out = 0.01 * _diesel_gen1_sync_check_check_phase_diff_to_pu__out;
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.w to wpu
    _diesel_gen1_control_freq_setpoint_control_w_to_wpu__out = 0.005305164769729845 * _diesel_gen1_bus_split__out1;
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.w to wpu
    _diesel_gen1_control_governor_and_engine_w_to_wpu__out = 0.005305164769729845 * _diesel_gen1_bus_split__out1;
    // Generated from the component: Diesel_Gen1.Control.Start_Exciter.w to wpu
    _diesel_gen1_control_start_exciter_w_to_wpu__out = 0.005305164769729845 * _diesel_gen1_bus_split__out1;
    // Generated from the component: Diesel_Gen1.Control.Termination1
    // Generated from the component: Diesel_Gen1.Control.check_steady_state_w.Sum3
    _diesel_gen1_control_check_steady_state_w_sum3__out = _diesel_gen1_bus_split__out1 - _diesel_gen1_control_check_steady_state_w_constant3__out;
    // Generated from the component: Diesel_Gen2.Control.Exciter.DC4B.TF4
    X_UnInt32 _diesel_gen2_control_exciter_dc4b_tf4__i;
    _diesel_gen2_control_exciter_dc4b_tf4__a_sum = 0.0f;
    _diesel_gen2_control_exciter_dc4b_tf4__b_sum = 0.0f;
    _diesel_gen2_control_exciter_dc4b_tf4__delay_line_in = 0.0f;
    for (_diesel_gen2_control_exciter_dc4b_tf4__i = 0; _diesel_gen2_control_exciter_dc4b_tf4__i < 1; _diesel_gen2_control_exciter_dc4b_tf4__i++) {
        _diesel_gen2_control_exciter_dc4b_tf4__b_sum += _diesel_gen2_control_exciter_dc4b_tf4__b_coeff[_diesel_gen2_control_exciter_dc4b_tf4__i + 1] * _diesel_gen2_control_exciter_dc4b_tf4__states[_diesel_gen2_control_exciter_dc4b_tf4__i];
    }
    _diesel_gen2_control_exciter_dc4b_tf4__a_sum += _diesel_gen2_control_exciter_dc4b_tf4__states[0] * _diesel_gen2_control_exciter_dc4b_tf4__a_coeff[1];
    _diesel_gen2_control_exciter_dc4b_tf4__delay_line_in = _diesel_gen2_control_exciter_dc4b_kf__out - _diesel_gen2_control_exciter_dc4b_tf4__a_sum;
    _diesel_gen2_control_exciter_dc4b_tf4__b_sum += _diesel_gen2_control_exciter_dc4b_tf4__b_coeff[0] * _diesel_gen2_control_exciter_dc4b_tf4__delay_line_in;
    _diesel_gen2_control_exciter_dc4b_tf4__out = _diesel_gen2_control_exciter_dc4b_tf4__b_sum;
    // Generated from the component: Diesel_Gen2.Control.Exciter.DC4B.switch
    _diesel_gen2_control_exciter_dc4b_switch__out = (_diesel_gen2_control_exciter_one__out > 0.5f) ? _diesel_gen2_control_exciter_dc4b_one__out : _diesel_gen2_control_exciter_dc4b_tf1__out;
    // Generated from the component: Diesel_Gen2.Control.Exciter.one_ov_sqrt_3
    _diesel_gen2_control_exciter_one_ov_sqrt_3__out = 0.5773502691896258 * _diesel_gen2_control_exciter_v_inner_droop__out;
    // Generated from the component: Diesel_Gen2.Control.Exciter.Sum1
    _diesel_gen2_control_exciter_sum1__out = _diesel_gen2_control_exciter_const__out + _diesel_gen2_control_exciter_vpss__out;
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.DEGOV.K
    _diesel_gen2_control_governor_and_engine_degov_k__out = 10.0 * _diesel_gen2_control_governor_and_engine_degov_kp__out;
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.Tpu to T
    _diesel_gen2_control_governor_and_engine_tpu_to_t__out = -5305.164769729845 * _diesel_gen2_control_governor_and_engine_degov_transport_delay1__out;
    // Generated from the component: Diesel_Gen2.Control.Start_Exciter.Exciter_start_speed
    _diesel_gen2_control_start_exciter_exciter_start_speed__out = 0.75 * _diesel_gen2_control_start_exciter_steadystate_w__out;
    // Generated from the component: Diesel_Gen2.Control.check_steady_state_w.speed_diff
    _diesel_gen2_control_check_steady_state_w_speed_diff__out = 0.001 * _diesel_gen2_control_check_steady_state_w_constant3__out;
    // Generated from the component: Diesel_Gen2.Ggrid_meas.Bus Join1
    _diesel_gen2_ggrid_meas_bus_join1__out[0] = _diesel_gen2_ggrid_meas_va_va1__out;
    _diesel_gen2_ggrid_meas_bus_join1__out[1] = _diesel_gen2_ggrid_meas_vb_va1__out;
    _diesel_gen2_ggrid_meas_bus_join1__out[2] = _diesel_gen2_ggrid_meas_vc_va1__out;
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.PI.Kd
    _diesel_gen2_measurements_3ph_pll_gen_pll_pi_kd__out = 1.0 * _diesel_gen2_measurements_3ph_pll_gen_pll_normalize_v_terminal__q_pu;
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.PI.Ki
    _diesel_gen2_measurements_3ph_pll_gen_pll_pi_ki__out = 3200.0 * _diesel_gen2_measurements_3ph_pll_gen_pll_normalize_v_terminal__q_pu;
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.PI.Kp
    _diesel_gen2_measurements_3ph_pll_gen_pll_pi_kp__out = 100.0 * _diesel_gen2_measurements_3ph_pll_gen_pll_normalize_v_terminal__q_pu;
    // Generated from the component: Diesel_Gen2.Measurements.e_f
    HIL_OutAO(0x4032, (float)_diesel_gen2_measurements_gain10__out);
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.ABC_dqz.abc to alpha beta
    _diesel_gen2_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__alpha = (2.0 * _diesel_gen2_measurements_va_va1__out - _diesel_gen2_measurements_vb_va1__out - _diesel_gen2_measurements_vc_va1__out) * 0.3333333333333333;
    _diesel_gen2_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__beta = (_diesel_gen2_measurements_vb_va1__out - _diesel_gen2_measurements_vc_va1__out) * 0.5773502691896258;
    _diesel_gen2_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__gamma = (_diesel_gen2_measurements_va_va1__out + _diesel_gen2_measurements_vb_va1__out + _diesel_gen2_measurements_vc_va1__out) * 0.3333333333333333;
    // Generated from the component: Diesel_Gen2.Measurements.PQ measure.PQ Power Meter1
    _diesel_gen2_measurements_pq_measure_pq_power_meter1__v_alpha = SQRT_2OVER3 * ( _diesel_gen2_measurements_va_va1__out - 0.5f * _diesel_gen2_measurements_vb_va1__out - 0.5f * _diesel_gen2_measurements_vc_va1__out);
    _diesel_gen2_measurements_pq_measure_pq_power_meter1__v_beta = SQRT_2OVER3 * (SQRT3_OVER_2 * _diesel_gen2_measurements_vb_va1__out - SQRT3_OVER_2 * _diesel_gen2_measurements_vc_va1__out);
    _diesel_gen2_measurements_pq_measure_pq_power_meter1__i_alpha = SQRT_2OVER3 * ( _diesel_gen2_measurements_ia_ia1__out - 0.5f * _diesel_gen2_measurements_ib_ia1__out - 0.5f * _diesel_gen2_measurements_ic_ia1__out);
    _diesel_gen2_measurements_pq_measure_pq_power_meter1__i_beta = SQRT_2OVER3 * (SQRT3_OVER_2 * _diesel_gen2_measurements_ib_ia1__out - SQRT3_OVER_2 * _diesel_gen2_measurements_ic_ia1__out);
    _diesel_gen2_measurements_pq_measure_pq_power_meter1__v_zero = ONE_DIV_BY_SQRT_3 * (_diesel_gen2_measurements_va_va1__out + _diesel_gen2_measurements_vb_va1__out + _diesel_gen2_measurements_vc_va1__out);
    _diesel_gen2_measurements_pq_measure_pq_power_meter1__i_zero = ONE_DIV_BY_SQRT_3 * (_diesel_gen2_measurements_ia_ia1__out + _diesel_gen2_measurements_ib_ia1__out + _diesel_gen2_measurements_ic_ia1__out);
    _diesel_gen2_measurements_pq_measure_pq_power_meter1__Pac = _diesel_gen2_measurements_pq_measure_pq_power_meter1__v_alpha * _diesel_gen2_measurements_pq_measure_pq_power_meter1__i_alpha + _diesel_gen2_measurements_pq_measure_pq_power_meter1__v_beta * _diesel_gen2_measurements_pq_measure_pq_power_meter1__i_beta;
    _diesel_gen2_measurements_pq_measure_pq_power_meter1__Qac = _diesel_gen2_measurements_pq_measure_pq_power_meter1__v_beta * _diesel_gen2_measurements_pq_measure_pq_power_meter1__i_alpha - _diesel_gen2_measurements_pq_measure_pq_power_meter1__v_alpha * _diesel_gen2_measurements_pq_measure_pq_power_meter1__i_beta;
    _diesel_gen2_measurements_pq_measure_pq_power_meter1__P0ac = _diesel_gen2_measurements_pq_measure_pq_power_meter1__v_zero * _diesel_gen2_measurements_pq_measure_pq_power_meter1__i_zero;
    _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_output = 0.018500823612264846 * (_diesel_gen2_measurements_pq_measure_pq_power_meter1__Pac + _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1) - (-0.9629983527754703) * _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1;
    _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_outputQ = 0.018500823612264846 * (_diesel_gen2_measurements_pq_measure_pq_power_meter1__Qac + _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1Q) - (-0.9629983527754703) * _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1Q;
    _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_outputP0 = 0.018500823612264846 * (_diesel_gen2_measurements_pq_measure_pq_power_meter1__P0ac + _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1P0) - (-0.9629983527754703) * _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1P0;
    _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1 = _diesel_gen2_measurements_pq_measure_pq_power_meter1__Pac;
    _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1 = _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_output;
    _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1Q = _diesel_gen2_measurements_pq_measure_pq_power_meter1__Qac;;
    _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1Q = _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_outputQ;
    _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1P0 = _diesel_gen2_measurements_pq_measure_pq_power_meter1__P0ac;
    _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1P0 = _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_outputP0;
    _diesel_gen2_measurements_pq_measure_pq_power_meter1__Pdc = _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_output;
    _diesel_gen2_measurements_pq_measure_pq_power_meter1__Qdc = _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_outputQ;
    _diesel_gen2_measurements_pq_measure_pq_power_meter1__P0dc = _diesel_gen2_measurements_pq_measure_pq_power_meter1__filter_1_outputP0;
    _diesel_gen2_measurements_pq_measure_pq_power_meter1__apparent = sqrt(pow(_diesel_gen2_measurements_pq_measure_pq_power_meter1__Pdc, 2) + pow(_diesel_gen2_measurements_pq_measure_pq_power_meter1__Qdc, 2));
    if (_diesel_gen2_measurements_pq_measure_pq_power_meter1__apparent > 0)
        _diesel_gen2_measurements_pq_measure_pq_power_meter1__k_factor = _diesel_gen2_measurements_pq_measure_pq_power_meter1__Pdc / _diesel_gen2_measurements_pq_measure_pq_power_meter1__apparent;
    else
        _diesel_gen2_measurements_pq_measure_pq_power_meter1__k_factor = 0;
    // Generated from the component: Diesel_Gen2.Sync_Check.Calculate_dw_synch.Signal switch1
    _diesel_gen2_sync_check_calculate_dw_synch_signal_switch1__out = (_diesel_gen2_sync_check_calculate_dw_synch_unit_delay1__out > 0.5f) ? _diesel_gen2_sync_check_calculate_dw_synch_dw_k__out : _diesel_gen2_sync_check_calculate_dw_synch_zero__out;
    // Generated from the component: Diesel_Gen2.MCB.CTC_Wrapper
    if (_diesel_gen2_sync_check_contactor_control_sr_flip_flop1__out == 0x0) {
        HIL_OutInt32(0x8240481, 0x0);
    }
    else {
        HIL_OutInt32(0x8240481, 0x1);
    }
    // Generated from the component: Diesel_Gen2.Sync_Check.Contactor_Control.GCB_cmd
    HIL_OutInt32(0xf00419, _diesel_gen2_sync_check_contactor_control_sr_flip_flop1__out != 0x0);
    // Generated from the component: Diesel_Gen2.Sync_Check.Contactor_Control.Termination12
    // Generated from the component: Diesel_Gen2.Sync_Check.not
    _diesel_gen2_sync_check_not__out = !_diesel_gen2_sync_check_contactor_control_sr_flip_flop1__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.pu1
    _diesel_gen2_sync_check_check_v_diff_pu1__out = 0.0025515518153991436 * _diesel_gen2_sync_check_check_v_diff_abs4__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.PI.Integrator1
    if (((_diesel_gen2_sync_check_check_v_diff_unit_delay1__out > 0.0) && (_diesel_gen2_sync_check_check_v_diff_pi_integrator1__reset_state <= 0)) || ((_diesel_gen2_sync_check_check_v_diff_unit_delay1__out <= 0.0) && (_diesel_gen2_sync_check_check_v_diff_pi_integrator1__reset_state == 1))) {
        _diesel_gen2_sync_check_check_v_diff_pi_integrator1__state = 0.0;
    }
    _diesel_gen2_sync_check_check_v_diff_pi_integrator1__out = _diesel_gen2_sync_check_check_v_diff_pi_integrator1__state;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.Volt_diff
    _diesel_gen2_sync_check_check_v_diff_volt_diff__out = 0.01 * _diesel_gen2_sync_check_check_v_diff_one__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.Vgrid_lowLim
    _diesel_gen2_sync_check_check_v_diff_vgrid_lowlim__out = 0.9 * _diesel_gen2_sync_check_check_v_diff_one1__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.Vgrid_upLim
    _diesel_gen2_sync_check_check_v_diff_vgrid_uplim__out = 1.1 * _diesel_gen2_sync_check_check_v_diff_one1__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_f_diff.Freq_diff
    _diesel_gen2_sync_check_check_f_diff_freq_diff__out = 0.005 * _diesel_gen2_sync_check_check_f_diff_constant1__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.dw_f
    HIL_OutAO(0x403d, (float)_diesel_gen2_sync_check_check_f_diff_topu__out);
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.Counter.c_function
    _diesel_gen2_sync_check_check_phase_diff_counter_c_function__counter = _diesel_gen2_sync_check_check_phase_diff_counter_counter1_accumulator1__out;
    if (_diesel_gen2_sync_check_check_phase_diff_counter_c_function__counter >= 0.1 / 0.0002) {
        _diesel_gen2_sync_check_check_phase_diff_counter_c_function__out = 1;
    }
    else {
        _diesel_gen2_sync_check_check_phase_diff_counter_c_function__out = 0;
    }
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.Phase_diff
    _diesel_gen2_sync_check_check_phase_diff_phase_diff__out = 0.017453292519943295 * _diesel_gen2_sync_check_check_phase_diff_one__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.PI.Ki
    _diesel_gen2_sync_check_check_phase_diff_pi_ki__out = 0.00012 * _diesel_gen2_sync_check_check_phase_diff_to_pu__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.PI.Kp
    _diesel_gen2_sync_check_check_phase_diff_pi_kp__out = 0.01 * _diesel_gen2_sync_check_check_phase_diff_to_pu__out;
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.w to wpu
    _diesel_gen2_control_freq_setpoint_control_w_to_wpu__out = 0.005305164769729845 * _diesel_gen2_bus_split__out1;
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.w to wpu
    _diesel_gen2_control_governor_and_engine_w_to_wpu__out = 0.005305164769729845 * _diesel_gen2_bus_split__out1;
    // Generated from the component: Diesel_Gen2.Control.Start_Exciter.w to wpu
    _diesel_gen2_control_start_exciter_w_to_wpu__out = 0.005305164769729845 * _diesel_gen2_bus_split__out1;
    // Generated from the component: Diesel_Gen2.Control.Termination1
    // Generated from the component: Diesel_Gen2.Control.check_steady_state_w.Sum3
    _diesel_gen2_control_check_steady_state_w_sum3__out = _diesel_gen2_bus_split__out1 - _diesel_gen2_control_check_steady_state_w_constant3__out;
    // Generated from the component: Diesel_Gen3.Control.Exciter.DC4B.TF4
    X_UnInt32 _diesel_gen3_control_exciter_dc4b_tf4__i;
    _diesel_gen3_control_exciter_dc4b_tf4__a_sum = 0.0f;
    _diesel_gen3_control_exciter_dc4b_tf4__b_sum = 0.0f;
    _diesel_gen3_control_exciter_dc4b_tf4__delay_line_in = 0.0f;
    for (_diesel_gen3_control_exciter_dc4b_tf4__i = 0; _diesel_gen3_control_exciter_dc4b_tf4__i < 1; _diesel_gen3_control_exciter_dc4b_tf4__i++) {
        _diesel_gen3_control_exciter_dc4b_tf4__b_sum += _diesel_gen3_control_exciter_dc4b_tf4__b_coeff[_diesel_gen3_control_exciter_dc4b_tf4__i + 1] * _diesel_gen3_control_exciter_dc4b_tf4__states[_diesel_gen3_control_exciter_dc4b_tf4__i];
    }
    _diesel_gen3_control_exciter_dc4b_tf4__a_sum += _diesel_gen3_control_exciter_dc4b_tf4__states[0] * _diesel_gen3_control_exciter_dc4b_tf4__a_coeff[1];
    _diesel_gen3_control_exciter_dc4b_tf4__delay_line_in = _diesel_gen3_control_exciter_dc4b_kf__out - _diesel_gen3_control_exciter_dc4b_tf4__a_sum;
    _diesel_gen3_control_exciter_dc4b_tf4__b_sum += _diesel_gen3_control_exciter_dc4b_tf4__b_coeff[0] * _diesel_gen3_control_exciter_dc4b_tf4__delay_line_in;
    _diesel_gen3_control_exciter_dc4b_tf4__out = _diesel_gen3_control_exciter_dc4b_tf4__b_sum;
    // Generated from the component: Diesel_Gen3.Control.Exciter.DC4B.switch
    _diesel_gen3_control_exciter_dc4b_switch__out = (_diesel_gen3_control_exciter_one__out > 0.5f) ? _diesel_gen3_control_exciter_dc4b_one__out : _diesel_gen3_control_exciter_dc4b_tf1__out;
    // Generated from the component: Diesel_Gen3.Control.Exciter.one_ov_sqrt_3
    _diesel_gen3_control_exciter_one_ov_sqrt_3__out = 0.5773502691896258 * _diesel_gen3_control_exciter_v_inner_droop__out;
    // Generated from the component: Diesel_Gen3.Control.Exciter.Sum1
    _diesel_gen3_control_exciter_sum1__out = _diesel_gen3_control_exciter_const__out + _diesel_gen3_control_exciter_vpss__out;
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.DEGOV.K
    _diesel_gen3_control_governor_and_engine_degov_k__out = 10.0 * _diesel_gen3_control_governor_and_engine_degov_kp__out;
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.Tpu to T
    _diesel_gen3_control_governor_and_engine_tpu_to_t__out = -5305.164769729845 * _diesel_gen3_control_governor_and_engine_degov_transport_delay1__out;
    // Generated from the component: Diesel_Gen3.Control.Start_Exciter.Exciter_start_speed
    _diesel_gen3_control_start_exciter_exciter_start_speed__out = 0.75 * _diesel_gen3_control_start_exciter_steadystate_w__out;
    // Generated from the component: Diesel_Gen3.Control.check_steady_state_w.speed_diff
    _diesel_gen3_control_check_steady_state_w_speed_diff__out = 0.001 * _diesel_gen3_control_check_steady_state_w_constant3__out;
    // Generated from the component: Diesel_Gen3.Ggrid_meas.Bus Join1
    _diesel_gen3_ggrid_meas_bus_join1__out[0] = _diesel_gen3_ggrid_meas_va_va1__out;
    _diesel_gen3_ggrid_meas_bus_join1__out[1] = _diesel_gen3_ggrid_meas_vb_va1__out;
    _diesel_gen3_ggrid_meas_bus_join1__out[2] = _diesel_gen3_ggrid_meas_vc_va1__out;
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.PI.Kd
    _diesel_gen3_measurements_3ph_pll_gen_pll_pi_kd__out = 1.0 * _diesel_gen3_measurements_3ph_pll_gen_pll_normalize_v_terminal__q_pu;
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.PI.Ki
    _diesel_gen3_measurements_3ph_pll_gen_pll_pi_ki__out = 3200.0 * _diesel_gen3_measurements_3ph_pll_gen_pll_normalize_v_terminal__q_pu;
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.PI.Kp
    _diesel_gen3_measurements_3ph_pll_gen_pll_pi_kp__out = 100.0 * _diesel_gen3_measurements_3ph_pll_gen_pll_normalize_v_terminal__q_pu;
    // Generated from the component: Diesel_Gen3.Measurements.e_f
    HIL_OutAO(0x4052, (float)_diesel_gen3_measurements_gain10__out);
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.ABC_dqz.abc to alpha beta
    _diesel_gen3_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__alpha = (2.0 * _diesel_gen3_measurements_va_va1__out - _diesel_gen3_measurements_vb_va1__out - _diesel_gen3_measurements_vc_va1__out) * 0.3333333333333333;
    _diesel_gen3_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__beta = (_diesel_gen3_measurements_vb_va1__out - _diesel_gen3_measurements_vc_va1__out) * 0.5773502691896258;
    _diesel_gen3_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__gamma = (_diesel_gen3_measurements_va_va1__out + _diesel_gen3_measurements_vb_va1__out + _diesel_gen3_measurements_vc_va1__out) * 0.3333333333333333;
    // Generated from the component: Diesel_Gen3.Measurements.PQ measure.PQ Power Meter1
    _diesel_gen3_measurements_pq_measure_pq_power_meter1__v_alpha = SQRT_2OVER3 * ( _diesel_gen3_measurements_va_va1__out - 0.5f * _diesel_gen3_measurements_vb_va1__out - 0.5f * _diesel_gen3_measurements_vc_va1__out);
    _diesel_gen3_measurements_pq_measure_pq_power_meter1__v_beta = SQRT_2OVER3 * (SQRT3_OVER_2 * _diesel_gen3_measurements_vb_va1__out - SQRT3_OVER_2 * _diesel_gen3_measurements_vc_va1__out);
    _diesel_gen3_measurements_pq_measure_pq_power_meter1__i_alpha = SQRT_2OVER3 * ( _diesel_gen3_measurements_ia_ia1__out - 0.5f * _diesel_gen3_measurements_ib_ia1__out - 0.5f * _diesel_gen3_measurements_ic_ia1__out);
    _diesel_gen3_measurements_pq_measure_pq_power_meter1__i_beta = SQRT_2OVER3 * (SQRT3_OVER_2 * _diesel_gen3_measurements_ib_ia1__out - SQRT3_OVER_2 * _diesel_gen3_measurements_ic_ia1__out);
    _diesel_gen3_measurements_pq_measure_pq_power_meter1__v_zero = ONE_DIV_BY_SQRT_3 * (_diesel_gen3_measurements_va_va1__out + _diesel_gen3_measurements_vb_va1__out + _diesel_gen3_measurements_vc_va1__out);
    _diesel_gen3_measurements_pq_measure_pq_power_meter1__i_zero = ONE_DIV_BY_SQRT_3 * (_diesel_gen3_measurements_ia_ia1__out + _diesel_gen3_measurements_ib_ia1__out + _diesel_gen3_measurements_ic_ia1__out);
    _diesel_gen3_measurements_pq_measure_pq_power_meter1__Pac = _diesel_gen3_measurements_pq_measure_pq_power_meter1__v_alpha * _diesel_gen3_measurements_pq_measure_pq_power_meter1__i_alpha + _diesel_gen3_measurements_pq_measure_pq_power_meter1__v_beta * _diesel_gen3_measurements_pq_measure_pq_power_meter1__i_beta;
    _diesel_gen3_measurements_pq_measure_pq_power_meter1__Qac = _diesel_gen3_measurements_pq_measure_pq_power_meter1__v_beta * _diesel_gen3_measurements_pq_measure_pq_power_meter1__i_alpha - _diesel_gen3_measurements_pq_measure_pq_power_meter1__v_alpha * _diesel_gen3_measurements_pq_measure_pq_power_meter1__i_beta;
    _diesel_gen3_measurements_pq_measure_pq_power_meter1__P0ac = _diesel_gen3_measurements_pq_measure_pq_power_meter1__v_zero * _diesel_gen3_measurements_pq_measure_pq_power_meter1__i_zero;
    _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_output = 0.018500823612264846 * (_diesel_gen3_measurements_pq_measure_pq_power_meter1__Pac + _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1) - (-0.9629983527754703) * _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1;
    _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_outputQ = 0.018500823612264846 * (_diesel_gen3_measurements_pq_measure_pq_power_meter1__Qac + _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1Q) - (-0.9629983527754703) * _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1Q;
    _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_outputP0 = 0.018500823612264846 * (_diesel_gen3_measurements_pq_measure_pq_power_meter1__P0ac + _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1P0) - (-0.9629983527754703) * _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1P0;
    _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1 = _diesel_gen3_measurements_pq_measure_pq_power_meter1__Pac;
    _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1 = _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_output;
    _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1Q = _diesel_gen3_measurements_pq_measure_pq_power_meter1__Qac;;
    _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1Q = _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_outputQ;
    _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1P0 = _diesel_gen3_measurements_pq_measure_pq_power_meter1__P0ac;
    _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1P0 = _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_outputP0;
    _diesel_gen3_measurements_pq_measure_pq_power_meter1__Pdc = _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_output;
    _diesel_gen3_measurements_pq_measure_pq_power_meter1__Qdc = _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_outputQ;
    _diesel_gen3_measurements_pq_measure_pq_power_meter1__P0dc = _diesel_gen3_measurements_pq_measure_pq_power_meter1__filter_1_outputP0;
    _diesel_gen3_measurements_pq_measure_pq_power_meter1__apparent = sqrt(pow(_diesel_gen3_measurements_pq_measure_pq_power_meter1__Pdc, 2) + pow(_diesel_gen3_measurements_pq_measure_pq_power_meter1__Qdc, 2));
    if (_diesel_gen3_measurements_pq_measure_pq_power_meter1__apparent > 0)
        _diesel_gen3_measurements_pq_measure_pq_power_meter1__k_factor = _diesel_gen3_measurements_pq_measure_pq_power_meter1__Pdc / _diesel_gen3_measurements_pq_measure_pq_power_meter1__apparent;
    else
        _diesel_gen3_measurements_pq_measure_pq_power_meter1__k_factor = 0;
    // Generated from the component: Diesel_Gen3.Sync_Check.Calculate_dw_synch.Signal switch1
    _diesel_gen3_sync_check_calculate_dw_synch_signal_switch1__out = (_diesel_gen3_sync_check_calculate_dw_synch_unit_delay1__out > 0.5f) ? _diesel_gen3_sync_check_calculate_dw_synch_dw_k__out : _diesel_gen3_sync_check_calculate_dw_synch_zero__out;
    // Generated from the component: Diesel_Gen3.MCB.CTC_Wrapper
    if (_diesel_gen3_sync_check_contactor_control_sr_flip_flop1__out == 0x0) {
        HIL_OutInt32(0x8240482, 0x0);
    }
    else {
        HIL_OutInt32(0x8240482, 0x1);
    }
    // Generated from the component: Diesel_Gen3.Sync_Check.Contactor_Control.GCB_cmd
    HIL_OutInt32(0xf00429, _diesel_gen3_sync_check_contactor_control_sr_flip_flop1__out != 0x0);
    // Generated from the component: Diesel_Gen3.Sync_Check.Contactor_Control.Termination12
    // Generated from the component: Diesel_Gen3.Sync_Check.not
    _diesel_gen3_sync_check_not__out = !_diesel_gen3_sync_check_contactor_control_sr_flip_flop1__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.pu1
    _diesel_gen3_sync_check_check_v_diff_pu1__out = 0.0025515518153991436 * _diesel_gen3_sync_check_check_v_diff_abs4__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.PI.Integrator1
    if (((_diesel_gen3_sync_check_check_v_diff_unit_delay1__out > 0.0) && (_diesel_gen3_sync_check_check_v_diff_pi_integrator1__reset_state <= 0)) || ((_diesel_gen3_sync_check_check_v_diff_unit_delay1__out <= 0.0) && (_diesel_gen3_sync_check_check_v_diff_pi_integrator1__reset_state == 1))) {
        _diesel_gen3_sync_check_check_v_diff_pi_integrator1__state = 0.0;
    }
    _diesel_gen3_sync_check_check_v_diff_pi_integrator1__out = _diesel_gen3_sync_check_check_v_diff_pi_integrator1__state;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.Volt_diff
    _diesel_gen3_sync_check_check_v_diff_volt_diff__out = 0.01 * _diesel_gen3_sync_check_check_v_diff_one__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.Vgrid_lowLim
    _diesel_gen3_sync_check_check_v_diff_vgrid_lowlim__out = 0.9 * _diesel_gen3_sync_check_check_v_diff_one1__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.Vgrid_upLim
    _diesel_gen3_sync_check_check_v_diff_vgrid_uplim__out = 1.1 * _diesel_gen3_sync_check_check_v_diff_one1__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_f_diff.Freq_diff
    _diesel_gen3_sync_check_check_f_diff_freq_diff__out = 0.005 * _diesel_gen3_sync_check_check_f_diff_constant1__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.dw_f
    HIL_OutAO(0x405d, (float)_diesel_gen3_sync_check_check_f_diff_topu__out);
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.Counter.c_function
    _diesel_gen3_sync_check_check_phase_diff_counter_c_function__counter = _diesel_gen3_sync_check_check_phase_diff_counter_counter1_accumulator1__out;
    if (_diesel_gen3_sync_check_check_phase_diff_counter_c_function__counter >= 0.1 / 0.0002) {
        _diesel_gen3_sync_check_check_phase_diff_counter_c_function__out = 1;
    }
    else {
        _diesel_gen3_sync_check_check_phase_diff_counter_c_function__out = 0;
    }
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.Phase_diff
    _diesel_gen3_sync_check_check_phase_diff_phase_diff__out = 0.017453292519943295 * _diesel_gen3_sync_check_check_phase_diff_one__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.PI.Ki
    _diesel_gen3_sync_check_check_phase_diff_pi_ki__out = 0.00012 * _diesel_gen3_sync_check_check_phase_diff_to_pu__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.PI.Kp
    _diesel_gen3_sync_check_check_phase_diff_pi_kp__out = 0.01 * _diesel_gen3_sync_check_check_phase_diff_to_pu__out;
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.w to wpu
    _diesel_gen3_control_freq_setpoint_control_w_to_wpu__out = 0.005305164769729845 * _diesel_gen3_bus_split__out1;
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.w to wpu
    _diesel_gen3_control_governor_and_engine_w_to_wpu__out = 0.005305164769729845 * _diesel_gen3_bus_split__out1;
    // Generated from the component: Diesel_Gen3.Control.Start_Exciter.w to wpu
    _diesel_gen3_control_start_exciter_w_to_wpu__out = 0.005305164769729845 * _diesel_gen3_bus_split__out1;
    // Generated from the component: Diesel_Gen3.Control.Termination1
    // Generated from the component: Diesel_Gen3.Control.check_steady_state_w.Sum3
    _diesel_gen3_control_check_steady_state_w_sum3__out = _diesel_gen3_bus_split__out1 - _diesel_gen3_control_check_steady_state_w_constant3__out;
    // Generated from the component: Diesel_Gen4.Control.Exciter.DC4B.TF4
    X_UnInt32 _diesel_gen4_control_exciter_dc4b_tf4__i;
    _diesel_gen4_control_exciter_dc4b_tf4__a_sum = 0.0f;
    _diesel_gen4_control_exciter_dc4b_tf4__b_sum = 0.0f;
    _diesel_gen4_control_exciter_dc4b_tf4__delay_line_in = 0.0f;
    for (_diesel_gen4_control_exciter_dc4b_tf4__i = 0; _diesel_gen4_control_exciter_dc4b_tf4__i < 1; _diesel_gen4_control_exciter_dc4b_tf4__i++) {
        _diesel_gen4_control_exciter_dc4b_tf4__b_sum += _diesel_gen4_control_exciter_dc4b_tf4__b_coeff[_diesel_gen4_control_exciter_dc4b_tf4__i + 1] * _diesel_gen4_control_exciter_dc4b_tf4__states[_diesel_gen4_control_exciter_dc4b_tf4__i];
    }
    _diesel_gen4_control_exciter_dc4b_tf4__a_sum += _diesel_gen4_control_exciter_dc4b_tf4__states[0] * _diesel_gen4_control_exciter_dc4b_tf4__a_coeff[1];
    _diesel_gen4_control_exciter_dc4b_tf4__delay_line_in = _diesel_gen4_control_exciter_dc4b_kf__out - _diesel_gen4_control_exciter_dc4b_tf4__a_sum;
    _diesel_gen4_control_exciter_dc4b_tf4__b_sum += _diesel_gen4_control_exciter_dc4b_tf4__b_coeff[0] * _diesel_gen4_control_exciter_dc4b_tf4__delay_line_in;
    _diesel_gen4_control_exciter_dc4b_tf4__out = _diesel_gen4_control_exciter_dc4b_tf4__b_sum;
    // Generated from the component: Diesel_Gen4.Control.Exciter.DC4B.switch
    _diesel_gen4_control_exciter_dc4b_switch__out = (_diesel_gen4_control_exciter_one__out > 0.5f) ? _diesel_gen4_control_exciter_dc4b_one__out : _diesel_gen4_control_exciter_dc4b_tf1__out;
    // Generated from the component: Diesel_Gen4.Control.Exciter.one_ov_sqrt_3
    _diesel_gen4_control_exciter_one_ov_sqrt_3__out = 0.5773502691896258 * _diesel_gen4_control_exciter_v_inner_droop__out;
    // Generated from the component: Diesel_Gen4.Control.Exciter.Sum1
    _diesel_gen4_control_exciter_sum1__out = _diesel_gen4_control_exciter_const__out + _diesel_gen4_control_exciter_vpss__out;
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.DEGOV.K
    _diesel_gen4_control_governor_and_engine_degov_k__out = 10.0 * _diesel_gen4_control_governor_and_engine_degov_kp__out;
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.Tpu to T
    _diesel_gen4_control_governor_and_engine_tpu_to_t__out = -5305.164769729845 * _diesel_gen4_control_governor_and_engine_degov_transport_delay1__out;
    // Generated from the component: Diesel_Gen4.Control.Start_Exciter.Exciter_start_speed
    _diesel_gen4_control_start_exciter_exciter_start_speed__out = 0.75 * _diesel_gen4_control_start_exciter_steadystate_w__out;
    // Generated from the component: Diesel_Gen4.Control.check_steady_state_w.speed_diff
    _diesel_gen4_control_check_steady_state_w_speed_diff__out = 0.001 * _diesel_gen4_control_check_steady_state_w_constant3__out;
    // Generated from the component: Diesel_Gen4.Ggrid_meas.Bus Join1
    _diesel_gen4_ggrid_meas_bus_join1__out[0] = _diesel_gen4_ggrid_meas_va_va1__out;
    _diesel_gen4_ggrid_meas_bus_join1__out[1] = _diesel_gen4_ggrid_meas_vb_va1__out;
    _diesel_gen4_ggrid_meas_bus_join1__out[2] = _diesel_gen4_ggrid_meas_vc_va1__out;
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.PI.Kd
    _diesel_gen4_measurements_3ph_pll_gen_pll_pi_kd__out = 1.0 * _diesel_gen4_measurements_3ph_pll_gen_pll_normalize_v_terminal__q_pu;
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.PI.Ki
    _diesel_gen4_measurements_3ph_pll_gen_pll_pi_ki__out = 3200.0 * _diesel_gen4_measurements_3ph_pll_gen_pll_normalize_v_terminal__q_pu;
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.PI.Kp
    _diesel_gen4_measurements_3ph_pll_gen_pll_pi_kp__out = 100.0 * _diesel_gen4_measurements_3ph_pll_gen_pll_normalize_v_terminal__q_pu;
    // Generated from the component: Diesel_Gen4.Measurements.e_f
    HIL_OutAO(0x4072, (float)_diesel_gen4_measurements_gain10__out);
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.ABC_dqz.abc to alpha beta
    _diesel_gen4_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__alpha = (2.0 * _diesel_gen4_measurements_va_va1__out - _diesel_gen4_measurements_vb_va1__out - _diesel_gen4_measurements_vc_va1__out) * 0.3333333333333333;
    _diesel_gen4_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__beta = (_diesel_gen4_measurements_vb_va1__out - _diesel_gen4_measurements_vc_va1__out) * 0.5773502691896258;
    _diesel_gen4_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__gamma = (_diesel_gen4_measurements_va_va1__out + _diesel_gen4_measurements_vb_va1__out + _diesel_gen4_measurements_vc_va1__out) * 0.3333333333333333;
    // Generated from the component: Diesel_Gen4.Measurements.PQ measure.PQ Power Meter1
    _diesel_gen4_measurements_pq_measure_pq_power_meter1__v_alpha = SQRT_2OVER3 * ( _diesel_gen4_measurements_va_va1__out - 0.5f * _diesel_gen4_measurements_vb_va1__out - 0.5f * _diesel_gen4_measurements_vc_va1__out);
    _diesel_gen4_measurements_pq_measure_pq_power_meter1__v_beta = SQRT_2OVER3 * (SQRT3_OVER_2 * _diesel_gen4_measurements_vb_va1__out - SQRT3_OVER_2 * _diesel_gen4_measurements_vc_va1__out);
    _diesel_gen4_measurements_pq_measure_pq_power_meter1__i_alpha = SQRT_2OVER3 * ( _diesel_gen4_measurements_ia_ia1__out - 0.5f * _diesel_gen4_measurements_ib_ia1__out - 0.5f * _diesel_gen4_measurements_ic_ia1__out);
    _diesel_gen4_measurements_pq_measure_pq_power_meter1__i_beta = SQRT_2OVER3 * (SQRT3_OVER_2 * _diesel_gen4_measurements_ib_ia1__out - SQRT3_OVER_2 * _diesel_gen4_measurements_ic_ia1__out);
    _diesel_gen4_measurements_pq_measure_pq_power_meter1__v_zero = ONE_DIV_BY_SQRT_3 * (_diesel_gen4_measurements_va_va1__out + _diesel_gen4_measurements_vb_va1__out + _diesel_gen4_measurements_vc_va1__out);
    _diesel_gen4_measurements_pq_measure_pq_power_meter1__i_zero = ONE_DIV_BY_SQRT_3 * (_diesel_gen4_measurements_ia_ia1__out + _diesel_gen4_measurements_ib_ia1__out + _diesel_gen4_measurements_ic_ia1__out);
    _diesel_gen4_measurements_pq_measure_pq_power_meter1__Pac = _diesel_gen4_measurements_pq_measure_pq_power_meter1__v_alpha * _diesel_gen4_measurements_pq_measure_pq_power_meter1__i_alpha + _diesel_gen4_measurements_pq_measure_pq_power_meter1__v_beta * _diesel_gen4_measurements_pq_measure_pq_power_meter1__i_beta;
    _diesel_gen4_measurements_pq_measure_pq_power_meter1__Qac = _diesel_gen4_measurements_pq_measure_pq_power_meter1__v_beta * _diesel_gen4_measurements_pq_measure_pq_power_meter1__i_alpha - _diesel_gen4_measurements_pq_measure_pq_power_meter1__v_alpha * _diesel_gen4_measurements_pq_measure_pq_power_meter1__i_beta;
    _diesel_gen4_measurements_pq_measure_pq_power_meter1__P0ac = _diesel_gen4_measurements_pq_measure_pq_power_meter1__v_zero * _diesel_gen4_measurements_pq_measure_pq_power_meter1__i_zero;
    _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_output = 0.018500823612264846 * (_diesel_gen4_measurements_pq_measure_pq_power_meter1__Pac + _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1) - (-0.9629983527754703) * _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1;
    _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_outputQ = 0.018500823612264846 * (_diesel_gen4_measurements_pq_measure_pq_power_meter1__Qac + _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1Q) - (-0.9629983527754703) * _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1Q;
    _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_outputP0 = 0.018500823612264846 * (_diesel_gen4_measurements_pq_measure_pq_power_meter1__P0ac + _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1P0) - (-0.9629983527754703) * _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1P0;
    _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1 = _diesel_gen4_measurements_pq_measure_pq_power_meter1__Pac;
    _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1 = _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_output;
    _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1Q = _diesel_gen4_measurements_pq_measure_pq_power_meter1__Qac;;
    _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1Q = _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_outputQ;
    _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_input_k_minus_1P0 = _diesel_gen4_measurements_pq_measure_pq_power_meter1__P0ac;
    _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_output_k_minus_1P0 = _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_outputP0;
    _diesel_gen4_measurements_pq_measure_pq_power_meter1__Pdc = _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_output;
    _diesel_gen4_measurements_pq_measure_pq_power_meter1__Qdc = _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_outputQ;
    _diesel_gen4_measurements_pq_measure_pq_power_meter1__P0dc = _diesel_gen4_measurements_pq_measure_pq_power_meter1__filter_1_outputP0;
    _diesel_gen4_measurements_pq_measure_pq_power_meter1__apparent = sqrt(pow(_diesel_gen4_measurements_pq_measure_pq_power_meter1__Pdc, 2) + pow(_diesel_gen4_measurements_pq_measure_pq_power_meter1__Qdc, 2));
    if (_diesel_gen4_measurements_pq_measure_pq_power_meter1__apparent > 0)
        _diesel_gen4_measurements_pq_measure_pq_power_meter1__k_factor = _diesel_gen4_measurements_pq_measure_pq_power_meter1__Pdc / _diesel_gen4_measurements_pq_measure_pq_power_meter1__apparent;
    else
        _diesel_gen4_measurements_pq_measure_pq_power_meter1__k_factor = 0;
    // Generated from the component: Diesel_Gen4.Sync_Check.Calculate_dw_synch.Signal switch1
    _diesel_gen4_sync_check_calculate_dw_synch_signal_switch1__out = (_diesel_gen4_sync_check_calculate_dw_synch_unit_delay1__out > 0.5f) ? _diesel_gen4_sync_check_calculate_dw_synch_dw_k__out : _diesel_gen4_sync_check_calculate_dw_synch_zero__out;
    // Generated from the component: Diesel_Gen4.MCB.CTC_Wrapper
    if (_diesel_gen4_sync_check_contactor_control_sr_flip_flop1__out == 0x0) {
        HIL_OutInt32(0x8240483, 0x0);
    }
    else {
        HIL_OutInt32(0x8240483, 0x1);
    }
    // Generated from the component: Diesel_Gen4.Sync_Check.Contactor_Control.GCB_cmd
    HIL_OutInt32(0xf00439, _diesel_gen4_sync_check_contactor_control_sr_flip_flop1__out != 0x0);
    // Generated from the component: Diesel_Gen4.Sync_Check.Contactor_Control.Termination12
    // Generated from the component: Diesel_Gen4.Sync_Check.not
    _diesel_gen4_sync_check_not__out = !_diesel_gen4_sync_check_contactor_control_sr_flip_flop1__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.pu1
    _diesel_gen4_sync_check_check_v_diff_pu1__out = 0.0025515518153991436 * _diesel_gen4_sync_check_check_v_diff_abs4__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.PI.Integrator1
    if (((_diesel_gen4_sync_check_check_v_diff_unit_delay1__out > 0.0) && (_diesel_gen4_sync_check_check_v_diff_pi_integrator1__reset_state <= 0)) || ((_diesel_gen4_sync_check_check_v_diff_unit_delay1__out <= 0.0) && (_diesel_gen4_sync_check_check_v_diff_pi_integrator1__reset_state == 1))) {
        _diesel_gen4_sync_check_check_v_diff_pi_integrator1__state = 0.0;
    }
    _diesel_gen4_sync_check_check_v_diff_pi_integrator1__out = _diesel_gen4_sync_check_check_v_diff_pi_integrator1__state;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.Volt_diff
    _diesel_gen4_sync_check_check_v_diff_volt_diff__out = 0.01 * _diesel_gen4_sync_check_check_v_diff_one__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.Vgrid_lowLim
    _diesel_gen4_sync_check_check_v_diff_vgrid_lowlim__out = 0.9 * _diesel_gen4_sync_check_check_v_diff_one1__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.Vgrid_upLim
    _diesel_gen4_sync_check_check_v_diff_vgrid_uplim__out = 1.1 * _diesel_gen4_sync_check_check_v_diff_one1__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_f_diff.Freq_diff
    _diesel_gen4_sync_check_check_f_diff_freq_diff__out = 0.005 * _diesel_gen4_sync_check_check_f_diff_constant1__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.dw_f
    HIL_OutAO(0x407d, (float)_diesel_gen4_sync_check_check_f_diff_topu__out);
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.Counter.c_function
    _diesel_gen4_sync_check_check_phase_diff_counter_c_function__counter = _diesel_gen4_sync_check_check_phase_diff_counter_counter1_accumulator1__out;
    if (_diesel_gen4_sync_check_check_phase_diff_counter_c_function__counter >= 0.1 / 0.0002) {
        _diesel_gen4_sync_check_check_phase_diff_counter_c_function__out = 1;
    }
    else {
        _diesel_gen4_sync_check_check_phase_diff_counter_c_function__out = 0;
    }
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.Phase_diff
    _diesel_gen4_sync_check_check_phase_diff_phase_diff__out = 0.017453292519943295 * _diesel_gen4_sync_check_check_phase_diff_one__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.PI.Ki
    _diesel_gen4_sync_check_check_phase_diff_pi_ki__out = 0.00012 * _diesel_gen4_sync_check_check_phase_diff_to_pu__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.PI.Kp
    _diesel_gen4_sync_check_check_phase_diff_pi_kp__out = 0.01 * _diesel_gen4_sync_check_check_phase_diff_to_pu__out;
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.w to wpu
    _diesel_gen4_control_freq_setpoint_control_w_to_wpu__out = 0.005305164769729845 * _diesel_gen4_bus_split__out1;
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.w to wpu
    _diesel_gen4_control_governor_and_engine_w_to_wpu__out = 0.005305164769729845 * _diesel_gen4_bus_split__out1;
    // Generated from the component: Diesel_Gen4.Control.Start_Exciter.w to wpu
    _diesel_gen4_control_start_exciter_w_to_wpu__out = 0.005305164769729845 * _diesel_gen4_bus_split__out1;
    // Generated from the component: Diesel_Gen4.Control.Termination1
    // Generated from the component: Diesel_Gen4.Control.check_steady_state_w.Sum3
    _diesel_gen4_control_check_steady_state_w_sum3__out = _diesel_gen4_bus_split__out1 - _diesel_gen4_control_check_steady_state_w_constant3__out;
    // Generated from the component: Diesel_Gen1.Control.Bus Split3
    _diesel_gen1_control_bus_split3__out = _dg_in_bus_join2__out[0];
    _diesel_gen1_control_bus_split3__out1 = _dg_in_bus_join2__out[1];
    _diesel_gen1_control_bus_split3__out2 = _dg_in_bus_join2__out[2];
    _diesel_gen1_control_bus_split3__out3 = _dg_in_bus_join2__out[3];
    _diesel_gen1_control_bus_split3__out4 = _dg_in_bus_join2__out[4];
    _diesel_gen1_control_bus_split3__out5 = _dg_in_bus_join2__out[5];
    _diesel_gen1_control_bus_split3__out6 = _dg_in_bus_join2__out[6];
    _diesel_gen1_control_bus_split3__out7 = _dg_in_bus_join2__out[7];
    _diesel_gen1_control_bus_split3__out8 = _dg_in_bus_join2__out[8];
    // Generated from the component: Diesel_Gen2.Control.Bus Split3
    _diesel_gen2_control_bus_split3__out = _dg_in1_bus_join2__out[0];
    _diesel_gen2_control_bus_split3__out1 = _dg_in1_bus_join2__out[1];
    _diesel_gen2_control_bus_split3__out2 = _dg_in1_bus_join2__out[2];
    _diesel_gen2_control_bus_split3__out3 = _dg_in1_bus_join2__out[3];
    _diesel_gen2_control_bus_split3__out4 = _dg_in1_bus_join2__out[4];
    _diesel_gen2_control_bus_split3__out5 = _dg_in1_bus_join2__out[5];
    _diesel_gen2_control_bus_split3__out6 = _dg_in1_bus_join2__out[6];
    _diesel_gen2_control_bus_split3__out7 = _dg_in1_bus_join2__out[7];
    _diesel_gen2_control_bus_split3__out8 = _dg_in1_bus_join2__out[8];
    // Generated from the component: Diesel_Gen4.Control.Bus Split3
    _diesel_gen4_control_bus_split3__out = _dg_in3_bus_join2__out[0];
    _diesel_gen4_control_bus_split3__out1 = _dg_in3_bus_join2__out[1];
    _diesel_gen4_control_bus_split3__out2 = _dg_in3_bus_join2__out[2];
    _diesel_gen4_control_bus_split3__out3 = _dg_in3_bus_join2__out[3];
    _diesel_gen4_control_bus_split3__out4 = _dg_in3_bus_join2__out[4];
    _diesel_gen4_control_bus_split3__out5 = _dg_in3_bus_join2__out[5];
    _diesel_gen4_control_bus_split3__out6 = _dg_in3_bus_join2__out[6];
    _diesel_gen4_control_bus_split3__out7 = _dg_in3_bus_join2__out[7];
    _diesel_gen4_control_bus_split3__out8 = _dg_in3_bus_join2__out[8];
    // Generated from the component: Diesel_Gen3.Control.Bus Split3
    _diesel_gen3_control_bus_split3__out = _dg_in4_bus_join2__out[0];
    _diesel_gen3_control_bus_split3__out1 = _dg_in4_bus_join2__out[1];
    _diesel_gen3_control_bus_split3__out2 = _dg_in4_bus_join2__out[2];
    _diesel_gen3_control_bus_split3__out3 = _dg_in4_bus_join2__out[3];
    _diesel_gen3_control_bus_split3__out4 = _dg_in4_bus_join2__out[4];
    _diesel_gen3_control_bus_split3__out5 = _dg_in4_bus_join2__out[5];
    _diesel_gen3_control_bus_split3__out6 = _dg_in4_bus_join2__out[6];
    _diesel_gen3_control_bus_split3__out7 = _dg_in4_bus_join2__out[7];
    _diesel_gen3_control_bus_split3__out8 = _dg_in4_bus_join2__out[8];
    // Generated from the component: Diesel_Gen1.Control.Exciter.DC4B.Variable Limit
    _diesel_gen1_control_exciter_dc4b_variable_limit__LimitChange = _diesel_gen1_control_exciter_dc4b_switch__out;
    _diesel_gen1_control_exciter_dc4b_variable_limit__in = _diesel_gen1_control_exciter_dc4b_tf2__out;
    if (_diesel_gen1_control_exciter_dc4b_variable_limit__LimitChange == 0.0) {
        _diesel_gen1_control_exciter_dc4b_variable_limit__LimitChange = 0.01;
    }
    if (_diesel_gen1_control_exciter_dc4b_variable_limit__in >= 10.0 * _diesel_gen1_control_exciter_dc4b_variable_limit__LimitChange) {
        _diesel_gen1_control_exciter_dc4b_variable_limit__out = 10.0 * _diesel_gen1_control_exciter_dc4b_variable_limit__LimitChange;
    }
    else {
        if (_diesel_gen1_control_exciter_dc4b_variable_limit__in <= (-10.0)*_diesel_gen1_control_exciter_dc4b_variable_limit__LimitChange) {
            _diesel_gen1_control_exciter_dc4b_variable_limit__out = (-10.0) * _diesel_gen1_control_exciter_dc4b_variable_limit__LimitChange;
        }
        else {
            _diesel_gen1_control_exciter_dc4b_variable_limit__out = _diesel_gen1_control_exciter_dc4b_variable_limit__in;
        }
    }
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.DEGOV.TF2
    X_UnInt32 _diesel_gen1_control_governor_and_engine_degov_tf2__i;
    _diesel_gen1_control_governor_and_engine_degov_tf2__a_sum = 0.0f;
    _diesel_gen1_control_governor_and_engine_degov_tf2__b_sum = 0.0f;
    _diesel_gen1_control_governor_and_engine_degov_tf2__delay_line_in = 0.0f;
    for (_diesel_gen1_control_governor_and_engine_degov_tf2__i = 0; _diesel_gen1_control_governor_and_engine_degov_tf2__i < 2; _diesel_gen1_control_governor_and_engine_degov_tf2__i++) {
        _diesel_gen1_control_governor_and_engine_degov_tf2__b_sum += _diesel_gen1_control_governor_and_engine_degov_tf2__b_coeff[_diesel_gen1_control_governor_and_engine_degov_tf2__i + 1] * _diesel_gen1_control_governor_and_engine_degov_tf2__states[_diesel_gen1_control_governor_and_engine_degov_tf2__i];
    }
    for (_diesel_gen1_control_governor_and_engine_degov_tf2__i = 1; _diesel_gen1_control_governor_and_engine_degov_tf2__i > 0; _diesel_gen1_control_governor_and_engine_degov_tf2__i--) {
        _diesel_gen1_control_governor_and_engine_degov_tf2__a_sum += _diesel_gen1_control_governor_and_engine_degov_tf2__a_coeff[_diesel_gen1_control_governor_and_engine_degov_tf2__i + 1] * _diesel_gen1_control_governor_and_engine_degov_tf2__states[_diesel_gen1_control_governor_and_engine_degov_tf2__i];
    }
    _diesel_gen1_control_governor_and_engine_degov_tf2__a_sum += _diesel_gen1_control_governor_and_engine_degov_tf2__states[0] * _diesel_gen1_control_governor_and_engine_degov_tf2__a_coeff[1];
    _diesel_gen1_control_governor_and_engine_degov_tf2__delay_line_in = _diesel_gen1_control_governor_and_engine_degov_k__out - _diesel_gen1_control_governor_and_engine_degov_tf2__a_sum;
    _diesel_gen1_control_governor_and_engine_degov_tf2__b_sum += _diesel_gen1_control_governor_and_engine_degov_tf2__b_coeff[0] * _diesel_gen1_control_governor_and_engine_degov_tf2__delay_line_in;
    _diesel_gen1_control_governor_and_engine_degov_tf2__out = _diesel_gen1_control_governor_and_engine_degov_tf2__b_sum;
    // Generated from the component: Diesel_Gen1.Control.T
    HIL_OutAO(0x400a, (float)_diesel_gen1_control_governor_and_engine_tpu_to_t__out);
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.split
    _diesel_gen1_sync_check_plls_split__out = _diesel_gen1_ggrid_meas_bus_join1__out[0];
    _diesel_gen1_sync_check_plls_split__out1 = _diesel_gen1_ggrid_meas_bus_join1__out[1];
    _diesel_gen1_sync_check_plls_split__out2 = _diesel_gen1_ggrid_meas_bus_join1__out[2];
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.PI.Sum8
    _diesel_gen1_measurements_3ph_pll_gen_pll_pi_sum8__out = _diesel_gen1_measurements_3ph_pll_gen_pll_pi_kd__out - _diesel_gen1_measurements_3ph_pll_gen_pll_pi_integrator2__out;
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.ABC_dqz.alpha beta to dq
    _diesel_gen1_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k1 = cos(_diesel_gen1_measurements_3ph_pll_gen_pll_unit_delay1__out);
    _diesel_gen1_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k2 = sin(_diesel_gen1_measurements_3ph_pll_gen_pll_unit_delay1__out);
    _diesel_gen1_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__d = _diesel_gen1_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k2 * _diesel_gen1_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__alpha - _diesel_gen1_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k1 * _diesel_gen1_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__beta;
    _diesel_gen1_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__q = _diesel_gen1_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k1 * _diesel_gen1_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__alpha + _diesel_gen1_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k2 * _diesel_gen1_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__beta;
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.Term
    // Generated from the component: Diesel_Gen1.Measurements.Bus Join1
    _diesel_gen1_measurements_bus_join1__out[0] = _diesel_gen1_measurements_pq_measure_pq_power_meter1__Pdc;
    _diesel_gen1_measurements_bus_join1__out[1] = _diesel_gen1_measurements_pq_measure_pq_power_meter1__Qdc;
    _diesel_gen1_measurements_bus_join1__out[2] = _diesel_gen1_measurements_3ph_pll_gen_pll_normalize_v_terminal__t;
    _diesel_gen1_measurements_bus_join1__out[3] = _diesel_gen1_measurements_pq_measure_pq_power_meter1__k_factor;
    // Generated from the component: Diesel_Gen1.Measurements.Gain7
    _diesel_gen1_measurements_gain7__out = 1e-06 * _diesel_gen1_measurements_pq_measure_pq_power_meter1__apparent;
    // Generated from the component: Diesel_Gen1.Measurements.Gain8
    _diesel_gen1_measurements_gain8__out = 1e-06 * _diesel_gen1_measurements_pq_measure_pq_power_meter1__Qdc;
    // Generated from the component: Diesel_Gen1.Measurements.Gain9
    _diesel_gen1_measurements_gain9__out = 1e-06 * _diesel_gen1_measurements_pq_measure_pq_power_meter1__Pdc;
    // Generated from the component: Diesel_Gen1.Measurements.PQ measure.Termination1
    // Generated from the component: Diesel_Gen1.Measurements.PQ measure.Termination2
    // Generated from the component: Diesel_Gen1.Measurements.pf
    HIL_OutAO(0x4013, (float)_diesel_gen1_measurements_pq_measure_pq_power_meter1__k_factor);
    // Generated from the component: Diesel_Gen1.Sync_Check.dw_synch
    HIL_OutAO(0x401f, (float)_diesel_gen1_sync_check_calculate_dw_synch_signal_switch1__out);
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.greater_equal
    _diesel_gen1_sync_check_check_v_diff_greater_equal__out = (_diesel_gen1_sync_check_check_v_diff_pu1__out >= _diesel_gen1_sync_check_check_v_diff_vgrid_lowlim__out) ? 1 : 0;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.less_equal
    _diesel_gen1_sync_check_check_v_diff_less_equal__out = (_diesel_gen1_sync_check_check_v_diff_pu1__out <= _diesel_gen1_sync_check_check_v_diff_vgrid_uplim__out) ? 1 : 0;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_f_diff.Comparator1
    if (_diesel_gen1_sync_check_check_f_diff_freq_diff__out < _diesel_gen1_sync_check_check_f_diff_abs3__out) {
        _diesel_gen1_sync_check_check_f_diff_comparator1__out = 0;
    } else if (_diesel_gen1_sync_check_check_f_diff_freq_diff__out > _diesel_gen1_sync_check_check_f_diff_abs3__out) {
        _diesel_gen1_sync_check_check_f_diff_comparator1__out = 1;
    } else {
        _diesel_gen1_sync_check_check_f_diff_comparator1__out = _diesel_gen1_sync_check_check_f_diff_comparator1__state;
    }
    // Generated from the component: Diesel_Gen1.Sync_Check.Phase_match
    HIL_OutInt32(0xf0040b, _diesel_gen1_sync_check_check_phase_diff_counter_c_function__out != 0x0);
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.Comparator2
    if (_diesel_gen1_sync_check_check_phase_diff_phase_diff__out < _diesel_gen1_sync_check_check_phase_diff_abs2__out) {
        _diesel_gen1_sync_check_check_phase_diff_comparator2__out = 0;
    } else if (_diesel_gen1_sync_check_check_phase_diff_phase_diff__out > _diesel_gen1_sync_check_check_phase_diff_abs2__out) {
        _diesel_gen1_sync_check_check_phase_diff_comparator2__out = 1;
    } else {
        _diesel_gen1_sync_check_check_phase_diff_comparator2__out = _diesel_gen1_sync_check_check_phase_diff_comparator2__state;
    }
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.wmeas
    HIL_OutAO(0x4008, (float)_diesel_gen1_control_governor_and_engine_w_to_wpu__out);
    // Generated from the component: Diesel_Gen1.Control.Start_Exciter.Comparator1
    if (_diesel_gen1_control_start_exciter_w_to_wpu__out < _diesel_gen1_control_start_exciter_exciter_start_speed__out) {
        _diesel_gen1_control_start_exciter_comparator1__out = 0;
    } else if (_diesel_gen1_control_start_exciter_w_to_wpu__out > _diesel_gen1_control_start_exciter_exciter_start_speed__out) {
        _diesel_gen1_control_start_exciter_comparator1__out = 1;
    } else {
        _diesel_gen1_control_start_exciter_comparator1__out = _diesel_gen1_control_start_exciter_comparator1__state;
    }
    // Generated from the component: Diesel_Gen1.Control.check_steady_state_w.Abs1
    _diesel_gen1_control_check_steady_state_w_abs1__out = fabs(_diesel_gen1_control_check_steady_state_w_sum3__out);
    // Generated from the component: Diesel_Gen2.Control.Exciter.DC4B.Variable Limit
    _diesel_gen2_control_exciter_dc4b_variable_limit__LimitChange = _diesel_gen2_control_exciter_dc4b_switch__out;
    _diesel_gen2_control_exciter_dc4b_variable_limit__in = _diesel_gen2_control_exciter_dc4b_tf2__out;
    if (_diesel_gen2_control_exciter_dc4b_variable_limit__LimitChange == 0.0) {
        _diesel_gen2_control_exciter_dc4b_variable_limit__LimitChange = 0.01;
    }
    if (_diesel_gen2_control_exciter_dc4b_variable_limit__in >= 10.0 * _diesel_gen2_control_exciter_dc4b_variable_limit__LimitChange) {
        _diesel_gen2_control_exciter_dc4b_variable_limit__out = 10.0 * _diesel_gen2_control_exciter_dc4b_variable_limit__LimitChange;
    }
    else {
        if (_diesel_gen2_control_exciter_dc4b_variable_limit__in <= (-10.0)*_diesel_gen2_control_exciter_dc4b_variable_limit__LimitChange) {
            _diesel_gen2_control_exciter_dc4b_variable_limit__out = (-10.0) * _diesel_gen2_control_exciter_dc4b_variable_limit__LimitChange;
        }
        else {
            _diesel_gen2_control_exciter_dc4b_variable_limit__out = _diesel_gen2_control_exciter_dc4b_variable_limit__in;
        }
    }
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.DEGOV.TF2
    X_UnInt32 _diesel_gen2_control_governor_and_engine_degov_tf2__i;
    _diesel_gen2_control_governor_and_engine_degov_tf2__a_sum = 0.0f;
    _diesel_gen2_control_governor_and_engine_degov_tf2__b_sum = 0.0f;
    _diesel_gen2_control_governor_and_engine_degov_tf2__delay_line_in = 0.0f;
    for (_diesel_gen2_control_governor_and_engine_degov_tf2__i = 0; _diesel_gen2_control_governor_and_engine_degov_tf2__i < 2; _diesel_gen2_control_governor_and_engine_degov_tf2__i++) {
        _diesel_gen2_control_governor_and_engine_degov_tf2__b_sum += _diesel_gen2_control_governor_and_engine_degov_tf2__b_coeff[_diesel_gen2_control_governor_and_engine_degov_tf2__i + 1] * _diesel_gen2_control_governor_and_engine_degov_tf2__states[_diesel_gen2_control_governor_and_engine_degov_tf2__i];
    }
    for (_diesel_gen2_control_governor_and_engine_degov_tf2__i = 1; _diesel_gen2_control_governor_and_engine_degov_tf2__i > 0; _diesel_gen2_control_governor_and_engine_degov_tf2__i--) {
        _diesel_gen2_control_governor_and_engine_degov_tf2__a_sum += _diesel_gen2_control_governor_and_engine_degov_tf2__a_coeff[_diesel_gen2_control_governor_and_engine_degov_tf2__i + 1] * _diesel_gen2_control_governor_and_engine_degov_tf2__states[_diesel_gen2_control_governor_and_engine_degov_tf2__i];
    }
    _diesel_gen2_control_governor_and_engine_degov_tf2__a_sum += _diesel_gen2_control_governor_and_engine_degov_tf2__states[0] * _diesel_gen2_control_governor_and_engine_degov_tf2__a_coeff[1];
    _diesel_gen2_control_governor_and_engine_degov_tf2__delay_line_in = _diesel_gen2_control_governor_and_engine_degov_k__out - _diesel_gen2_control_governor_and_engine_degov_tf2__a_sum;
    _diesel_gen2_control_governor_and_engine_degov_tf2__b_sum += _diesel_gen2_control_governor_and_engine_degov_tf2__b_coeff[0] * _diesel_gen2_control_governor_and_engine_degov_tf2__delay_line_in;
    _diesel_gen2_control_governor_and_engine_degov_tf2__out = _diesel_gen2_control_governor_and_engine_degov_tf2__b_sum;
    // Generated from the component: Diesel_Gen2.Control.T
    HIL_OutAO(0x402a, (float)_diesel_gen2_control_governor_and_engine_tpu_to_t__out);
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.split
    _diesel_gen2_sync_check_plls_split__out = _diesel_gen2_ggrid_meas_bus_join1__out[0];
    _diesel_gen2_sync_check_plls_split__out1 = _diesel_gen2_ggrid_meas_bus_join1__out[1];
    _diesel_gen2_sync_check_plls_split__out2 = _diesel_gen2_ggrid_meas_bus_join1__out[2];
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.PI.Sum8
    _diesel_gen2_measurements_3ph_pll_gen_pll_pi_sum8__out = _diesel_gen2_measurements_3ph_pll_gen_pll_pi_kd__out - _diesel_gen2_measurements_3ph_pll_gen_pll_pi_integrator2__out;
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.ABC_dqz.alpha beta to dq
    _diesel_gen2_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k1 = cos(_diesel_gen2_measurements_3ph_pll_gen_pll_unit_delay1__out);
    _diesel_gen2_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k2 = sin(_diesel_gen2_measurements_3ph_pll_gen_pll_unit_delay1__out);
    _diesel_gen2_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__d = _diesel_gen2_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k2 * _diesel_gen2_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__alpha - _diesel_gen2_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k1 * _diesel_gen2_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__beta;
    _diesel_gen2_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__q = _diesel_gen2_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k1 * _diesel_gen2_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__alpha + _diesel_gen2_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k2 * _diesel_gen2_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__beta;
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.Term
    // Generated from the component: Diesel_Gen2.Measurements.Bus Join1
    _diesel_gen2_measurements_bus_join1__out[0] = _diesel_gen2_measurements_pq_measure_pq_power_meter1__Pdc;
    _diesel_gen2_measurements_bus_join1__out[1] = _diesel_gen2_measurements_pq_measure_pq_power_meter1__Qdc;
    _diesel_gen2_measurements_bus_join1__out[2] = _diesel_gen2_measurements_3ph_pll_gen_pll_normalize_v_terminal__t;
    _diesel_gen2_measurements_bus_join1__out[3] = _diesel_gen2_measurements_pq_measure_pq_power_meter1__k_factor;
    // Generated from the component: Diesel_Gen2.Measurements.Gain7
    _diesel_gen2_measurements_gain7__out = 1e-06 * _diesel_gen2_measurements_pq_measure_pq_power_meter1__apparent;
    // Generated from the component: Diesel_Gen2.Measurements.Gain8
    _diesel_gen2_measurements_gain8__out = 1e-06 * _diesel_gen2_measurements_pq_measure_pq_power_meter1__Qdc;
    // Generated from the component: Diesel_Gen2.Measurements.Gain9
    _diesel_gen2_measurements_gain9__out = 1e-06 * _diesel_gen2_measurements_pq_measure_pq_power_meter1__Pdc;
    // Generated from the component: Diesel_Gen2.Measurements.PQ measure.Termination1
    // Generated from the component: Diesel_Gen2.Measurements.PQ measure.Termination2
    // Generated from the component: Diesel_Gen2.Measurements.pf
    HIL_OutAO(0x4033, (float)_diesel_gen2_measurements_pq_measure_pq_power_meter1__k_factor);
    // Generated from the component: Diesel_Gen2.Sync_Check.dw_synch
    HIL_OutAO(0x403f, (float)_diesel_gen2_sync_check_calculate_dw_synch_signal_switch1__out);
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.greater_equal
    _diesel_gen2_sync_check_check_v_diff_greater_equal__out = (_diesel_gen2_sync_check_check_v_diff_pu1__out >= _diesel_gen2_sync_check_check_v_diff_vgrid_lowlim__out) ? 1 : 0;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.less_equal
    _diesel_gen2_sync_check_check_v_diff_less_equal__out = (_diesel_gen2_sync_check_check_v_diff_pu1__out <= _diesel_gen2_sync_check_check_v_diff_vgrid_uplim__out) ? 1 : 0;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_f_diff.Comparator1
    if (_diesel_gen2_sync_check_check_f_diff_freq_diff__out < _diesel_gen2_sync_check_check_f_diff_abs3__out) {
        _diesel_gen2_sync_check_check_f_diff_comparator1__out = 0;
    } else if (_diesel_gen2_sync_check_check_f_diff_freq_diff__out > _diesel_gen2_sync_check_check_f_diff_abs3__out) {
        _diesel_gen2_sync_check_check_f_diff_comparator1__out = 1;
    } else {
        _diesel_gen2_sync_check_check_f_diff_comparator1__out = _diesel_gen2_sync_check_check_f_diff_comparator1__state;
    }
    // Generated from the component: Diesel_Gen2.Sync_Check.Phase_match
    HIL_OutInt32(0xf0041b, _diesel_gen2_sync_check_check_phase_diff_counter_c_function__out != 0x0);
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.Comparator2
    if (_diesel_gen2_sync_check_check_phase_diff_phase_diff__out < _diesel_gen2_sync_check_check_phase_diff_abs2__out) {
        _diesel_gen2_sync_check_check_phase_diff_comparator2__out = 0;
    } else if (_diesel_gen2_sync_check_check_phase_diff_phase_diff__out > _diesel_gen2_sync_check_check_phase_diff_abs2__out) {
        _diesel_gen2_sync_check_check_phase_diff_comparator2__out = 1;
    } else {
        _diesel_gen2_sync_check_check_phase_diff_comparator2__out = _diesel_gen2_sync_check_check_phase_diff_comparator2__state;
    }
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.wmeas
    HIL_OutAO(0x4028, (float)_diesel_gen2_control_governor_and_engine_w_to_wpu__out);
    // Generated from the component: Diesel_Gen2.Control.Start_Exciter.Comparator1
    if (_diesel_gen2_control_start_exciter_w_to_wpu__out < _diesel_gen2_control_start_exciter_exciter_start_speed__out) {
        _diesel_gen2_control_start_exciter_comparator1__out = 0;
    } else if (_diesel_gen2_control_start_exciter_w_to_wpu__out > _diesel_gen2_control_start_exciter_exciter_start_speed__out) {
        _diesel_gen2_control_start_exciter_comparator1__out = 1;
    } else {
        _diesel_gen2_control_start_exciter_comparator1__out = _diesel_gen2_control_start_exciter_comparator1__state;
    }
    // Generated from the component: Diesel_Gen2.Control.check_steady_state_w.Abs1
    _diesel_gen2_control_check_steady_state_w_abs1__out = fabs(_diesel_gen2_control_check_steady_state_w_sum3__out);
    // Generated from the component: Diesel_Gen3.Control.Exciter.DC4B.Variable Limit
    _diesel_gen3_control_exciter_dc4b_variable_limit__LimitChange = _diesel_gen3_control_exciter_dc4b_switch__out;
    _diesel_gen3_control_exciter_dc4b_variable_limit__in = _diesel_gen3_control_exciter_dc4b_tf2__out;
    if (_diesel_gen3_control_exciter_dc4b_variable_limit__LimitChange == 0.0) {
        _diesel_gen3_control_exciter_dc4b_variable_limit__LimitChange = 0.01;
    }
    if (_diesel_gen3_control_exciter_dc4b_variable_limit__in >= 10.0 * _diesel_gen3_control_exciter_dc4b_variable_limit__LimitChange) {
        _diesel_gen3_control_exciter_dc4b_variable_limit__out = 10.0 * _diesel_gen3_control_exciter_dc4b_variable_limit__LimitChange;
    }
    else {
        if (_diesel_gen3_control_exciter_dc4b_variable_limit__in <= (-10.0)*_diesel_gen3_control_exciter_dc4b_variable_limit__LimitChange) {
            _diesel_gen3_control_exciter_dc4b_variable_limit__out = (-10.0) * _diesel_gen3_control_exciter_dc4b_variable_limit__LimitChange;
        }
        else {
            _diesel_gen3_control_exciter_dc4b_variable_limit__out = _diesel_gen3_control_exciter_dc4b_variable_limit__in;
        }
    }
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.DEGOV.TF2
    X_UnInt32 _diesel_gen3_control_governor_and_engine_degov_tf2__i;
    _diesel_gen3_control_governor_and_engine_degov_tf2__a_sum = 0.0f;
    _diesel_gen3_control_governor_and_engine_degov_tf2__b_sum = 0.0f;
    _diesel_gen3_control_governor_and_engine_degov_tf2__delay_line_in = 0.0f;
    for (_diesel_gen3_control_governor_and_engine_degov_tf2__i = 0; _diesel_gen3_control_governor_and_engine_degov_tf2__i < 2; _diesel_gen3_control_governor_and_engine_degov_tf2__i++) {
        _diesel_gen3_control_governor_and_engine_degov_tf2__b_sum += _diesel_gen3_control_governor_and_engine_degov_tf2__b_coeff[_diesel_gen3_control_governor_and_engine_degov_tf2__i + 1] * _diesel_gen3_control_governor_and_engine_degov_tf2__states[_diesel_gen3_control_governor_and_engine_degov_tf2__i];
    }
    for (_diesel_gen3_control_governor_and_engine_degov_tf2__i = 1; _diesel_gen3_control_governor_and_engine_degov_tf2__i > 0; _diesel_gen3_control_governor_and_engine_degov_tf2__i--) {
        _diesel_gen3_control_governor_and_engine_degov_tf2__a_sum += _diesel_gen3_control_governor_and_engine_degov_tf2__a_coeff[_diesel_gen3_control_governor_and_engine_degov_tf2__i + 1] * _diesel_gen3_control_governor_and_engine_degov_tf2__states[_diesel_gen3_control_governor_and_engine_degov_tf2__i];
    }
    _diesel_gen3_control_governor_and_engine_degov_tf2__a_sum += _diesel_gen3_control_governor_and_engine_degov_tf2__states[0] * _diesel_gen3_control_governor_and_engine_degov_tf2__a_coeff[1];
    _diesel_gen3_control_governor_and_engine_degov_tf2__delay_line_in = _diesel_gen3_control_governor_and_engine_degov_k__out - _diesel_gen3_control_governor_and_engine_degov_tf2__a_sum;
    _diesel_gen3_control_governor_and_engine_degov_tf2__b_sum += _diesel_gen3_control_governor_and_engine_degov_tf2__b_coeff[0] * _diesel_gen3_control_governor_and_engine_degov_tf2__delay_line_in;
    _diesel_gen3_control_governor_and_engine_degov_tf2__out = _diesel_gen3_control_governor_and_engine_degov_tf2__b_sum;
    // Generated from the component: Diesel_Gen3.Control.T
    HIL_OutAO(0x404a, (float)_diesel_gen3_control_governor_and_engine_tpu_to_t__out);
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.split
    _diesel_gen3_sync_check_plls_split__out = _diesel_gen3_ggrid_meas_bus_join1__out[0];
    _diesel_gen3_sync_check_plls_split__out1 = _diesel_gen3_ggrid_meas_bus_join1__out[1];
    _diesel_gen3_sync_check_plls_split__out2 = _diesel_gen3_ggrid_meas_bus_join1__out[2];
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.PI.Sum8
    _diesel_gen3_measurements_3ph_pll_gen_pll_pi_sum8__out = _diesel_gen3_measurements_3ph_pll_gen_pll_pi_kd__out - _diesel_gen3_measurements_3ph_pll_gen_pll_pi_integrator2__out;
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.ABC_dqz.alpha beta to dq
    _diesel_gen3_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k1 = cos(_diesel_gen3_measurements_3ph_pll_gen_pll_unit_delay1__out);
    _diesel_gen3_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k2 = sin(_diesel_gen3_measurements_3ph_pll_gen_pll_unit_delay1__out);
    _diesel_gen3_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__d = _diesel_gen3_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k2 * _diesel_gen3_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__alpha - _diesel_gen3_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k1 * _diesel_gen3_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__beta;
    _diesel_gen3_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__q = _diesel_gen3_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k1 * _diesel_gen3_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__alpha + _diesel_gen3_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k2 * _diesel_gen3_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__beta;
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.Term
    // Generated from the component: Diesel_Gen3.Measurements.Bus Join1
    _diesel_gen3_measurements_bus_join1__out[0] = _diesel_gen3_measurements_pq_measure_pq_power_meter1__Pdc;
    _diesel_gen3_measurements_bus_join1__out[1] = _diesel_gen3_measurements_pq_measure_pq_power_meter1__Qdc;
    _diesel_gen3_measurements_bus_join1__out[2] = _diesel_gen3_measurements_3ph_pll_gen_pll_normalize_v_terminal__t;
    _diesel_gen3_measurements_bus_join1__out[3] = _diesel_gen3_measurements_pq_measure_pq_power_meter1__k_factor;
    // Generated from the component: Diesel_Gen3.Measurements.Gain7
    _diesel_gen3_measurements_gain7__out = 1e-06 * _diesel_gen3_measurements_pq_measure_pq_power_meter1__apparent;
    // Generated from the component: Diesel_Gen3.Measurements.Gain8
    _diesel_gen3_measurements_gain8__out = 1e-06 * _diesel_gen3_measurements_pq_measure_pq_power_meter1__Qdc;
    // Generated from the component: Diesel_Gen3.Measurements.Gain9
    _diesel_gen3_measurements_gain9__out = 1e-06 * _diesel_gen3_measurements_pq_measure_pq_power_meter1__Pdc;
    // Generated from the component: Diesel_Gen3.Measurements.PQ measure.Termination1
    // Generated from the component: Diesel_Gen3.Measurements.PQ measure.Termination2
    // Generated from the component: Diesel_Gen3.Measurements.pf
    HIL_OutAO(0x4053, (float)_diesel_gen3_measurements_pq_measure_pq_power_meter1__k_factor);
    // Generated from the component: Diesel_Gen3.Sync_Check.dw_synch
    HIL_OutAO(0x405f, (float)_diesel_gen3_sync_check_calculate_dw_synch_signal_switch1__out);
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.greater_equal
    _diesel_gen3_sync_check_check_v_diff_greater_equal__out = (_diesel_gen3_sync_check_check_v_diff_pu1__out >= _diesel_gen3_sync_check_check_v_diff_vgrid_lowlim__out) ? 1 : 0;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.less_equal
    _diesel_gen3_sync_check_check_v_diff_less_equal__out = (_diesel_gen3_sync_check_check_v_diff_pu1__out <= _diesel_gen3_sync_check_check_v_diff_vgrid_uplim__out) ? 1 : 0;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_f_diff.Comparator1
    if (_diesel_gen3_sync_check_check_f_diff_freq_diff__out < _diesel_gen3_sync_check_check_f_diff_abs3__out) {
        _diesel_gen3_sync_check_check_f_diff_comparator1__out = 0;
    } else if (_diesel_gen3_sync_check_check_f_diff_freq_diff__out > _diesel_gen3_sync_check_check_f_diff_abs3__out) {
        _diesel_gen3_sync_check_check_f_diff_comparator1__out = 1;
    } else {
        _diesel_gen3_sync_check_check_f_diff_comparator1__out = _diesel_gen3_sync_check_check_f_diff_comparator1__state;
    }
    // Generated from the component: Diesel_Gen3.Sync_Check.Phase_match
    HIL_OutInt32(0xf0042b, _diesel_gen3_sync_check_check_phase_diff_counter_c_function__out != 0x0);
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.Comparator2
    if (_diesel_gen3_sync_check_check_phase_diff_phase_diff__out < _diesel_gen3_sync_check_check_phase_diff_abs2__out) {
        _diesel_gen3_sync_check_check_phase_diff_comparator2__out = 0;
    } else if (_diesel_gen3_sync_check_check_phase_diff_phase_diff__out > _diesel_gen3_sync_check_check_phase_diff_abs2__out) {
        _diesel_gen3_sync_check_check_phase_diff_comparator2__out = 1;
    } else {
        _diesel_gen3_sync_check_check_phase_diff_comparator2__out = _diesel_gen3_sync_check_check_phase_diff_comparator2__state;
    }
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.wmeas
    HIL_OutAO(0x4048, (float)_diesel_gen3_control_governor_and_engine_w_to_wpu__out);
    // Generated from the component: Diesel_Gen3.Control.Start_Exciter.Comparator1
    if (_diesel_gen3_control_start_exciter_w_to_wpu__out < _diesel_gen3_control_start_exciter_exciter_start_speed__out) {
        _diesel_gen3_control_start_exciter_comparator1__out = 0;
    } else if (_diesel_gen3_control_start_exciter_w_to_wpu__out > _diesel_gen3_control_start_exciter_exciter_start_speed__out) {
        _diesel_gen3_control_start_exciter_comparator1__out = 1;
    } else {
        _diesel_gen3_control_start_exciter_comparator1__out = _diesel_gen3_control_start_exciter_comparator1__state;
    }
    // Generated from the component: Diesel_Gen3.Control.check_steady_state_w.Abs1
    _diesel_gen3_control_check_steady_state_w_abs1__out = fabs(_diesel_gen3_control_check_steady_state_w_sum3__out);
    // Generated from the component: Diesel_Gen4.Control.Exciter.DC4B.Variable Limit
    _diesel_gen4_control_exciter_dc4b_variable_limit__LimitChange = _diesel_gen4_control_exciter_dc4b_switch__out;
    _diesel_gen4_control_exciter_dc4b_variable_limit__in = _diesel_gen4_control_exciter_dc4b_tf2__out;
    if (_diesel_gen4_control_exciter_dc4b_variable_limit__LimitChange == 0.0) {
        _diesel_gen4_control_exciter_dc4b_variable_limit__LimitChange = 0.01;
    }
    if (_diesel_gen4_control_exciter_dc4b_variable_limit__in >= 10.0 * _diesel_gen4_control_exciter_dc4b_variable_limit__LimitChange) {
        _diesel_gen4_control_exciter_dc4b_variable_limit__out = 10.0 * _diesel_gen4_control_exciter_dc4b_variable_limit__LimitChange;
    }
    else {
        if (_diesel_gen4_control_exciter_dc4b_variable_limit__in <= (-10.0)*_diesel_gen4_control_exciter_dc4b_variable_limit__LimitChange) {
            _diesel_gen4_control_exciter_dc4b_variable_limit__out = (-10.0) * _diesel_gen4_control_exciter_dc4b_variable_limit__LimitChange;
        }
        else {
            _diesel_gen4_control_exciter_dc4b_variable_limit__out = _diesel_gen4_control_exciter_dc4b_variable_limit__in;
        }
    }
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.DEGOV.TF2
    X_UnInt32 _diesel_gen4_control_governor_and_engine_degov_tf2__i;
    _diesel_gen4_control_governor_and_engine_degov_tf2__a_sum = 0.0f;
    _diesel_gen4_control_governor_and_engine_degov_tf2__b_sum = 0.0f;
    _diesel_gen4_control_governor_and_engine_degov_tf2__delay_line_in = 0.0f;
    for (_diesel_gen4_control_governor_and_engine_degov_tf2__i = 0; _diesel_gen4_control_governor_and_engine_degov_tf2__i < 2; _diesel_gen4_control_governor_and_engine_degov_tf2__i++) {
        _diesel_gen4_control_governor_and_engine_degov_tf2__b_sum += _diesel_gen4_control_governor_and_engine_degov_tf2__b_coeff[_diesel_gen4_control_governor_and_engine_degov_tf2__i + 1] * _diesel_gen4_control_governor_and_engine_degov_tf2__states[_diesel_gen4_control_governor_and_engine_degov_tf2__i];
    }
    for (_diesel_gen4_control_governor_and_engine_degov_tf2__i = 1; _diesel_gen4_control_governor_and_engine_degov_tf2__i > 0; _diesel_gen4_control_governor_and_engine_degov_tf2__i--) {
        _diesel_gen4_control_governor_and_engine_degov_tf2__a_sum += _diesel_gen4_control_governor_and_engine_degov_tf2__a_coeff[_diesel_gen4_control_governor_and_engine_degov_tf2__i + 1] * _diesel_gen4_control_governor_and_engine_degov_tf2__states[_diesel_gen4_control_governor_and_engine_degov_tf2__i];
    }
    _diesel_gen4_control_governor_and_engine_degov_tf2__a_sum += _diesel_gen4_control_governor_and_engine_degov_tf2__states[0] * _diesel_gen4_control_governor_and_engine_degov_tf2__a_coeff[1];
    _diesel_gen4_control_governor_and_engine_degov_tf2__delay_line_in = _diesel_gen4_control_governor_and_engine_degov_k__out - _diesel_gen4_control_governor_and_engine_degov_tf2__a_sum;
    _diesel_gen4_control_governor_and_engine_degov_tf2__b_sum += _diesel_gen4_control_governor_and_engine_degov_tf2__b_coeff[0] * _diesel_gen4_control_governor_and_engine_degov_tf2__delay_line_in;
    _diesel_gen4_control_governor_and_engine_degov_tf2__out = _diesel_gen4_control_governor_and_engine_degov_tf2__b_sum;
    // Generated from the component: Diesel_Gen4.Control.T
    HIL_OutAO(0x406a, (float)_diesel_gen4_control_governor_and_engine_tpu_to_t__out);
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.split
    _diesel_gen4_sync_check_plls_split__out = _diesel_gen4_ggrid_meas_bus_join1__out[0];
    _diesel_gen4_sync_check_plls_split__out1 = _diesel_gen4_ggrid_meas_bus_join1__out[1];
    _diesel_gen4_sync_check_plls_split__out2 = _diesel_gen4_ggrid_meas_bus_join1__out[2];
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.PI.Sum8
    _diesel_gen4_measurements_3ph_pll_gen_pll_pi_sum8__out = _diesel_gen4_measurements_3ph_pll_gen_pll_pi_kd__out - _diesel_gen4_measurements_3ph_pll_gen_pll_pi_integrator2__out;
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.ABC_dqz.alpha beta to dq
    _diesel_gen4_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k1 = cos(_diesel_gen4_measurements_3ph_pll_gen_pll_unit_delay1__out);
    _diesel_gen4_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k2 = sin(_diesel_gen4_measurements_3ph_pll_gen_pll_unit_delay1__out);
    _diesel_gen4_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__d = _diesel_gen4_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k2 * _diesel_gen4_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__alpha - _diesel_gen4_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k1 * _diesel_gen4_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__beta;
    _diesel_gen4_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__q = _diesel_gen4_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k1 * _diesel_gen4_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__alpha + _diesel_gen4_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__k2 * _diesel_gen4_measurements_3ph_pll_gen_pll_abc_dqz_abc_to_alpha_beta__beta;
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.Term
    // Generated from the component: Diesel_Gen4.Measurements.Bus Join1
    _diesel_gen4_measurements_bus_join1__out[0] = _diesel_gen4_measurements_pq_measure_pq_power_meter1__Pdc;
    _diesel_gen4_measurements_bus_join1__out[1] = _diesel_gen4_measurements_pq_measure_pq_power_meter1__Qdc;
    _diesel_gen4_measurements_bus_join1__out[2] = _diesel_gen4_measurements_3ph_pll_gen_pll_normalize_v_terminal__t;
    _diesel_gen4_measurements_bus_join1__out[3] = _diesel_gen4_measurements_pq_measure_pq_power_meter1__k_factor;
    // Generated from the component: Diesel_Gen4.Measurements.Gain7
    _diesel_gen4_measurements_gain7__out = 1e-06 * _diesel_gen4_measurements_pq_measure_pq_power_meter1__apparent;
    // Generated from the component: Diesel_Gen4.Measurements.Gain8
    _diesel_gen4_measurements_gain8__out = 1e-06 * _diesel_gen4_measurements_pq_measure_pq_power_meter1__Qdc;
    // Generated from the component: Diesel_Gen4.Measurements.Gain9
    _diesel_gen4_measurements_gain9__out = 1e-06 * _diesel_gen4_measurements_pq_measure_pq_power_meter1__Pdc;
    // Generated from the component: Diesel_Gen4.Measurements.PQ measure.Termination1
    // Generated from the component: Diesel_Gen4.Measurements.PQ measure.Termination2
    // Generated from the component: Diesel_Gen4.Measurements.pf
    HIL_OutAO(0x4073, (float)_diesel_gen4_measurements_pq_measure_pq_power_meter1__k_factor);
    // Generated from the component: Diesel_Gen4.Sync_Check.dw_synch
    HIL_OutAO(0x407f, (float)_diesel_gen4_sync_check_calculate_dw_synch_signal_switch1__out);
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.greater_equal
    _diesel_gen4_sync_check_check_v_diff_greater_equal__out = (_diesel_gen4_sync_check_check_v_diff_pu1__out >= _diesel_gen4_sync_check_check_v_diff_vgrid_lowlim__out) ? 1 : 0;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.less_equal
    _diesel_gen4_sync_check_check_v_diff_less_equal__out = (_diesel_gen4_sync_check_check_v_diff_pu1__out <= _diesel_gen4_sync_check_check_v_diff_vgrid_uplim__out) ? 1 : 0;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_f_diff.Comparator1
    if (_diesel_gen4_sync_check_check_f_diff_freq_diff__out < _diesel_gen4_sync_check_check_f_diff_abs3__out) {
        _diesel_gen4_sync_check_check_f_diff_comparator1__out = 0;
    } else if (_diesel_gen4_sync_check_check_f_diff_freq_diff__out > _diesel_gen4_sync_check_check_f_diff_abs3__out) {
        _diesel_gen4_sync_check_check_f_diff_comparator1__out = 1;
    } else {
        _diesel_gen4_sync_check_check_f_diff_comparator1__out = _diesel_gen4_sync_check_check_f_diff_comparator1__state;
    }
    // Generated from the component: Diesel_Gen4.Sync_Check.Phase_match
    HIL_OutInt32(0xf0043b, _diesel_gen4_sync_check_check_phase_diff_counter_c_function__out != 0x0);
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.Comparator2
    if (_diesel_gen4_sync_check_check_phase_diff_phase_diff__out < _diesel_gen4_sync_check_check_phase_diff_abs2__out) {
        _diesel_gen4_sync_check_check_phase_diff_comparator2__out = 0;
    } else if (_diesel_gen4_sync_check_check_phase_diff_phase_diff__out > _diesel_gen4_sync_check_check_phase_diff_abs2__out) {
        _diesel_gen4_sync_check_check_phase_diff_comparator2__out = 1;
    } else {
        _diesel_gen4_sync_check_check_phase_diff_comparator2__out = _diesel_gen4_sync_check_check_phase_diff_comparator2__state;
    }
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.wmeas
    HIL_OutAO(0x4068, (float)_diesel_gen4_control_governor_and_engine_w_to_wpu__out);
    // Generated from the component: Diesel_Gen4.Control.Start_Exciter.Comparator1
    if (_diesel_gen4_control_start_exciter_w_to_wpu__out < _diesel_gen4_control_start_exciter_exciter_start_speed__out) {
        _diesel_gen4_control_start_exciter_comparator1__out = 0;
    } else if (_diesel_gen4_control_start_exciter_w_to_wpu__out > _diesel_gen4_control_start_exciter_exciter_start_speed__out) {
        _diesel_gen4_control_start_exciter_comparator1__out = 1;
    } else {
        _diesel_gen4_control_start_exciter_comparator1__out = _diesel_gen4_control_start_exciter_comparator1__state;
    }
    // Generated from the component: Diesel_Gen4.Control.check_steady_state_w.Abs1
    _diesel_gen4_control_check_steady_state_w_abs1__out = fabs(_diesel_gen4_control_check_steady_state_w_sum3__out);
    // Generated from the component: Diesel_Gen1.Control.Define_control_mode.Control_mode
    _diesel_gen1_control_define_control_mode_control_mode__Control_mode = _diesel_gen1_control_bus_split3__out6;
    if (_diesel_gen1_control_define_control_mode_control_mode__Control_mode == 1) {
        _diesel_gen1_control_define_control_mode_control_mode__P_control = 1;
        _diesel_gen1_control_define_control_mode_control_mode__Q_control = 0;
    }
    else {
        if (_diesel_gen1_control_define_control_mode_control_mode__Control_mode == 2) {
            _diesel_gen1_control_define_control_mode_control_mode__P_control = 1;
            _diesel_gen1_control_define_control_mode_control_mode__Q_control = 1;
        }
        else {
            _diesel_gen1_control_define_control_mode_control_mode__P_control = 0;
            _diesel_gen1_control_define_control_mode_control_mode__Q_control = 0;
        }
    }
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.P_limit
    _diesel_gen1_control_freq_setpoint_control_p_limit__out = MIN(MAX(_diesel_gen1_control_bus_split3__out3, 0.0), 0.8);
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.load_share_switch
    _diesel_gen1_control_freq_setpoint_control_load_share_switch__out = (_diesel_gen1_control_bus_split3__out7 > 0.5f) ? _diesel_gen1_control_bus_split3__out8 : _diesel_gen1_control_freq_setpoint_control_zero1__out;
    // Generated from the component: Diesel_Gen1.Control.Gen_On
    HIL_OutInt32(0xf00401, _diesel_gen1_control_bus_split3__out != 0x0);
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.DEGOV.Integrator.Integrator1
    if (((_diesel_gen1_control_bus_split3__out > 0.0) && (_diesel_gen1_control_governor_and_engine_degov_integrator_integrator1__reset_state <= 0)) || ((_diesel_gen1_control_bus_split3__out <= 0.0) && (_diesel_gen1_control_governor_and_engine_degov_integrator_integrator1__reset_state == 1))) {
        _diesel_gen1_control_governor_and_engine_degov_integrator_integrator1__state = 0.0;
    }
    _diesel_gen1_control_governor_and_engine_degov_integrator_integrator1__out = _diesel_gen1_control_governor_and_engine_degov_integrator_integrator1__state;
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.w_switch
    _diesel_gen1_control_governor_and_engine_w_switch__out = (_diesel_gen1_control_bus_split3__out > 0.5f) ? _diesel_gen1_control_bus_split3__out2 : _diesel_gen1_control_governor_and_engine_zero__out;
    // Generated from the component: Diesel_Gen1.Control.Round1
    _diesel_gen1_control_round1__out =  round(_diesel_gen1_control_bus_split3__out5);
    // Generated from the component: Diesel_Gen1.Control.pf Control.greater_equal
    _diesel_gen1_control_pf_control_greater_equal__out = (_diesel_gen1_control_bus_split3__out3 >= _diesel_gen1_control_pf_control_constant1__out) ? 1 : 0;
    // Generated from the component: Diesel_Gen1.Output.Bus Join1
    _diesel_gen1_output_bus_join1__out[0] = _diesel_gen1_control_bus_split3__out;
    _diesel_gen1_output_bus_join1__out[1] = _diesel_gen1_bus_split__out1;
    _diesel_gen1_output_bus_join1__out[2] = _diesel_gen1_sync_check_contactor_control_sr_flip_flop1__out;
    _diesel_gen1_output_bus_join1__out[3] = _diesel_gen1_measurements_va_va1__out;
    _diesel_gen1_output_bus_join1__out[4] = _diesel_gen1_measurements_vb_va1__out;
    _diesel_gen1_output_bus_join1__out[5] = _diesel_gen1_measurements_vc_va1__out;
    _diesel_gen1_output_bus_join1__out[6] = _diesel_gen1_measurements_3ph_pll_gen_pll_normalize_v_terminal__t;
    _diesel_gen1_output_bus_join1__out[7] = _diesel_gen1_measurements_ia_ia1__out;
    _diesel_gen1_output_bus_join1__out[8] = _diesel_gen1_measurements_ib_ia1__out;
    _diesel_gen1_output_bus_join1__out[9] = _diesel_gen1_measurements_ic_ia1__out;
    _diesel_gen1_output_bus_join1__out[10] = _diesel_gen1_measurements_pq_measure_pq_power_meter1__Pdc;
    _diesel_gen1_output_bus_join1__out[11] = _diesel_gen1_measurements_pq_measure_pq_power_meter1__Qdc;
    _diesel_gen1_output_bus_join1__out[12] = _diesel_gen1_measurements_pq_measure_pq_power_meter1__apparent;
    _diesel_gen1_output_bus_join1__out[13] = _diesel_gen1_measurements_pq_measure_pq_power_meter1__k_factor;
    // Generated from the component: Diesel_Gen2.Control.Define_control_mode.Control_mode
    _diesel_gen2_control_define_control_mode_control_mode__Control_mode = _diesel_gen2_control_bus_split3__out6;
    if (_diesel_gen2_control_define_control_mode_control_mode__Control_mode == 1) {
        _diesel_gen2_control_define_control_mode_control_mode__P_control = 1;
        _diesel_gen2_control_define_control_mode_control_mode__Q_control = 0;
    }
    else {
        if (_diesel_gen2_control_define_control_mode_control_mode__Control_mode == 2) {
            _diesel_gen2_control_define_control_mode_control_mode__P_control = 1;
            _diesel_gen2_control_define_control_mode_control_mode__Q_control = 1;
        }
        else {
            _diesel_gen2_control_define_control_mode_control_mode__P_control = 0;
            _diesel_gen2_control_define_control_mode_control_mode__Q_control = 0;
        }
    }
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.P_limit
    _diesel_gen2_control_freq_setpoint_control_p_limit__out = MIN(MAX(_diesel_gen2_control_bus_split3__out3, 0.0), 0.8);
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.load_share_switch
    _diesel_gen2_control_freq_setpoint_control_load_share_switch__out = (_diesel_gen2_control_bus_split3__out7 > 0.5f) ? _diesel_gen2_control_bus_split3__out8 : _diesel_gen2_control_freq_setpoint_control_zero1__out;
    // Generated from the component: Diesel_Gen2.Control.Gen_On
    HIL_OutInt32(0xf00411, _diesel_gen2_control_bus_split3__out != 0x0);
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.DEGOV.Integrator.Integrator1
    if (((_diesel_gen2_control_bus_split3__out > 0.0) && (_diesel_gen2_control_governor_and_engine_degov_integrator_integrator1__reset_state <= 0)) || ((_diesel_gen2_control_bus_split3__out <= 0.0) && (_diesel_gen2_control_governor_and_engine_degov_integrator_integrator1__reset_state == 1))) {
        _diesel_gen2_control_governor_and_engine_degov_integrator_integrator1__state = 0.0;
    }
    _diesel_gen2_control_governor_and_engine_degov_integrator_integrator1__out = _diesel_gen2_control_governor_and_engine_degov_integrator_integrator1__state;
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.w_switch
    _diesel_gen2_control_governor_and_engine_w_switch__out = (_diesel_gen2_control_bus_split3__out > 0.5f) ? _diesel_gen2_control_bus_split3__out2 : _diesel_gen2_control_governor_and_engine_zero__out;
    // Generated from the component: Diesel_Gen2.Control.Round1
    _diesel_gen2_control_round1__out =  round(_diesel_gen2_control_bus_split3__out5);
    // Generated from the component: Diesel_Gen2.Control.pf Control.greater_equal
    _diesel_gen2_control_pf_control_greater_equal__out = (_diesel_gen2_control_bus_split3__out3 >= _diesel_gen2_control_pf_control_constant1__out) ? 1 : 0;
    // Generated from the component: Diesel_Gen2.Output.Bus Join1
    _diesel_gen2_output_bus_join1__out[0] = _diesel_gen2_control_bus_split3__out;
    _diesel_gen2_output_bus_join1__out[1] = _diesel_gen2_bus_split__out1;
    _diesel_gen2_output_bus_join1__out[2] = _diesel_gen2_sync_check_contactor_control_sr_flip_flop1__out;
    _diesel_gen2_output_bus_join1__out[3] = _diesel_gen2_measurements_va_va1__out;
    _diesel_gen2_output_bus_join1__out[4] = _diesel_gen2_measurements_vb_va1__out;
    _diesel_gen2_output_bus_join1__out[5] = _diesel_gen2_measurements_vc_va1__out;
    _diesel_gen2_output_bus_join1__out[6] = _diesel_gen2_measurements_3ph_pll_gen_pll_normalize_v_terminal__t;
    _diesel_gen2_output_bus_join1__out[7] = _diesel_gen2_measurements_ia_ia1__out;
    _diesel_gen2_output_bus_join1__out[8] = _diesel_gen2_measurements_ib_ia1__out;
    _diesel_gen2_output_bus_join1__out[9] = _diesel_gen2_measurements_ic_ia1__out;
    _diesel_gen2_output_bus_join1__out[10] = _diesel_gen2_measurements_pq_measure_pq_power_meter1__Pdc;
    _diesel_gen2_output_bus_join1__out[11] = _diesel_gen2_measurements_pq_measure_pq_power_meter1__Qdc;
    _diesel_gen2_output_bus_join1__out[12] = _diesel_gen2_measurements_pq_measure_pq_power_meter1__apparent;
    _diesel_gen2_output_bus_join1__out[13] = _diesel_gen2_measurements_pq_measure_pq_power_meter1__k_factor;
    // Generated from the component: Diesel_Gen4.Control.Define_control_mode.Control_mode
    _diesel_gen4_control_define_control_mode_control_mode__Control_mode = _diesel_gen4_control_bus_split3__out6;
    if (_diesel_gen4_control_define_control_mode_control_mode__Control_mode == 1) {
        _diesel_gen4_control_define_control_mode_control_mode__P_control = 1;
        _diesel_gen4_control_define_control_mode_control_mode__Q_control = 0;
    }
    else {
        if (_diesel_gen4_control_define_control_mode_control_mode__Control_mode == 2) {
            _diesel_gen4_control_define_control_mode_control_mode__P_control = 1;
            _diesel_gen4_control_define_control_mode_control_mode__Q_control = 1;
        }
        else {
            _diesel_gen4_control_define_control_mode_control_mode__P_control = 0;
            _diesel_gen4_control_define_control_mode_control_mode__Q_control = 0;
        }
    }
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.P_limit
    _diesel_gen4_control_freq_setpoint_control_p_limit__out = MIN(MAX(_diesel_gen4_control_bus_split3__out3, 0.0), 0.8);
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.load_share_switch
    _diesel_gen4_control_freq_setpoint_control_load_share_switch__out = (_diesel_gen4_control_bus_split3__out7 > 0.5f) ? _diesel_gen4_control_bus_split3__out8 : _diesel_gen4_control_freq_setpoint_control_zero1__out;
    // Generated from the component: Diesel_Gen4.Control.Gen_On
    HIL_OutInt32(0xf00431, _diesel_gen4_control_bus_split3__out != 0x0);
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.DEGOV.Integrator.Integrator1
    if (((_diesel_gen4_control_bus_split3__out > 0.0) && (_diesel_gen4_control_governor_and_engine_degov_integrator_integrator1__reset_state <= 0)) || ((_diesel_gen4_control_bus_split3__out <= 0.0) && (_diesel_gen4_control_governor_and_engine_degov_integrator_integrator1__reset_state == 1))) {
        _diesel_gen4_control_governor_and_engine_degov_integrator_integrator1__state = 0.0;
    }
    _diesel_gen4_control_governor_and_engine_degov_integrator_integrator1__out = _diesel_gen4_control_governor_and_engine_degov_integrator_integrator1__state;
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.w_switch
    _diesel_gen4_control_governor_and_engine_w_switch__out = (_diesel_gen4_control_bus_split3__out > 0.5f) ? _diesel_gen4_control_bus_split3__out2 : _diesel_gen4_control_governor_and_engine_zero__out;
    // Generated from the component: Diesel_Gen4.Control.Round1
    _diesel_gen4_control_round1__out =  round(_diesel_gen4_control_bus_split3__out5);
    // Generated from the component: Diesel_Gen4.Control.pf Control.greater_equal
    _diesel_gen4_control_pf_control_greater_equal__out = (_diesel_gen4_control_bus_split3__out3 >= _diesel_gen4_control_pf_control_constant1__out) ? 1 : 0;
    // Generated from the component: Diesel_Gen4.Output.Bus Join1
    _diesel_gen4_output_bus_join1__out[0] = _diesel_gen4_control_bus_split3__out;
    _diesel_gen4_output_bus_join1__out[1] = _diesel_gen4_bus_split__out1;
    _diesel_gen4_output_bus_join1__out[2] = _diesel_gen4_sync_check_contactor_control_sr_flip_flop1__out;
    _diesel_gen4_output_bus_join1__out[3] = _diesel_gen4_measurements_va_va1__out;
    _diesel_gen4_output_bus_join1__out[4] = _diesel_gen4_measurements_vb_va1__out;
    _diesel_gen4_output_bus_join1__out[5] = _diesel_gen4_measurements_vc_va1__out;
    _diesel_gen4_output_bus_join1__out[6] = _diesel_gen4_measurements_3ph_pll_gen_pll_normalize_v_terminal__t;
    _diesel_gen4_output_bus_join1__out[7] = _diesel_gen4_measurements_ia_ia1__out;
    _diesel_gen4_output_bus_join1__out[8] = _diesel_gen4_measurements_ib_ia1__out;
    _diesel_gen4_output_bus_join1__out[9] = _diesel_gen4_measurements_ic_ia1__out;
    _diesel_gen4_output_bus_join1__out[10] = _diesel_gen4_measurements_pq_measure_pq_power_meter1__Pdc;
    _diesel_gen4_output_bus_join1__out[11] = _diesel_gen4_measurements_pq_measure_pq_power_meter1__Qdc;
    _diesel_gen4_output_bus_join1__out[12] = _diesel_gen4_measurements_pq_measure_pq_power_meter1__apparent;
    _diesel_gen4_output_bus_join1__out[13] = _diesel_gen4_measurements_pq_measure_pq_power_meter1__k_factor;
    // Generated from the component: Diesel_Gen3.Control.Define_control_mode.Control_mode
    _diesel_gen3_control_define_control_mode_control_mode__Control_mode = _diesel_gen3_control_bus_split3__out6;
    if (_diesel_gen3_control_define_control_mode_control_mode__Control_mode == 1) {
        _diesel_gen3_control_define_control_mode_control_mode__P_control = 1;
        _diesel_gen3_control_define_control_mode_control_mode__Q_control = 0;
    }
    else {
        if (_diesel_gen3_control_define_control_mode_control_mode__Control_mode == 2) {
            _diesel_gen3_control_define_control_mode_control_mode__P_control = 1;
            _diesel_gen3_control_define_control_mode_control_mode__Q_control = 1;
        }
        else {
            _diesel_gen3_control_define_control_mode_control_mode__P_control = 0;
            _diesel_gen3_control_define_control_mode_control_mode__Q_control = 0;
        }
    }
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.P_limit
    _diesel_gen3_control_freq_setpoint_control_p_limit__out = MIN(MAX(_diesel_gen3_control_bus_split3__out3, 0.0), 0.8);
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.load_share_switch
    _diesel_gen3_control_freq_setpoint_control_load_share_switch__out = (_diesel_gen3_control_bus_split3__out7 > 0.5f) ? _diesel_gen3_control_bus_split3__out8 : _diesel_gen3_control_freq_setpoint_control_zero1__out;
    // Generated from the component: Diesel_Gen3.Control.Gen_On
    HIL_OutInt32(0xf00421, _diesel_gen3_control_bus_split3__out != 0x0);
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.DEGOV.Integrator.Integrator1
    if (((_diesel_gen3_control_bus_split3__out > 0.0) && (_diesel_gen3_control_governor_and_engine_degov_integrator_integrator1__reset_state <= 0)) || ((_diesel_gen3_control_bus_split3__out <= 0.0) && (_diesel_gen3_control_governor_and_engine_degov_integrator_integrator1__reset_state == 1))) {
        _diesel_gen3_control_governor_and_engine_degov_integrator_integrator1__state = 0.0;
    }
    _diesel_gen3_control_governor_and_engine_degov_integrator_integrator1__out = _diesel_gen3_control_governor_and_engine_degov_integrator_integrator1__state;
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.w_switch
    _diesel_gen3_control_governor_and_engine_w_switch__out = (_diesel_gen3_control_bus_split3__out > 0.5f) ? _diesel_gen3_control_bus_split3__out2 : _diesel_gen3_control_governor_and_engine_zero__out;
    // Generated from the component: Diesel_Gen3.Control.Round1
    _diesel_gen3_control_round1__out =  round(_diesel_gen3_control_bus_split3__out5);
    // Generated from the component: Diesel_Gen3.Control.pf Control.greater_equal
    _diesel_gen3_control_pf_control_greater_equal__out = (_diesel_gen3_control_bus_split3__out3 >= _diesel_gen3_control_pf_control_constant1__out) ? 1 : 0;
    // Generated from the component: Diesel_Gen3.Output.Bus Join1
    _diesel_gen3_output_bus_join1__out[0] = _diesel_gen3_control_bus_split3__out;
    _diesel_gen3_output_bus_join1__out[1] = _diesel_gen3_bus_split__out1;
    _diesel_gen3_output_bus_join1__out[2] = _diesel_gen3_sync_check_contactor_control_sr_flip_flop1__out;
    _diesel_gen3_output_bus_join1__out[3] = _diesel_gen3_measurements_va_va1__out;
    _diesel_gen3_output_bus_join1__out[4] = _diesel_gen3_measurements_vb_va1__out;
    _diesel_gen3_output_bus_join1__out[5] = _diesel_gen3_measurements_vc_va1__out;
    _diesel_gen3_output_bus_join1__out[6] = _diesel_gen3_measurements_3ph_pll_gen_pll_normalize_v_terminal__t;
    _diesel_gen3_output_bus_join1__out[7] = _diesel_gen3_measurements_ia_ia1__out;
    _diesel_gen3_output_bus_join1__out[8] = _diesel_gen3_measurements_ib_ia1__out;
    _diesel_gen3_output_bus_join1__out[9] = _diesel_gen3_measurements_ic_ia1__out;
    _diesel_gen3_output_bus_join1__out[10] = _diesel_gen3_measurements_pq_measure_pq_power_meter1__Pdc;
    _diesel_gen3_output_bus_join1__out[11] = _diesel_gen3_measurements_pq_measure_pq_power_meter1__Qdc;
    _diesel_gen3_output_bus_join1__out[12] = _diesel_gen3_measurements_pq_measure_pq_power_meter1__apparent;
    _diesel_gen3_output_bus_join1__out[13] = _diesel_gen3_measurements_pq_measure_pq_power_meter1__k_factor;
    // Generated from the component: Diesel_Gen1.Control.Exciter.DC4B.TF3
    X_UnInt32 _diesel_gen1_control_exciter_dc4b_tf3__i;
    _diesel_gen1_control_exciter_dc4b_tf3__a_sum = 0.0f;
    _diesel_gen1_control_exciter_dc4b_tf3__b_sum = 0.0f;
    _diesel_gen1_control_exciter_dc4b_tf3__delay_line_in = 0.0f;
    for (_diesel_gen1_control_exciter_dc4b_tf3__i = 0; _diesel_gen1_control_exciter_dc4b_tf3__i < 1; _diesel_gen1_control_exciter_dc4b_tf3__i++) {
        _diesel_gen1_control_exciter_dc4b_tf3__b_sum += _diesel_gen1_control_exciter_dc4b_tf3__b_coeff[_diesel_gen1_control_exciter_dc4b_tf3__i + 1] * _diesel_gen1_control_exciter_dc4b_tf3__states[_diesel_gen1_control_exciter_dc4b_tf3__i];
    }
    _diesel_gen1_control_exciter_dc4b_tf3__a_sum += _diesel_gen1_control_exciter_dc4b_tf3__states[0] * _diesel_gen1_control_exciter_dc4b_tf3__a_coeff[1];
    _diesel_gen1_control_exciter_dc4b_tf3__delay_line_in = _diesel_gen1_control_exciter_dc4b_variable_limit__out - _diesel_gen1_control_exciter_dc4b_tf3__a_sum;
    _diesel_gen1_control_exciter_dc4b_tf3__b_sum += _diesel_gen1_control_exciter_dc4b_tf3__b_coeff[0] * _diesel_gen1_control_exciter_dc4b_tf3__delay_line_in;
    _diesel_gen1_control_exciter_dc4b_tf3__out = _diesel_gen1_control_exciter_dc4b_tf3__b_sum;
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.PLL_Grid.PLL.ABC_dqz.abc to alpha beta
    _diesel_gen1_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__alpha = (2.0 * _diesel_gen1_sync_check_plls_split__out - _diesel_gen1_sync_check_plls_split__out1 - _diesel_gen1_sync_check_plls_split__out2) * 0.3333333333333333;
    _diesel_gen1_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__beta = (_diesel_gen1_sync_check_plls_split__out1 - _diesel_gen1_sync_check_plls_split__out2) * 0.5773502691896258;
    _diesel_gen1_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__gamma = (_diesel_gen1_sync_check_plls_split__out + _diesel_gen1_sync_check_plls_split__out1 + _diesel_gen1_sync_check_plls_split__out2) * 0.3333333333333333;
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.PI.Gain1
    _diesel_gen1_measurements_3ph_pll_gen_pll_pi_gain1__out = 714.2857004093205 * _diesel_gen1_measurements_3ph_pll_gen_pll_pi_sum8__out;
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.LPF_d
    X_UnInt32 _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__i;
    _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__a_sum = 0.0f;
    _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__b_sum = 0.0f;
    _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__delay_line_in = 0.0f;
    for (_diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__i = 0; _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__i < 1; _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__i++) {
        _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__b_sum += _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__b_coeff[_diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__i + 1] * _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__states[_diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__i];
    }
    _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__a_sum += _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__states[0] * _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__a_coeff[1];
    _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__delay_line_in = _diesel_gen1_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__d - _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__a_sum;
    _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__b_sum += _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__b_coeff[0] * _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__delay_line_in;
    _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__out = _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__b_sum;
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.LPF_q
    X_UnInt32 _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__i;
    _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__a_sum = 0.0f;
    _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__b_sum = 0.0f;
    _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__delay_line_in = 0.0f;
    for (_diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__i = 0; _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__i < 1; _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__i++) {
        _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__b_sum += _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__b_coeff[_diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__i + 1] * _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__states[_diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__i];
    }
    _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__a_sum += _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__states[0] * _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__a_coeff[1];
    _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__delay_line_in = _diesel_gen1_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__q - _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__a_sum;
    _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__b_sum += _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__b_coeff[0] * _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__delay_line_in;
    _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__out = _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__b_sum;
    // Generated from the component: Diesel_Gen1.Control.Bus Split1
    _diesel_gen1_control_bus_split1__out = _diesel_gen1_measurements_bus_join1__out[0];
    _diesel_gen1_control_bus_split1__out1 = _diesel_gen1_measurements_bus_join1__out[1];
    _diesel_gen1_control_bus_split1__out2 = _diesel_gen1_measurements_bus_join1__out[2];
    _diesel_gen1_control_bus_split1__out3 = _diesel_gen1_measurements_bus_join1__out[3];
    // Generated from the component: Diesel_Gen1.Measurements.S
    HIL_OutAO(0x4011, (float)_diesel_gen1_measurements_gain7__out);
    // Generated from the component: Diesel_Gen1.Measurements.Q
    HIL_OutAO(0x4010, (float)_diesel_gen1_measurements_gain8__out);
    // Generated from the component: Diesel_Gen1.Measurements.P
    HIL_OutAO(0x400f, (float)_diesel_gen1_measurements_gain9__out);
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.and
    _diesel_gen1_sync_check_check_v_diff_and__out = _diesel_gen1_sync_check_check_v_diff_less_equal__out && _diesel_gen1_sync_check_check_v_diff_greater_equal__out ;
    // Generated from the component: Diesel_Gen1.Sync_Check.f_match
    HIL_OutInt32(0xf0040f, _diesel_gen1_sync_check_check_f_diff_comparator1__out != 0x0);
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.Counter.Counter1.en_switch
    _diesel_gen1_sync_check_check_phase_diff_counter_counter1_en_switch__out = (_diesel_gen1_sync_check_check_phase_diff_comparator2__out > 0.5f) ? _diesel_gen1_sync_check_check_phase_diff_counter_counter1_const_value_1__out : _diesel_gen1_sync_check_check_phase_diff_counter_counter1_const_value_0__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.Counter.not
    _diesel_gen1_sync_check_check_phase_diff_counter_not__out = !_diesel_gen1_sync_check_check_phase_diff_comparator2__out;
    // Generated from the component: Diesel_Gen1.Control.Start_Exciter.and
    _diesel_gen1_control_start_exciter_and__out = _diesel_gen1_control_bus_split3__out && _diesel_gen1_control_start_exciter_comparator1__out ;
    // Generated from the component: Diesel_Gen1.Control.check_steady_state_w.Comparator3
    if (_diesel_gen1_control_check_steady_state_w_speed_diff__out < _diesel_gen1_control_check_steady_state_w_abs1__out) {
        _diesel_gen1_control_check_steady_state_w_comparator3__out = 0;
    } else if (_diesel_gen1_control_check_steady_state_w_speed_diff__out > _diesel_gen1_control_check_steady_state_w_abs1__out) {
        _diesel_gen1_control_check_steady_state_w_comparator3__out = 1;
    } else {
        _diesel_gen1_control_check_steady_state_w_comparator3__out = _diesel_gen1_control_check_steady_state_w_comparator3__state;
    }
    // Generated from the component: Diesel_Gen2.Control.Exciter.DC4B.TF3
    X_UnInt32 _diesel_gen2_control_exciter_dc4b_tf3__i;
    _diesel_gen2_control_exciter_dc4b_tf3__a_sum = 0.0f;
    _diesel_gen2_control_exciter_dc4b_tf3__b_sum = 0.0f;
    _diesel_gen2_control_exciter_dc4b_tf3__delay_line_in = 0.0f;
    for (_diesel_gen2_control_exciter_dc4b_tf3__i = 0; _diesel_gen2_control_exciter_dc4b_tf3__i < 1; _diesel_gen2_control_exciter_dc4b_tf3__i++) {
        _diesel_gen2_control_exciter_dc4b_tf3__b_sum += _diesel_gen2_control_exciter_dc4b_tf3__b_coeff[_diesel_gen2_control_exciter_dc4b_tf3__i + 1] * _diesel_gen2_control_exciter_dc4b_tf3__states[_diesel_gen2_control_exciter_dc4b_tf3__i];
    }
    _diesel_gen2_control_exciter_dc4b_tf3__a_sum += _diesel_gen2_control_exciter_dc4b_tf3__states[0] * _diesel_gen2_control_exciter_dc4b_tf3__a_coeff[1];
    _diesel_gen2_control_exciter_dc4b_tf3__delay_line_in = _diesel_gen2_control_exciter_dc4b_variable_limit__out - _diesel_gen2_control_exciter_dc4b_tf3__a_sum;
    _diesel_gen2_control_exciter_dc4b_tf3__b_sum += _diesel_gen2_control_exciter_dc4b_tf3__b_coeff[0] * _diesel_gen2_control_exciter_dc4b_tf3__delay_line_in;
    _diesel_gen2_control_exciter_dc4b_tf3__out = _diesel_gen2_control_exciter_dc4b_tf3__b_sum;
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.PLL_Grid.PLL.ABC_dqz.abc to alpha beta
    _diesel_gen2_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__alpha = (2.0 * _diesel_gen2_sync_check_plls_split__out - _diesel_gen2_sync_check_plls_split__out1 - _diesel_gen2_sync_check_plls_split__out2) * 0.3333333333333333;
    _diesel_gen2_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__beta = (_diesel_gen2_sync_check_plls_split__out1 - _diesel_gen2_sync_check_plls_split__out2) * 0.5773502691896258;
    _diesel_gen2_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__gamma = (_diesel_gen2_sync_check_plls_split__out + _diesel_gen2_sync_check_plls_split__out1 + _diesel_gen2_sync_check_plls_split__out2) * 0.3333333333333333;
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.PI.Gain1
    _diesel_gen2_measurements_3ph_pll_gen_pll_pi_gain1__out = 714.2857004093205 * _diesel_gen2_measurements_3ph_pll_gen_pll_pi_sum8__out;
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.LPF_d
    X_UnInt32 _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__i;
    _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__a_sum = 0.0f;
    _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__b_sum = 0.0f;
    _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__delay_line_in = 0.0f;
    for (_diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__i = 0; _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__i < 1; _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__i++) {
        _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__b_sum += _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__b_coeff[_diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__i + 1] * _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__states[_diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__i];
    }
    _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__a_sum += _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__states[0] * _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__a_coeff[1];
    _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__delay_line_in = _diesel_gen2_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__d - _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__a_sum;
    _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__b_sum += _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__b_coeff[0] * _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__delay_line_in;
    _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__out = _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__b_sum;
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.LPF_q
    X_UnInt32 _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__i;
    _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__a_sum = 0.0f;
    _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__b_sum = 0.0f;
    _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__delay_line_in = 0.0f;
    for (_diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__i = 0; _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__i < 1; _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__i++) {
        _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__b_sum += _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__b_coeff[_diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__i + 1] * _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__states[_diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__i];
    }
    _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__a_sum += _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__states[0] * _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__a_coeff[1];
    _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__delay_line_in = _diesel_gen2_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__q - _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__a_sum;
    _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__b_sum += _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__b_coeff[0] * _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__delay_line_in;
    _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__out = _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__b_sum;
    // Generated from the component: Diesel_Gen2.Control.Bus Split1
    _diesel_gen2_control_bus_split1__out = _diesel_gen2_measurements_bus_join1__out[0];
    _diesel_gen2_control_bus_split1__out1 = _diesel_gen2_measurements_bus_join1__out[1];
    _diesel_gen2_control_bus_split1__out2 = _diesel_gen2_measurements_bus_join1__out[2];
    _diesel_gen2_control_bus_split1__out3 = _diesel_gen2_measurements_bus_join1__out[3];
    // Generated from the component: Diesel_Gen2.Measurements.S
    HIL_OutAO(0x4031, (float)_diesel_gen2_measurements_gain7__out);
    // Generated from the component: Diesel_Gen2.Measurements.Q
    HIL_OutAO(0x4030, (float)_diesel_gen2_measurements_gain8__out);
    // Generated from the component: Diesel_Gen2.Measurements.P
    HIL_OutAO(0x402f, (float)_diesel_gen2_measurements_gain9__out);
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.and
    _diesel_gen2_sync_check_check_v_diff_and__out = _diesel_gen2_sync_check_check_v_diff_less_equal__out && _diesel_gen2_sync_check_check_v_diff_greater_equal__out ;
    // Generated from the component: Diesel_Gen2.Sync_Check.f_match
    HIL_OutInt32(0xf0041f, _diesel_gen2_sync_check_check_f_diff_comparator1__out != 0x0);
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.Counter.Counter1.en_switch
    _diesel_gen2_sync_check_check_phase_diff_counter_counter1_en_switch__out = (_diesel_gen2_sync_check_check_phase_diff_comparator2__out > 0.5f) ? _diesel_gen2_sync_check_check_phase_diff_counter_counter1_const_value_1__out : _diesel_gen2_sync_check_check_phase_diff_counter_counter1_const_value_0__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.Counter.not
    _diesel_gen2_sync_check_check_phase_diff_counter_not__out = !_diesel_gen2_sync_check_check_phase_diff_comparator2__out;
    // Generated from the component: Diesel_Gen2.Control.Start_Exciter.and
    _diesel_gen2_control_start_exciter_and__out = _diesel_gen2_control_bus_split3__out && _diesel_gen2_control_start_exciter_comparator1__out ;
    // Generated from the component: Diesel_Gen2.Control.check_steady_state_w.Comparator3
    if (_diesel_gen2_control_check_steady_state_w_speed_diff__out < _diesel_gen2_control_check_steady_state_w_abs1__out) {
        _diesel_gen2_control_check_steady_state_w_comparator3__out = 0;
    } else if (_diesel_gen2_control_check_steady_state_w_speed_diff__out > _diesel_gen2_control_check_steady_state_w_abs1__out) {
        _diesel_gen2_control_check_steady_state_w_comparator3__out = 1;
    } else {
        _diesel_gen2_control_check_steady_state_w_comparator3__out = _diesel_gen2_control_check_steady_state_w_comparator3__state;
    }
    // Generated from the component: Diesel_Gen3.Control.Exciter.DC4B.TF3
    X_UnInt32 _diesel_gen3_control_exciter_dc4b_tf3__i;
    _diesel_gen3_control_exciter_dc4b_tf3__a_sum = 0.0f;
    _diesel_gen3_control_exciter_dc4b_tf3__b_sum = 0.0f;
    _diesel_gen3_control_exciter_dc4b_tf3__delay_line_in = 0.0f;
    for (_diesel_gen3_control_exciter_dc4b_tf3__i = 0; _diesel_gen3_control_exciter_dc4b_tf3__i < 1; _diesel_gen3_control_exciter_dc4b_tf3__i++) {
        _diesel_gen3_control_exciter_dc4b_tf3__b_sum += _diesel_gen3_control_exciter_dc4b_tf3__b_coeff[_diesel_gen3_control_exciter_dc4b_tf3__i + 1] * _diesel_gen3_control_exciter_dc4b_tf3__states[_diesel_gen3_control_exciter_dc4b_tf3__i];
    }
    _diesel_gen3_control_exciter_dc4b_tf3__a_sum += _diesel_gen3_control_exciter_dc4b_tf3__states[0] * _diesel_gen3_control_exciter_dc4b_tf3__a_coeff[1];
    _diesel_gen3_control_exciter_dc4b_tf3__delay_line_in = _diesel_gen3_control_exciter_dc4b_variable_limit__out - _diesel_gen3_control_exciter_dc4b_tf3__a_sum;
    _diesel_gen3_control_exciter_dc4b_tf3__b_sum += _diesel_gen3_control_exciter_dc4b_tf3__b_coeff[0] * _diesel_gen3_control_exciter_dc4b_tf3__delay_line_in;
    _diesel_gen3_control_exciter_dc4b_tf3__out = _diesel_gen3_control_exciter_dc4b_tf3__b_sum;
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.PLL_Grid.PLL.ABC_dqz.abc to alpha beta
    _diesel_gen3_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__alpha = (2.0 * _diesel_gen3_sync_check_plls_split__out - _diesel_gen3_sync_check_plls_split__out1 - _diesel_gen3_sync_check_plls_split__out2) * 0.3333333333333333;
    _diesel_gen3_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__beta = (_diesel_gen3_sync_check_plls_split__out1 - _diesel_gen3_sync_check_plls_split__out2) * 0.5773502691896258;
    _diesel_gen3_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__gamma = (_diesel_gen3_sync_check_plls_split__out + _diesel_gen3_sync_check_plls_split__out1 + _diesel_gen3_sync_check_plls_split__out2) * 0.3333333333333333;
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.PI.Gain1
    _diesel_gen3_measurements_3ph_pll_gen_pll_pi_gain1__out = 714.2857004093205 * _diesel_gen3_measurements_3ph_pll_gen_pll_pi_sum8__out;
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.LPF_d
    X_UnInt32 _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__i;
    _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__a_sum = 0.0f;
    _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__b_sum = 0.0f;
    _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__delay_line_in = 0.0f;
    for (_diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__i = 0; _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__i < 1; _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__i++) {
        _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__b_sum += _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__b_coeff[_diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__i + 1] * _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__states[_diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__i];
    }
    _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__a_sum += _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__states[0] * _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__a_coeff[1];
    _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__delay_line_in = _diesel_gen3_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__d - _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__a_sum;
    _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__b_sum += _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__b_coeff[0] * _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__delay_line_in;
    _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__out = _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__b_sum;
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.LPF_q
    X_UnInt32 _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__i;
    _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__a_sum = 0.0f;
    _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__b_sum = 0.0f;
    _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__delay_line_in = 0.0f;
    for (_diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__i = 0; _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__i < 1; _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__i++) {
        _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__b_sum += _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__b_coeff[_diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__i + 1] * _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__states[_diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__i];
    }
    _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__a_sum += _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__states[0] * _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__a_coeff[1];
    _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__delay_line_in = _diesel_gen3_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__q - _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__a_sum;
    _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__b_sum += _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__b_coeff[0] * _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__delay_line_in;
    _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__out = _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__b_sum;
    // Generated from the component: Diesel_Gen3.Control.Bus Split1
    _diesel_gen3_control_bus_split1__out = _diesel_gen3_measurements_bus_join1__out[0];
    _diesel_gen3_control_bus_split1__out1 = _diesel_gen3_measurements_bus_join1__out[1];
    _diesel_gen3_control_bus_split1__out2 = _diesel_gen3_measurements_bus_join1__out[2];
    _diesel_gen3_control_bus_split1__out3 = _diesel_gen3_measurements_bus_join1__out[3];
    // Generated from the component: Diesel_Gen3.Measurements.S
    HIL_OutAO(0x4051, (float)_diesel_gen3_measurements_gain7__out);
    // Generated from the component: Diesel_Gen3.Measurements.Q
    HIL_OutAO(0x4050, (float)_diesel_gen3_measurements_gain8__out);
    // Generated from the component: Diesel_Gen3.Measurements.P
    HIL_OutAO(0x404f, (float)_diesel_gen3_measurements_gain9__out);
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.and
    _diesel_gen3_sync_check_check_v_diff_and__out = _diesel_gen3_sync_check_check_v_diff_less_equal__out && _diesel_gen3_sync_check_check_v_diff_greater_equal__out ;
    // Generated from the component: Diesel_Gen3.Sync_Check.f_match
    HIL_OutInt32(0xf0042f, _diesel_gen3_sync_check_check_f_diff_comparator1__out != 0x0);
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.Counter.Counter1.en_switch
    _diesel_gen3_sync_check_check_phase_diff_counter_counter1_en_switch__out = (_diesel_gen3_sync_check_check_phase_diff_comparator2__out > 0.5f) ? _diesel_gen3_sync_check_check_phase_diff_counter_counter1_const_value_1__out : _diesel_gen3_sync_check_check_phase_diff_counter_counter1_const_value_0__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.Counter.not
    _diesel_gen3_sync_check_check_phase_diff_counter_not__out = !_diesel_gen3_sync_check_check_phase_diff_comparator2__out;
    // Generated from the component: Diesel_Gen3.Control.Start_Exciter.and
    _diesel_gen3_control_start_exciter_and__out = _diesel_gen3_control_bus_split3__out && _diesel_gen3_control_start_exciter_comparator1__out ;
    // Generated from the component: Diesel_Gen3.Control.check_steady_state_w.Comparator3
    if (_diesel_gen3_control_check_steady_state_w_speed_diff__out < _diesel_gen3_control_check_steady_state_w_abs1__out) {
        _diesel_gen3_control_check_steady_state_w_comparator3__out = 0;
    } else if (_diesel_gen3_control_check_steady_state_w_speed_diff__out > _diesel_gen3_control_check_steady_state_w_abs1__out) {
        _diesel_gen3_control_check_steady_state_w_comparator3__out = 1;
    } else {
        _diesel_gen3_control_check_steady_state_w_comparator3__out = _diesel_gen3_control_check_steady_state_w_comparator3__state;
    }
    // Generated from the component: Diesel_Gen4.Control.Exciter.DC4B.TF3
    X_UnInt32 _diesel_gen4_control_exciter_dc4b_tf3__i;
    _diesel_gen4_control_exciter_dc4b_tf3__a_sum = 0.0f;
    _diesel_gen4_control_exciter_dc4b_tf3__b_sum = 0.0f;
    _diesel_gen4_control_exciter_dc4b_tf3__delay_line_in = 0.0f;
    for (_diesel_gen4_control_exciter_dc4b_tf3__i = 0; _diesel_gen4_control_exciter_dc4b_tf3__i < 1; _diesel_gen4_control_exciter_dc4b_tf3__i++) {
        _diesel_gen4_control_exciter_dc4b_tf3__b_sum += _diesel_gen4_control_exciter_dc4b_tf3__b_coeff[_diesel_gen4_control_exciter_dc4b_tf3__i + 1] * _diesel_gen4_control_exciter_dc4b_tf3__states[_diesel_gen4_control_exciter_dc4b_tf3__i];
    }
    _diesel_gen4_control_exciter_dc4b_tf3__a_sum += _diesel_gen4_control_exciter_dc4b_tf3__states[0] * _diesel_gen4_control_exciter_dc4b_tf3__a_coeff[1];
    _diesel_gen4_control_exciter_dc4b_tf3__delay_line_in = _diesel_gen4_control_exciter_dc4b_variable_limit__out - _diesel_gen4_control_exciter_dc4b_tf3__a_sum;
    _diesel_gen4_control_exciter_dc4b_tf3__b_sum += _diesel_gen4_control_exciter_dc4b_tf3__b_coeff[0] * _diesel_gen4_control_exciter_dc4b_tf3__delay_line_in;
    _diesel_gen4_control_exciter_dc4b_tf3__out = _diesel_gen4_control_exciter_dc4b_tf3__b_sum;
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.PLL_Grid.PLL.ABC_dqz.abc to alpha beta
    _diesel_gen4_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__alpha = (2.0 * _diesel_gen4_sync_check_plls_split__out - _diesel_gen4_sync_check_plls_split__out1 - _diesel_gen4_sync_check_plls_split__out2) * 0.3333333333333333;
    _diesel_gen4_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__beta = (_diesel_gen4_sync_check_plls_split__out1 - _diesel_gen4_sync_check_plls_split__out2) * 0.5773502691896258;
    _diesel_gen4_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__gamma = (_diesel_gen4_sync_check_plls_split__out + _diesel_gen4_sync_check_plls_split__out1 + _diesel_gen4_sync_check_plls_split__out2) * 0.3333333333333333;
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.PI.Gain1
    _diesel_gen4_measurements_3ph_pll_gen_pll_pi_gain1__out = 714.2857004093205 * _diesel_gen4_measurements_3ph_pll_gen_pll_pi_sum8__out;
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.LPF_d
    X_UnInt32 _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__i;
    _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__a_sum = 0.0f;
    _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__b_sum = 0.0f;
    _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__delay_line_in = 0.0f;
    for (_diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__i = 0; _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__i < 1; _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__i++) {
        _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__b_sum += _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__b_coeff[_diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__i + 1] * _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__states[_diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__i];
    }
    _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__a_sum += _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__states[0] * _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__a_coeff[1];
    _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__delay_line_in = _diesel_gen4_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__d - _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__a_sum;
    _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__b_sum += _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__b_coeff[0] * _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__delay_line_in;
    _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__out = _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__b_sum;
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.LPF_q
    X_UnInt32 _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__i;
    _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__a_sum = 0.0f;
    _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__b_sum = 0.0f;
    _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__delay_line_in = 0.0f;
    for (_diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__i = 0; _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__i < 1; _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__i++) {
        _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__b_sum += _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__b_coeff[_diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__i + 1] * _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__states[_diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__i];
    }
    _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__a_sum += _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__states[0] * _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__a_coeff[1];
    _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__delay_line_in = _diesel_gen4_measurements_3ph_pll_gen_pll_abc_dqz_alpha_beta_to_dq__q - _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__a_sum;
    _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__b_sum += _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__b_coeff[0] * _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__delay_line_in;
    _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__out = _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__b_sum;
    // Generated from the component: Diesel_Gen4.Control.Bus Split1
    _diesel_gen4_control_bus_split1__out = _diesel_gen4_measurements_bus_join1__out[0];
    _diesel_gen4_control_bus_split1__out1 = _diesel_gen4_measurements_bus_join1__out[1];
    _diesel_gen4_control_bus_split1__out2 = _diesel_gen4_measurements_bus_join1__out[2];
    _diesel_gen4_control_bus_split1__out3 = _diesel_gen4_measurements_bus_join1__out[3];
    // Generated from the component: Diesel_Gen4.Measurements.S
    HIL_OutAO(0x4071, (float)_diesel_gen4_measurements_gain7__out);
    // Generated from the component: Diesel_Gen4.Measurements.Q
    HIL_OutAO(0x4070, (float)_diesel_gen4_measurements_gain8__out);
    // Generated from the component: Diesel_Gen4.Measurements.P
    HIL_OutAO(0x406f, (float)_diesel_gen4_measurements_gain9__out);
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.and
    _diesel_gen4_sync_check_check_v_diff_and__out = _diesel_gen4_sync_check_check_v_diff_less_equal__out && _diesel_gen4_sync_check_check_v_diff_greater_equal__out ;
    // Generated from the component: Diesel_Gen4.Sync_Check.f_match
    HIL_OutInt32(0xf0043f, _diesel_gen4_sync_check_check_f_diff_comparator1__out != 0x0);
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.Counter.Counter1.en_switch
    _diesel_gen4_sync_check_check_phase_diff_counter_counter1_en_switch__out = (_diesel_gen4_sync_check_check_phase_diff_comparator2__out > 0.5f) ? _diesel_gen4_sync_check_check_phase_diff_counter_counter1_const_value_1__out : _diesel_gen4_sync_check_check_phase_diff_counter_counter1_const_value_0__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.Counter.not
    _diesel_gen4_sync_check_check_phase_diff_counter_not__out = !_diesel_gen4_sync_check_check_phase_diff_comparator2__out;
    // Generated from the component: Diesel_Gen4.Control.Start_Exciter.and
    _diesel_gen4_control_start_exciter_and__out = _diesel_gen4_control_bus_split3__out && _diesel_gen4_control_start_exciter_comparator1__out ;
    // Generated from the component: Diesel_Gen4.Control.check_steady_state_w.Comparator3
    if (_diesel_gen4_control_check_steady_state_w_speed_diff__out < _diesel_gen4_control_check_steady_state_w_abs1__out) {
        _diesel_gen4_control_check_steady_state_w_comparator3__out = 0;
    } else if (_diesel_gen4_control_check_steady_state_w_speed_diff__out > _diesel_gen4_control_check_steady_state_w_abs1__out) {
        _diesel_gen4_control_check_steady_state_w_comparator3__out = 1;
    } else {
        _diesel_gen4_control_check_steady_state_w_comparator3__out = _diesel_gen4_control_check_steady_state_w_comparator3__state;
    }
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.P_ramp
    if (_diesel_gen1_control_freq_setpoint_control_p_ramp__first_step) {
        _diesel_gen1_control_freq_setpoint_control_p_ramp__out = _diesel_gen1_control_freq_setpoint_control_p_limit__out;
        _diesel_gen1_control_freq_setpoint_control_p_ramp__state = _diesel_gen1_control_freq_setpoint_control_p_limit__out;
    } else {
        _diesel_gen1_control_freq_setpoint_control_p_ramp__out = _diesel_gen1_control_freq_setpoint_control_p_limit__out;
        if (_diesel_gen1_control_freq_setpoint_control_p_limit__out - _diesel_gen1_control_freq_setpoint_control_p_ramp__state > 0.002)
            _diesel_gen1_control_freq_setpoint_control_p_ramp__out = _diesel_gen1_control_freq_setpoint_control_p_ramp__state + (0.002);
        if (_diesel_gen1_control_freq_setpoint_control_p_limit__out - _diesel_gen1_control_freq_setpoint_control_p_ramp__state < -0.002)
            _diesel_gen1_control_freq_setpoint_control_p_ramp__out = _diesel_gen1_control_freq_setpoint_control_p_ramp__state + (-0.002);
    }
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.DEGOV.Integrator.Limit1
    _diesel_gen1_control_governor_and_engine_degov_integrator_limit1__out = MIN(MAX(_diesel_gen1_control_governor_and_engine_degov_integrator_integrator1__out, -10.0), 10.0);
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.w_ramp
    if (_diesel_gen1_control_governor_and_engine_w_ramp__first_step) {
        _diesel_gen1_control_governor_and_engine_w_ramp__out = _diesel_gen1_control_governor_and_engine_w_switch__out;
        _diesel_gen1_control_governor_and_engine_w_ramp__state = _diesel_gen1_control_governor_and_engine_w_switch__out;
    } else {
        _diesel_gen1_control_governor_and_engine_w_ramp__out = _diesel_gen1_control_governor_and_engine_w_switch__out;
        if (_diesel_gen1_control_governor_and_engine_w_switch__out - _diesel_gen1_control_governor_and_engine_w_ramp__state > 0.002)
            _diesel_gen1_control_governor_and_engine_w_ramp__out = _diesel_gen1_control_governor_and_engine_w_ramp__state + (0.002);
        if (_diesel_gen1_control_governor_and_engine_w_switch__out - _diesel_gen1_control_governor_and_engine_w_ramp__state < -0.002)
            _diesel_gen1_control_governor_and_engine_w_ramp__out = _diesel_gen1_control_governor_and_engine_w_ramp__state + (-0.002);
    }
    // Generated from the component: Diesel_Gen1.Control.read_OP_mode
    _diesel_gen1_control_read_op_mode__GCB_status = _diesel_gen1_control_unit_delay1__out;
    _diesel_gen1_control_read_op_mode__OP_mode = _diesel_gen1_control_round1__out;
    if (_diesel_gen1_control_read_op_mode__OP_mode == 0) {
        _diesel_gen1_control_read_op_mode__StandBy = 1;
        _diesel_gen1_control_read_op_mode__GridFollowing = 0;
        _diesel_gen1_control_read_op_mode__GridForming = 0;
        _diesel_gen1_control_read_op_mode__enable = 0;
    }
    else {
        if (_diesel_gen1_control_read_op_mode__OP_mode == 1) {
            _diesel_gen1_control_read_op_mode__StandBy = 0;
            _diesel_gen1_control_read_op_mode__GridFollowing = 1;
            _diesel_gen1_control_read_op_mode__GridForming = 0;
            if (_diesel_gen1_control_read_op_mode__GCB_status == 0) {
                _diesel_gen1_control_read_op_mode__enable = 0;
            }
            else {
                _diesel_gen1_control_read_op_mode__enable = 1;
            }
        }
        else {
            _diesel_gen1_control_read_op_mode__StandBy = 0;
            _diesel_gen1_control_read_op_mode__GridFollowing = 0;
            _diesel_gen1_control_read_op_mode__GridForming = 1;
            _diesel_gen1_control_read_op_mode__enable = 0;
        }
    }
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.P_ramp
    if (_diesel_gen2_control_freq_setpoint_control_p_ramp__first_step) {
        _diesel_gen2_control_freq_setpoint_control_p_ramp__out = _diesel_gen2_control_freq_setpoint_control_p_limit__out;
        _diesel_gen2_control_freq_setpoint_control_p_ramp__state = _diesel_gen2_control_freq_setpoint_control_p_limit__out;
    } else {
        _diesel_gen2_control_freq_setpoint_control_p_ramp__out = _diesel_gen2_control_freq_setpoint_control_p_limit__out;
        if (_diesel_gen2_control_freq_setpoint_control_p_limit__out - _diesel_gen2_control_freq_setpoint_control_p_ramp__state > 0.002)
            _diesel_gen2_control_freq_setpoint_control_p_ramp__out = _diesel_gen2_control_freq_setpoint_control_p_ramp__state + (0.002);
        if (_diesel_gen2_control_freq_setpoint_control_p_limit__out - _diesel_gen2_control_freq_setpoint_control_p_ramp__state < -0.002)
            _diesel_gen2_control_freq_setpoint_control_p_ramp__out = _diesel_gen2_control_freq_setpoint_control_p_ramp__state + (-0.002);
    }
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.DEGOV.Integrator.Limit1
    _diesel_gen2_control_governor_and_engine_degov_integrator_limit1__out = MIN(MAX(_diesel_gen2_control_governor_and_engine_degov_integrator_integrator1__out, -10.0), 10.0);
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.w_ramp
    if (_diesel_gen2_control_governor_and_engine_w_ramp__first_step) {
        _diesel_gen2_control_governor_and_engine_w_ramp__out = _diesel_gen2_control_governor_and_engine_w_switch__out;
        _diesel_gen2_control_governor_and_engine_w_ramp__state = _diesel_gen2_control_governor_and_engine_w_switch__out;
    } else {
        _diesel_gen2_control_governor_and_engine_w_ramp__out = _diesel_gen2_control_governor_and_engine_w_switch__out;
        if (_diesel_gen2_control_governor_and_engine_w_switch__out - _diesel_gen2_control_governor_and_engine_w_ramp__state > 0.002)
            _diesel_gen2_control_governor_and_engine_w_ramp__out = _diesel_gen2_control_governor_and_engine_w_ramp__state + (0.002);
        if (_diesel_gen2_control_governor_and_engine_w_switch__out - _diesel_gen2_control_governor_and_engine_w_ramp__state < -0.002)
            _diesel_gen2_control_governor_and_engine_w_ramp__out = _diesel_gen2_control_governor_and_engine_w_ramp__state + (-0.002);
    }
    // Generated from the component: Diesel_Gen2.Control.read_OP_mode
    _diesel_gen2_control_read_op_mode__GCB_status = _diesel_gen2_control_unit_delay1__out;
    _diesel_gen2_control_read_op_mode__OP_mode = _diesel_gen2_control_round1__out;
    if (_diesel_gen2_control_read_op_mode__OP_mode == 0) {
        _diesel_gen2_control_read_op_mode__StandBy = 1;
        _diesel_gen2_control_read_op_mode__GridFollowing = 0;
        _diesel_gen2_control_read_op_mode__GridForming = 0;
        _diesel_gen2_control_read_op_mode__enable = 0;
    }
    else {
        if (_diesel_gen2_control_read_op_mode__OP_mode == 1) {
            _diesel_gen2_control_read_op_mode__StandBy = 0;
            _diesel_gen2_control_read_op_mode__GridFollowing = 1;
            _diesel_gen2_control_read_op_mode__GridForming = 0;
            if (_diesel_gen2_control_read_op_mode__GCB_status == 0) {
                _diesel_gen2_control_read_op_mode__enable = 0;
            }
            else {
                _diesel_gen2_control_read_op_mode__enable = 1;
            }
        }
        else {
            _diesel_gen2_control_read_op_mode__StandBy = 0;
            _diesel_gen2_control_read_op_mode__GridFollowing = 0;
            _diesel_gen2_control_read_op_mode__GridForming = 1;
            _diesel_gen2_control_read_op_mode__enable = 0;
        }
    }
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.P_ramp
    if (_diesel_gen4_control_freq_setpoint_control_p_ramp__first_step) {
        _diesel_gen4_control_freq_setpoint_control_p_ramp__out = _diesel_gen4_control_freq_setpoint_control_p_limit__out;
        _diesel_gen4_control_freq_setpoint_control_p_ramp__state = _diesel_gen4_control_freq_setpoint_control_p_limit__out;
    } else {
        _diesel_gen4_control_freq_setpoint_control_p_ramp__out = _diesel_gen4_control_freq_setpoint_control_p_limit__out;
        if (_diesel_gen4_control_freq_setpoint_control_p_limit__out - _diesel_gen4_control_freq_setpoint_control_p_ramp__state > 0.002)
            _diesel_gen4_control_freq_setpoint_control_p_ramp__out = _diesel_gen4_control_freq_setpoint_control_p_ramp__state + (0.002);
        if (_diesel_gen4_control_freq_setpoint_control_p_limit__out - _diesel_gen4_control_freq_setpoint_control_p_ramp__state < -0.002)
            _diesel_gen4_control_freq_setpoint_control_p_ramp__out = _diesel_gen4_control_freq_setpoint_control_p_ramp__state + (-0.002);
    }
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.DEGOV.Integrator.Limit1
    _diesel_gen4_control_governor_and_engine_degov_integrator_limit1__out = MIN(MAX(_diesel_gen4_control_governor_and_engine_degov_integrator_integrator1__out, -10.0), 10.0);
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.w_ramp
    if (_diesel_gen4_control_governor_and_engine_w_ramp__first_step) {
        _diesel_gen4_control_governor_and_engine_w_ramp__out = _diesel_gen4_control_governor_and_engine_w_switch__out;
        _diesel_gen4_control_governor_and_engine_w_ramp__state = _diesel_gen4_control_governor_and_engine_w_switch__out;
    } else {
        _diesel_gen4_control_governor_and_engine_w_ramp__out = _diesel_gen4_control_governor_and_engine_w_switch__out;
        if (_diesel_gen4_control_governor_and_engine_w_switch__out - _diesel_gen4_control_governor_and_engine_w_ramp__state > 0.002)
            _diesel_gen4_control_governor_and_engine_w_ramp__out = _diesel_gen4_control_governor_and_engine_w_ramp__state + (0.002);
        if (_diesel_gen4_control_governor_and_engine_w_switch__out - _diesel_gen4_control_governor_and_engine_w_ramp__state < -0.002)
            _diesel_gen4_control_governor_and_engine_w_ramp__out = _diesel_gen4_control_governor_and_engine_w_ramp__state + (-0.002);
    }
    // Generated from the component: Diesel_Gen4.Control.read_OP_mode
    _diesel_gen4_control_read_op_mode__GCB_status = _diesel_gen4_control_unit_delay1__out;
    _diesel_gen4_control_read_op_mode__OP_mode = _diesel_gen4_control_round1__out;
    if (_diesel_gen4_control_read_op_mode__OP_mode == 0) {
        _diesel_gen4_control_read_op_mode__StandBy = 1;
        _diesel_gen4_control_read_op_mode__GridFollowing = 0;
        _diesel_gen4_control_read_op_mode__GridForming = 0;
        _diesel_gen4_control_read_op_mode__enable = 0;
    }
    else {
        if (_diesel_gen4_control_read_op_mode__OP_mode == 1) {
            _diesel_gen4_control_read_op_mode__StandBy = 0;
            _diesel_gen4_control_read_op_mode__GridFollowing = 1;
            _diesel_gen4_control_read_op_mode__GridForming = 0;
            if (_diesel_gen4_control_read_op_mode__GCB_status == 0) {
                _diesel_gen4_control_read_op_mode__enable = 0;
            }
            else {
                _diesel_gen4_control_read_op_mode__enable = 1;
            }
        }
        else {
            _diesel_gen4_control_read_op_mode__StandBy = 0;
            _diesel_gen4_control_read_op_mode__GridFollowing = 0;
            _diesel_gen4_control_read_op_mode__GridForming = 1;
            _diesel_gen4_control_read_op_mode__enable = 0;
        }
    }
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.P_ramp
    if (_diesel_gen3_control_freq_setpoint_control_p_ramp__first_step) {
        _diesel_gen3_control_freq_setpoint_control_p_ramp__out = _diesel_gen3_control_freq_setpoint_control_p_limit__out;
        _diesel_gen3_control_freq_setpoint_control_p_ramp__state = _diesel_gen3_control_freq_setpoint_control_p_limit__out;
    } else {
        _diesel_gen3_control_freq_setpoint_control_p_ramp__out = _diesel_gen3_control_freq_setpoint_control_p_limit__out;
        if (_diesel_gen3_control_freq_setpoint_control_p_limit__out - _diesel_gen3_control_freq_setpoint_control_p_ramp__state > 0.002)
            _diesel_gen3_control_freq_setpoint_control_p_ramp__out = _diesel_gen3_control_freq_setpoint_control_p_ramp__state + (0.002);
        if (_diesel_gen3_control_freq_setpoint_control_p_limit__out - _diesel_gen3_control_freq_setpoint_control_p_ramp__state < -0.002)
            _diesel_gen3_control_freq_setpoint_control_p_ramp__out = _diesel_gen3_control_freq_setpoint_control_p_ramp__state + (-0.002);
    }
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.DEGOV.Integrator.Limit1
    _diesel_gen3_control_governor_and_engine_degov_integrator_limit1__out = MIN(MAX(_diesel_gen3_control_governor_and_engine_degov_integrator_integrator1__out, -10.0), 10.0);
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.w_ramp
    if (_diesel_gen3_control_governor_and_engine_w_ramp__first_step) {
        _diesel_gen3_control_governor_and_engine_w_ramp__out = _diesel_gen3_control_governor_and_engine_w_switch__out;
        _diesel_gen3_control_governor_and_engine_w_ramp__state = _diesel_gen3_control_governor_and_engine_w_switch__out;
    } else {
        _diesel_gen3_control_governor_and_engine_w_ramp__out = _diesel_gen3_control_governor_and_engine_w_switch__out;
        if (_diesel_gen3_control_governor_and_engine_w_switch__out - _diesel_gen3_control_governor_and_engine_w_ramp__state > 0.002)
            _diesel_gen3_control_governor_and_engine_w_ramp__out = _diesel_gen3_control_governor_and_engine_w_ramp__state + (0.002);
        if (_diesel_gen3_control_governor_and_engine_w_switch__out - _diesel_gen3_control_governor_and_engine_w_ramp__state < -0.002)
            _diesel_gen3_control_governor_and_engine_w_ramp__out = _diesel_gen3_control_governor_and_engine_w_ramp__state + (-0.002);
    }
    // Generated from the component: Diesel_Gen3.Control.read_OP_mode
    _diesel_gen3_control_read_op_mode__GCB_status = _diesel_gen3_control_unit_delay1__out;
    _diesel_gen3_control_read_op_mode__OP_mode = _diesel_gen3_control_round1__out;
    if (_diesel_gen3_control_read_op_mode__OP_mode == 0) {
        _diesel_gen3_control_read_op_mode__StandBy = 1;
        _diesel_gen3_control_read_op_mode__GridFollowing = 0;
        _diesel_gen3_control_read_op_mode__GridForming = 0;
        _diesel_gen3_control_read_op_mode__enable = 0;
    }
    else {
        if (_diesel_gen3_control_read_op_mode__OP_mode == 1) {
            _diesel_gen3_control_read_op_mode__StandBy = 0;
            _diesel_gen3_control_read_op_mode__GridFollowing = 1;
            _diesel_gen3_control_read_op_mode__GridForming = 0;
            if (_diesel_gen3_control_read_op_mode__GCB_status == 0) {
                _diesel_gen3_control_read_op_mode__enable = 0;
            }
            else {
                _diesel_gen3_control_read_op_mode__enable = 1;
            }
        }
        else {
            _diesel_gen3_control_read_op_mode__StandBy = 0;
            _diesel_gen3_control_read_op_mode__GridFollowing = 0;
            _diesel_gen3_control_read_op_mode__GridForming = 1;
            _diesel_gen3_control_read_op_mode__enable = 0;
        }
    }
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.PLL_Grid.PLL.ABC_dqz.alpha beta to dq
    _diesel_gen1_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k1 = cos(_diesel_gen1_sync_check_plls_pll_grid_pll_unit_delay1__out);
    _diesel_gen1_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k2 = sin(_diesel_gen1_sync_check_plls_pll_grid_pll_unit_delay1__out);
    _diesel_gen1_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__d = _diesel_gen1_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k2 * _diesel_gen1_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__alpha - _diesel_gen1_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k1 * _diesel_gen1_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__beta;
    _diesel_gen1_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__q = _diesel_gen1_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k1 * _diesel_gen1_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__alpha + _diesel_gen1_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k2 * _diesel_gen1_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__beta;
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.PLL_Grid.PLL.Term
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.PI.Sum5
    _diesel_gen1_measurements_3ph_pll_gen_pll_pi_sum5__out = _diesel_gen1_measurements_3ph_pll_gen_pll_pi_kp__out + _diesel_gen1_measurements_3ph_pll_gen_pll_pi_gain1__out + _diesel_gen1_measurements_3ph_pll_gen_pll_pi_integrator1__out;
    // Generated from the component: Diesel_Gen1.Control.Exciter.Vt_to_Vtpu
    _diesel_gen1_control_exciter_vt_to_vtpu__out = 0.002551551815399144 * _diesel_gen1_control_bus_split1__out2;
    // Generated from the component: Diesel_Gen1.Control.Exciter.to_pu
    _diesel_gen1_control_exciter_to_pu__out = 1e-06 * _diesel_gen1_control_bus_split1__out1;
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.P_3ph_to_pu
    _diesel_gen1_control_freq_setpoint_control_p_3ph_to_pu__out = 1e-06 * _diesel_gen1_control_bus_split1__out;
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.to_pu
    _diesel_gen1_control_governor_and_engine_to_pu__out = 1e-06 * _diesel_gen1_control_bus_split1__out;
    // Generated from the component: Diesel_Gen1.Control.pf Control.norm_pf_meas
    _diesel_gen1_control_pf_control_norm_pf_meas__Q = _diesel_gen1_control_bus_split1__out1;
    _diesel_gen1_control_pf_control_norm_pf_meas__pf = _diesel_gen1_control_bus_split1__out3;
    if (_diesel_gen1_control_pf_control_norm_pf_meas__pf >= 0) {
        if (_diesel_gen1_control_pf_control_norm_pf_meas__Q >= 0) {
            _diesel_gen1_control_pf_control_norm_pf_meas__pf_norm = 2 - _diesel_gen1_control_pf_control_norm_pf_meas__pf;
        }
        else {
            _diesel_gen1_control_pf_control_norm_pf_meas__pf_norm = _diesel_gen1_control_pf_control_norm_pf_meas__pf;
        }
    }
    else {
        if (_diesel_gen1_control_pf_control_norm_pf_meas__Q >= 0) {
            _diesel_gen1_control_pf_control_norm_pf_meas__pf_norm = 2 + _diesel_gen1_control_pf_control_norm_pf_meas__pf;
        }
        else {
            _diesel_gen1_control_pf_control_norm_pf_meas__pf_norm = -_diesel_gen1_control_pf_control_norm_pf_meas__pf;
        }
    }
    // Generated from the component: Diesel_Gen1.Control.pf Control.norm_pf_ref
    _diesel_gen1_control_pf_control_norm_pf_ref__P = _diesel_gen1_control_bus_split1__out;
    _diesel_gen1_control_pf_control_norm_pf_ref__pf = _diesel_gen1_control_bus_split3__out4;
    if (_diesel_gen1_control_pf_control_norm_pf_ref__P >= 0) {
        if (_diesel_gen1_control_pf_control_norm_pf_ref__pf >= 0) {
            _diesel_gen1_control_pf_control_norm_pf_ref__pf_norm = 2 - _diesel_gen1_control_pf_control_norm_pf_ref__pf;
        }
        else {
            _diesel_gen1_control_pf_control_norm_pf_ref__pf_norm = -_diesel_gen1_control_pf_control_norm_pf_ref__pf;
        }
    }
    else {
        if (_diesel_gen1_control_pf_control_norm_pf_ref__pf >= 0) {
            _diesel_gen1_control_pf_control_norm_pf_ref__pf_norm = 2 - _diesel_gen1_control_pf_control_norm_pf_ref__pf;
        }
        else {
            _diesel_gen1_control_pf_control_norm_pf_ref__pf_norm = -_diesel_gen1_control_pf_control_norm_pf_ref__pf;
        }
    }
    // Generated from the component: Diesel_Gen1.Control.Exciter.DC4B.PI.Integrator1
    if (((_diesel_gen1_control_start_exciter_and__out > 0.0) && (_diesel_gen1_control_exciter_dc4b_pi_integrator1__reset_state <= 0)) || ((_diesel_gen1_control_start_exciter_and__out <= 0.0) && (_diesel_gen1_control_exciter_dc4b_pi_integrator1__reset_state == 1))) {
        _diesel_gen1_control_exciter_dc4b_pi_integrator1__state = 0.0;
    }
    _diesel_gen1_control_exciter_dc4b_pi_integrator1__out = _diesel_gen1_control_exciter_dc4b_pi_integrator1__state;
    // Generated from the component: Diesel_Gen1.Control.Exciter.Product1
    _diesel_gen1_control_exciter_product1__out = (_diesel_gen1_control_start_exciter_and__out * _diesel_gen1_control_exciter_dc4b_tf3__out);
    // Generated from the component: Diesel_Gen1.Control.Exciter.switch
    _diesel_gen1_control_exciter_switch__out = (_diesel_gen1_control_start_exciter_and__out > 0.5f) ? _diesel_gen1_control_bus_split3__out1 : _diesel_gen1_control_exciter_zero__out;
    // Generated from the component: Diesel_Gen1.Control.Exciter_on
    HIL_OutInt32(0xf00400, _diesel_gen1_control_start_exciter_and__out != 0x0);
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.PLL_Grid.PLL.ABC_dqz.alpha beta to dq
    _diesel_gen2_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k1 = cos(_diesel_gen2_sync_check_plls_pll_grid_pll_unit_delay1__out);
    _diesel_gen2_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k2 = sin(_diesel_gen2_sync_check_plls_pll_grid_pll_unit_delay1__out);
    _diesel_gen2_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__d = _diesel_gen2_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k2 * _diesel_gen2_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__alpha - _diesel_gen2_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k1 * _diesel_gen2_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__beta;
    _diesel_gen2_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__q = _diesel_gen2_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k1 * _diesel_gen2_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__alpha + _diesel_gen2_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k2 * _diesel_gen2_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__beta;
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.PLL_Grid.PLL.Term
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.PI.Sum5
    _diesel_gen2_measurements_3ph_pll_gen_pll_pi_sum5__out = _diesel_gen2_measurements_3ph_pll_gen_pll_pi_kp__out + _diesel_gen2_measurements_3ph_pll_gen_pll_pi_gain1__out + _diesel_gen2_measurements_3ph_pll_gen_pll_pi_integrator1__out;
    // Generated from the component: Diesel_Gen2.Control.Exciter.Vt_to_Vtpu
    _diesel_gen2_control_exciter_vt_to_vtpu__out = 0.002551551815399144 * _diesel_gen2_control_bus_split1__out2;
    // Generated from the component: Diesel_Gen2.Control.Exciter.to_pu
    _diesel_gen2_control_exciter_to_pu__out = 1e-06 * _diesel_gen2_control_bus_split1__out1;
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.P_3ph_to_pu
    _diesel_gen2_control_freq_setpoint_control_p_3ph_to_pu__out = 1e-06 * _diesel_gen2_control_bus_split1__out;
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.to_pu
    _diesel_gen2_control_governor_and_engine_to_pu__out = 1e-06 * _diesel_gen2_control_bus_split1__out;
    // Generated from the component: Diesel_Gen2.Control.pf Control.norm_pf_meas
    _diesel_gen2_control_pf_control_norm_pf_meas__Q = _diesel_gen2_control_bus_split1__out1;
    _diesel_gen2_control_pf_control_norm_pf_meas__pf = _diesel_gen2_control_bus_split1__out3;
    if (_diesel_gen2_control_pf_control_norm_pf_meas__pf >= 0) {
        if (_diesel_gen2_control_pf_control_norm_pf_meas__Q >= 0) {
            _diesel_gen2_control_pf_control_norm_pf_meas__pf_norm = 2 - _diesel_gen2_control_pf_control_norm_pf_meas__pf;
        }
        else {
            _diesel_gen2_control_pf_control_norm_pf_meas__pf_norm = _diesel_gen2_control_pf_control_norm_pf_meas__pf;
        }
    }
    else {
        if (_diesel_gen2_control_pf_control_norm_pf_meas__Q >= 0) {
            _diesel_gen2_control_pf_control_norm_pf_meas__pf_norm = 2 + _diesel_gen2_control_pf_control_norm_pf_meas__pf;
        }
        else {
            _diesel_gen2_control_pf_control_norm_pf_meas__pf_norm = -_diesel_gen2_control_pf_control_norm_pf_meas__pf;
        }
    }
    // Generated from the component: Diesel_Gen2.Control.pf Control.norm_pf_ref
    _diesel_gen2_control_pf_control_norm_pf_ref__P = _diesel_gen2_control_bus_split1__out;
    _diesel_gen2_control_pf_control_norm_pf_ref__pf = _diesel_gen2_control_bus_split3__out4;
    if (_diesel_gen2_control_pf_control_norm_pf_ref__P >= 0) {
        if (_diesel_gen2_control_pf_control_norm_pf_ref__pf >= 0) {
            _diesel_gen2_control_pf_control_norm_pf_ref__pf_norm = 2 - _diesel_gen2_control_pf_control_norm_pf_ref__pf;
        }
        else {
            _diesel_gen2_control_pf_control_norm_pf_ref__pf_norm = -_diesel_gen2_control_pf_control_norm_pf_ref__pf;
        }
    }
    else {
        if (_diesel_gen2_control_pf_control_norm_pf_ref__pf >= 0) {
            _diesel_gen2_control_pf_control_norm_pf_ref__pf_norm = 2 - _diesel_gen2_control_pf_control_norm_pf_ref__pf;
        }
        else {
            _diesel_gen2_control_pf_control_norm_pf_ref__pf_norm = -_diesel_gen2_control_pf_control_norm_pf_ref__pf;
        }
    }
    // Generated from the component: Diesel_Gen2.Control.Exciter.DC4B.PI.Integrator1
    if (((_diesel_gen2_control_start_exciter_and__out > 0.0) && (_diesel_gen2_control_exciter_dc4b_pi_integrator1__reset_state <= 0)) || ((_diesel_gen2_control_start_exciter_and__out <= 0.0) && (_diesel_gen2_control_exciter_dc4b_pi_integrator1__reset_state == 1))) {
        _diesel_gen2_control_exciter_dc4b_pi_integrator1__state = 0.0;
    }
    _diesel_gen2_control_exciter_dc4b_pi_integrator1__out = _diesel_gen2_control_exciter_dc4b_pi_integrator1__state;
    // Generated from the component: Diesel_Gen2.Control.Exciter.Product1
    _diesel_gen2_control_exciter_product1__out = (_diesel_gen2_control_start_exciter_and__out * _diesel_gen2_control_exciter_dc4b_tf3__out);
    // Generated from the component: Diesel_Gen2.Control.Exciter.switch
    _diesel_gen2_control_exciter_switch__out = (_diesel_gen2_control_start_exciter_and__out > 0.5f) ? _diesel_gen2_control_bus_split3__out1 : _diesel_gen2_control_exciter_zero__out;
    // Generated from the component: Diesel_Gen2.Control.Exciter_on
    HIL_OutInt32(0xf00410, _diesel_gen2_control_start_exciter_and__out != 0x0);
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.PLL_Grid.PLL.ABC_dqz.alpha beta to dq
    _diesel_gen3_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k1 = cos(_diesel_gen3_sync_check_plls_pll_grid_pll_unit_delay1__out);
    _diesel_gen3_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k2 = sin(_diesel_gen3_sync_check_plls_pll_grid_pll_unit_delay1__out);
    _diesel_gen3_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__d = _diesel_gen3_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k2 * _diesel_gen3_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__alpha - _diesel_gen3_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k1 * _diesel_gen3_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__beta;
    _diesel_gen3_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__q = _diesel_gen3_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k1 * _diesel_gen3_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__alpha + _diesel_gen3_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k2 * _diesel_gen3_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__beta;
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.PLL_Grid.PLL.Term
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.PI.Sum5
    _diesel_gen3_measurements_3ph_pll_gen_pll_pi_sum5__out = _diesel_gen3_measurements_3ph_pll_gen_pll_pi_kp__out + _diesel_gen3_measurements_3ph_pll_gen_pll_pi_gain1__out + _diesel_gen3_measurements_3ph_pll_gen_pll_pi_integrator1__out;
    // Generated from the component: Diesel_Gen3.Control.Exciter.Vt_to_Vtpu
    _diesel_gen3_control_exciter_vt_to_vtpu__out = 0.002551551815399144 * _diesel_gen3_control_bus_split1__out2;
    // Generated from the component: Diesel_Gen3.Control.Exciter.to_pu
    _diesel_gen3_control_exciter_to_pu__out = 1e-06 * _diesel_gen3_control_bus_split1__out1;
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.P_3ph_to_pu
    _diesel_gen3_control_freq_setpoint_control_p_3ph_to_pu__out = 1e-06 * _diesel_gen3_control_bus_split1__out;
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.to_pu
    _diesel_gen3_control_governor_and_engine_to_pu__out = 1e-06 * _diesel_gen3_control_bus_split1__out;
    // Generated from the component: Diesel_Gen3.Control.pf Control.norm_pf_meas
    _diesel_gen3_control_pf_control_norm_pf_meas__Q = _diesel_gen3_control_bus_split1__out1;
    _diesel_gen3_control_pf_control_norm_pf_meas__pf = _diesel_gen3_control_bus_split1__out3;
    if (_diesel_gen3_control_pf_control_norm_pf_meas__pf >= 0) {
        if (_diesel_gen3_control_pf_control_norm_pf_meas__Q >= 0) {
            _diesel_gen3_control_pf_control_norm_pf_meas__pf_norm = 2 - _diesel_gen3_control_pf_control_norm_pf_meas__pf;
        }
        else {
            _diesel_gen3_control_pf_control_norm_pf_meas__pf_norm = _diesel_gen3_control_pf_control_norm_pf_meas__pf;
        }
    }
    else {
        if (_diesel_gen3_control_pf_control_norm_pf_meas__Q >= 0) {
            _diesel_gen3_control_pf_control_norm_pf_meas__pf_norm = 2 + _diesel_gen3_control_pf_control_norm_pf_meas__pf;
        }
        else {
            _diesel_gen3_control_pf_control_norm_pf_meas__pf_norm = -_diesel_gen3_control_pf_control_norm_pf_meas__pf;
        }
    }
    // Generated from the component: Diesel_Gen3.Control.pf Control.norm_pf_ref
    _diesel_gen3_control_pf_control_norm_pf_ref__P = _diesel_gen3_control_bus_split1__out;
    _diesel_gen3_control_pf_control_norm_pf_ref__pf = _diesel_gen3_control_bus_split3__out4;
    if (_diesel_gen3_control_pf_control_norm_pf_ref__P >= 0) {
        if (_diesel_gen3_control_pf_control_norm_pf_ref__pf >= 0) {
            _diesel_gen3_control_pf_control_norm_pf_ref__pf_norm = 2 - _diesel_gen3_control_pf_control_norm_pf_ref__pf;
        }
        else {
            _diesel_gen3_control_pf_control_norm_pf_ref__pf_norm = -_diesel_gen3_control_pf_control_norm_pf_ref__pf;
        }
    }
    else {
        if (_diesel_gen3_control_pf_control_norm_pf_ref__pf >= 0) {
            _diesel_gen3_control_pf_control_norm_pf_ref__pf_norm = 2 - _diesel_gen3_control_pf_control_norm_pf_ref__pf;
        }
        else {
            _diesel_gen3_control_pf_control_norm_pf_ref__pf_norm = -_diesel_gen3_control_pf_control_norm_pf_ref__pf;
        }
    }
    // Generated from the component: Diesel_Gen3.Control.Exciter.DC4B.PI.Integrator1
    if (((_diesel_gen3_control_start_exciter_and__out > 0.0) && (_diesel_gen3_control_exciter_dc4b_pi_integrator1__reset_state <= 0)) || ((_diesel_gen3_control_start_exciter_and__out <= 0.0) && (_diesel_gen3_control_exciter_dc4b_pi_integrator1__reset_state == 1))) {
        _diesel_gen3_control_exciter_dc4b_pi_integrator1__state = 0.0;
    }
    _diesel_gen3_control_exciter_dc4b_pi_integrator1__out = _diesel_gen3_control_exciter_dc4b_pi_integrator1__state;
    // Generated from the component: Diesel_Gen3.Control.Exciter.Product1
    _diesel_gen3_control_exciter_product1__out = (_diesel_gen3_control_start_exciter_and__out * _diesel_gen3_control_exciter_dc4b_tf3__out);
    // Generated from the component: Diesel_Gen3.Control.Exciter.switch
    _diesel_gen3_control_exciter_switch__out = (_diesel_gen3_control_start_exciter_and__out > 0.5f) ? _diesel_gen3_control_bus_split3__out1 : _diesel_gen3_control_exciter_zero__out;
    // Generated from the component: Diesel_Gen3.Control.Exciter_on
    HIL_OutInt32(0xf00420, _diesel_gen3_control_start_exciter_and__out != 0x0);
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.PLL_Grid.PLL.ABC_dqz.alpha beta to dq
    _diesel_gen4_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k1 = cos(_diesel_gen4_sync_check_plls_pll_grid_pll_unit_delay1__out);
    _diesel_gen4_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k2 = sin(_diesel_gen4_sync_check_plls_pll_grid_pll_unit_delay1__out);
    _diesel_gen4_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__d = _diesel_gen4_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k2 * _diesel_gen4_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__alpha - _diesel_gen4_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k1 * _diesel_gen4_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__beta;
    _diesel_gen4_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__q = _diesel_gen4_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k1 * _diesel_gen4_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__alpha + _diesel_gen4_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__k2 * _diesel_gen4_sync_check_plls_pll_grid_pll_abc_dqz_abc_to_alpha_beta__beta;
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.PLL_Grid.PLL.Term
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.PI.Sum5
    _diesel_gen4_measurements_3ph_pll_gen_pll_pi_sum5__out = _diesel_gen4_measurements_3ph_pll_gen_pll_pi_kp__out + _diesel_gen4_measurements_3ph_pll_gen_pll_pi_gain1__out + _diesel_gen4_measurements_3ph_pll_gen_pll_pi_integrator1__out;
    // Generated from the component: Diesel_Gen4.Control.Exciter.Vt_to_Vtpu
    _diesel_gen4_control_exciter_vt_to_vtpu__out = 0.002551551815399144 * _diesel_gen4_control_bus_split1__out2;
    // Generated from the component: Diesel_Gen4.Control.Exciter.to_pu
    _diesel_gen4_control_exciter_to_pu__out = 1e-06 * _diesel_gen4_control_bus_split1__out1;
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.P_3ph_to_pu
    _diesel_gen4_control_freq_setpoint_control_p_3ph_to_pu__out = 1e-06 * _diesel_gen4_control_bus_split1__out;
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.to_pu
    _diesel_gen4_control_governor_and_engine_to_pu__out = 1e-06 * _diesel_gen4_control_bus_split1__out;
    // Generated from the component: Diesel_Gen4.Control.pf Control.norm_pf_meas
    _diesel_gen4_control_pf_control_norm_pf_meas__Q = _diesel_gen4_control_bus_split1__out1;
    _diesel_gen4_control_pf_control_norm_pf_meas__pf = _diesel_gen4_control_bus_split1__out3;
    if (_diesel_gen4_control_pf_control_norm_pf_meas__pf >= 0) {
        if (_diesel_gen4_control_pf_control_norm_pf_meas__Q >= 0) {
            _diesel_gen4_control_pf_control_norm_pf_meas__pf_norm = 2 - _diesel_gen4_control_pf_control_norm_pf_meas__pf;
        }
        else {
            _diesel_gen4_control_pf_control_norm_pf_meas__pf_norm = _diesel_gen4_control_pf_control_norm_pf_meas__pf;
        }
    }
    else {
        if (_diesel_gen4_control_pf_control_norm_pf_meas__Q >= 0) {
            _diesel_gen4_control_pf_control_norm_pf_meas__pf_norm = 2 + _diesel_gen4_control_pf_control_norm_pf_meas__pf;
        }
        else {
            _diesel_gen4_control_pf_control_norm_pf_meas__pf_norm = -_diesel_gen4_control_pf_control_norm_pf_meas__pf;
        }
    }
    // Generated from the component: Diesel_Gen4.Control.pf Control.norm_pf_ref
    _diesel_gen4_control_pf_control_norm_pf_ref__P = _diesel_gen4_control_bus_split1__out;
    _diesel_gen4_control_pf_control_norm_pf_ref__pf = _diesel_gen4_control_bus_split3__out4;
    if (_diesel_gen4_control_pf_control_norm_pf_ref__P >= 0) {
        if (_diesel_gen4_control_pf_control_norm_pf_ref__pf >= 0) {
            _diesel_gen4_control_pf_control_norm_pf_ref__pf_norm = 2 - _diesel_gen4_control_pf_control_norm_pf_ref__pf;
        }
        else {
            _diesel_gen4_control_pf_control_norm_pf_ref__pf_norm = -_diesel_gen4_control_pf_control_norm_pf_ref__pf;
        }
    }
    else {
        if (_diesel_gen4_control_pf_control_norm_pf_ref__pf >= 0) {
            _diesel_gen4_control_pf_control_norm_pf_ref__pf_norm = 2 - _diesel_gen4_control_pf_control_norm_pf_ref__pf;
        }
        else {
            _diesel_gen4_control_pf_control_norm_pf_ref__pf_norm = -_diesel_gen4_control_pf_control_norm_pf_ref__pf;
        }
    }
    // Generated from the component: Diesel_Gen4.Control.Exciter.DC4B.PI.Integrator1
    if (((_diesel_gen4_control_start_exciter_and__out > 0.0) && (_diesel_gen4_control_exciter_dc4b_pi_integrator1__reset_state <= 0)) || ((_diesel_gen4_control_start_exciter_and__out <= 0.0) && (_diesel_gen4_control_exciter_dc4b_pi_integrator1__reset_state == 1))) {
        _diesel_gen4_control_exciter_dc4b_pi_integrator1__state = 0.0;
    }
    _diesel_gen4_control_exciter_dc4b_pi_integrator1__out = _diesel_gen4_control_exciter_dc4b_pi_integrator1__state;
    // Generated from the component: Diesel_Gen4.Control.Exciter.Product1
    _diesel_gen4_control_exciter_product1__out = (_diesel_gen4_control_start_exciter_and__out * _diesel_gen4_control_exciter_dc4b_tf3__out);
    // Generated from the component: Diesel_Gen4.Control.Exciter.switch
    _diesel_gen4_control_exciter_switch__out = (_diesel_gen4_control_start_exciter_and__out > 0.5f) ? _diesel_gen4_control_bus_split3__out1 : _diesel_gen4_control_exciter_zero__out;
    // Generated from the component: Diesel_Gen4.Control.Exciter_on
    HIL_OutInt32(0xf00430, _diesel_gen4_control_start_exciter_and__out != 0x0);
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.Product2
    _diesel_gen1_control_freq_setpoint_control_product2__out = (_diesel_gen1_control_freq_setpoint_control_p_droop__out * _diesel_gen1_control_freq_setpoint_control_p_ramp__out * _diesel_gen1_control_freq_setpoint_control_w_to_wpu__out);
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.DEGOV.Integrator.Sum6
    _diesel_gen1_control_governor_and_engine_degov_integrator_sum6__out =  - _diesel_gen1_control_governor_and_engine_degov_integrator_integrator1__out + _diesel_gen1_control_governor_and_engine_degov_integrator_limit1__out;
    // Generated from the component: Diesel_Gen1.Control.Bus Join1
    _diesel_gen1_control_bus_join1__out[0] = _diesel_gen1_control_bus_split3__out;
    _diesel_gen1_control_bus_join1__out[1] = _diesel_gen1_control_read_op_mode__StandBy;
    _diesel_gen1_control_bus_join1__out[2] = _diesel_gen1_control_read_op_mode__GridForming;
    _diesel_gen1_control_bus_join1__out[3] = _diesel_gen1_control_read_op_mode__GridFollowing;
    _diesel_gen1_control_bus_join1__out[4] = _diesel_gen1_control_check_steady_state_w_comparator3__out;
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.PI.Integrator1
    if (((_diesel_gen1_control_read_op_mode__enable > 0.0) && (_diesel_gen1_control_freq_setpoint_control_pi_integrator1__reset_state <= 0)) || ((_diesel_gen1_control_read_op_mode__enable <= 0.0) && (_diesel_gen1_control_freq_setpoint_control_pi_integrator1__reset_state == 1))) {
        _diesel_gen1_control_freq_setpoint_control_pi_integrator1__state = 0.0;
    }
    _diesel_gen1_control_freq_setpoint_control_pi_integrator1__out = _diesel_gen1_control_freq_setpoint_control_pi_integrator1__state;
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.w_switch
    _diesel_gen1_control_freq_setpoint_control_w_switch__out = (_diesel_gen1_control_read_op_mode__enable > 0.5f) ? _diesel_gen1_control_bus_split3__out2 : _diesel_gen1_control_freq_setpoint_control_zero1__out;
    // Generated from the component: Diesel_Gen1.Control.GridFollowing
    HIL_OutInt32(0xf00402, _diesel_gen1_control_read_op_mode__GridFollowing != 0x0);
    // Generated from the component: Diesel_Gen1.Control.GridForming
    HIL_OutInt32(0xf00403, _diesel_gen1_control_read_op_mode__GridForming != 0x0);
    // Generated from the component: Diesel_Gen1.Control.StandBy
    HIL_OutInt32(0xf00407, _diesel_gen1_control_read_op_mode__StandBy != 0x0);
    // Generated from the component: Diesel_Gen1.Control.pf Control.Logical operator5
    _diesel_gen1_control_pf_control_logical_operator5__out = _diesel_gen1_control_read_op_mode__enable && _diesel_gen1_control_define_control_mode_control_mode__Q_control && _diesel_gen1_control_define_control_mode_control_mode__P_control && _diesel_gen1_control_pf_control_greater_equal__out ;
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.Product2
    _diesel_gen2_control_freq_setpoint_control_product2__out = (_diesel_gen2_control_freq_setpoint_control_p_droop__out * _diesel_gen2_control_freq_setpoint_control_p_ramp__out * _diesel_gen2_control_freq_setpoint_control_w_to_wpu__out);
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.DEGOV.Integrator.Sum6
    _diesel_gen2_control_governor_and_engine_degov_integrator_sum6__out =  - _diesel_gen2_control_governor_and_engine_degov_integrator_integrator1__out + _diesel_gen2_control_governor_and_engine_degov_integrator_limit1__out;
    // Generated from the component: Diesel_Gen2.Control.Bus Join1
    _diesel_gen2_control_bus_join1__out[0] = _diesel_gen2_control_bus_split3__out;
    _diesel_gen2_control_bus_join1__out[1] = _diesel_gen2_control_read_op_mode__StandBy;
    _diesel_gen2_control_bus_join1__out[2] = _diesel_gen2_control_read_op_mode__GridForming;
    _diesel_gen2_control_bus_join1__out[3] = _diesel_gen2_control_read_op_mode__GridFollowing;
    _diesel_gen2_control_bus_join1__out[4] = _diesel_gen2_control_check_steady_state_w_comparator3__out;
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.PI.Integrator1
    if (((_diesel_gen2_control_read_op_mode__enable > 0.0) && (_diesel_gen2_control_freq_setpoint_control_pi_integrator1__reset_state <= 0)) || ((_diesel_gen2_control_read_op_mode__enable <= 0.0) && (_diesel_gen2_control_freq_setpoint_control_pi_integrator1__reset_state == 1))) {
        _diesel_gen2_control_freq_setpoint_control_pi_integrator1__state = 0.0;
    }
    _diesel_gen2_control_freq_setpoint_control_pi_integrator1__out = _diesel_gen2_control_freq_setpoint_control_pi_integrator1__state;
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.w_switch
    _diesel_gen2_control_freq_setpoint_control_w_switch__out = (_diesel_gen2_control_read_op_mode__enable > 0.5f) ? _diesel_gen2_control_bus_split3__out2 : _diesel_gen2_control_freq_setpoint_control_zero1__out;
    // Generated from the component: Diesel_Gen2.Control.GridFollowing
    HIL_OutInt32(0xf00412, _diesel_gen2_control_read_op_mode__GridFollowing != 0x0);
    // Generated from the component: Diesel_Gen2.Control.GridForming
    HIL_OutInt32(0xf00413, _diesel_gen2_control_read_op_mode__GridForming != 0x0);
    // Generated from the component: Diesel_Gen2.Control.StandBy
    HIL_OutInt32(0xf00417, _diesel_gen2_control_read_op_mode__StandBy != 0x0);
    // Generated from the component: Diesel_Gen2.Control.pf Control.Logical operator5
    _diesel_gen2_control_pf_control_logical_operator5__out = _diesel_gen2_control_read_op_mode__enable && _diesel_gen2_control_define_control_mode_control_mode__Q_control && _diesel_gen2_control_define_control_mode_control_mode__P_control && _diesel_gen2_control_pf_control_greater_equal__out ;
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.Product2
    _diesel_gen4_control_freq_setpoint_control_product2__out = (_diesel_gen4_control_freq_setpoint_control_p_droop__out * _diesel_gen4_control_freq_setpoint_control_p_ramp__out * _diesel_gen4_control_freq_setpoint_control_w_to_wpu__out);
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.DEGOV.Integrator.Sum6
    _diesel_gen4_control_governor_and_engine_degov_integrator_sum6__out =  - _diesel_gen4_control_governor_and_engine_degov_integrator_integrator1__out + _diesel_gen4_control_governor_and_engine_degov_integrator_limit1__out;
    // Generated from the component: Diesel_Gen4.Control.Bus Join1
    _diesel_gen4_control_bus_join1__out[0] = _diesel_gen4_control_bus_split3__out;
    _diesel_gen4_control_bus_join1__out[1] = _diesel_gen4_control_read_op_mode__StandBy;
    _diesel_gen4_control_bus_join1__out[2] = _diesel_gen4_control_read_op_mode__GridForming;
    _diesel_gen4_control_bus_join1__out[3] = _diesel_gen4_control_read_op_mode__GridFollowing;
    _diesel_gen4_control_bus_join1__out[4] = _diesel_gen4_control_check_steady_state_w_comparator3__out;
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.PI.Integrator1
    if (((_diesel_gen4_control_read_op_mode__enable > 0.0) && (_diesel_gen4_control_freq_setpoint_control_pi_integrator1__reset_state <= 0)) || ((_diesel_gen4_control_read_op_mode__enable <= 0.0) && (_diesel_gen4_control_freq_setpoint_control_pi_integrator1__reset_state == 1))) {
        _diesel_gen4_control_freq_setpoint_control_pi_integrator1__state = 0.0;
    }
    _diesel_gen4_control_freq_setpoint_control_pi_integrator1__out = _diesel_gen4_control_freq_setpoint_control_pi_integrator1__state;
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.w_switch
    _diesel_gen4_control_freq_setpoint_control_w_switch__out = (_diesel_gen4_control_read_op_mode__enable > 0.5f) ? _diesel_gen4_control_bus_split3__out2 : _diesel_gen4_control_freq_setpoint_control_zero1__out;
    // Generated from the component: Diesel_Gen4.Control.GridFollowing
    HIL_OutInt32(0xf00432, _diesel_gen4_control_read_op_mode__GridFollowing != 0x0);
    // Generated from the component: Diesel_Gen4.Control.GridForming
    HIL_OutInt32(0xf00433, _diesel_gen4_control_read_op_mode__GridForming != 0x0);
    // Generated from the component: Diesel_Gen4.Control.StandBy
    HIL_OutInt32(0xf00437, _diesel_gen4_control_read_op_mode__StandBy != 0x0);
    // Generated from the component: Diesel_Gen4.Control.pf Control.Logical operator5
    _diesel_gen4_control_pf_control_logical_operator5__out = _diesel_gen4_control_read_op_mode__enable && _diesel_gen4_control_define_control_mode_control_mode__Q_control && _diesel_gen4_control_define_control_mode_control_mode__P_control && _diesel_gen4_control_pf_control_greater_equal__out ;
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.Product2
    _diesel_gen3_control_freq_setpoint_control_product2__out = (_diesel_gen3_control_freq_setpoint_control_p_droop__out * _diesel_gen3_control_freq_setpoint_control_p_ramp__out * _diesel_gen3_control_freq_setpoint_control_w_to_wpu__out);
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.DEGOV.Integrator.Sum6
    _diesel_gen3_control_governor_and_engine_degov_integrator_sum6__out =  - _diesel_gen3_control_governor_and_engine_degov_integrator_integrator1__out + _diesel_gen3_control_governor_and_engine_degov_integrator_limit1__out;
    // Generated from the component: Diesel_Gen3.Control.Bus Join1
    _diesel_gen3_control_bus_join1__out[0] = _diesel_gen3_control_bus_split3__out;
    _diesel_gen3_control_bus_join1__out[1] = _diesel_gen3_control_read_op_mode__StandBy;
    _diesel_gen3_control_bus_join1__out[2] = _diesel_gen3_control_read_op_mode__GridForming;
    _diesel_gen3_control_bus_join1__out[3] = _diesel_gen3_control_read_op_mode__GridFollowing;
    _diesel_gen3_control_bus_join1__out[4] = _diesel_gen3_control_check_steady_state_w_comparator3__out;
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.PI.Integrator1
    if (((_diesel_gen3_control_read_op_mode__enable > 0.0) && (_diesel_gen3_control_freq_setpoint_control_pi_integrator1__reset_state <= 0)) || ((_diesel_gen3_control_read_op_mode__enable <= 0.0) && (_diesel_gen3_control_freq_setpoint_control_pi_integrator1__reset_state == 1))) {
        _diesel_gen3_control_freq_setpoint_control_pi_integrator1__state = 0.0;
    }
    _diesel_gen3_control_freq_setpoint_control_pi_integrator1__out = _diesel_gen3_control_freq_setpoint_control_pi_integrator1__state;
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.w_switch
    _diesel_gen3_control_freq_setpoint_control_w_switch__out = (_diesel_gen3_control_read_op_mode__enable > 0.5f) ? _diesel_gen3_control_bus_split3__out2 : _diesel_gen3_control_freq_setpoint_control_zero1__out;
    // Generated from the component: Diesel_Gen3.Control.GridFollowing
    HIL_OutInt32(0xf00422, _diesel_gen3_control_read_op_mode__GridFollowing != 0x0);
    // Generated from the component: Diesel_Gen3.Control.GridForming
    HIL_OutInt32(0xf00423, _diesel_gen3_control_read_op_mode__GridForming != 0x0);
    // Generated from the component: Diesel_Gen3.Control.StandBy
    HIL_OutInt32(0xf00427, _diesel_gen3_control_read_op_mode__StandBy != 0x0);
    // Generated from the component: Diesel_Gen3.Control.pf Control.Logical operator5
    _diesel_gen3_control_pf_control_logical_operator5__out = _diesel_gen3_control_read_op_mode__enable && _diesel_gen3_control_define_control_mode_control_mode__Q_control && _diesel_gen3_control_define_control_mode_control_mode__P_control && _diesel_gen3_control_pf_control_greater_equal__out ;
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.PLL_Grid.PLL.Normalize.V_terminal
    _diesel_gen1_sync_check_plls_pll_grid_pll_normalize_v_terminal__d = _diesel_gen1_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__d;
    _diesel_gen1_sync_check_plls_pll_grid_pll_normalize_v_terminal__q = _diesel_gen1_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__q;
    _diesel_gen1_sync_check_plls_pll_grid_pll_normalize_v_terminal__t = (powf(_diesel_gen1_sync_check_plls_pll_grid_pll_normalize_v_terminal__d, 2.0) + powf(_diesel_gen1_sync_check_plls_pll_grid_pll_normalize_v_terminal__q, 2.0));
    _diesel_gen1_sync_check_plls_pll_grid_pll_normalize_v_terminal__t = sqrt(_diesel_gen1_sync_check_plls_pll_grid_pll_normalize_v_terminal__t);
    if (_diesel_gen1_sync_check_plls_pll_grid_pll_normalize_v_terminal__t < 0.1) {
        _diesel_gen1_sync_check_plls_pll_grid_pll_normalize_v_terminal__q_pu = _diesel_gen1_sync_check_plls_pll_grid_pll_normalize_v_terminal__q / 0.1;
    }
    else {
        _diesel_gen1_sync_check_plls_pll_grid_pll_normalize_v_terminal__q_pu = _diesel_gen1_sync_check_plls_pll_grid_pll_normalize_v_terminal__q / _diesel_gen1_sync_check_plls_pll_grid_pll_normalize_v_terminal__t;
    }
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.PLL_Grid.Term
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.PLL_Grid.Term1
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.PI.Limit1
    _diesel_gen1_measurements_3ph_pll_gen_pll_pi_limit1__out = MIN(MAX(_diesel_gen1_measurements_3ph_pll_gen_pll_pi_sum5__out, 263.89378290154264), 527.7875658030853);
    // Generated from the component: Diesel_Gen1.Control.Exciter.DC4B.TF1
    X_UnInt32 _diesel_gen1_control_exciter_dc4b_tf1__i;
    _diesel_gen1_control_exciter_dc4b_tf1__a_sum = 0.0f;
    _diesel_gen1_control_exciter_dc4b_tf1__b_sum = 0.0f;
    _diesel_gen1_control_exciter_dc4b_tf1__delay_line_in = 0.0f;
    for (_diesel_gen1_control_exciter_dc4b_tf1__i = 0; _diesel_gen1_control_exciter_dc4b_tf1__i < 1; _diesel_gen1_control_exciter_dc4b_tf1__i++) {
        _diesel_gen1_control_exciter_dc4b_tf1__b_sum += _diesel_gen1_control_exciter_dc4b_tf1__b_coeff[_diesel_gen1_control_exciter_dc4b_tf1__i + 1] * _diesel_gen1_control_exciter_dc4b_tf1__states[_diesel_gen1_control_exciter_dc4b_tf1__i];
    }
    _diesel_gen1_control_exciter_dc4b_tf1__a_sum += _diesel_gen1_control_exciter_dc4b_tf1__states[0] * _diesel_gen1_control_exciter_dc4b_tf1__a_coeff[1];
    _diesel_gen1_control_exciter_dc4b_tf1__delay_line_in = _diesel_gen1_control_exciter_vt_to_vtpu__out - _diesel_gen1_control_exciter_dc4b_tf1__a_sum;
    _diesel_gen1_control_exciter_dc4b_tf1__b_sum += _diesel_gen1_control_exciter_dc4b_tf1__b_coeff[0] * _diesel_gen1_control_exciter_dc4b_tf1__delay_line_in;
    _diesel_gen1_control_exciter_dc4b_tf1__out = _diesel_gen1_control_exciter_dc4b_tf1__b_sum;
    // Generated from the component: Diesel_Gen1.Control.Exciter.Vt
    HIL_OutAO(0x4002, (float)_diesel_gen1_control_exciter_vt_to_vtpu__out);
    // Generated from the component: Diesel_Gen1.Control.Exciter.Product2
    _diesel_gen1_control_exciter_product2__out = (_diesel_gen1_control_unit_delay3__out * _diesel_gen1_control_exciter_to_pu__out * _diesel_gen1_control_exciter_one_ov_sqrt_3__out);
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.Product1
    _diesel_gen1_control_freq_setpoint_control_product1__out = (_diesel_gen1_control_freq_setpoint_control_w_droop__out * _diesel_gen1_control_freq_setpoint_control_p_3ph_to_pu__out);
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.Product3
    _diesel_gen1_control_freq_setpoint_control_product3__out = (_diesel_gen1_control_freq_setpoint_control_w_to_wpu__out * _diesel_gen1_control_freq_setpoint_control_p_droop__out * _diesel_gen1_control_freq_setpoint_control_p_3ph_to_pu__out);
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.Product1
    _diesel_gen1_control_governor_and_engine_product1__out = (_diesel_gen1_control_governor_and_engine_to_pu__out * _diesel_gen1_control_governor_and_engine_inner_w_droop__out);
    // Generated from the component: Diesel_Gen1.Control.pf Control.pf_m
    HIL_OutAO(0x400d, (float)_diesel_gen1_control_pf_control_norm_pf_meas__pf_norm);
    // Generated from the component: Diesel_Gen1.Control.pf Control.pf_r
    HIL_OutAO(0x400e, (float)_diesel_gen1_control_pf_control_norm_pf_ref__pf_norm);
    // Generated from the component: Diesel_Gen1.Control.Exciter.Vfpu_to_Vf
    _diesel_gen1_control_exciter_vfpu_to_vf__out = 15601.845495434256 * _diesel_gen1_control_exciter_product1__out;
    // Generated from the component: Diesel_Gen1.Control.Exciter.Rate Limit
    if (_diesel_gen1_control_exciter_rate_limit__first_step) {
        _diesel_gen1_control_exciter_rate_limit__out = _diesel_gen1_control_exciter_switch__out;
        _diesel_gen1_control_exciter_rate_limit__state = _diesel_gen1_control_exciter_switch__out;
    } else {
        _diesel_gen1_control_exciter_rate_limit__out = _diesel_gen1_control_exciter_switch__out;
        if (_diesel_gen1_control_exciter_switch__out - _diesel_gen1_control_exciter_rate_limit__state > 0.002)
            _diesel_gen1_control_exciter_rate_limit__out = _diesel_gen1_control_exciter_rate_limit__state + (0.002);
        if (_diesel_gen1_control_exciter_switch__out - _diesel_gen1_control_exciter_rate_limit__state < -0.002)
            _diesel_gen1_control_exciter_rate_limit__out = _diesel_gen1_control_exciter_rate_limit__state + (-0.002);
    }
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.PLL_Grid.PLL.Normalize.V_terminal
    _diesel_gen2_sync_check_plls_pll_grid_pll_normalize_v_terminal__d = _diesel_gen2_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__d;
    _diesel_gen2_sync_check_plls_pll_grid_pll_normalize_v_terminal__q = _diesel_gen2_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__q;
    _diesel_gen2_sync_check_plls_pll_grid_pll_normalize_v_terminal__t = (powf(_diesel_gen2_sync_check_plls_pll_grid_pll_normalize_v_terminal__d, 2.0) + powf(_diesel_gen2_sync_check_plls_pll_grid_pll_normalize_v_terminal__q, 2.0));
    _diesel_gen2_sync_check_plls_pll_grid_pll_normalize_v_terminal__t = sqrt(_diesel_gen2_sync_check_plls_pll_grid_pll_normalize_v_terminal__t);
    if (_diesel_gen2_sync_check_plls_pll_grid_pll_normalize_v_terminal__t < 0.1) {
        _diesel_gen2_sync_check_plls_pll_grid_pll_normalize_v_terminal__q_pu = _diesel_gen2_sync_check_plls_pll_grid_pll_normalize_v_terminal__q / 0.1;
    }
    else {
        _diesel_gen2_sync_check_plls_pll_grid_pll_normalize_v_terminal__q_pu = _diesel_gen2_sync_check_plls_pll_grid_pll_normalize_v_terminal__q / _diesel_gen2_sync_check_plls_pll_grid_pll_normalize_v_terminal__t;
    }
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.PLL_Grid.Term
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.PLL_Grid.Term1
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.PI.Limit1
    _diesel_gen2_measurements_3ph_pll_gen_pll_pi_limit1__out = MIN(MAX(_diesel_gen2_measurements_3ph_pll_gen_pll_pi_sum5__out, 263.89378290154264), 527.7875658030853);
    // Generated from the component: Diesel_Gen2.Control.Exciter.DC4B.TF1
    X_UnInt32 _diesel_gen2_control_exciter_dc4b_tf1__i;
    _diesel_gen2_control_exciter_dc4b_tf1__a_sum = 0.0f;
    _diesel_gen2_control_exciter_dc4b_tf1__b_sum = 0.0f;
    _diesel_gen2_control_exciter_dc4b_tf1__delay_line_in = 0.0f;
    for (_diesel_gen2_control_exciter_dc4b_tf1__i = 0; _diesel_gen2_control_exciter_dc4b_tf1__i < 1; _diesel_gen2_control_exciter_dc4b_tf1__i++) {
        _diesel_gen2_control_exciter_dc4b_tf1__b_sum += _diesel_gen2_control_exciter_dc4b_tf1__b_coeff[_diesel_gen2_control_exciter_dc4b_tf1__i + 1] * _diesel_gen2_control_exciter_dc4b_tf1__states[_diesel_gen2_control_exciter_dc4b_tf1__i];
    }
    _diesel_gen2_control_exciter_dc4b_tf1__a_sum += _diesel_gen2_control_exciter_dc4b_tf1__states[0] * _diesel_gen2_control_exciter_dc4b_tf1__a_coeff[1];
    _diesel_gen2_control_exciter_dc4b_tf1__delay_line_in = _diesel_gen2_control_exciter_vt_to_vtpu__out - _diesel_gen2_control_exciter_dc4b_tf1__a_sum;
    _diesel_gen2_control_exciter_dc4b_tf1__b_sum += _diesel_gen2_control_exciter_dc4b_tf1__b_coeff[0] * _diesel_gen2_control_exciter_dc4b_tf1__delay_line_in;
    _diesel_gen2_control_exciter_dc4b_tf1__out = _diesel_gen2_control_exciter_dc4b_tf1__b_sum;
    // Generated from the component: Diesel_Gen2.Control.Exciter.Vt
    HIL_OutAO(0x4022, (float)_diesel_gen2_control_exciter_vt_to_vtpu__out);
    // Generated from the component: Diesel_Gen2.Control.Exciter.Product2
    _diesel_gen2_control_exciter_product2__out = (_diesel_gen2_control_unit_delay3__out * _diesel_gen2_control_exciter_to_pu__out * _diesel_gen2_control_exciter_one_ov_sqrt_3__out);
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.Product1
    _diesel_gen2_control_freq_setpoint_control_product1__out = (_diesel_gen2_control_freq_setpoint_control_w_droop__out * _diesel_gen2_control_freq_setpoint_control_p_3ph_to_pu__out);
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.Product3
    _diesel_gen2_control_freq_setpoint_control_product3__out = (_diesel_gen2_control_freq_setpoint_control_w_to_wpu__out * _diesel_gen2_control_freq_setpoint_control_p_droop__out * _diesel_gen2_control_freq_setpoint_control_p_3ph_to_pu__out);
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.Product1
    _diesel_gen2_control_governor_and_engine_product1__out = (_diesel_gen2_control_governor_and_engine_to_pu__out * _diesel_gen2_control_governor_and_engine_inner_w_droop__out);
    // Generated from the component: Diesel_Gen2.Control.pf Control.pf_m
    HIL_OutAO(0x402d, (float)_diesel_gen2_control_pf_control_norm_pf_meas__pf_norm);
    // Generated from the component: Diesel_Gen2.Control.pf Control.pf_r
    HIL_OutAO(0x402e, (float)_diesel_gen2_control_pf_control_norm_pf_ref__pf_norm);
    // Generated from the component: Diesel_Gen2.Control.Exciter.Vfpu_to_Vf
    _diesel_gen2_control_exciter_vfpu_to_vf__out = 15601.845495434256 * _diesel_gen2_control_exciter_product1__out;
    // Generated from the component: Diesel_Gen2.Control.Exciter.Rate Limit
    if (_diesel_gen2_control_exciter_rate_limit__first_step) {
        _diesel_gen2_control_exciter_rate_limit__out = _diesel_gen2_control_exciter_switch__out;
        _diesel_gen2_control_exciter_rate_limit__state = _diesel_gen2_control_exciter_switch__out;
    } else {
        _diesel_gen2_control_exciter_rate_limit__out = _diesel_gen2_control_exciter_switch__out;
        if (_diesel_gen2_control_exciter_switch__out - _diesel_gen2_control_exciter_rate_limit__state > 0.002)
            _diesel_gen2_control_exciter_rate_limit__out = _diesel_gen2_control_exciter_rate_limit__state + (0.002);
        if (_diesel_gen2_control_exciter_switch__out - _diesel_gen2_control_exciter_rate_limit__state < -0.002)
            _diesel_gen2_control_exciter_rate_limit__out = _diesel_gen2_control_exciter_rate_limit__state + (-0.002);
    }
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.PLL_Grid.PLL.Normalize.V_terminal
    _diesel_gen3_sync_check_plls_pll_grid_pll_normalize_v_terminal__d = _diesel_gen3_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__d;
    _diesel_gen3_sync_check_plls_pll_grid_pll_normalize_v_terminal__q = _diesel_gen3_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__q;
    _diesel_gen3_sync_check_plls_pll_grid_pll_normalize_v_terminal__t = (powf(_diesel_gen3_sync_check_plls_pll_grid_pll_normalize_v_terminal__d, 2.0) + powf(_diesel_gen3_sync_check_plls_pll_grid_pll_normalize_v_terminal__q, 2.0));
    _diesel_gen3_sync_check_plls_pll_grid_pll_normalize_v_terminal__t = sqrt(_diesel_gen3_sync_check_plls_pll_grid_pll_normalize_v_terminal__t);
    if (_diesel_gen3_sync_check_plls_pll_grid_pll_normalize_v_terminal__t < 0.1) {
        _diesel_gen3_sync_check_plls_pll_grid_pll_normalize_v_terminal__q_pu = _diesel_gen3_sync_check_plls_pll_grid_pll_normalize_v_terminal__q / 0.1;
    }
    else {
        _diesel_gen3_sync_check_plls_pll_grid_pll_normalize_v_terminal__q_pu = _diesel_gen3_sync_check_plls_pll_grid_pll_normalize_v_terminal__q / _diesel_gen3_sync_check_plls_pll_grid_pll_normalize_v_terminal__t;
    }
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.PLL_Grid.Term
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.PLL_Grid.Term1
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.PI.Limit1
    _diesel_gen3_measurements_3ph_pll_gen_pll_pi_limit1__out = MIN(MAX(_diesel_gen3_measurements_3ph_pll_gen_pll_pi_sum5__out, 263.89378290154264), 527.7875658030853);
    // Generated from the component: Diesel_Gen3.Control.Exciter.DC4B.TF1
    X_UnInt32 _diesel_gen3_control_exciter_dc4b_tf1__i;
    _diesel_gen3_control_exciter_dc4b_tf1__a_sum = 0.0f;
    _diesel_gen3_control_exciter_dc4b_tf1__b_sum = 0.0f;
    _diesel_gen3_control_exciter_dc4b_tf1__delay_line_in = 0.0f;
    for (_diesel_gen3_control_exciter_dc4b_tf1__i = 0; _diesel_gen3_control_exciter_dc4b_tf1__i < 1; _diesel_gen3_control_exciter_dc4b_tf1__i++) {
        _diesel_gen3_control_exciter_dc4b_tf1__b_sum += _diesel_gen3_control_exciter_dc4b_tf1__b_coeff[_diesel_gen3_control_exciter_dc4b_tf1__i + 1] * _diesel_gen3_control_exciter_dc4b_tf1__states[_diesel_gen3_control_exciter_dc4b_tf1__i];
    }
    _diesel_gen3_control_exciter_dc4b_tf1__a_sum += _diesel_gen3_control_exciter_dc4b_tf1__states[0] * _diesel_gen3_control_exciter_dc4b_tf1__a_coeff[1];
    _diesel_gen3_control_exciter_dc4b_tf1__delay_line_in = _diesel_gen3_control_exciter_vt_to_vtpu__out - _diesel_gen3_control_exciter_dc4b_tf1__a_sum;
    _diesel_gen3_control_exciter_dc4b_tf1__b_sum += _diesel_gen3_control_exciter_dc4b_tf1__b_coeff[0] * _diesel_gen3_control_exciter_dc4b_tf1__delay_line_in;
    _diesel_gen3_control_exciter_dc4b_tf1__out = _diesel_gen3_control_exciter_dc4b_tf1__b_sum;
    // Generated from the component: Diesel_Gen3.Control.Exciter.Vt
    HIL_OutAO(0x4042, (float)_diesel_gen3_control_exciter_vt_to_vtpu__out);
    // Generated from the component: Diesel_Gen3.Control.Exciter.Product2
    _diesel_gen3_control_exciter_product2__out = (_diesel_gen3_control_unit_delay3__out * _diesel_gen3_control_exciter_to_pu__out * _diesel_gen3_control_exciter_one_ov_sqrt_3__out);
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.Product1
    _diesel_gen3_control_freq_setpoint_control_product1__out = (_diesel_gen3_control_freq_setpoint_control_w_droop__out * _diesel_gen3_control_freq_setpoint_control_p_3ph_to_pu__out);
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.Product3
    _diesel_gen3_control_freq_setpoint_control_product3__out = (_diesel_gen3_control_freq_setpoint_control_w_to_wpu__out * _diesel_gen3_control_freq_setpoint_control_p_droop__out * _diesel_gen3_control_freq_setpoint_control_p_3ph_to_pu__out);
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.Product1
    _diesel_gen3_control_governor_and_engine_product1__out = (_diesel_gen3_control_governor_and_engine_to_pu__out * _diesel_gen3_control_governor_and_engine_inner_w_droop__out);
    // Generated from the component: Diesel_Gen3.Control.pf Control.pf_m
    HIL_OutAO(0x404d, (float)_diesel_gen3_control_pf_control_norm_pf_meas__pf_norm);
    // Generated from the component: Diesel_Gen3.Control.pf Control.pf_r
    HIL_OutAO(0x404e, (float)_diesel_gen3_control_pf_control_norm_pf_ref__pf_norm);
    // Generated from the component: Diesel_Gen3.Control.Exciter.Vfpu_to_Vf
    _diesel_gen3_control_exciter_vfpu_to_vf__out = 15601.845495434256 * _diesel_gen3_control_exciter_product1__out;
    // Generated from the component: Diesel_Gen3.Control.Exciter.Rate Limit
    if (_diesel_gen3_control_exciter_rate_limit__first_step) {
        _diesel_gen3_control_exciter_rate_limit__out = _diesel_gen3_control_exciter_switch__out;
        _diesel_gen3_control_exciter_rate_limit__state = _diesel_gen3_control_exciter_switch__out;
    } else {
        _diesel_gen3_control_exciter_rate_limit__out = _diesel_gen3_control_exciter_switch__out;
        if (_diesel_gen3_control_exciter_switch__out - _diesel_gen3_control_exciter_rate_limit__state > 0.002)
            _diesel_gen3_control_exciter_rate_limit__out = _diesel_gen3_control_exciter_rate_limit__state + (0.002);
        if (_diesel_gen3_control_exciter_switch__out - _diesel_gen3_control_exciter_rate_limit__state < -0.002)
            _diesel_gen3_control_exciter_rate_limit__out = _diesel_gen3_control_exciter_rate_limit__state + (-0.002);
    }
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.PLL_Grid.PLL.Normalize.V_terminal
    _diesel_gen4_sync_check_plls_pll_grid_pll_normalize_v_terminal__d = _diesel_gen4_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__d;
    _diesel_gen4_sync_check_plls_pll_grid_pll_normalize_v_terminal__q = _diesel_gen4_sync_check_plls_pll_grid_pll_abc_dqz_alpha_beta_to_dq__q;
    _diesel_gen4_sync_check_plls_pll_grid_pll_normalize_v_terminal__t = (powf(_diesel_gen4_sync_check_plls_pll_grid_pll_normalize_v_terminal__d, 2.0) + powf(_diesel_gen4_sync_check_plls_pll_grid_pll_normalize_v_terminal__q, 2.0));
    _diesel_gen4_sync_check_plls_pll_grid_pll_normalize_v_terminal__t = sqrt(_diesel_gen4_sync_check_plls_pll_grid_pll_normalize_v_terminal__t);
    if (_diesel_gen4_sync_check_plls_pll_grid_pll_normalize_v_terminal__t < 0.1) {
        _diesel_gen4_sync_check_plls_pll_grid_pll_normalize_v_terminal__q_pu = _diesel_gen4_sync_check_plls_pll_grid_pll_normalize_v_terminal__q / 0.1;
    }
    else {
        _diesel_gen4_sync_check_plls_pll_grid_pll_normalize_v_terminal__q_pu = _diesel_gen4_sync_check_plls_pll_grid_pll_normalize_v_terminal__q / _diesel_gen4_sync_check_plls_pll_grid_pll_normalize_v_terminal__t;
    }
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.PLL_Grid.Term
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.PLL_Grid.Term1
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.PI.Limit1
    _diesel_gen4_measurements_3ph_pll_gen_pll_pi_limit1__out = MIN(MAX(_diesel_gen4_measurements_3ph_pll_gen_pll_pi_sum5__out, 263.89378290154264), 527.7875658030853);
    // Generated from the component: Diesel_Gen4.Control.Exciter.DC4B.TF1
    X_UnInt32 _diesel_gen4_control_exciter_dc4b_tf1__i;
    _diesel_gen4_control_exciter_dc4b_tf1__a_sum = 0.0f;
    _diesel_gen4_control_exciter_dc4b_tf1__b_sum = 0.0f;
    _diesel_gen4_control_exciter_dc4b_tf1__delay_line_in = 0.0f;
    for (_diesel_gen4_control_exciter_dc4b_tf1__i = 0; _diesel_gen4_control_exciter_dc4b_tf1__i < 1; _diesel_gen4_control_exciter_dc4b_tf1__i++) {
        _diesel_gen4_control_exciter_dc4b_tf1__b_sum += _diesel_gen4_control_exciter_dc4b_tf1__b_coeff[_diesel_gen4_control_exciter_dc4b_tf1__i + 1] * _diesel_gen4_control_exciter_dc4b_tf1__states[_diesel_gen4_control_exciter_dc4b_tf1__i];
    }
    _diesel_gen4_control_exciter_dc4b_tf1__a_sum += _diesel_gen4_control_exciter_dc4b_tf1__states[0] * _diesel_gen4_control_exciter_dc4b_tf1__a_coeff[1];
    _diesel_gen4_control_exciter_dc4b_tf1__delay_line_in = _diesel_gen4_control_exciter_vt_to_vtpu__out - _diesel_gen4_control_exciter_dc4b_tf1__a_sum;
    _diesel_gen4_control_exciter_dc4b_tf1__b_sum += _diesel_gen4_control_exciter_dc4b_tf1__b_coeff[0] * _diesel_gen4_control_exciter_dc4b_tf1__delay_line_in;
    _diesel_gen4_control_exciter_dc4b_tf1__out = _diesel_gen4_control_exciter_dc4b_tf1__b_sum;
    // Generated from the component: Diesel_Gen4.Control.Exciter.Vt
    HIL_OutAO(0x4062, (float)_diesel_gen4_control_exciter_vt_to_vtpu__out);
    // Generated from the component: Diesel_Gen4.Control.Exciter.Product2
    _diesel_gen4_control_exciter_product2__out = (_diesel_gen4_control_unit_delay3__out * _diesel_gen4_control_exciter_to_pu__out * _diesel_gen4_control_exciter_one_ov_sqrt_3__out);
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.Product1
    _diesel_gen4_control_freq_setpoint_control_product1__out = (_diesel_gen4_control_freq_setpoint_control_w_droop__out * _diesel_gen4_control_freq_setpoint_control_p_3ph_to_pu__out);
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.Product3
    _diesel_gen4_control_freq_setpoint_control_product3__out = (_diesel_gen4_control_freq_setpoint_control_w_to_wpu__out * _diesel_gen4_control_freq_setpoint_control_p_droop__out * _diesel_gen4_control_freq_setpoint_control_p_3ph_to_pu__out);
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.Product1
    _diesel_gen4_control_governor_and_engine_product1__out = (_diesel_gen4_control_governor_and_engine_to_pu__out * _diesel_gen4_control_governor_and_engine_inner_w_droop__out);
    // Generated from the component: Diesel_Gen4.Control.pf Control.pf_m
    HIL_OutAO(0x406d, (float)_diesel_gen4_control_pf_control_norm_pf_meas__pf_norm);
    // Generated from the component: Diesel_Gen4.Control.pf Control.pf_r
    HIL_OutAO(0x406e, (float)_diesel_gen4_control_pf_control_norm_pf_ref__pf_norm);
    // Generated from the component: Diesel_Gen4.Control.Exciter.Vfpu_to_Vf
    _diesel_gen4_control_exciter_vfpu_to_vf__out = 15601.845495434256 * _diesel_gen4_control_exciter_product1__out;
    // Generated from the component: Diesel_Gen4.Control.Exciter.Rate Limit
    if (_diesel_gen4_control_exciter_rate_limit__first_step) {
        _diesel_gen4_control_exciter_rate_limit__out = _diesel_gen4_control_exciter_switch__out;
        _diesel_gen4_control_exciter_rate_limit__state = _diesel_gen4_control_exciter_switch__out;
    } else {
        _diesel_gen4_control_exciter_rate_limit__out = _diesel_gen4_control_exciter_switch__out;
        if (_diesel_gen4_control_exciter_switch__out - _diesel_gen4_control_exciter_rate_limit__state > 0.002)
            _diesel_gen4_control_exciter_rate_limit__out = _diesel_gen4_control_exciter_rate_limit__state + (0.002);
        if (_diesel_gen4_control_exciter_switch__out - _diesel_gen4_control_exciter_rate_limit__state < -0.002)
            _diesel_gen4_control_exciter_rate_limit__out = _diesel_gen4_control_exciter_rate_limit__state + (-0.002);
    }
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.Sum5
    _diesel_gen1_control_freq_setpoint_control_sum5__out = _diesel_gen1_control_freq_setpoint_control_w_to_wpu__out + _diesel_gen1_control_freq_setpoint_control_product2__out;
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.DEGOV.Integrator.Kb
    _diesel_gen1_control_governor_and_engine_degov_integrator_kb__out = 1000.0 * _diesel_gen1_control_governor_and_engine_degov_integrator_sum6__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.Bus Split1
    _diesel_gen1_sync_check_bus_split1__out = _diesel_gen1_control_bus_join1__out[0];
    _diesel_gen1_sync_check_bus_split1__out1 = _diesel_gen1_control_bus_join1__out[1];
    _diesel_gen1_sync_check_bus_split1__out2 = _diesel_gen1_control_bus_join1__out[2];
    _diesel_gen1_sync_check_bus_split1__out3 = _diesel_gen1_control_bus_join1__out[3];
    _diesel_gen1_sync_check_bus_split1__out4 = _diesel_gen1_control_bus_join1__out[4];
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.w_ramp
    if (_diesel_gen1_control_freq_setpoint_control_w_ramp__first_step) {
        _diesel_gen1_control_freq_setpoint_control_w_ramp__out = _diesel_gen1_control_freq_setpoint_control_w_switch__out;
        _diesel_gen1_control_freq_setpoint_control_w_ramp__state = _diesel_gen1_control_freq_setpoint_control_w_switch__out;
    } else {
        _diesel_gen1_control_freq_setpoint_control_w_ramp__out = _diesel_gen1_control_freq_setpoint_control_w_switch__out;
        if (_diesel_gen1_control_freq_setpoint_control_w_switch__out - _diesel_gen1_control_freq_setpoint_control_w_ramp__state > 0.002)
            _diesel_gen1_control_freq_setpoint_control_w_ramp__out = _diesel_gen1_control_freq_setpoint_control_w_ramp__state + (0.002);
        if (_diesel_gen1_control_freq_setpoint_control_w_switch__out - _diesel_gen1_control_freq_setpoint_control_w_ramp__state < -0.002)
            _diesel_gen1_control_freq_setpoint_control_w_ramp__out = _diesel_gen1_control_freq_setpoint_control_w_ramp__state + (-0.002);
    }
    // Generated from the component: Diesel_Gen1.Control.Read_Control_mode.State
    _diesel_gen1_control_read_control_mode_state__P = _diesel_gen1_control_define_control_mode_control_mode__P_control;
    _diesel_gen1_control_read_control_mode_state__Q = _diesel_gen1_control_pf_control_logical_operator5__out;
    _diesel_gen1_control_read_control_mode_state__enable = _diesel_gen1_control_read_op_mode__enable;
    if (_diesel_gen1_control_read_control_mode_state__enable && _diesel_gen1_control_read_control_mode_state__P && _diesel_gen1_control_read_control_mode_state__Q) {
        _diesel_gen1_control_read_control_mode_state__Vf = 0;
        _diesel_gen1_control_read_control_mode_state__PV = 0;
        _diesel_gen1_control_read_control_mode_state__PQ = 1;
    }
    else {
        if (_diesel_gen1_control_read_control_mode_state__enable && _diesel_gen1_control_read_control_mode_state__P) {
            _diesel_gen1_control_read_control_mode_state__Vf = 0;
            _diesel_gen1_control_read_control_mode_state__PV = 1;
            _diesel_gen1_control_read_control_mode_state__PQ = 0;
        }
        else {
            _diesel_gen1_control_read_control_mode_state__Vf = 1;
            _diesel_gen1_control_read_control_mode_state__PV = 0;
            _diesel_gen1_control_read_control_mode_state__PQ = 0;
        }
    }
    // Generated from the component: Diesel_Gen1.Control.pf Control.PI.Integrator1
    if (((_diesel_gen1_control_pf_control_logical_operator5__out > 0.0) && (_diesel_gen1_control_pf_control_pi_integrator1__reset_state <= 0)) || ((_diesel_gen1_control_pf_control_logical_operator5__out <= 0.0) && (_diesel_gen1_control_pf_control_pi_integrator1__reset_state == 1))) {
        _diesel_gen1_control_pf_control_pi_integrator1__state = 0.0;
    }
    _diesel_gen1_control_pf_control_pi_integrator1__out = _diesel_gen1_control_pf_control_pi_integrator1__state;
    // Generated from the component: Diesel_Gen1.Control.pf Control.Signal switch2
    _diesel_gen1_control_pf_control_signal_switch2__out = (_diesel_gen1_control_pf_control_logical_operator5__out > 0.5f) ? _diesel_gen1_control_pf_control_norm_pf_ref__pf_norm : _diesel_gen1_control_pf_control_norm_pf_meas__pf_norm;
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.Sum5
    _diesel_gen2_control_freq_setpoint_control_sum5__out = _diesel_gen2_control_freq_setpoint_control_w_to_wpu__out + _diesel_gen2_control_freq_setpoint_control_product2__out;
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.DEGOV.Integrator.Kb
    _diesel_gen2_control_governor_and_engine_degov_integrator_kb__out = 1000.0 * _diesel_gen2_control_governor_and_engine_degov_integrator_sum6__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.Bus Split1
    _diesel_gen2_sync_check_bus_split1__out = _diesel_gen2_control_bus_join1__out[0];
    _diesel_gen2_sync_check_bus_split1__out1 = _diesel_gen2_control_bus_join1__out[1];
    _diesel_gen2_sync_check_bus_split1__out2 = _diesel_gen2_control_bus_join1__out[2];
    _diesel_gen2_sync_check_bus_split1__out3 = _diesel_gen2_control_bus_join1__out[3];
    _diesel_gen2_sync_check_bus_split1__out4 = _diesel_gen2_control_bus_join1__out[4];
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.w_ramp
    if (_diesel_gen2_control_freq_setpoint_control_w_ramp__first_step) {
        _diesel_gen2_control_freq_setpoint_control_w_ramp__out = _diesel_gen2_control_freq_setpoint_control_w_switch__out;
        _diesel_gen2_control_freq_setpoint_control_w_ramp__state = _diesel_gen2_control_freq_setpoint_control_w_switch__out;
    } else {
        _diesel_gen2_control_freq_setpoint_control_w_ramp__out = _diesel_gen2_control_freq_setpoint_control_w_switch__out;
        if (_diesel_gen2_control_freq_setpoint_control_w_switch__out - _diesel_gen2_control_freq_setpoint_control_w_ramp__state > 0.002)
            _diesel_gen2_control_freq_setpoint_control_w_ramp__out = _diesel_gen2_control_freq_setpoint_control_w_ramp__state + (0.002);
        if (_diesel_gen2_control_freq_setpoint_control_w_switch__out - _diesel_gen2_control_freq_setpoint_control_w_ramp__state < -0.002)
            _diesel_gen2_control_freq_setpoint_control_w_ramp__out = _diesel_gen2_control_freq_setpoint_control_w_ramp__state + (-0.002);
    }
    // Generated from the component: Diesel_Gen2.Control.Read_Control_mode.State
    _diesel_gen2_control_read_control_mode_state__P = _diesel_gen2_control_define_control_mode_control_mode__P_control;
    _diesel_gen2_control_read_control_mode_state__Q = _diesel_gen2_control_pf_control_logical_operator5__out;
    _diesel_gen2_control_read_control_mode_state__enable = _diesel_gen2_control_read_op_mode__enable;
    if (_diesel_gen2_control_read_control_mode_state__enable && _diesel_gen2_control_read_control_mode_state__P && _diesel_gen2_control_read_control_mode_state__Q) {
        _diesel_gen2_control_read_control_mode_state__Vf = 0;
        _diesel_gen2_control_read_control_mode_state__PV = 0;
        _diesel_gen2_control_read_control_mode_state__PQ = 1;
    }
    else {
        if (_diesel_gen2_control_read_control_mode_state__enable && _diesel_gen2_control_read_control_mode_state__P) {
            _diesel_gen2_control_read_control_mode_state__Vf = 0;
            _diesel_gen2_control_read_control_mode_state__PV = 1;
            _diesel_gen2_control_read_control_mode_state__PQ = 0;
        }
        else {
            _diesel_gen2_control_read_control_mode_state__Vf = 1;
            _diesel_gen2_control_read_control_mode_state__PV = 0;
            _diesel_gen2_control_read_control_mode_state__PQ = 0;
        }
    }
    // Generated from the component: Diesel_Gen2.Control.pf Control.PI.Integrator1
    if (((_diesel_gen2_control_pf_control_logical_operator5__out > 0.0) && (_diesel_gen2_control_pf_control_pi_integrator1__reset_state <= 0)) || ((_diesel_gen2_control_pf_control_logical_operator5__out <= 0.0) && (_diesel_gen2_control_pf_control_pi_integrator1__reset_state == 1))) {
        _diesel_gen2_control_pf_control_pi_integrator1__state = 0.0;
    }
    _diesel_gen2_control_pf_control_pi_integrator1__out = _diesel_gen2_control_pf_control_pi_integrator1__state;
    // Generated from the component: Diesel_Gen2.Control.pf Control.Signal switch2
    _diesel_gen2_control_pf_control_signal_switch2__out = (_diesel_gen2_control_pf_control_logical_operator5__out > 0.5f) ? _diesel_gen2_control_pf_control_norm_pf_ref__pf_norm : _diesel_gen2_control_pf_control_norm_pf_meas__pf_norm;
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.Sum5
    _diesel_gen4_control_freq_setpoint_control_sum5__out = _diesel_gen4_control_freq_setpoint_control_w_to_wpu__out + _diesel_gen4_control_freq_setpoint_control_product2__out;
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.DEGOV.Integrator.Kb
    _diesel_gen4_control_governor_and_engine_degov_integrator_kb__out = 1000.0 * _diesel_gen4_control_governor_and_engine_degov_integrator_sum6__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.Bus Split1
    _diesel_gen4_sync_check_bus_split1__out = _diesel_gen4_control_bus_join1__out[0];
    _diesel_gen4_sync_check_bus_split1__out1 = _diesel_gen4_control_bus_join1__out[1];
    _diesel_gen4_sync_check_bus_split1__out2 = _diesel_gen4_control_bus_join1__out[2];
    _diesel_gen4_sync_check_bus_split1__out3 = _diesel_gen4_control_bus_join1__out[3];
    _diesel_gen4_sync_check_bus_split1__out4 = _diesel_gen4_control_bus_join1__out[4];
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.w_ramp
    if (_diesel_gen4_control_freq_setpoint_control_w_ramp__first_step) {
        _diesel_gen4_control_freq_setpoint_control_w_ramp__out = _diesel_gen4_control_freq_setpoint_control_w_switch__out;
        _diesel_gen4_control_freq_setpoint_control_w_ramp__state = _diesel_gen4_control_freq_setpoint_control_w_switch__out;
    } else {
        _diesel_gen4_control_freq_setpoint_control_w_ramp__out = _diesel_gen4_control_freq_setpoint_control_w_switch__out;
        if (_diesel_gen4_control_freq_setpoint_control_w_switch__out - _diesel_gen4_control_freq_setpoint_control_w_ramp__state > 0.002)
            _diesel_gen4_control_freq_setpoint_control_w_ramp__out = _diesel_gen4_control_freq_setpoint_control_w_ramp__state + (0.002);
        if (_diesel_gen4_control_freq_setpoint_control_w_switch__out - _diesel_gen4_control_freq_setpoint_control_w_ramp__state < -0.002)
            _diesel_gen4_control_freq_setpoint_control_w_ramp__out = _diesel_gen4_control_freq_setpoint_control_w_ramp__state + (-0.002);
    }
    // Generated from the component: Diesel_Gen4.Control.Read_Control_mode.State
    _diesel_gen4_control_read_control_mode_state__P = _diesel_gen4_control_define_control_mode_control_mode__P_control;
    _diesel_gen4_control_read_control_mode_state__Q = _diesel_gen4_control_pf_control_logical_operator5__out;
    _diesel_gen4_control_read_control_mode_state__enable = _diesel_gen4_control_read_op_mode__enable;
    if (_diesel_gen4_control_read_control_mode_state__enable && _diesel_gen4_control_read_control_mode_state__P && _diesel_gen4_control_read_control_mode_state__Q) {
        _diesel_gen4_control_read_control_mode_state__Vf = 0;
        _diesel_gen4_control_read_control_mode_state__PV = 0;
        _diesel_gen4_control_read_control_mode_state__PQ = 1;
    }
    else {
        if (_diesel_gen4_control_read_control_mode_state__enable && _diesel_gen4_control_read_control_mode_state__P) {
            _diesel_gen4_control_read_control_mode_state__Vf = 0;
            _diesel_gen4_control_read_control_mode_state__PV = 1;
            _diesel_gen4_control_read_control_mode_state__PQ = 0;
        }
        else {
            _diesel_gen4_control_read_control_mode_state__Vf = 1;
            _diesel_gen4_control_read_control_mode_state__PV = 0;
            _diesel_gen4_control_read_control_mode_state__PQ = 0;
        }
    }
    // Generated from the component: Diesel_Gen4.Control.pf Control.PI.Integrator1
    if (((_diesel_gen4_control_pf_control_logical_operator5__out > 0.0) && (_diesel_gen4_control_pf_control_pi_integrator1__reset_state <= 0)) || ((_diesel_gen4_control_pf_control_logical_operator5__out <= 0.0) && (_diesel_gen4_control_pf_control_pi_integrator1__reset_state == 1))) {
        _diesel_gen4_control_pf_control_pi_integrator1__state = 0.0;
    }
    _diesel_gen4_control_pf_control_pi_integrator1__out = _diesel_gen4_control_pf_control_pi_integrator1__state;
    // Generated from the component: Diesel_Gen4.Control.pf Control.Signal switch2
    _diesel_gen4_control_pf_control_signal_switch2__out = (_diesel_gen4_control_pf_control_logical_operator5__out > 0.5f) ? _diesel_gen4_control_pf_control_norm_pf_ref__pf_norm : _diesel_gen4_control_pf_control_norm_pf_meas__pf_norm;
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.Sum5
    _diesel_gen3_control_freq_setpoint_control_sum5__out = _diesel_gen3_control_freq_setpoint_control_w_to_wpu__out + _diesel_gen3_control_freq_setpoint_control_product2__out;
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.DEGOV.Integrator.Kb
    _diesel_gen3_control_governor_and_engine_degov_integrator_kb__out = 1000.0 * _diesel_gen3_control_governor_and_engine_degov_integrator_sum6__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.Bus Split1
    _diesel_gen3_sync_check_bus_split1__out = _diesel_gen3_control_bus_join1__out[0];
    _diesel_gen3_sync_check_bus_split1__out1 = _diesel_gen3_control_bus_join1__out[1];
    _diesel_gen3_sync_check_bus_split1__out2 = _diesel_gen3_control_bus_join1__out[2];
    _diesel_gen3_sync_check_bus_split1__out3 = _diesel_gen3_control_bus_join1__out[3];
    _diesel_gen3_sync_check_bus_split1__out4 = _diesel_gen3_control_bus_join1__out[4];
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.w_ramp
    if (_diesel_gen3_control_freq_setpoint_control_w_ramp__first_step) {
        _diesel_gen3_control_freq_setpoint_control_w_ramp__out = _diesel_gen3_control_freq_setpoint_control_w_switch__out;
        _diesel_gen3_control_freq_setpoint_control_w_ramp__state = _diesel_gen3_control_freq_setpoint_control_w_switch__out;
    } else {
        _diesel_gen3_control_freq_setpoint_control_w_ramp__out = _diesel_gen3_control_freq_setpoint_control_w_switch__out;
        if (_diesel_gen3_control_freq_setpoint_control_w_switch__out - _diesel_gen3_control_freq_setpoint_control_w_ramp__state > 0.002)
            _diesel_gen3_control_freq_setpoint_control_w_ramp__out = _diesel_gen3_control_freq_setpoint_control_w_ramp__state + (0.002);
        if (_diesel_gen3_control_freq_setpoint_control_w_switch__out - _diesel_gen3_control_freq_setpoint_control_w_ramp__state < -0.002)
            _diesel_gen3_control_freq_setpoint_control_w_ramp__out = _diesel_gen3_control_freq_setpoint_control_w_ramp__state + (-0.002);
    }
    // Generated from the component: Diesel_Gen3.Control.Read_Control_mode.State
    _diesel_gen3_control_read_control_mode_state__P = _diesel_gen3_control_define_control_mode_control_mode__P_control;
    _diesel_gen3_control_read_control_mode_state__Q = _diesel_gen3_control_pf_control_logical_operator5__out;
    _diesel_gen3_control_read_control_mode_state__enable = _diesel_gen3_control_read_op_mode__enable;
    if (_diesel_gen3_control_read_control_mode_state__enable && _diesel_gen3_control_read_control_mode_state__P && _diesel_gen3_control_read_control_mode_state__Q) {
        _diesel_gen3_control_read_control_mode_state__Vf = 0;
        _diesel_gen3_control_read_control_mode_state__PV = 0;
        _diesel_gen3_control_read_control_mode_state__PQ = 1;
    }
    else {
        if (_diesel_gen3_control_read_control_mode_state__enable && _diesel_gen3_control_read_control_mode_state__P) {
            _diesel_gen3_control_read_control_mode_state__Vf = 0;
            _diesel_gen3_control_read_control_mode_state__PV = 1;
            _diesel_gen3_control_read_control_mode_state__PQ = 0;
        }
        else {
            _diesel_gen3_control_read_control_mode_state__Vf = 1;
            _diesel_gen3_control_read_control_mode_state__PV = 0;
            _diesel_gen3_control_read_control_mode_state__PQ = 0;
        }
    }
    // Generated from the component: Diesel_Gen3.Control.pf Control.PI.Integrator1
    if (((_diesel_gen3_control_pf_control_logical_operator5__out > 0.0) && (_diesel_gen3_control_pf_control_pi_integrator1__reset_state <= 0)) || ((_diesel_gen3_control_pf_control_logical_operator5__out <= 0.0) && (_diesel_gen3_control_pf_control_pi_integrator1__reset_state == 1))) {
        _diesel_gen3_control_pf_control_pi_integrator1__state = 0.0;
    }
    _diesel_gen3_control_pf_control_pi_integrator1__out = _diesel_gen3_control_pf_control_pi_integrator1__state;
    // Generated from the component: Diesel_Gen3.Control.pf Control.Signal switch2
    _diesel_gen3_control_pf_control_signal_switch2__out = (_diesel_gen3_control_pf_control_logical_operator5__out > 0.5f) ? _diesel_gen3_control_pf_control_norm_pf_ref__pf_norm : _diesel_gen3_control_pf_control_norm_pf_meas__pf_norm;
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.PLL_Grid.LPF_Vt
    X_UnInt32 _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__i;
    _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__a_sum = 0.0f;
    _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__b_sum = 0.0f;
    _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__delay_line_in = 0.0f;
    for (_diesel_gen1_sync_check_plls_pll_grid_lpf_vt__i = 0; _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__i < 1; _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__i++) {
        _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__b_sum += _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__b_coeff[_diesel_gen1_sync_check_plls_pll_grid_lpf_vt__i + 1] * _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__states[_diesel_gen1_sync_check_plls_pll_grid_lpf_vt__i];
    }
    _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__a_sum += _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__states[0] * _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__a_coeff[1];
    _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__delay_line_in = _diesel_gen1_sync_check_plls_pll_grid_pll_normalize_v_terminal__t - _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__a_sum;
    _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__b_sum += _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__b_coeff[0] * _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__delay_line_in;
    _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__out = _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__b_sum;
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.PLL_Grid.PLL.PI.Ki
    _diesel_gen1_sync_check_plls_pll_grid_pll_pi_ki__out = 3200.0 * _diesel_gen1_sync_check_plls_pll_grid_pll_normalize_v_terminal__q_pu;
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.PLL_Grid.PLL.PI.Kp
    _diesel_gen1_sync_check_plls_pll_grid_pll_pi_kp__out = 100.0 * _diesel_gen1_sync_check_plls_pll_grid_pll_normalize_v_terminal__q_pu;
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.PI.Sum6
    _diesel_gen1_measurements_3ph_pll_gen_pll_pi_sum6__out =  - _diesel_gen1_measurements_3ph_pll_gen_pll_pi_sum5__out + _diesel_gen1_measurements_3ph_pll_gen_pll_pi_limit1__out;
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.Rate Limiter1
    if (_diesel_gen1_measurements_3ph_pll_gen_pll_rate_limiter1__first_step) {
        _diesel_gen1_measurements_3ph_pll_gen_pll_rate_limiter1__out = _diesel_gen1_measurements_3ph_pll_gen_pll_pi_limit1__out;
        _diesel_gen1_measurements_3ph_pll_gen_pll_rate_limiter1__state = _diesel_gen1_measurements_3ph_pll_gen_pll_pi_limit1__out;
    } else {
        _diesel_gen1_measurements_3ph_pll_gen_pll_rate_limiter1__out = _diesel_gen1_measurements_3ph_pll_gen_pll_pi_limit1__out;
        if (_diesel_gen1_measurements_3ph_pll_gen_pll_pi_limit1__out - _diesel_gen1_measurements_3ph_pll_gen_pll_rate_limiter1__state > 0.015079644737231007)
            _diesel_gen1_measurements_3ph_pll_gen_pll_rate_limiter1__out = _diesel_gen1_measurements_3ph_pll_gen_pll_rate_limiter1__state + (0.015079644737231007);
        if (_diesel_gen1_measurements_3ph_pll_gen_pll_pi_limit1__out - _diesel_gen1_measurements_3ph_pll_gen_pll_rate_limiter1__state < -0.015079644737231007)
            _diesel_gen1_measurements_3ph_pll_gen_pll_rate_limiter1__out = _diesel_gen1_measurements_3ph_pll_gen_pll_rate_limiter1__state + (-0.015079644737231007);
    }
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.integrator
    _diesel_gen1_measurements_3ph_pll_gen_pll_integrator__in = _diesel_gen1_measurements_3ph_pll_gen_pll_pi_limit1__out;
    _diesel_gen1_measurements_3ph_pll_gen_pll_integrator__out += 0.0002 * _diesel_gen1_measurements_3ph_pll_gen_pll_integrator__in;
    if (_diesel_gen1_measurements_3ph_pll_gen_pll_integrator__in >= 0.0) {
        if (_diesel_gen1_measurements_3ph_pll_gen_pll_integrator__out >= 6.283185307179586) {
            _diesel_gen1_measurements_3ph_pll_gen_pll_integrator__out -= 6.283185307179586;
        }
    }
    else {
        if (_diesel_gen1_measurements_3ph_pll_gen_pll_integrator__out <= -6.283185307179586) {
            _diesel_gen1_measurements_3ph_pll_gen_pll_integrator__out += 6.283185307179586;
        }
    }
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.f_droop_switch
    _diesel_gen1_control_freq_setpoint_control_f_droop_switch__out = (_diesel_gen1_control_read_op_mode__enable > 0.5f) ? _diesel_gen1_control_freq_setpoint_control_product1__out : _diesel_gen1_control_freq_setpoint_control_zero1__out;
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.w_Pm
    HIL_OutAO(0x4004, (float)_diesel_gen1_control_freq_setpoint_control_product3__out);
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.w_switch1
    _diesel_gen1_control_governor_and_engine_w_switch1__out = (_diesel_gen1_control_unit_delay2__out > 0.5f) ? _diesel_gen1_control_governor_and_engine_product1__out : _diesel_gen1_control_governor_and_engine_zero__out;
    // Generated from the component: Diesel_Gen1.Control.Vf
    HIL_OutAO(0x400b, (float)_diesel_gen1_control_exciter_vfpu_to_vf__out);
    // Generated from the component: Diesel_Gen1.Vfd.Vs1
    HIL_OutFloat(137101312, (float) _diesel_gen1_control_exciter_vfpu_to_vf__out);
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.PLL_Grid.LPF_Vt
    X_UnInt32 _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__i;
    _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__a_sum = 0.0f;
    _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__b_sum = 0.0f;
    _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__delay_line_in = 0.0f;
    for (_diesel_gen2_sync_check_plls_pll_grid_lpf_vt__i = 0; _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__i < 1; _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__i++) {
        _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__b_sum += _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__b_coeff[_diesel_gen2_sync_check_plls_pll_grid_lpf_vt__i + 1] * _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__states[_diesel_gen2_sync_check_plls_pll_grid_lpf_vt__i];
    }
    _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__a_sum += _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__states[0] * _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__a_coeff[1];
    _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__delay_line_in = _diesel_gen2_sync_check_plls_pll_grid_pll_normalize_v_terminal__t - _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__a_sum;
    _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__b_sum += _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__b_coeff[0] * _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__delay_line_in;
    _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__out = _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__b_sum;
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.PLL_Grid.PLL.PI.Ki
    _diesel_gen2_sync_check_plls_pll_grid_pll_pi_ki__out = 3200.0 * _diesel_gen2_sync_check_plls_pll_grid_pll_normalize_v_terminal__q_pu;
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.PLL_Grid.PLL.PI.Kp
    _diesel_gen2_sync_check_plls_pll_grid_pll_pi_kp__out = 100.0 * _diesel_gen2_sync_check_plls_pll_grid_pll_normalize_v_terminal__q_pu;
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.PI.Sum6
    _diesel_gen2_measurements_3ph_pll_gen_pll_pi_sum6__out =  - _diesel_gen2_measurements_3ph_pll_gen_pll_pi_sum5__out + _diesel_gen2_measurements_3ph_pll_gen_pll_pi_limit1__out;
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.Rate Limiter1
    if (_diesel_gen2_measurements_3ph_pll_gen_pll_rate_limiter1__first_step) {
        _diesel_gen2_measurements_3ph_pll_gen_pll_rate_limiter1__out = _diesel_gen2_measurements_3ph_pll_gen_pll_pi_limit1__out;
        _diesel_gen2_measurements_3ph_pll_gen_pll_rate_limiter1__state = _diesel_gen2_measurements_3ph_pll_gen_pll_pi_limit1__out;
    } else {
        _diesel_gen2_measurements_3ph_pll_gen_pll_rate_limiter1__out = _diesel_gen2_measurements_3ph_pll_gen_pll_pi_limit1__out;
        if (_diesel_gen2_measurements_3ph_pll_gen_pll_pi_limit1__out - _diesel_gen2_measurements_3ph_pll_gen_pll_rate_limiter1__state > 0.015079644737231007)
            _diesel_gen2_measurements_3ph_pll_gen_pll_rate_limiter1__out = _diesel_gen2_measurements_3ph_pll_gen_pll_rate_limiter1__state + (0.015079644737231007);
        if (_diesel_gen2_measurements_3ph_pll_gen_pll_pi_limit1__out - _diesel_gen2_measurements_3ph_pll_gen_pll_rate_limiter1__state < -0.015079644737231007)
            _diesel_gen2_measurements_3ph_pll_gen_pll_rate_limiter1__out = _diesel_gen2_measurements_3ph_pll_gen_pll_rate_limiter1__state + (-0.015079644737231007);
    }
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.integrator
    _diesel_gen2_measurements_3ph_pll_gen_pll_integrator__in = _diesel_gen2_measurements_3ph_pll_gen_pll_pi_limit1__out;
    _diesel_gen2_measurements_3ph_pll_gen_pll_integrator__out += 0.0002 * _diesel_gen2_measurements_3ph_pll_gen_pll_integrator__in;
    if (_diesel_gen2_measurements_3ph_pll_gen_pll_integrator__in >= 0.0) {
        if (_diesel_gen2_measurements_3ph_pll_gen_pll_integrator__out >= 6.283185307179586) {
            _diesel_gen2_measurements_3ph_pll_gen_pll_integrator__out -= 6.283185307179586;
        }
    }
    else {
        if (_diesel_gen2_measurements_3ph_pll_gen_pll_integrator__out <= -6.283185307179586) {
            _diesel_gen2_measurements_3ph_pll_gen_pll_integrator__out += 6.283185307179586;
        }
    }
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.f_droop_switch
    _diesel_gen2_control_freq_setpoint_control_f_droop_switch__out = (_diesel_gen2_control_read_op_mode__enable > 0.5f) ? _diesel_gen2_control_freq_setpoint_control_product1__out : _diesel_gen2_control_freq_setpoint_control_zero1__out;
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.w_Pm
    HIL_OutAO(0x4024, (float)_diesel_gen2_control_freq_setpoint_control_product3__out);
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.w_switch1
    _diesel_gen2_control_governor_and_engine_w_switch1__out = (_diesel_gen2_control_unit_delay2__out > 0.5f) ? _diesel_gen2_control_governor_and_engine_product1__out : _diesel_gen2_control_governor_and_engine_zero__out;
    // Generated from the component: Diesel_Gen2.Control.Vf
    HIL_OutAO(0x402b, (float)_diesel_gen2_control_exciter_vfpu_to_vf__out);
    // Generated from the component: Diesel_Gen2.Vfd.Vs1
    HIL_OutFloat(137101313, (float) _diesel_gen2_control_exciter_vfpu_to_vf__out);
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.PLL_Grid.LPF_Vt
    X_UnInt32 _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__i;
    _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__a_sum = 0.0f;
    _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__b_sum = 0.0f;
    _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__delay_line_in = 0.0f;
    for (_diesel_gen3_sync_check_plls_pll_grid_lpf_vt__i = 0; _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__i < 1; _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__i++) {
        _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__b_sum += _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__b_coeff[_diesel_gen3_sync_check_plls_pll_grid_lpf_vt__i + 1] * _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__states[_diesel_gen3_sync_check_plls_pll_grid_lpf_vt__i];
    }
    _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__a_sum += _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__states[0] * _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__a_coeff[1];
    _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__delay_line_in = _diesel_gen3_sync_check_plls_pll_grid_pll_normalize_v_terminal__t - _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__a_sum;
    _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__b_sum += _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__b_coeff[0] * _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__delay_line_in;
    _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__out = _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__b_sum;
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.PLL_Grid.PLL.PI.Ki
    _diesel_gen3_sync_check_plls_pll_grid_pll_pi_ki__out = 3200.0 * _diesel_gen3_sync_check_plls_pll_grid_pll_normalize_v_terminal__q_pu;
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.PLL_Grid.PLL.PI.Kp
    _diesel_gen3_sync_check_plls_pll_grid_pll_pi_kp__out = 100.0 * _diesel_gen3_sync_check_plls_pll_grid_pll_normalize_v_terminal__q_pu;
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.PI.Sum6
    _diesel_gen3_measurements_3ph_pll_gen_pll_pi_sum6__out =  - _diesel_gen3_measurements_3ph_pll_gen_pll_pi_sum5__out + _diesel_gen3_measurements_3ph_pll_gen_pll_pi_limit1__out;
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.Rate Limiter1
    if (_diesel_gen3_measurements_3ph_pll_gen_pll_rate_limiter1__first_step) {
        _diesel_gen3_measurements_3ph_pll_gen_pll_rate_limiter1__out = _diesel_gen3_measurements_3ph_pll_gen_pll_pi_limit1__out;
        _diesel_gen3_measurements_3ph_pll_gen_pll_rate_limiter1__state = _diesel_gen3_measurements_3ph_pll_gen_pll_pi_limit1__out;
    } else {
        _diesel_gen3_measurements_3ph_pll_gen_pll_rate_limiter1__out = _diesel_gen3_measurements_3ph_pll_gen_pll_pi_limit1__out;
        if (_diesel_gen3_measurements_3ph_pll_gen_pll_pi_limit1__out - _diesel_gen3_measurements_3ph_pll_gen_pll_rate_limiter1__state > 0.015079644737231007)
            _diesel_gen3_measurements_3ph_pll_gen_pll_rate_limiter1__out = _diesel_gen3_measurements_3ph_pll_gen_pll_rate_limiter1__state + (0.015079644737231007);
        if (_diesel_gen3_measurements_3ph_pll_gen_pll_pi_limit1__out - _diesel_gen3_measurements_3ph_pll_gen_pll_rate_limiter1__state < -0.015079644737231007)
            _diesel_gen3_measurements_3ph_pll_gen_pll_rate_limiter1__out = _diesel_gen3_measurements_3ph_pll_gen_pll_rate_limiter1__state + (-0.015079644737231007);
    }
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.integrator
    _diesel_gen3_measurements_3ph_pll_gen_pll_integrator__in = _diesel_gen3_measurements_3ph_pll_gen_pll_pi_limit1__out;
    _diesel_gen3_measurements_3ph_pll_gen_pll_integrator__out += 0.0002 * _diesel_gen3_measurements_3ph_pll_gen_pll_integrator__in;
    if (_diesel_gen3_measurements_3ph_pll_gen_pll_integrator__in >= 0.0) {
        if (_diesel_gen3_measurements_3ph_pll_gen_pll_integrator__out >= 6.283185307179586) {
            _diesel_gen3_measurements_3ph_pll_gen_pll_integrator__out -= 6.283185307179586;
        }
    }
    else {
        if (_diesel_gen3_measurements_3ph_pll_gen_pll_integrator__out <= -6.283185307179586) {
            _diesel_gen3_measurements_3ph_pll_gen_pll_integrator__out += 6.283185307179586;
        }
    }
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.f_droop_switch
    _diesel_gen3_control_freq_setpoint_control_f_droop_switch__out = (_diesel_gen3_control_read_op_mode__enable > 0.5f) ? _diesel_gen3_control_freq_setpoint_control_product1__out : _diesel_gen3_control_freq_setpoint_control_zero1__out;
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.w_Pm
    HIL_OutAO(0x4044, (float)_diesel_gen3_control_freq_setpoint_control_product3__out);
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.w_switch1
    _diesel_gen3_control_governor_and_engine_w_switch1__out = (_diesel_gen3_control_unit_delay2__out > 0.5f) ? _diesel_gen3_control_governor_and_engine_product1__out : _diesel_gen3_control_governor_and_engine_zero__out;
    // Generated from the component: Diesel_Gen3.Control.Vf
    HIL_OutAO(0x404b, (float)_diesel_gen3_control_exciter_vfpu_to_vf__out);
    // Generated from the component: Diesel_Gen3.Vfd.Vs1
    HIL_OutFloat(137101314, (float) _diesel_gen3_control_exciter_vfpu_to_vf__out);
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.PLL_Grid.LPF_Vt
    X_UnInt32 _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__i;
    _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__a_sum = 0.0f;
    _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__b_sum = 0.0f;
    _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__delay_line_in = 0.0f;
    for (_diesel_gen4_sync_check_plls_pll_grid_lpf_vt__i = 0; _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__i < 1; _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__i++) {
        _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__b_sum += _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__b_coeff[_diesel_gen4_sync_check_plls_pll_grid_lpf_vt__i + 1] * _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__states[_diesel_gen4_sync_check_plls_pll_grid_lpf_vt__i];
    }
    _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__a_sum += _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__states[0] * _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__a_coeff[1];
    _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__delay_line_in = _diesel_gen4_sync_check_plls_pll_grid_pll_normalize_v_terminal__t - _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__a_sum;
    _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__b_sum += _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__b_coeff[0] * _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__delay_line_in;
    _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__out = _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__b_sum;
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.PLL_Grid.PLL.PI.Ki
    _diesel_gen4_sync_check_plls_pll_grid_pll_pi_ki__out = 3200.0 * _diesel_gen4_sync_check_plls_pll_grid_pll_normalize_v_terminal__q_pu;
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.PLL_Grid.PLL.PI.Kp
    _diesel_gen4_sync_check_plls_pll_grid_pll_pi_kp__out = 100.0 * _diesel_gen4_sync_check_plls_pll_grid_pll_normalize_v_terminal__q_pu;
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.PI.Sum6
    _diesel_gen4_measurements_3ph_pll_gen_pll_pi_sum6__out =  - _diesel_gen4_measurements_3ph_pll_gen_pll_pi_sum5__out + _diesel_gen4_measurements_3ph_pll_gen_pll_pi_limit1__out;
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.Rate Limiter1
    if (_diesel_gen4_measurements_3ph_pll_gen_pll_rate_limiter1__first_step) {
        _diesel_gen4_measurements_3ph_pll_gen_pll_rate_limiter1__out = _diesel_gen4_measurements_3ph_pll_gen_pll_pi_limit1__out;
        _diesel_gen4_measurements_3ph_pll_gen_pll_rate_limiter1__state = _diesel_gen4_measurements_3ph_pll_gen_pll_pi_limit1__out;
    } else {
        _diesel_gen4_measurements_3ph_pll_gen_pll_rate_limiter1__out = _diesel_gen4_measurements_3ph_pll_gen_pll_pi_limit1__out;
        if (_diesel_gen4_measurements_3ph_pll_gen_pll_pi_limit1__out - _diesel_gen4_measurements_3ph_pll_gen_pll_rate_limiter1__state > 0.015079644737231007)
            _diesel_gen4_measurements_3ph_pll_gen_pll_rate_limiter1__out = _diesel_gen4_measurements_3ph_pll_gen_pll_rate_limiter1__state + (0.015079644737231007);
        if (_diesel_gen4_measurements_3ph_pll_gen_pll_pi_limit1__out - _diesel_gen4_measurements_3ph_pll_gen_pll_rate_limiter1__state < -0.015079644737231007)
            _diesel_gen4_measurements_3ph_pll_gen_pll_rate_limiter1__out = _diesel_gen4_measurements_3ph_pll_gen_pll_rate_limiter1__state + (-0.015079644737231007);
    }
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.integrator
    _diesel_gen4_measurements_3ph_pll_gen_pll_integrator__in = _diesel_gen4_measurements_3ph_pll_gen_pll_pi_limit1__out;
    _diesel_gen4_measurements_3ph_pll_gen_pll_integrator__out += 0.0002 * _diesel_gen4_measurements_3ph_pll_gen_pll_integrator__in;
    if (_diesel_gen4_measurements_3ph_pll_gen_pll_integrator__in >= 0.0) {
        if (_diesel_gen4_measurements_3ph_pll_gen_pll_integrator__out >= 6.283185307179586) {
            _diesel_gen4_measurements_3ph_pll_gen_pll_integrator__out -= 6.283185307179586;
        }
    }
    else {
        if (_diesel_gen4_measurements_3ph_pll_gen_pll_integrator__out <= -6.283185307179586) {
            _diesel_gen4_measurements_3ph_pll_gen_pll_integrator__out += 6.283185307179586;
        }
    }
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.f_droop_switch
    _diesel_gen4_control_freq_setpoint_control_f_droop_switch__out = (_diesel_gen4_control_read_op_mode__enable > 0.5f) ? _diesel_gen4_control_freq_setpoint_control_product1__out : _diesel_gen4_control_freq_setpoint_control_zero1__out;
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.w_Pm
    HIL_OutAO(0x4064, (float)_diesel_gen4_control_freq_setpoint_control_product3__out);
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.w_switch1
    _diesel_gen4_control_governor_and_engine_w_switch1__out = (_diesel_gen4_control_unit_delay2__out > 0.5f) ? _diesel_gen4_control_governor_and_engine_product1__out : _diesel_gen4_control_governor_and_engine_zero__out;
    // Generated from the component: Diesel_Gen4.Control.Vf
    HIL_OutAO(0x406b, (float)_diesel_gen4_control_exciter_vfpu_to_vf__out);
    // Generated from the component: Diesel_Gen4.Vfd.Vs1
    HIL_OutFloat(137101315, (float) _diesel_gen4_control_exciter_vfpu_to_vf__out);
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.Sum6
    _diesel_gen1_control_freq_setpoint_control_sum6__out =  - _diesel_gen1_control_freq_setpoint_control_product3__out + _diesel_gen1_control_freq_setpoint_control_sum5__out;
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.w_Psp
    HIL_OutAO(0x4005, (float)_diesel_gen1_control_freq_setpoint_control_sum5__out);
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.DEGOV.Integrator.Sum7
    _diesel_gen1_control_governor_and_engine_degov_integrator_sum7__out = _diesel_gen1_control_governor_and_engine_degov_tf2__out + _diesel_gen1_control_governor_and_engine_degov_integrator_kb__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.Bus Join2
    _diesel_gen1_sync_check_bus_join2__out[0] = _diesel_gen1_sync_check_bus_split1__out1;
    _diesel_gen1_sync_check_bus_join2__out[1] = _diesel_gen1_sync_check_bus_split1__out2;
    _diesel_gen1_sync_check_bus_join2__out[2] = _diesel_gen1_sync_check_bus_split1__out3;
    // Generated from the component: Diesel_Gen1.Sync_Check.Contactor_Control.not
    _diesel_gen1_sync_check_contactor_control_not__out = !_diesel_gen1_sync_check_bus_split1__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.Speed_ss
    HIL_OutInt32(0xf0040c, _diesel_gen1_sync_check_bus_split1__out4 != 0x0);
    // Generated from the component: Diesel_Gen1.Sync_Check.and2
    _diesel_gen1_sync_check_and2__out = _diesel_gen1_sync_check_not__out && _diesel_gen1_sync_check_bus_split1__out && _diesel_gen1_sync_check_bus_split1__out3 && _diesel_gen1_sync_check_bus_split1__out4 && _diesel_gen1_sync_check_check_v_diff_and__out ;
    // Generated from the component: Diesel_Gen1.Control.Read_Control_mode.PQ_mode
    HIL_OutInt32(0xf00404, _diesel_gen1_control_read_control_mode_state__PQ != 0x0);
    // Generated from the component: Diesel_Gen1.Control.Read_Control_mode.PV_mode
    HIL_OutInt32(0xf00405, _diesel_gen1_control_read_control_mode_state__PV != 0x0);
    // Generated from the component: Diesel_Gen1.Control.Read_Control_mode.Vf_mode
    HIL_OutInt32(0xf00406, _diesel_gen1_control_read_control_mode_state__Vf != 0x0);
    // Generated from the component: Diesel_Gen1.Control.pf Control.Rate Limiter1
    if (_diesel_gen1_control_pf_control_rate_limiter1__first_step) {
        _diesel_gen1_control_pf_control_rate_limiter1__out = _diesel_gen1_control_pf_control_signal_switch2__out;
        _diesel_gen1_control_pf_control_rate_limiter1__state = _diesel_gen1_control_pf_control_signal_switch2__out;
    } else {
        _diesel_gen1_control_pf_control_rate_limiter1__out = _diesel_gen1_control_pf_control_signal_switch2__out;
        if (_diesel_gen1_control_pf_control_signal_switch2__out - _diesel_gen1_control_pf_control_rate_limiter1__state > 0.002)
            _diesel_gen1_control_pf_control_rate_limiter1__out = _diesel_gen1_control_pf_control_rate_limiter1__state + (0.002);
        if (_diesel_gen1_control_pf_control_signal_switch2__out - _diesel_gen1_control_pf_control_rate_limiter1__state < -0.002)
            _diesel_gen1_control_pf_control_rate_limiter1__out = _diesel_gen1_control_pf_control_rate_limiter1__state + (-0.002);
    }
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.Sum6
    _diesel_gen2_control_freq_setpoint_control_sum6__out =  - _diesel_gen2_control_freq_setpoint_control_product3__out + _diesel_gen2_control_freq_setpoint_control_sum5__out;
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.w_Psp
    HIL_OutAO(0x4025, (float)_diesel_gen2_control_freq_setpoint_control_sum5__out);
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.DEGOV.Integrator.Sum7
    _diesel_gen2_control_governor_and_engine_degov_integrator_sum7__out = _diesel_gen2_control_governor_and_engine_degov_tf2__out + _diesel_gen2_control_governor_and_engine_degov_integrator_kb__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.Bus Join2
    _diesel_gen2_sync_check_bus_join2__out[0] = _diesel_gen2_sync_check_bus_split1__out1;
    _diesel_gen2_sync_check_bus_join2__out[1] = _diesel_gen2_sync_check_bus_split1__out2;
    _diesel_gen2_sync_check_bus_join2__out[2] = _diesel_gen2_sync_check_bus_split1__out3;
    // Generated from the component: Diesel_Gen2.Sync_Check.Contactor_Control.not
    _diesel_gen2_sync_check_contactor_control_not__out = !_diesel_gen2_sync_check_bus_split1__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.Speed_ss
    HIL_OutInt32(0xf0041c, _diesel_gen2_sync_check_bus_split1__out4 != 0x0);
    // Generated from the component: Diesel_Gen2.Sync_Check.and2
    _diesel_gen2_sync_check_and2__out = _diesel_gen2_sync_check_not__out && _diesel_gen2_sync_check_bus_split1__out && _diesel_gen2_sync_check_bus_split1__out3 && _diesel_gen2_sync_check_bus_split1__out4 && _diesel_gen2_sync_check_check_v_diff_and__out ;
    // Generated from the component: Diesel_Gen2.Control.Read_Control_mode.PQ_mode
    HIL_OutInt32(0xf00414, _diesel_gen2_control_read_control_mode_state__PQ != 0x0);
    // Generated from the component: Diesel_Gen2.Control.Read_Control_mode.PV_mode
    HIL_OutInt32(0xf00415, _diesel_gen2_control_read_control_mode_state__PV != 0x0);
    // Generated from the component: Diesel_Gen2.Control.Read_Control_mode.Vf_mode
    HIL_OutInt32(0xf00416, _diesel_gen2_control_read_control_mode_state__Vf != 0x0);
    // Generated from the component: Diesel_Gen2.Control.pf Control.Rate Limiter1
    if (_diesel_gen2_control_pf_control_rate_limiter1__first_step) {
        _diesel_gen2_control_pf_control_rate_limiter1__out = _diesel_gen2_control_pf_control_signal_switch2__out;
        _diesel_gen2_control_pf_control_rate_limiter1__state = _diesel_gen2_control_pf_control_signal_switch2__out;
    } else {
        _diesel_gen2_control_pf_control_rate_limiter1__out = _diesel_gen2_control_pf_control_signal_switch2__out;
        if (_diesel_gen2_control_pf_control_signal_switch2__out - _diesel_gen2_control_pf_control_rate_limiter1__state > 0.002)
            _diesel_gen2_control_pf_control_rate_limiter1__out = _diesel_gen2_control_pf_control_rate_limiter1__state + (0.002);
        if (_diesel_gen2_control_pf_control_signal_switch2__out - _diesel_gen2_control_pf_control_rate_limiter1__state < -0.002)
            _diesel_gen2_control_pf_control_rate_limiter1__out = _diesel_gen2_control_pf_control_rate_limiter1__state + (-0.002);
    }
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.Sum6
    _diesel_gen4_control_freq_setpoint_control_sum6__out =  - _diesel_gen4_control_freq_setpoint_control_product3__out + _diesel_gen4_control_freq_setpoint_control_sum5__out;
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.w_Psp
    HIL_OutAO(0x4065, (float)_diesel_gen4_control_freq_setpoint_control_sum5__out);
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.DEGOV.Integrator.Sum7
    _diesel_gen4_control_governor_and_engine_degov_integrator_sum7__out = _diesel_gen4_control_governor_and_engine_degov_tf2__out + _diesel_gen4_control_governor_and_engine_degov_integrator_kb__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.Bus Join2
    _diesel_gen4_sync_check_bus_join2__out[0] = _diesel_gen4_sync_check_bus_split1__out1;
    _diesel_gen4_sync_check_bus_join2__out[1] = _diesel_gen4_sync_check_bus_split1__out2;
    _diesel_gen4_sync_check_bus_join2__out[2] = _diesel_gen4_sync_check_bus_split1__out3;
    // Generated from the component: Diesel_Gen4.Sync_Check.Contactor_Control.not
    _diesel_gen4_sync_check_contactor_control_not__out = !_diesel_gen4_sync_check_bus_split1__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.Speed_ss
    HIL_OutInt32(0xf0043c, _diesel_gen4_sync_check_bus_split1__out4 != 0x0);
    // Generated from the component: Diesel_Gen4.Sync_Check.and2
    _diesel_gen4_sync_check_and2__out = _diesel_gen4_sync_check_not__out && _diesel_gen4_sync_check_bus_split1__out && _diesel_gen4_sync_check_bus_split1__out3 && _diesel_gen4_sync_check_bus_split1__out4 && _diesel_gen4_sync_check_check_v_diff_and__out ;
    // Generated from the component: Diesel_Gen4.Control.Read_Control_mode.PQ_mode
    HIL_OutInt32(0xf00434, _diesel_gen4_control_read_control_mode_state__PQ != 0x0);
    // Generated from the component: Diesel_Gen4.Control.Read_Control_mode.PV_mode
    HIL_OutInt32(0xf00435, _diesel_gen4_control_read_control_mode_state__PV != 0x0);
    // Generated from the component: Diesel_Gen4.Control.Read_Control_mode.Vf_mode
    HIL_OutInt32(0xf00436, _diesel_gen4_control_read_control_mode_state__Vf != 0x0);
    // Generated from the component: Diesel_Gen4.Control.pf Control.Rate Limiter1
    if (_diesel_gen4_control_pf_control_rate_limiter1__first_step) {
        _diesel_gen4_control_pf_control_rate_limiter1__out = _diesel_gen4_control_pf_control_signal_switch2__out;
        _diesel_gen4_control_pf_control_rate_limiter1__state = _diesel_gen4_control_pf_control_signal_switch2__out;
    } else {
        _diesel_gen4_control_pf_control_rate_limiter1__out = _diesel_gen4_control_pf_control_signal_switch2__out;
        if (_diesel_gen4_control_pf_control_signal_switch2__out - _diesel_gen4_control_pf_control_rate_limiter1__state > 0.002)
            _diesel_gen4_control_pf_control_rate_limiter1__out = _diesel_gen4_control_pf_control_rate_limiter1__state + (0.002);
        if (_diesel_gen4_control_pf_control_signal_switch2__out - _diesel_gen4_control_pf_control_rate_limiter1__state < -0.002)
            _diesel_gen4_control_pf_control_rate_limiter1__out = _diesel_gen4_control_pf_control_rate_limiter1__state + (-0.002);
    }
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.Sum6
    _diesel_gen3_control_freq_setpoint_control_sum6__out =  - _diesel_gen3_control_freq_setpoint_control_product3__out + _diesel_gen3_control_freq_setpoint_control_sum5__out;
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.w_Psp
    HIL_OutAO(0x4045, (float)_diesel_gen3_control_freq_setpoint_control_sum5__out);
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.DEGOV.Integrator.Sum7
    _diesel_gen3_control_governor_and_engine_degov_integrator_sum7__out = _diesel_gen3_control_governor_and_engine_degov_tf2__out + _diesel_gen3_control_governor_and_engine_degov_integrator_kb__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.Bus Join2
    _diesel_gen3_sync_check_bus_join2__out[0] = _diesel_gen3_sync_check_bus_split1__out1;
    _diesel_gen3_sync_check_bus_join2__out[1] = _diesel_gen3_sync_check_bus_split1__out2;
    _diesel_gen3_sync_check_bus_join2__out[2] = _diesel_gen3_sync_check_bus_split1__out3;
    // Generated from the component: Diesel_Gen3.Sync_Check.Contactor_Control.not
    _diesel_gen3_sync_check_contactor_control_not__out = !_diesel_gen3_sync_check_bus_split1__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.Speed_ss
    HIL_OutInt32(0xf0042c, _diesel_gen3_sync_check_bus_split1__out4 != 0x0);
    // Generated from the component: Diesel_Gen3.Sync_Check.and2
    _diesel_gen3_sync_check_and2__out = _diesel_gen3_sync_check_not__out && _diesel_gen3_sync_check_bus_split1__out && _diesel_gen3_sync_check_bus_split1__out3 && _diesel_gen3_sync_check_bus_split1__out4 && _diesel_gen3_sync_check_check_v_diff_and__out ;
    // Generated from the component: Diesel_Gen3.Control.Read_Control_mode.PQ_mode
    HIL_OutInt32(0xf00424, _diesel_gen3_control_read_control_mode_state__PQ != 0x0);
    // Generated from the component: Diesel_Gen3.Control.Read_Control_mode.PV_mode
    HIL_OutInt32(0xf00425, _diesel_gen3_control_read_control_mode_state__PV != 0x0);
    // Generated from the component: Diesel_Gen3.Control.Read_Control_mode.Vf_mode
    HIL_OutInt32(0xf00426, _diesel_gen3_control_read_control_mode_state__Vf != 0x0);
    // Generated from the component: Diesel_Gen3.Control.pf Control.Rate Limiter1
    if (_diesel_gen3_control_pf_control_rate_limiter1__first_step) {
        _diesel_gen3_control_pf_control_rate_limiter1__out = _diesel_gen3_control_pf_control_signal_switch2__out;
        _diesel_gen3_control_pf_control_rate_limiter1__state = _diesel_gen3_control_pf_control_signal_switch2__out;
    } else {
        _diesel_gen3_control_pf_control_rate_limiter1__out = _diesel_gen3_control_pf_control_signal_switch2__out;
        if (_diesel_gen3_control_pf_control_signal_switch2__out - _diesel_gen3_control_pf_control_rate_limiter1__state > 0.002)
            _diesel_gen3_control_pf_control_rate_limiter1__out = _diesel_gen3_control_pf_control_rate_limiter1__state + (0.002);
        if (_diesel_gen3_control_pf_control_signal_switch2__out - _diesel_gen3_control_pf_control_rate_limiter1__state < -0.002)
            _diesel_gen3_control_pf_control_rate_limiter1__out = _diesel_gen3_control_pf_control_rate_limiter1__state + (-0.002);
    }
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.PLL_Grid.PLL.PI.Sum8
    _diesel_gen1_sync_check_plls_pll_grid_pll_pi_sum8__out = _diesel_gen1_sync_check_plls_pll_grid_pll_pi_kp__out + _diesel_gen1_sync_check_plls_pll_grid_pll_pi_integrator1__out;
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.PI.Kb
    _diesel_gen1_measurements_3ph_pll_gen_pll_pi_kb__out = 1.0 * _diesel_gen1_measurements_3ph_pll_gen_pll_pi_sum6__out;
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.LPF_q1
    X_UnInt32 _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__i;
    _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__a_sum = 0.0f;
    _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__b_sum = 0.0f;
    _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__delay_line_in = 0.0f;
    for (_diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__i = 0; _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__i < 2; _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__i++) {
        _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__b_sum += _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__b_coeff[_diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__i + 1] * _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__states[_diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__i];
    }
    for (_diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__i = 1; _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__i > 0; _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__i--) {
        _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__a_sum += _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__a_coeff[_diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__i + 1] * _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__states[_diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__i];
    }
    _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__a_sum += _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__states[0] * _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__a_coeff[1];
    _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__delay_line_in = _diesel_gen1_measurements_3ph_pll_gen_pll_rate_limiter1__out - _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__a_sum;
    _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__b_sum += _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__b_coeff[0] * _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__delay_line_in;
    _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__out = _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__b_sum;
    // Generated from the component: Diesel_Gen1.Measurements.Bus Join3
    _diesel_gen1_measurements_bus_join3__out[0] = _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__out;
    _diesel_gen1_measurements_bus_join3__out[1] = _diesel_gen1_measurements_3ph_pll_gen_pll_integrator__out;
    _diesel_gen1_measurements_bus_join3__out[2] = _diesel_gen1_measurements_3ph_pll_gen_pll_normalize_v_terminal__t;
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.Sum8
    _diesel_gen1_control_freq_setpoint_control_sum8__out =  - _diesel_gen1_control_freq_setpoint_control_f_droop_switch__out + _diesel_gen1_control_freq_setpoint_control_w_ramp__out;
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.Inner_droop_dw
    HIL_OutAO(0x4007, (float)_diesel_gen1_control_governor_and_engine_w_switch1__out);
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.PLL_Grid.PLL.PI.Sum8
    _diesel_gen2_sync_check_plls_pll_grid_pll_pi_sum8__out = _diesel_gen2_sync_check_plls_pll_grid_pll_pi_kp__out + _diesel_gen2_sync_check_plls_pll_grid_pll_pi_integrator1__out;
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.PI.Kb
    _diesel_gen2_measurements_3ph_pll_gen_pll_pi_kb__out = 1.0 * _diesel_gen2_measurements_3ph_pll_gen_pll_pi_sum6__out;
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.LPF_q1
    X_UnInt32 _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__i;
    _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__a_sum = 0.0f;
    _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__b_sum = 0.0f;
    _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__delay_line_in = 0.0f;
    for (_diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__i = 0; _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__i < 2; _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__i++) {
        _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__b_sum += _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__b_coeff[_diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__i + 1] * _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__states[_diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__i];
    }
    for (_diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__i = 1; _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__i > 0; _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__i--) {
        _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__a_sum += _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__a_coeff[_diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__i + 1] * _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__states[_diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__i];
    }
    _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__a_sum += _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__states[0] * _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__a_coeff[1];
    _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__delay_line_in = _diesel_gen2_measurements_3ph_pll_gen_pll_rate_limiter1__out - _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__a_sum;
    _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__b_sum += _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__b_coeff[0] * _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__delay_line_in;
    _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__out = _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__b_sum;
    // Generated from the component: Diesel_Gen2.Measurements.Bus Join3
    _diesel_gen2_measurements_bus_join3__out[0] = _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__out;
    _diesel_gen2_measurements_bus_join3__out[1] = _diesel_gen2_measurements_3ph_pll_gen_pll_integrator__out;
    _diesel_gen2_measurements_bus_join3__out[2] = _diesel_gen2_measurements_3ph_pll_gen_pll_normalize_v_terminal__t;
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.Sum8
    _diesel_gen2_control_freq_setpoint_control_sum8__out =  - _diesel_gen2_control_freq_setpoint_control_f_droop_switch__out + _diesel_gen2_control_freq_setpoint_control_w_ramp__out;
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.Inner_droop_dw
    HIL_OutAO(0x4027, (float)_diesel_gen2_control_governor_and_engine_w_switch1__out);
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.PLL_Grid.PLL.PI.Sum8
    _diesel_gen3_sync_check_plls_pll_grid_pll_pi_sum8__out = _diesel_gen3_sync_check_plls_pll_grid_pll_pi_kp__out + _diesel_gen3_sync_check_plls_pll_grid_pll_pi_integrator1__out;
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.PI.Kb
    _diesel_gen3_measurements_3ph_pll_gen_pll_pi_kb__out = 1.0 * _diesel_gen3_measurements_3ph_pll_gen_pll_pi_sum6__out;
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.LPF_q1
    X_UnInt32 _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__i;
    _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__a_sum = 0.0f;
    _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__b_sum = 0.0f;
    _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__delay_line_in = 0.0f;
    for (_diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__i = 0; _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__i < 2; _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__i++) {
        _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__b_sum += _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__b_coeff[_diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__i + 1] * _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__states[_diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__i];
    }
    for (_diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__i = 1; _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__i > 0; _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__i--) {
        _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__a_sum += _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__a_coeff[_diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__i + 1] * _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__states[_diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__i];
    }
    _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__a_sum += _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__states[0] * _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__a_coeff[1];
    _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__delay_line_in = _diesel_gen3_measurements_3ph_pll_gen_pll_rate_limiter1__out - _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__a_sum;
    _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__b_sum += _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__b_coeff[0] * _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__delay_line_in;
    _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__out = _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__b_sum;
    // Generated from the component: Diesel_Gen3.Measurements.Bus Join3
    _diesel_gen3_measurements_bus_join3__out[0] = _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__out;
    _diesel_gen3_measurements_bus_join3__out[1] = _diesel_gen3_measurements_3ph_pll_gen_pll_integrator__out;
    _diesel_gen3_measurements_bus_join3__out[2] = _diesel_gen3_measurements_3ph_pll_gen_pll_normalize_v_terminal__t;
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.Sum8
    _diesel_gen3_control_freq_setpoint_control_sum8__out =  - _diesel_gen3_control_freq_setpoint_control_f_droop_switch__out + _diesel_gen3_control_freq_setpoint_control_w_ramp__out;
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.Inner_droop_dw
    HIL_OutAO(0x4047, (float)_diesel_gen3_control_governor_and_engine_w_switch1__out);
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.PLL_Grid.PLL.PI.Sum8
    _diesel_gen4_sync_check_plls_pll_grid_pll_pi_sum8__out = _diesel_gen4_sync_check_plls_pll_grid_pll_pi_kp__out + _diesel_gen4_sync_check_plls_pll_grid_pll_pi_integrator1__out;
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.PI.Kb
    _diesel_gen4_measurements_3ph_pll_gen_pll_pi_kb__out = 1.0 * _diesel_gen4_measurements_3ph_pll_gen_pll_pi_sum6__out;
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.LPF_q1
    X_UnInt32 _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__i;
    _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__a_sum = 0.0f;
    _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__b_sum = 0.0f;
    _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__delay_line_in = 0.0f;
    for (_diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__i = 0; _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__i < 2; _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__i++) {
        _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__b_sum += _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__b_coeff[_diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__i + 1] * _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__states[_diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__i];
    }
    for (_diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__i = 1; _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__i > 0; _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__i--) {
        _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__a_sum += _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__a_coeff[_diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__i + 1] * _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__states[_diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__i];
    }
    _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__a_sum += _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__states[0] * _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__a_coeff[1];
    _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__delay_line_in = _diesel_gen4_measurements_3ph_pll_gen_pll_rate_limiter1__out - _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__a_sum;
    _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__b_sum += _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__b_coeff[0] * _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__delay_line_in;
    _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__out = _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__b_sum;
    // Generated from the component: Diesel_Gen4.Measurements.Bus Join3
    _diesel_gen4_measurements_bus_join3__out[0] = _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__out;
    _diesel_gen4_measurements_bus_join3__out[1] = _diesel_gen4_measurements_3ph_pll_gen_pll_integrator__out;
    _diesel_gen4_measurements_bus_join3__out[2] = _diesel_gen4_measurements_3ph_pll_gen_pll_normalize_v_terminal__t;
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.Sum8
    _diesel_gen4_control_freq_setpoint_control_sum8__out =  - _diesel_gen4_control_freq_setpoint_control_f_droop_switch__out + _diesel_gen4_control_freq_setpoint_control_w_ramp__out;
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.Inner_droop_dw
    HIL_OutAO(0x4067, (float)_diesel_gen4_control_governor_and_engine_w_switch1__out);
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.w_sp
    HIL_OutAO(0x4006, (float)_diesel_gen1_control_freq_setpoint_control_sum6__out);
    // Generated from the component: Diesel_Gen1.Sync_Check.Contactor_Control.Bus Split1
    _diesel_gen1_sync_check_contactor_control_bus_split1__out = _diesel_gen1_sync_check_bus_join2__out[0];
    _diesel_gen1_sync_check_contactor_control_bus_split1__out1 = _diesel_gen1_sync_check_bus_join2__out[1];
    _diesel_gen1_sync_check_contactor_control_bus_split1__out2 = _diesel_gen1_sync_check_bus_join2__out[2];
    // Generated from the component: Diesel_Gen1.Sync_Check.and1
    _diesel_gen1_sync_check_and1__out = _diesel_gen1_sync_check_check_f_diff_comparator1__out && _diesel_gen1_sync_check_and2__out ;
    // Generated from the component: Diesel_Gen1.Sync_Check.dw_synch_ON
    HIL_OutInt32(0xf0040e, _diesel_gen1_sync_check_and2__out != 0x0);
    // Generated from the component: Diesel_Gen1.Control.pf Control.Sum6
    _diesel_gen1_control_pf_control_sum6__out = _diesel_gen1_control_pf_control_rate_limiter1__out - _diesel_gen1_control_pf_control_norm_pf_meas__pf_norm;
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.w_sp
    HIL_OutAO(0x4026, (float)_diesel_gen2_control_freq_setpoint_control_sum6__out);
    // Generated from the component: Diesel_Gen2.Sync_Check.Contactor_Control.Bus Split1
    _diesel_gen2_sync_check_contactor_control_bus_split1__out = _diesel_gen2_sync_check_bus_join2__out[0];
    _diesel_gen2_sync_check_contactor_control_bus_split1__out1 = _diesel_gen2_sync_check_bus_join2__out[1];
    _diesel_gen2_sync_check_contactor_control_bus_split1__out2 = _diesel_gen2_sync_check_bus_join2__out[2];
    // Generated from the component: Diesel_Gen2.Sync_Check.and1
    _diesel_gen2_sync_check_and1__out = _diesel_gen2_sync_check_check_f_diff_comparator1__out && _diesel_gen2_sync_check_and2__out ;
    // Generated from the component: Diesel_Gen2.Sync_Check.dw_synch_ON
    HIL_OutInt32(0xf0041e, _diesel_gen2_sync_check_and2__out != 0x0);
    // Generated from the component: Diesel_Gen2.Control.pf Control.Sum6
    _diesel_gen2_control_pf_control_sum6__out = _diesel_gen2_control_pf_control_rate_limiter1__out - _diesel_gen2_control_pf_control_norm_pf_meas__pf_norm;
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.w_sp
    HIL_OutAO(0x4066, (float)_diesel_gen4_control_freq_setpoint_control_sum6__out);
    // Generated from the component: Diesel_Gen4.Sync_Check.Contactor_Control.Bus Split1
    _diesel_gen4_sync_check_contactor_control_bus_split1__out = _diesel_gen4_sync_check_bus_join2__out[0];
    _diesel_gen4_sync_check_contactor_control_bus_split1__out1 = _diesel_gen4_sync_check_bus_join2__out[1];
    _diesel_gen4_sync_check_contactor_control_bus_split1__out2 = _diesel_gen4_sync_check_bus_join2__out[2];
    // Generated from the component: Diesel_Gen4.Sync_Check.and1
    _diesel_gen4_sync_check_and1__out = _diesel_gen4_sync_check_check_f_diff_comparator1__out && _diesel_gen4_sync_check_and2__out ;
    // Generated from the component: Diesel_Gen4.Sync_Check.dw_synch_ON
    HIL_OutInt32(0xf0043e, _diesel_gen4_sync_check_and2__out != 0x0);
    // Generated from the component: Diesel_Gen4.Control.pf Control.Sum6
    _diesel_gen4_control_pf_control_sum6__out = _diesel_gen4_control_pf_control_rate_limiter1__out - _diesel_gen4_control_pf_control_norm_pf_meas__pf_norm;
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.w_sp
    HIL_OutAO(0x4046, (float)_diesel_gen3_control_freq_setpoint_control_sum6__out);
    // Generated from the component: Diesel_Gen3.Sync_Check.Contactor_Control.Bus Split1
    _diesel_gen3_sync_check_contactor_control_bus_split1__out = _diesel_gen3_sync_check_bus_join2__out[0];
    _diesel_gen3_sync_check_contactor_control_bus_split1__out1 = _diesel_gen3_sync_check_bus_join2__out[1];
    _diesel_gen3_sync_check_contactor_control_bus_split1__out2 = _diesel_gen3_sync_check_bus_join2__out[2];
    // Generated from the component: Diesel_Gen3.Sync_Check.and1
    _diesel_gen3_sync_check_and1__out = _diesel_gen3_sync_check_check_f_diff_comparator1__out && _diesel_gen3_sync_check_and2__out ;
    // Generated from the component: Diesel_Gen3.Sync_Check.dw_synch_ON
    HIL_OutInt32(0xf0042e, _diesel_gen3_sync_check_and2__out != 0x0);
    // Generated from the component: Diesel_Gen3.Control.pf Control.Sum6
    _diesel_gen3_control_pf_control_sum6__out = _diesel_gen3_control_pf_control_rate_limiter1__out - _diesel_gen3_control_pf_control_norm_pf_meas__pf_norm;
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.PLL_Grid.PLL.PI.Limit1
    _diesel_gen1_sync_check_plls_pll_grid_pll_pi_limit1__out = MIN(MAX(_diesel_gen1_sync_check_plls_pll_grid_pll_pi_sum8__out, 263.89378290154264), 527.7875658030853);
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.PI.Sum7
    _diesel_gen1_measurements_3ph_pll_gen_pll_pi_sum7__out = _diesel_gen1_measurements_3ph_pll_gen_pll_pi_ki__out + _diesel_gen1_measurements_3ph_pll_gen_pll_pi_kb__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.split1
    _diesel_gen1_sync_check_plls_split1__out = _diesel_gen1_measurements_bus_join3__out[0];
    _diesel_gen1_sync_check_plls_split1__out1 = _diesel_gen1_measurements_bus_join3__out[1];
    _diesel_gen1_sync_check_plls_split1__out2 = _diesel_gen1_measurements_bus_join3__out[2];
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.mode_switch
    _diesel_gen1_control_freq_setpoint_control_mode_switch__out = (_diesel_gen1_control_define_control_mode_control_mode__P_control > 0.5f) ? _diesel_gen1_control_freq_setpoint_control_sum6__out : _diesel_gen1_control_freq_setpoint_control_sum8__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.PLL_Grid.PLL.PI.Limit1
    _diesel_gen2_sync_check_plls_pll_grid_pll_pi_limit1__out = MIN(MAX(_diesel_gen2_sync_check_plls_pll_grid_pll_pi_sum8__out, 263.89378290154264), 527.7875658030853);
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.PI.Sum7
    _diesel_gen2_measurements_3ph_pll_gen_pll_pi_sum7__out = _diesel_gen2_measurements_3ph_pll_gen_pll_pi_ki__out + _diesel_gen2_measurements_3ph_pll_gen_pll_pi_kb__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.split1
    _diesel_gen2_sync_check_plls_split1__out = _diesel_gen2_measurements_bus_join3__out[0];
    _diesel_gen2_sync_check_plls_split1__out1 = _diesel_gen2_measurements_bus_join3__out[1];
    _diesel_gen2_sync_check_plls_split1__out2 = _diesel_gen2_measurements_bus_join3__out[2];
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.mode_switch
    _diesel_gen2_control_freq_setpoint_control_mode_switch__out = (_diesel_gen2_control_define_control_mode_control_mode__P_control > 0.5f) ? _diesel_gen2_control_freq_setpoint_control_sum6__out : _diesel_gen2_control_freq_setpoint_control_sum8__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.PLL_Grid.PLL.PI.Limit1
    _diesel_gen3_sync_check_plls_pll_grid_pll_pi_limit1__out = MIN(MAX(_diesel_gen3_sync_check_plls_pll_grid_pll_pi_sum8__out, 263.89378290154264), 527.7875658030853);
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.PI.Sum7
    _diesel_gen3_measurements_3ph_pll_gen_pll_pi_sum7__out = _diesel_gen3_measurements_3ph_pll_gen_pll_pi_ki__out + _diesel_gen3_measurements_3ph_pll_gen_pll_pi_kb__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.split1
    _diesel_gen3_sync_check_plls_split1__out = _diesel_gen3_measurements_bus_join3__out[0];
    _diesel_gen3_sync_check_plls_split1__out1 = _diesel_gen3_measurements_bus_join3__out[1];
    _diesel_gen3_sync_check_plls_split1__out2 = _diesel_gen3_measurements_bus_join3__out[2];
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.mode_switch
    _diesel_gen3_control_freq_setpoint_control_mode_switch__out = (_diesel_gen3_control_define_control_mode_control_mode__P_control > 0.5f) ? _diesel_gen3_control_freq_setpoint_control_sum6__out : _diesel_gen3_control_freq_setpoint_control_sum8__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.PLL_Grid.PLL.PI.Limit1
    _diesel_gen4_sync_check_plls_pll_grid_pll_pi_limit1__out = MIN(MAX(_diesel_gen4_sync_check_plls_pll_grid_pll_pi_sum8__out, 263.89378290154264), 527.7875658030853);
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.PI.Sum7
    _diesel_gen4_measurements_3ph_pll_gen_pll_pi_sum7__out = _diesel_gen4_measurements_3ph_pll_gen_pll_pi_ki__out + _diesel_gen4_measurements_3ph_pll_gen_pll_pi_kb__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.split1
    _diesel_gen4_sync_check_plls_split1__out = _diesel_gen4_measurements_bus_join3__out[0];
    _diesel_gen4_sync_check_plls_split1__out1 = _diesel_gen4_measurements_bus_join3__out[1];
    _diesel_gen4_sync_check_plls_split1__out2 = _diesel_gen4_measurements_bus_join3__out[2];
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.mode_switch
    _diesel_gen4_control_freq_setpoint_control_mode_switch__out = (_diesel_gen4_control_define_control_mode_control_mode__P_control > 0.5f) ? _diesel_gen4_control_freq_setpoint_control_sum6__out : _diesel_gen4_control_freq_setpoint_control_sum8__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.Contactor_Control.Edge Detection1.Relational operator1
    _diesel_gen1_sync_check_contactor_control_edge_detection1_relational_operator1__out = (_diesel_gen1_sync_check_contactor_control_bus_split1__out2 != _diesel_gen1_sync_check_contactor_control_edge_detection1_unit_delay1__out) ? 1 : 0;
    // Generated from the component: Diesel_Gen1.Sync_Check.Contactor_Control.or
    _diesel_gen1_sync_check_contactor_control_or__out = _diesel_gen1_sync_check_contactor_control_not__out || _diesel_gen1_sync_check_contactor_control_bus_split1__out ;
    // Generated from the component: Diesel_Gen1.Sync_Check.Check_phase_ON
    HIL_OutInt32(0xf00408, _diesel_gen1_sync_check_and1__out != 0x0);
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.PI.Integrator1
    if (((_diesel_gen1_sync_check_and1__out > 0.0) && (_diesel_gen1_sync_check_check_phase_diff_pi_integrator1__reset_state <= 0)) || ((_diesel_gen1_sync_check_and1__out <= 0.0) && (_diesel_gen1_sync_check_check_phase_diff_pi_integrator1__reset_state == 1))) {
        _diesel_gen1_sync_check_check_phase_diff_pi_integrator1__state = 0.0;
    }
    _diesel_gen1_sync_check_check_phase_diff_pi_integrator1__out = _diesel_gen1_sync_check_check_phase_diff_pi_integrator1__state;
    // Generated from the component: Diesel_Gen1.Control.pf Control.PI.Ki
    _diesel_gen1_control_pf_control_pi_ki__out = 0.075 * _diesel_gen1_control_pf_control_sum6__out;
    // Generated from the component: Diesel_Gen1.Control.pf Control.PI.Kp
    _diesel_gen1_control_pf_control_pi_kp__out = 0.05 * _diesel_gen1_control_pf_control_sum6__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.Contactor_Control.Edge Detection1.Relational operator1
    _diesel_gen2_sync_check_contactor_control_edge_detection1_relational_operator1__out = (_diesel_gen2_sync_check_contactor_control_bus_split1__out2 != _diesel_gen2_sync_check_contactor_control_edge_detection1_unit_delay1__out) ? 1 : 0;
    // Generated from the component: Diesel_Gen2.Sync_Check.Contactor_Control.or
    _diesel_gen2_sync_check_contactor_control_or__out = _diesel_gen2_sync_check_contactor_control_not__out || _diesel_gen2_sync_check_contactor_control_bus_split1__out ;
    // Generated from the component: Diesel_Gen2.Sync_Check.Check_phase_ON
    HIL_OutInt32(0xf00418, _diesel_gen2_sync_check_and1__out != 0x0);
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.PI.Integrator1
    if (((_diesel_gen2_sync_check_and1__out > 0.0) && (_diesel_gen2_sync_check_check_phase_diff_pi_integrator1__reset_state <= 0)) || ((_diesel_gen2_sync_check_and1__out <= 0.0) && (_diesel_gen2_sync_check_check_phase_diff_pi_integrator1__reset_state == 1))) {
        _diesel_gen2_sync_check_check_phase_diff_pi_integrator1__state = 0.0;
    }
    _diesel_gen2_sync_check_check_phase_diff_pi_integrator1__out = _diesel_gen2_sync_check_check_phase_diff_pi_integrator1__state;
    // Generated from the component: Diesel_Gen2.Control.pf Control.PI.Ki
    _diesel_gen2_control_pf_control_pi_ki__out = 0.075 * _diesel_gen2_control_pf_control_sum6__out;
    // Generated from the component: Diesel_Gen2.Control.pf Control.PI.Kp
    _diesel_gen2_control_pf_control_pi_kp__out = 0.05 * _diesel_gen2_control_pf_control_sum6__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.Contactor_Control.Edge Detection1.Relational operator1
    _diesel_gen4_sync_check_contactor_control_edge_detection1_relational_operator1__out = (_diesel_gen4_sync_check_contactor_control_bus_split1__out2 != _diesel_gen4_sync_check_contactor_control_edge_detection1_unit_delay1__out) ? 1 : 0;
    // Generated from the component: Diesel_Gen4.Sync_Check.Contactor_Control.or
    _diesel_gen4_sync_check_contactor_control_or__out = _diesel_gen4_sync_check_contactor_control_not__out || _diesel_gen4_sync_check_contactor_control_bus_split1__out ;
    // Generated from the component: Diesel_Gen4.Sync_Check.Check_phase_ON
    HIL_OutInt32(0xf00438, _diesel_gen4_sync_check_and1__out != 0x0);
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.PI.Integrator1
    if (((_diesel_gen4_sync_check_and1__out > 0.0) && (_diesel_gen4_sync_check_check_phase_diff_pi_integrator1__reset_state <= 0)) || ((_diesel_gen4_sync_check_and1__out <= 0.0) && (_diesel_gen4_sync_check_check_phase_diff_pi_integrator1__reset_state == 1))) {
        _diesel_gen4_sync_check_check_phase_diff_pi_integrator1__state = 0.0;
    }
    _diesel_gen4_sync_check_check_phase_diff_pi_integrator1__out = _diesel_gen4_sync_check_check_phase_diff_pi_integrator1__state;
    // Generated from the component: Diesel_Gen4.Control.pf Control.PI.Ki
    _diesel_gen4_control_pf_control_pi_ki__out = 0.075 * _diesel_gen4_control_pf_control_sum6__out;
    // Generated from the component: Diesel_Gen4.Control.pf Control.PI.Kp
    _diesel_gen4_control_pf_control_pi_kp__out = 0.05 * _diesel_gen4_control_pf_control_sum6__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.Contactor_Control.Edge Detection1.Relational operator1
    _diesel_gen3_sync_check_contactor_control_edge_detection1_relational_operator1__out = (_diesel_gen3_sync_check_contactor_control_bus_split1__out2 != _diesel_gen3_sync_check_contactor_control_edge_detection1_unit_delay1__out) ? 1 : 0;
    // Generated from the component: Diesel_Gen3.Sync_Check.Contactor_Control.or
    _diesel_gen3_sync_check_contactor_control_or__out = _diesel_gen3_sync_check_contactor_control_not__out || _diesel_gen3_sync_check_contactor_control_bus_split1__out ;
    // Generated from the component: Diesel_Gen3.Sync_Check.Check_phase_ON
    HIL_OutInt32(0xf00428, _diesel_gen3_sync_check_and1__out != 0x0);
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.PI.Integrator1
    if (((_diesel_gen3_sync_check_and1__out > 0.0) && (_diesel_gen3_sync_check_check_phase_diff_pi_integrator1__reset_state <= 0)) || ((_diesel_gen3_sync_check_and1__out <= 0.0) && (_diesel_gen3_sync_check_check_phase_diff_pi_integrator1__reset_state == 1))) {
        _diesel_gen3_sync_check_check_phase_diff_pi_integrator1__state = 0.0;
    }
    _diesel_gen3_sync_check_check_phase_diff_pi_integrator1__out = _diesel_gen3_sync_check_check_phase_diff_pi_integrator1__state;
    // Generated from the component: Diesel_Gen3.Control.pf Control.PI.Ki
    _diesel_gen3_control_pf_control_pi_ki__out = 0.075 * _diesel_gen3_control_pf_control_sum6__out;
    // Generated from the component: Diesel_Gen3.Control.pf Control.PI.Kp
    _diesel_gen3_control_pf_control_pi_kp__out = 0.05 * _diesel_gen3_control_pf_control_sum6__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.PLL_Grid.PLL.PI.Sum6
    _diesel_gen1_sync_check_plls_pll_grid_pll_pi_sum6__out =  - _diesel_gen1_sync_check_plls_pll_grid_pll_pi_sum8__out + _diesel_gen1_sync_check_plls_pll_grid_pll_pi_limit1__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.PLL_Grid.PLL.integrator
    _diesel_gen1_sync_check_plls_pll_grid_pll_integrator__in = _diesel_gen1_sync_check_plls_pll_grid_pll_pi_limit1__out;
    _diesel_gen1_sync_check_plls_pll_grid_pll_integrator__output = _diesel_gen1_sync_check_plls_pll_grid_pll_integrator__out + 0.0;
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.PLL_Grid.PLL.rads_to_Hz
    _diesel_gen1_sync_check_plls_pll_grid_pll_rads_to_hz__out = 0.15915494309189535 * _diesel_gen1_sync_check_plls_pll_grid_pll_pi_limit1__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.Gain1
    _diesel_gen1_sync_check_plls_gain1__out = 0.15915494309189535 * _diesel_gen1_sync_check_plls_split1__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.V_gen
    HIL_OutAO(0x4014, (float)_diesel_gen1_sync_check_plls_split1__out2);
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.wt_gen
    HIL_OutAO(0x4016, (float)_diesel_gen1_sync_check_plls_split1__out1);
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.Sum1
    _diesel_gen1_sync_check_check_v_diff_sum1__out = _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__out - _diesel_gen1_sync_check_plls_split1__out2;
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.Sum7
    _diesel_gen1_control_freq_setpoint_control_sum7__out = _diesel_gen1_control_freq_setpoint_control_load_share_switch__out + _diesel_gen1_control_freq_setpoint_control_mode_switch__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.PLL_Grid.PLL.PI.Sum6
    _diesel_gen2_sync_check_plls_pll_grid_pll_pi_sum6__out =  - _diesel_gen2_sync_check_plls_pll_grid_pll_pi_sum8__out + _diesel_gen2_sync_check_plls_pll_grid_pll_pi_limit1__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.PLL_Grid.PLL.integrator
    _diesel_gen2_sync_check_plls_pll_grid_pll_integrator__in = _diesel_gen2_sync_check_plls_pll_grid_pll_pi_limit1__out;
    _diesel_gen2_sync_check_plls_pll_grid_pll_integrator__output = _diesel_gen2_sync_check_plls_pll_grid_pll_integrator__out + 0.0;
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.PLL_Grid.PLL.rads_to_Hz
    _diesel_gen2_sync_check_plls_pll_grid_pll_rads_to_hz__out = 0.15915494309189535 * _diesel_gen2_sync_check_plls_pll_grid_pll_pi_limit1__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.Gain1
    _diesel_gen2_sync_check_plls_gain1__out = 0.15915494309189535 * _diesel_gen2_sync_check_plls_split1__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.V_gen
    HIL_OutAO(0x4034, (float)_diesel_gen2_sync_check_plls_split1__out2);
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.wt_gen
    HIL_OutAO(0x4036, (float)_diesel_gen2_sync_check_plls_split1__out1);
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.Sum1
    _diesel_gen2_sync_check_check_v_diff_sum1__out = _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__out - _diesel_gen2_sync_check_plls_split1__out2;
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.Sum7
    _diesel_gen2_control_freq_setpoint_control_sum7__out = _diesel_gen2_control_freq_setpoint_control_load_share_switch__out + _diesel_gen2_control_freq_setpoint_control_mode_switch__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.PLL_Grid.PLL.PI.Sum6
    _diesel_gen3_sync_check_plls_pll_grid_pll_pi_sum6__out =  - _diesel_gen3_sync_check_plls_pll_grid_pll_pi_sum8__out + _diesel_gen3_sync_check_plls_pll_grid_pll_pi_limit1__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.PLL_Grid.PLL.integrator
    _diesel_gen3_sync_check_plls_pll_grid_pll_integrator__in = _diesel_gen3_sync_check_plls_pll_grid_pll_pi_limit1__out;
    _diesel_gen3_sync_check_plls_pll_grid_pll_integrator__output = _diesel_gen3_sync_check_plls_pll_grid_pll_integrator__out + 0.0;
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.PLL_Grid.PLL.rads_to_Hz
    _diesel_gen3_sync_check_plls_pll_grid_pll_rads_to_hz__out = 0.15915494309189535 * _diesel_gen3_sync_check_plls_pll_grid_pll_pi_limit1__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.Gain1
    _diesel_gen3_sync_check_plls_gain1__out = 0.15915494309189535 * _diesel_gen3_sync_check_plls_split1__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.V_gen
    HIL_OutAO(0x4054, (float)_diesel_gen3_sync_check_plls_split1__out2);
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.wt_gen
    HIL_OutAO(0x4056, (float)_diesel_gen3_sync_check_plls_split1__out1);
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.Sum1
    _diesel_gen3_sync_check_check_v_diff_sum1__out = _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__out - _diesel_gen3_sync_check_plls_split1__out2;
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.Sum7
    _diesel_gen3_control_freq_setpoint_control_sum7__out = _diesel_gen3_control_freq_setpoint_control_load_share_switch__out + _diesel_gen3_control_freq_setpoint_control_mode_switch__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.PLL_Grid.PLL.PI.Sum6
    _diesel_gen4_sync_check_plls_pll_grid_pll_pi_sum6__out =  - _diesel_gen4_sync_check_plls_pll_grid_pll_pi_sum8__out + _diesel_gen4_sync_check_plls_pll_grid_pll_pi_limit1__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.PLL_Grid.PLL.integrator
    _diesel_gen4_sync_check_plls_pll_grid_pll_integrator__in = _diesel_gen4_sync_check_plls_pll_grid_pll_pi_limit1__out;
    _diesel_gen4_sync_check_plls_pll_grid_pll_integrator__output = _diesel_gen4_sync_check_plls_pll_grid_pll_integrator__out + 0.0;
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.PLL_Grid.PLL.rads_to_Hz
    _diesel_gen4_sync_check_plls_pll_grid_pll_rads_to_hz__out = 0.15915494309189535 * _diesel_gen4_sync_check_plls_pll_grid_pll_pi_limit1__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.Gain1
    _diesel_gen4_sync_check_plls_gain1__out = 0.15915494309189535 * _diesel_gen4_sync_check_plls_split1__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.V_gen
    HIL_OutAO(0x4074, (float)_diesel_gen4_sync_check_plls_split1__out2);
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.wt_gen
    HIL_OutAO(0x4076, (float)_diesel_gen4_sync_check_plls_split1__out1);
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.Sum1
    _diesel_gen4_sync_check_check_v_diff_sum1__out = _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__out - _diesel_gen4_sync_check_plls_split1__out2;
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.Sum7
    _diesel_gen4_control_freq_setpoint_control_sum7__out = _diesel_gen4_control_freq_setpoint_control_load_share_switch__out + _diesel_gen4_control_freq_setpoint_control_mode_switch__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.Contactor_Control.wait_to_trip
    _diesel_gen1_sync_check_contactor_control_wait_to_trip__Reset = _diesel_gen1_sync_check_contactor_control_edge_detection1_relational_operator1__out;
    _diesel_gen1_sync_check_contactor_control_wait_to_trip__boolean = _diesel_gen1_sync_check_contactor_control_bus_split1__out2;
    if (_diesel_gen1_sync_check_contactor_control_wait_to_trip__time_acc >= 3.0) {
        _diesel_gen1_sync_check_contactor_control_wait_to_trip__Trip = 1;
    }
    else {
        _diesel_gen1_sync_check_contactor_control_wait_to_trip__time_acc += 0.0002 * _diesel_gen1_sync_check_contactor_control_wait_to_trip__boolean;
    }
    if (_diesel_gen1_sync_check_contactor_control_wait_to_trip__Reset == 1) {
        _diesel_gen1_sync_check_contactor_control_wait_to_trip__time_acc = 0;
        _diesel_gen1_sync_check_contactor_control_wait_to_trip__Trip = 0;
    }
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.PI.Sum5
    _diesel_gen1_sync_check_check_phase_diff_pi_sum5__out = _diesel_gen1_sync_check_check_phase_diff_pi_kp__out + _diesel_gen1_sync_check_check_phase_diff_pi_integrator1__out;
    // Generated from the component: Diesel_Gen1.Control.pf Control.PI.Sum5
    _diesel_gen1_control_pf_control_pi_sum5__out = _diesel_gen1_control_pf_control_pi_kp__out + _diesel_gen1_control_pf_control_pi_integrator1__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.Contactor_Control.wait_to_trip
    _diesel_gen2_sync_check_contactor_control_wait_to_trip__Reset = _diesel_gen2_sync_check_contactor_control_edge_detection1_relational_operator1__out;
    _diesel_gen2_sync_check_contactor_control_wait_to_trip__boolean = _diesel_gen2_sync_check_contactor_control_bus_split1__out2;
    if (_diesel_gen2_sync_check_contactor_control_wait_to_trip__time_acc >= 3.0) {
        _diesel_gen2_sync_check_contactor_control_wait_to_trip__Trip = 1;
    }
    else {
        _diesel_gen2_sync_check_contactor_control_wait_to_trip__time_acc += 0.0002 * _diesel_gen2_sync_check_contactor_control_wait_to_trip__boolean;
    }
    if (_diesel_gen2_sync_check_contactor_control_wait_to_trip__Reset == 1) {
        _diesel_gen2_sync_check_contactor_control_wait_to_trip__time_acc = 0;
        _diesel_gen2_sync_check_contactor_control_wait_to_trip__Trip = 0;
    }
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.PI.Sum5
    _diesel_gen2_sync_check_check_phase_diff_pi_sum5__out = _diesel_gen2_sync_check_check_phase_diff_pi_kp__out + _diesel_gen2_sync_check_check_phase_diff_pi_integrator1__out;
    // Generated from the component: Diesel_Gen2.Control.pf Control.PI.Sum5
    _diesel_gen2_control_pf_control_pi_sum5__out = _diesel_gen2_control_pf_control_pi_kp__out + _diesel_gen2_control_pf_control_pi_integrator1__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.Contactor_Control.wait_to_trip
    _diesel_gen4_sync_check_contactor_control_wait_to_trip__Reset = _diesel_gen4_sync_check_contactor_control_edge_detection1_relational_operator1__out;
    _diesel_gen4_sync_check_contactor_control_wait_to_trip__boolean = _diesel_gen4_sync_check_contactor_control_bus_split1__out2;
    if (_diesel_gen4_sync_check_contactor_control_wait_to_trip__time_acc >= 3.0) {
        _diesel_gen4_sync_check_contactor_control_wait_to_trip__Trip = 1;
    }
    else {
        _diesel_gen4_sync_check_contactor_control_wait_to_trip__time_acc += 0.0002 * _diesel_gen4_sync_check_contactor_control_wait_to_trip__boolean;
    }
    if (_diesel_gen4_sync_check_contactor_control_wait_to_trip__Reset == 1) {
        _diesel_gen4_sync_check_contactor_control_wait_to_trip__time_acc = 0;
        _diesel_gen4_sync_check_contactor_control_wait_to_trip__Trip = 0;
    }
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.PI.Sum5
    _diesel_gen4_sync_check_check_phase_diff_pi_sum5__out = _diesel_gen4_sync_check_check_phase_diff_pi_kp__out + _diesel_gen4_sync_check_check_phase_diff_pi_integrator1__out;
    // Generated from the component: Diesel_Gen4.Control.pf Control.PI.Sum5
    _diesel_gen4_control_pf_control_pi_sum5__out = _diesel_gen4_control_pf_control_pi_kp__out + _diesel_gen4_control_pf_control_pi_integrator1__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.Contactor_Control.wait_to_trip
    _diesel_gen3_sync_check_contactor_control_wait_to_trip__Reset = _diesel_gen3_sync_check_contactor_control_edge_detection1_relational_operator1__out;
    _diesel_gen3_sync_check_contactor_control_wait_to_trip__boolean = _diesel_gen3_sync_check_contactor_control_bus_split1__out2;
    if (_diesel_gen3_sync_check_contactor_control_wait_to_trip__time_acc >= 3.0) {
        _diesel_gen3_sync_check_contactor_control_wait_to_trip__Trip = 1;
    }
    else {
        _diesel_gen3_sync_check_contactor_control_wait_to_trip__time_acc += 0.0002 * _diesel_gen3_sync_check_contactor_control_wait_to_trip__boolean;
    }
    if (_diesel_gen3_sync_check_contactor_control_wait_to_trip__Reset == 1) {
        _diesel_gen3_sync_check_contactor_control_wait_to_trip__time_acc = 0;
        _diesel_gen3_sync_check_contactor_control_wait_to_trip__Trip = 0;
    }
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.PI.Sum5
    _diesel_gen3_sync_check_check_phase_diff_pi_sum5__out = _diesel_gen3_sync_check_check_phase_diff_pi_kp__out + _diesel_gen3_sync_check_check_phase_diff_pi_integrator1__out;
    // Generated from the component: Diesel_Gen3.Control.pf Control.PI.Sum5
    _diesel_gen3_control_pf_control_pi_sum5__out = _diesel_gen3_control_pf_control_pi_kp__out + _diesel_gen3_control_pf_control_pi_integrator1__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.PLL_Grid.PLL.PI.Kb
    _diesel_gen1_sync_check_plls_pll_grid_pll_pi_kb__out = 1000.0 * _diesel_gen1_sync_check_plls_pll_grid_pll_pi_sum6__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.Sum1
    _diesel_gen1_sync_check_plls_sum1__out = _diesel_gen1_sync_check_plls_pll_grid_pll_integrator__output - _diesel_gen1_sync_check_plls_split1__out1;
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.wt_grid
    HIL_OutAO(0x4017, (float)_diesel_gen1_sync_check_plls_pll_grid_pll_integrator__output);
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.PLL_Grid.LPF_f
    X_UnInt32 _diesel_gen1_sync_check_plls_pll_grid_lpf_f__i;
    _diesel_gen1_sync_check_plls_pll_grid_lpf_f__a_sum = 0.0f;
    _diesel_gen1_sync_check_plls_pll_grid_lpf_f__b_sum = 0.0f;
    _diesel_gen1_sync_check_plls_pll_grid_lpf_f__delay_line_in = 0.0f;
    for (_diesel_gen1_sync_check_plls_pll_grid_lpf_f__i = 0; _diesel_gen1_sync_check_plls_pll_grid_lpf_f__i < 1; _diesel_gen1_sync_check_plls_pll_grid_lpf_f__i++) {
        _diesel_gen1_sync_check_plls_pll_grid_lpf_f__b_sum += _diesel_gen1_sync_check_plls_pll_grid_lpf_f__b_coeff[_diesel_gen1_sync_check_plls_pll_grid_lpf_f__i + 1] * _diesel_gen1_sync_check_plls_pll_grid_lpf_f__states[_diesel_gen1_sync_check_plls_pll_grid_lpf_f__i];
    }
    _diesel_gen1_sync_check_plls_pll_grid_lpf_f__a_sum += _diesel_gen1_sync_check_plls_pll_grid_lpf_f__states[0] * _diesel_gen1_sync_check_plls_pll_grid_lpf_f__a_coeff[1];
    _diesel_gen1_sync_check_plls_pll_grid_lpf_f__delay_line_in = _diesel_gen1_sync_check_plls_pll_grid_pll_rads_to_hz__out - _diesel_gen1_sync_check_plls_pll_grid_lpf_f__a_sum;
    _diesel_gen1_sync_check_plls_pll_grid_lpf_f__b_sum += _diesel_gen1_sync_check_plls_pll_grid_lpf_f__b_coeff[0] * _diesel_gen1_sync_check_plls_pll_grid_lpf_f__delay_line_in;
    _diesel_gen1_sync_check_plls_pll_grid_lpf_f__out = _diesel_gen1_sync_check_plls_pll_grid_lpf_f__b_sum;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_f_diff.Sum1
    _diesel_gen1_sync_check_check_f_diff_sum1__out = _diesel_gen1_sync_check_plls_pll_grid_lpf_f__out - _diesel_gen1_sync_check_plls_gain1__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.pu
    _diesel_gen1_sync_check_check_v_diff_pu__out = 0.0025515518153991436 * _diesel_gen1_sync_check_check_v_diff_sum1__out;
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.Sum3
    _diesel_gen1_control_freq_setpoint_control_sum3__out = _diesel_gen1_control_freq_setpoint_control_sum7__out - _diesel_gen1_control_freq_setpoint_control_w_to_wpu__out;
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.delta_w
    HIL_OutAO(0x4003, (float)_diesel_gen1_control_freq_setpoint_control_sum7__out);
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.PLL_Grid.PLL.PI.Kb
    _diesel_gen2_sync_check_plls_pll_grid_pll_pi_kb__out = 1000.0 * _diesel_gen2_sync_check_plls_pll_grid_pll_pi_sum6__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.Sum1
    _diesel_gen2_sync_check_plls_sum1__out = _diesel_gen2_sync_check_plls_pll_grid_pll_integrator__output - _diesel_gen2_sync_check_plls_split1__out1;
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.wt_grid
    HIL_OutAO(0x4037, (float)_diesel_gen2_sync_check_plls_pll_grid_pll_integrator__output);
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.PLL_Grid.LPF_f
    X_UnInt32 _diesel_gen2_sync_check_plls_pll_grid_lpf_f__i;
    _diesel_gen2_sync_check_plls_pll_grid_lpf_f__a_sum = 0.0f;
    _diesel_gen2_sync_check_plls_pll_grid_lpf_f__b_sum = 0.0f;
    _diesel_gen2_sync_check_plls_pll_grid_lpf_f__delay_line_in = 0.0f;
    for (_diesel_gen2_sync_check_plls_pll_grid_lpf_f__i = 0; _diesel_gen2_sync_check_plls_pll_grid_lpf_f__i < 1; _diesel_gen2_sync_check_plls_pll_grid_lpf_f__i++) {
        _diesel_gen2_sync_check_plls_pll_grid_lpf_f__b_sum += _diesel_gen2_sync_check_plls_pll_grid_lpf_f__b_coeff[_diesel_gen2_sync_check_plls_pll_grid_lpf_f__i + 1] * _diesel_gen2_sync_check_plls_pll_grid_lpf_f__states[_diesel_gen2_sync_check_plls_pll_grid_lpf_f__i];
    }
    _diesel_gen2_sync_check_plls_pll_grid_lpf_f__a_sum += _diesel_gen2_sync_check_plls_pll_grid_lpf_f__states[0] * _diesel_gen2_sync_check_plls_pll_grid_lpf_f__a_coeff[1];
    _diesel_gen2_sync_check_plls_pll_grid_lpf_f__delay_line_in = _diesel_gen2_sync_check_plls_pll_grid_pll_rads_to_hz__out - _diesel_gen2_sync_check_plls_pll_grid_lpf_f__a_sum;
    _diesel_gen2_sync_check_plls_pll_grid_lpf_f__b_sum += _diesel_gen2_sync_check_plls_pll_grid_lpf_f__b_coeff[0] * _diesel_gen2_sync_check_plls_pll_grid_lpf_f__delay_line_in;
    _diesel_gen2_sync_check_plls_pll_grid_lpf_f__out = _diesel_gen2_sync_check_plls_pll_grid_lpf_f__b_sum;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_f_diff.Sum1
    _diesel_gen2_sync_check_check_f_diff_sum1__out = _diesel_gen2_sync_check_plls_pll_grid_lpf_f__out - _diesel_gen2_sync_check_plls_gain1__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.pu
    _diesel_gen2_sync_check_check_v_diff_pu__out = 0.0025515518153991436 * _diesel_gen2_sync_check_check_v_diff_sum1__out;
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.Sum3
    _diesel_gen2_control_freq_setpoint_control_sum3__out = _diesel_gen2_control_freq_setpoint_control_sum7__out - _diesel_gen2_control_freq_setpoint_control_w_to_wpu__out;
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.delta_w
    HIL_OutAO(0x4023, (float)_diesel_gen2_control_freq_setpoint_control_sum7__out);
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.PLL_Grid.PLL.PI.Kb
    _diesel_gen3_sync_check_plls_pll_grid_pll_pi_kb__out = 1000.0 * _diesel_gen3_sync_check_plls_pll_grid_pll_pi_sum6__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.Sum1
    _diesel_gen3_sync_check_plls_sum1__out = _diesel_gen3_sync_check_plls_pll_grid_pll_integrator__output - _diesel_gen3_sync_check_plls_split1__out1;
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.wt_grid
    HIL_OutAO(0x4057, (float)_diesel_gen3_sync_check_plls_pll_grid_pll_integrator__output);
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.PLL_Grid.LPF_f
    X_UnInt32 _diesel_gen3_sync_check_plls_pll_grid_lpf_f__i;
    _diesel_gen3_sync_check_plls_pll_grid_lpf_f__a_sum = 0.0f;
    _diesel_gen3_sync_check_plls_pll_grid_lpf_f__b_sum = 0.0f;
    _diesel_gen3_sync_check_plls_pll_grid_lpf_f__delay_line_in = 0.0f;
    for (_diesel_gen3_sync_check_plls_pll_grid_lpf_f__i = 0; _diesel_gen3_sync_check_plls_pll_grid_lpf_f__i < 1; _diesel_gen3_sync_check_plls_pll_grid_lpf_f__i++) {
        _diesel_gen3_sync_check_plls_pll_grid_lpf_f__b_sum += _diesel_gen3_sync_check_plls_pll_grid_lpf_f__b_coeff[_diesel_gen3_sync_check_plls_pll_grid_lpf_f__i + 1] * _diesel_gen3_sync_check_plls_pll_grid_lpf_f__states[_diesel_gen3_sync_check_plls_pll_grid_lpf_f__i];
    }
    _diesel_gen3_sync_check_plls_pll_grid_lpf_f__a_sum += _diesel_gen3_sync_check_plls_pll_grid_lpf_f__states[0] * _diesel_gen3_sync_check_plls_pll_grid_lpf_f__a_coeff[1];
    _diesel_gen3_sync_check_plls_pll_grid_lpf_f__delay_line_in = _diesel_gen3_sync_check_plls_pll_grid_pll_rads_to_hz__out - _diesel_gen3_sync_check_plls_pll_grid_lpf_f__a_sum;
    _diesel_gen3_sync_check_plls_pll_grid_lpf_f__b_sum += _diesel_gen3_sync_check_plls_pll_grid_lpf_f__b_coeff[0] * _diesel_gen3_sync_check_plls_pll_grid_lpf_f__delay_line_in;
    _diesel_gen3_sync_check_plls_pll_grid_lpf_f__out = _diesel_gen3_sync_check_plls_pll_grid_lpf_f__b_sum;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_f_diff.Sum1
    _diesel_gen3_sync_check_check_f_diff_sum1__out = _diesel_gen3_sync_check_plls_pll_grid_lpf_f__out - _diesel_gen3_sync_check_plls_gain1__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.pu
    _diesel_gen3_sync_check_check_v_diff_pu__out = 0.0025515518153991436 * _diesel_gen3_sync_check_check_v_diff_sum1__out;
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.Sum3
    _diesel_gen3_control_freq_setpoint_control_sum3__out = _diesel_gen3_control_freq_setpoint_control_sum7__out - _diesel_gen3_control_freq_setpoint_control_w_to_wpu__out;
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.delta_w
    HIL_OutAO(0x4043, (float)_diesel_gen3_control_freq_setpoint_control_sum7__out);
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.PLL_Grid.PLL.PI.Kb
    _diesel_gen4_sync_check_plls_pll_grid_pll_pi_kb__out = 1000.0 * _diesel_gen4_sync_check_plls_pll_grid_pll_pi_sum6__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.Sum1
    _diesel_gen4_sync_check_plls_sum1__out = _diesel_gen4_sync_check_plls_pll_grid_pll_integrator__output - _diesel_gen4_sync_check_plls_split1__out1;
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.wt_grid
    HIL_OutAO(0x4077, (float)_diesel_gen4_sync_check_plls_pll_grid_pll_integrator__output);
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.PLL_Grid.LPF_f
    X_UnInt32 _diesel_gen4_sync_check_plls_pll_grid_lpf_f__i;
    _diesel_gen4_sync_check_plls_pll_grid_lpf_f__a_sum = 0.0f;
    _diesel_gen4_sync_check_plls_pll_grid_lpf_f__b_sum = 0.0f;
    _diesel_gen4_sync_check_plls_pll_grid_lpf_f__delay_line_in = 0.0f;
    for (_diesel_gen4_sync_check_plls_pll_grid_lpf_f__i = 0; _diesel_gen4_sync_check_plls_pll_grid_lpf_f__i < 1; _diesel_gen4_sync_check_plls_pll_grid_lpf_f__i++) {
        _diesel_gen4_sync_check_plls_pll_grid_lpf_f__b_sum += _diesel_gen4_sync_check_plls_pll_grid_lpf_f__b_coeff[_diesel_gen4_sync_check_plls_pll_grid_lpf_f__i + 1] * _diesel_gen4_sync_check_plls_pll_grid_lpf_f__states[_diesel_gen4_sync_check_plls_pll_grid_lpf_f__i];
    }
    _diesel_gen4_sync_check_plls_pll_grid_lpf_f__a_sum += _diesel_gen4_sync_check_plls_pll_grid_lpf_f__states[0] * _diesel_gen4_sync_check_plls_pll_grid_lpf_f__a_coeff[1];
    _diesel_gen4_sync_check_plls_pll_grid_lpf_f__delay_line_in = _diesel_gen4_sync_check_plls_pll_grid_pll_rads_to_hz__out - _diesel_gen4_sync_check_plls_pll_grid_lpf_f__a_sum;
    _diesel_gen4_sync_check_plls_pll_grid_lpf_f__b_sum += _diesel_gen4_sync_check_plls_pll_grid_lpf_f__b_coeff[0] * _diesel_gen4_sync_check_plls_pll_grid_lpf_f__delay_line_in;
    _diesel_gen4_sync_check_plls_pll_grid_lpf_f__out = _diesel_gen4_sync_check_plls_pll_grid_lpf_f__b_sum;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_f_diff.Sum1
    _diesel_gen4_sync_check_check_f_diff_sum1__out = _diesel_gen4_sync_check_plls_pll_grid_lpf_f__out - _diesel_gen4_sync_check_plls_gain1__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.pu
    _diesel_gen4_sync_check_check_v_diff_pu__out = 0.0025515518153991436 * _diesel_gen4_sync_check_check_v_diff_sum1__out;
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.Sum3
    _diesel_gen4_control_freq_setpoint_control_sum3__out = _diesel_gen4_control_freq_setpoint_control_sum7__out - _diesel_gen4_control_freq_setpoint_control_w_to_wpu__out;
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.delta_w
    HIL_OutAO(0x4063, (float)_diesel_gen4_control_freq_setpoint_control_sum7__out);
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.PI.Limit1
    _diesel_gen1_sync_check_check_phase_diff_pi_limit1__out = MIN(MAX(_diesel_gen1_sync_check_check_phase_diff_pi_sum5__out, -0.1), 0.1);
    // Generated from the component: Diesel_Gen1.Control.pf Control.PI.Limit1
    _diesel_gen1_control_pf_control_pi_limit1__out = MIN(MAX(_diesel_gen1_control_pf_control_pi_sum5__out, -10.0), 10.0);
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.PI.Limit1
    _diesel_gen2_sync_check_check_phase_diff_pi_limit1__out = MIN(MAX(_diesel_gen2_sync_check_check_phase_diff_pi_sum5__out, -0.1), 0.1);
    // Generated from the component: Diesel_Gen2.Control.pf Control.PI.Limit1
    _diesel_gen2_control_pf_control_pi_limit1__out = MIN(MAX(_diesel_gen2_control_pf_control_pi_sum5__out, -10.0), 10.0);
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.PI.Limit1
    _diesel_gen4_sync_check_check_phase_diff_pi_limit1__out = MIN(MAX(_diesel_gen4_sync_check_check_phase_diff_pi_sum5__out, -0.1), 0.1);
    // Generated from the component: Diesel_Gen4.Control.pf Control.PI.Limit1
    _diesel_gen4_control_pf_control_pi_limit1__out = MIN(MAX(_diesel_gen4_control_pf_control_pi_sum5__out, -10.0), 10.0);
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.PI.Limit1
    _diesel_gen3_sync_check_check_phase_diff_pi_limit1__out = MIN(MAX(_diesel_gen3_sync_check_check_phase_diff_pi_sum5__out, -0.1), 0.1);
    // Generated from the component: Diesel_Gen3.Control.pf Control.PI.Limit1
    _diesel_gen3_control_pf_control_pi_limit1__out = MIN(MAX(_diesel_gen3_control_pf_control_pi_sum5__out, -10.0), 10.0);
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.PLL_Grid.PLL.PI.Sum7
    _diesel_gen1_sync_check_plls_pll_grid_pll_pi_sum7__out = _diesel_gen1_sync_check_plls_pll_grid_pll_pi_ki__out + _diesel_gen1_sync_check_plls_pll_grid_pll_pi_kb__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.confine_phase
    _diesel_gen1_sync_check_check_phase_diff_confine_phase__dtheta = _diesel_gen1_sync_check_plls_sum1__out;
    if (_diesel_gen1_sync_check_check_phase_diff_confine_phase__dtheta > 3.14159265359) {
        _diesel_gen1_sync_check_check_phase_diff_confine_phase__dtheta_confined = _diesel_gen1_sync_check_check_phase_diff_confine_phase__dtheta - 6.28318530718;
    }
    else {
        if (_diesel_gen1_sync_check_check_phase_diff_confine_phase__dtheta < -3.14159265359) {
            _diesel_gen1_sync_check_check_phase_diff_confine_phase__dtheta_confined = _diesel_gen1_sync_check_check_phase_diff_confine_phase__dtheta + 6.28318530718;
        }
        else {
            _diesel_gen1_sync_check_check_phase_diff_confine_phase__dtheta_confined = _diesel_gen1_sync_check_check_phase_diff_confine_phase__dtheta;
        }
    }
    // Generated from the component: Diesel_Gen1.Sync_Check.check_f_diff.LPF_dwf
    X_UnInt32 _diesel_gen1_sync_check_check_f_diff_lpf_dwf__i;
    _diesel_gen1_sync_check_check_f_diff_lpf_dwf__a_sum = 0.0f;
    _diesel_gen1_sync_check_check_f_diff_lpf_dwf__b_sum = 0.0f;
    _diesel_gen1_sync_check_check_f_diff_lpf_dwf__delay_line_in = 0.0f;
    for (_diesel_gen1_sync_check_check_f_diff_lpf_dwf__i = 0; _diesel_gen1_sync_check_check_f_diff_lpf_dwf__i < 1; _diesel_gen1_sync_check_check_f_diff_lpf_dwf__i++) {
        _diesel_gen1_sync_check_check_f_diff_lpf_dwf__b_sum += _diesel_gen1_sync_check_check_f_diff_lpf_dwf__b_coeff[_diesel_gen1_sync_check_check_f_diff_lpf_dwf__i + 1] * _diesel_gen1_sync_check_check_f_diff_lpf_dwf__states[_diesel_gen1_sync_check_check_f_diff_lpf_dwf__i];
    }
    _diesel_gen1_sync_check_check_f_diff_lpf_dwf__a_sum += _diesel_gen1_sync_check_check_f_diff_lpf_dwf__states[0] * _diesel_gen1_sync_check_check_f_diff_lpf_dwf__a_coeff[1];
    _diesel_gen1_sync_check_check_f_diff_lpf_dwf__delay_line_in = _diesel_gen1_sync_check_check_f_diff_sum1__out - _diesel_gen1_sync_check_check_f_diff_lpf_dwf__a_sum;
    _diesel_gen1_sync_check_check_f_diff_lpf_dwf__b_sum += _diesel_gen1_sync_check_check_f_diff_lpf_dwf__b_coeff[0] * _diesel_gen1_sync_check_check_f_diff_lpf_dwf__delay_line_in;
    _diesel_gen1_sync_check_check_f_diff_lpf_dwf__out = _diesel_gen1_sync_check_check_f_diff_lpf_dwf__b_sum;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.Abs3
    _diesel_gen1_sync_check_check_v_diff_abs3__out = fabs(_diesel_gen1_sync_check_check_v_diff_pu__out);
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.PI.Ki
    _diesel_gen1_sync_check_check_v_diff_pi_ki__out = 0.0354 * _diesel_gen1_sync_check_check_v_diff_pu__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.PI.Kp
    _diesel_gen1_sync_check_check_v_diff_pi_kp__out = 0.0071 * _diesel_gen1_sync_check_check_v_diff_pu__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.V_diff
    HIL_OutAO(0x4018, (float)_diesel_gen1_sync_check_check_v_diff_pu__out);
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.PI.Ki
    _diesel_gen1_control_freq_setpoint_control_pi_ki__out = 0.01 * _diesel_gen1_control_freq_setpoint_control_sum3__out;
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.PI.Kp
    _diesel_gen1_control_freq_setpoint_control_pi_kp__out = 0.01 * _diesel_gen1_control_freq_setpoint_control_sum3__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.PLL_Grid.PLL.PI.Sum7
    _diesel_gen2_sync_check_plls_pll_grid_pll_pi_sum7__out = _diesel_gen2_sync_check_plls_pll_grid_pll_pi_ki__out + _diesel_gen2_sync_check_plls_pll_grid_pll_pi_kb__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.confine_phase
    _diesel_gen2_sync_check_check_phase_diff_confine_phase__dtheta = _diesel_gen2_sync_check_plls_sum1__out;
    if (_diesel_gen2_sync_check_check_phase_diff_confine_phase__dtheta > 3.14159265359) {
        _diesel_gen2_sync_check_check_phase_diff_confine_phase__dtheta_confined = _diesel_gen2_sync_check_check_phase_diff_confine_phase__dtheta - 6.28318530718;
    }
    else {
        if (_diesel_gen2_sync_check_check_phase_diff_confine_phase__dtheta < -3.14159265359) {
            _diesel_gen2_sync_check_check_phase_diff_confine_phase__dtheta_confined = _diesel_gen2_sync_check_check_phase_diff_confine_phase__dtheta + 6.28318530718;
        }
        else {
            _diesel_gen2_sync_check_check_phase_diff_confine_phase__dtheta_confined = _diesel_gen2_sync_check_check_phase_diff_confine_phase__dtheta;
        }
    }
    // Generated from the component: Diesel_Gen2.Sync_Check.check_f_diff.LPF_dwf
    X_UnInt32 _diesel_gen2_sync_check_check_f_diff_lpf_dwf__i;
    _diesel_gen2_sync_check_check_f_diff_lpf_dwf__a_sum = 0.0f;
    _diesel_gen2_sync_check_check_f_diff_lpf_dwf__b_sum = 0.0f;
    _diesel_gen2_sync_check_check_f_diff_lpf_dwf__delay_line_in = 0.0f;
    for (_diesel_gen2_sync_check_check_f_diff_lpf_dwf__i = 0; _diesel_gen2_sync_check_check_f_diff_lpf_dwf__i < 1; _diesel_gen2_sync_check_check_f_diff_lpf_dwf__i++) {
        _diesel_gen2_sync_check_check_f_diff_lpf_dwf__b_sum += _diesel_gen2_sync_check_check_f_diff_lpf_dwf__b_coeff[_diesel_gen2_sync_check_check_f_diff_lpf_dwf__i + 1] * _diesel_gen2_sync_check_check_f_diff_lpf_dwf__states[_diesel_gen2_sync_check_check_f_diff_lpf_dwf__i];
    }
    _diesel_gen2_sync_check_check_f_diff_lpf_dwf__a_sum += _diesel_gen2_sync_check_check_f_diff_lpf_dwf__states[0] * _diesel_gen2_sync_check_check_f_diff_lpf_dwf__a_coeff[1];
    _diesel_gen2_sync_check_check_f_diff_lpf_dwf__delay_line_in = _diesel_gen2_sync_check_check_f_diff_sum1__out - _diesel_gen2_sync_check_check_f_diff_lpf_dwf__a_sum;
    _diesel_gen2_sync_check_check_f_diff_lpf_dwf__b_sum += _diesel_gen2_sync_check_check_f_diff_lpf_dwf__b_coeff[0] * _diesel_gen2_sync_check_check_f_diff_lpf_dwf__delay_line_in;
    _diesel_gen2_sync_check_check_f_diff_lpf_dwf__out = _diesel_gen2_sync_check_check_f_diff_lpf_dwf__b_sum;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.Abs3
    _diesel_gen2_sync_check_check_v_diff_abs3__out = fabs(_diesel_gen2_sync_check_check_v_diff_pu__out);
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.PI.Ki
    _diesel_gen2_sync_check_check_v_diff_pi_ki__out = 0.0354 * _diesel_gen2_sync_check_check_v_diff_pu__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.PI.Kp
    _diesel_gen2_sync_check_check_v_diff_pi_kp__out = 0.0071 * _diesel_gen2_sync_check_check_v_diff_pu__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.V_diff
    HIL_OutAO(0x4038, (float)_diesel_gen2_sync_check_check_v_diff_pu__out);
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.PI.Ki
    _diesel_gen2_control_freq_setpoint_control_pi_ki__out = 0.01 * _diesel_gen2_control_freq_setpoint_control_sum3__out;
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.PI.Kp
    _diesel_gen2_control_freq_setpoint_control_pi_kp__out = 0.01 * _diesel_gen2_control_freq_setpoint_control_sum3__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.PLL_Grid.PLL.PI.Sum7
    _diesel_gen3_sync_check_plls_pll_grid_pll_pi_sum7__out = _diesel_gen3_sync_check_plls_pll_grid_pll_pi_ki__out + _diesel_gen3_sync_check_plls_pll_grid_pll_pi_kb__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.confine_phase
    _diesel_gen3_sync_check_check_phase_diff_confine_phase__dtheta = _diesel_gen3_sync_check_plls_sum1__out;
    if (_diesel_gen3_sync_check_check_phase_diff_confine_phase__dtheta > 3.14159265359) {
        _diesel_gen3_sync_check_check_phase_diff_confine_phase__dtheta_confined = _diesel_gen3_sync_check_check_phase_diff_confine_phase__dtheta - 6.28318530718;
    }
    else {
        if (_diesel_gen3_sync_check_check_phase_diff_confine_phase__dtheta < -3.14159265359) {
            _diesel_gen3_sync_check_check_phase_diff_confine_phase__dtheta_confined = _diesel_gen3_sync_check_check_phase_diff_confine_phase__dtheta + 6.28318530718;
        }
        else {
            _diesel_gen3_sync_check_check_phase_diff_confine_phase__dtheta_confined = _diesel_gen3_sync_check_check_phase_diff_confine_phase__dtheta;
        }
    }
    // Generated from the component: Diesel_Gen3.Sync_Check.check_f_diff.LPF_dwf
    X_UnInt32 _diesel_gen3_sync_check_check_f_diff_lpf_dwf__i;
    _diesel_gen3_sync_check_check_f_diff_lpf_dwf__a_sum = 0.0f;
    _diesel_gen3_sync_check_check_f_diff_lpf_dwf__b_sum = 0.0f;
    _diesel_gen3_sync_check_check_f_diff_lpf_dwf__delay_line_in = 0.0f;
    for (_diesel_gen3_sync_check_check_f_diff_lpf_dwf__i = 0; _diesel_gen3_sync_check_check_f_diff_lpf_dwf__i < 1; _diesel_gen3_sync_check_check_f_diff_lpf_dwf__i++) {
        _diesel_gen3_sync_check_check_f_diff_lpf_dwf__b_sum += _diesel_gen3_sync_check_check_f_diff_lpf_dwf__b_coeff[_diesel_gen3_sync_check_check_f_diff_lpf_dwf__i + 1] * _diesel_gen3_sync_check_check_f_diff_lpf_dwf__states[_diesel_gen3_sync_check_check_f_diff_lpf_dwf__i];
    }
    _diesel_gen3_sync_check_check_f_diff_lpf_dwf__a_sum += _diesel_gen3_sync_check_check_f_diff_lpf_dwf__states[0] * _diesel_gen3_sync_check_check_f_diff_lpf_dwf__a_coeff[1];
    _diesel_gen3_sync_check_check_f_diff_lpf_dwf__delay_line_in = _diesel_gen3_sync_check_check_f_diff_sum1__out - _diesel_gen3_sync_check_check_f_diff_lpf_dwf__a_sum;
    _diesel_gen3_sync_check_check_f_diff_lpf_dwf__b_sum += _diesel_gen3_sync_check_check_f_diff_lpf_dwf__b_coeff[0] * _diesel_gen3_sync_check_check_f_diff_lpf_dwf__delay_line_in;
    _diesel_gen3_sync_check_check_f_diff_lpf_dwf__out = _diesel_gen3_sync_check_check_f_diff_lpf_dwf__b_sum;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.Abs3
    _diesel_gen3_sync_check_check_v_diff_abs3__out = fabs(_diesel_gen3_sync_check_check_v_diff_pu__out);
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.PI.Ki
    _diesel_gen3_sync_check_check_v_diff_pi_ki__out = 0.0354 * _diesel_gen3_sync_check_check_v_diff_pu__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.PI.Kp
    _diesel_gen3_sync_check_check_v_diff_pi_kp__out = 0.0071 * _diesel_gen3_sync_check_check_v_diff_pu__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.V_diff
    HIL_OutAO(0x4058, (float)_diesel_gen3_sync_check_check_v_diff_pu__out);
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.PI.Ki
    _diesel_gen3_control_freq_setpoint_control_pi_ki__out = 0.01 * _diesel_gen3_control_freq_setpoint_control_sum3__out;
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.PI.Kp
    _diesel_gen3_control_freq_setpoint_control_pi_kp__out = 0.01 * _diesel_gen3_control_freq_setpoint_control_sum3__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.PLL_Grid.PLL.PI.Sum7
    _diesel_gen4_sync_check_plls_pll_grid_pll_pi_sum7__out = _diesel_gen4_sync_check_plls_pll_grid_pll_pi_ki__out + _diesel_gen4_sync_check_plls_pll_grid_pll_pi_kb__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.confine_phase
    _diesel_gen4_sync_check_check_phase_diff_confine_phase__dtheta = _diesel_gen4_sync_check_plls_sum1__out;
    if (_diesel_gen4_sync_check_check_phase_diff_confine_phase__dtheta > 3.14159265359) {
        _diesel_gen4_sync_check_check_phase_diff_confine_phase__dtheta_confined = _diesel_gen4_sync_check_check_phase_diff_confine_phase__dtheta - 6.28318530718;
    }
    else {
        if (_diesel_gen4_sync_check_check_phase_diff_confine_phase__dtheta < -3.14159265359) {
            _diesel_gen4_sync_check_check_phase_diff_confine_phase__dtheta_confined = _diesel_gen4_sync_check_check_phase_diff_confine_phase__dtheta + 6.28318530718;
        }
        else {
            _diesel_gen4_sync_check_check_phase_diff_confine_phase__dtheta_confined = _diesel_gen4_sync_check_check_phase_diff_confine_phase__dtheta;
        }
    }
    // Generated from the component: Diesel_Gen4.Sync_Check.check_f_diff.LPF_dwf
    X_UnInt32 _diesel_gen4_sync_check_check_f_diff_lpf_dwf__i;
    _diesel_gen4_sync_check_check_f_diff_lpf_dwf__a_sum = 0.0f;
    _diesel_gen4_sync_check_check_f_diff_lpf_dwf__b_sum = 0.0f;
    _diesel_gen4_sync_check_check_f_diff_lpf_dwf__delay_line_in = 0.0f;
    for (_diesel_gen4_sync_check_check_f_diff_lpf_dwf__i = 0; _diesel_gen4_sync_check_check_f_diff_lpf_dwf__i < 1; _diesel_gen4_sync_check_check_f_diff_lpf_dwf__i++) {
        _diesel_gen4_sync_check_check_f_diff_lpf_dwf__b_sum += _diesel_gen4_sync_check_check_f_diff_lpf_dwf__b_coeff[_diesel_gen4_sync_check_check_f_diff_lpf_dwf__i + 1] * _diesel_gen4_sync_check_check_f_diff_lpf_dwf__states[_diesel_gen4_sync_check_check_f_diff_lpf_dwf__i];
    }
    _diesel_gen4_sync_check_check_f_diff_lpf_dwf__a_sum += _diesel_gen4_sync_check_check_f_diff_lpf_dwf__states[0] * _diesel_gen4_sync_check_check_f_diff_lpf_dwf__a_coeff[1];
    _diesel_gen4_sync_check_check_f_diff_lpf_dwf__delay_line_in = _diesel_gen4_sync_check_check_f_diff_sum1__out - _diesel_gen4_sync_check_check_f_diff_lpf_dwf__a_sum;
    _diesel_gen4_sync_check_check_f_diff_lpf_dwf__b_sum += _diesel_gen4_sync_check_check_f_diff_lpf_dwf__b_coeff[0] * _diesel_gen4_sync_check_check_f_diff_lpf_dwf__delay_line_in;
    _diesel_gen4_sync_check_check_f_diff_lpf_dwf__out = _diesel_gen4_sync_check_check_f_diff_lpf_dwf__b_sum;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.Abs3
    _diesel_gen4_sync_check_check_v_diff_abs3__out = fabs(_diesel_gen4_sync_check_check_v_diff_pu__out);
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.PI.Ki
    _diesel_gen4_sync_check_check_v_diff_pi_ki__out = 0.0354 * _diesel_gen4_sync_check_check_v_diff_pu__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.PI.Kp
    _diesel_gen4_sync_check_check_v_diff_pi_kp__out = 0.0071 * _diesel_gen4_sync_check_check_v_diff_pu__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.V_diff
    HIL_OutAO(0x4078, (float)_diesel_gen4_sync_check_check_v_diff_pu__out);
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.PI.Ki
    _diesel_gen4_control_freq_setpoint_control_pi_ki__out = 0.01 * _diesel_gen4_control_freq_setpoint_control_sum3__out;
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.PI.Kp
    _diesel_gen4_control_freq_setpoint_control_pi_kp__out = 0.01 * _diesel_gen4_control_freq_setpoint_control_sum3__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.PI.Sum6
    _diesel_gen1_sync_check_check_phase_diff_pi_sum6__out =  - _diesel_gen1_sync_check_check_phase_diff_pi_sum5__out + _diesel_gen1_sync_check_check_phase_diff_pi_limit1__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.Product1
    _diesel_gen1_sync_check_check_phase_diff_product1__out = (_diesel_gen1_sync_check_and1__out * _diesel_gen1_sync_check_check_phase_diff_pi_limit1__out);
    // Generated from the component: Diesel_Gen1.Control.pf Control.PI.Sum6
    _diesel_gen1_control_pf_control_pi_sum6__out =  - _diesel_gen1_control_pf_control_pi_sum5__out + _diesel_gen1_control_pf_control_pi_limit1__out;
    // Generated from the component: Diesel_Gen1.Control.pf Control.Signal switch4
    _diesel_gen1_control_pf_control_signal_switch4__out = (_diesel_gen1_control_pf_control_logical_operator5__out > 0.5f) ? _diesel_gen1_control_pf_control_pi_limit1__out : _diesel_gen1_control_pf_control_zero1__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.PI.Sum6
    _diesel_gen2_sync_check_check_phase_diff_pi_sum6__out =  - _diesel_gen2_sync_check_check_phase_diff_pi_sum5__out + _diesel_gen2_sync_check_check_phase_diff_pi_limit1__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.Product1
    _diesel_gen2_sync_check_check_phase_diff_product1__out = (_diesel_gen2_sync_check_and1__out * _diesel_gen2_sync_check_check_phase_diff_pi_limit1__out);
    // Generated from the component: Diesel_Gen2.Control.pf Control.PI.Sum6
    _diesel_gen2_control_pf_control_pi_sum6__out =  - _diesel_gen2_control_pf_control_pi_sum5__out + _diesel_gen2_control_pf_control_pi_limit1__out;
    // Generated from the component: Diesel_Gen2.Control.pf Control.Signal switch4
    _diesel_gen2_control_pf_control_signal_switch4__out = (_diesel_gen2_control_pf_control_logical_operator5__out > 0.5f) ? _diesel_gen2_control_pf_control_pi_limit1__out : _diesel_gen2_control_pf_control_zero1__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.PI.Sum6
    _diesel_gen4_sync_check_check_phase_diff_pi_sum6__out =  - _diesel_gen4_sync_check_check_phase_diff_pi_sum5__out + _diesel_gen4_sync_check_check_phase_diff_pi_limit1__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.Product1
    _diesel_gen4_sync_check_check_phase_diff_product1__out = (_diesel_gen4_sync_check_and1__out * _diesel_gen4_sync_check_check_phase_diff_pi_limit1__out);
    // Generated from the component: Diesel_Gen4.Control.pf Control.PI.Sum6
    _diesel_gen4_control_pf_control_pi_sum6__out =  - _diesel_gen4_control_pf_control_pi_sum5__out + _diesel_gen4_control_pf_control_pi_limit1__out;
    // Generated from the component: Diesel_Gen4.Control.pf Control.Signal switch4
    _diesel_gen4_control_pf_control_signal_switch4__out = (_diesel_gen4_control_pf_control_logical_operator5__out > 0.5f) ? _diesel_gen4_control_pf_control_pi_limit1__out : _diesel_gen4_control_pf_control_zero1__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.PI.Sum6
    _diesel_gen3_sync_check_check_phase_diff_pi_sum6__out =  - _diesel_gen3_sync_check_check_phase_diff_pi_sum5__out + _diesel_gen3_sync_check_check_phase_diff_pi_limit1__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.Product1
    _diesel_gen3_sync_check_check_phase_diff_product1__out = (_diesel_gen3_sync_check_and1__out * _diesel_gen3_sync_check_check_phase_diff_pi_limit1__out);
    // Generated from the component: Diesel_Gen3.Control.pf Control.PI.Sum6
    _diesel_gen3_control_pf_control_pi_sum6__out =  - _diesel_gen3_control_pf_control_pi_sum5__out + _diesel_gen3_control_pf_control_pi_limit1__out;
    // Generated from the component: Diesel_Gen3.Control.pf Control.Signal switch4
    _diesel_gen3_control_pf_control_signal_switch4__out = (_diesel_gen3_control_pf_control_logical_operator5__out > 0.5f) ? _diesel_gen3_control_pf_control_pi_limit1__out : _diesel_gen3_control_pf_control_zero1__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.offset_phase
    _diesel_gen1_sync_check_check_phase_diff_offset_phase__phase = _diesel_gen1_sync_check_check_phase_diff_confine_phase__dtheta_confined;
    _diesel_gen1_sync_check_check_phase_diff_offset_phase__phase_out = _diesel_gen1_sync_check_check_phase_diff_offset_phase__phase - _diesel_gen1_sync_check_check_phase_diff_offset_phase__off1 + _diesel_gen1_sync_check_check_phase_diff_offset_phase__off2;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.Comparator1
    if (_diesel_gen1_sync_check_check_v_diff_volt_diff__out < _diesel_gen1_sync_check_check_v_diff_abs3__out) {
        _diesel_gen1_sync_check_check_v_diff_comparator1__out = 0;
    } else if (_diesel_gen1_sync_check_check_v_diff_volt_diff__out > _diesel_gen1_sync_check_check_v_diff_abs3__out) {
        _diesel_gen1_sync_check_check_v_diff_comparator1__out = 1;
    } else {
        _diesel_gen1_sync_check_check_v_diff_comparator1__out = _diesel_gen1_sync_check_check_v_diff_comparator1__state;
    }
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.PI.Sum5
    _diesel_gen1_sync_check_check_v_diff_pi_sum5__out = _diesel_gen1_sync_check_check_v_diff_pi_kp__out + _diesel_gen1_sync_check_check_v_diff_pi_integrator1__out;
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.PI.Sum5
    _diesel_gen1_control_freq_setpoint_control_pi_sum5__out = _diesel_gen1_control_freq_setpoint_control_pi_kp__out + _diesel_gen1_control_freq_setpoint_control_pi_integrator1__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.offset_phase
    _diesel_gen2_sync_check_check_phase_diff_offset_phase__phase = _diesel_gen2_sync_check_check_phase_diff_confine_phase__dtheta_confined;
    _diesel_gen2_sync_check_check_phase_diff_offset_phase__phase_out = _diesel_gen2_sync_check_check_phase_diff_offset_phase__phase - _diesel_gen2_sync_check_check_phase_diff_offset_phase__off1 + _diesel_gen2_sync_check_check_phase_diff_offset_phase__off2;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.Comparator1
    if (_diesel_gen2_sync_check_check_v_diff_volt_diff__out < _diesel_gen2_sync_check_check_v_diff_abs3__out) {
        _diesel_gen2_sync_check_check_v_diff_comparator1__out = 0;
    } else if (_diesel_gen2_sync_check_check_v_diff_volt_diff__out > _diesel_gen2_sync_check_check_v_diff_abs3__out) {
        _diesel_gen2_sync_check_check_v_diff_comparator1__out = 1;
    } else {
        _diesel_gen2_sync_check_check_v_diff_comparator1__out = _diesel_gen2_sync_check_check_v_diff_comparator1__state;
    }
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.PI.Sum5
    _diesel_gen2_sync_check_check_v_diff_pi_sum5__out = _diesel_gen2_sync_check_check_v_diff_pi_kp__out + _diesel_gen2_sync_check_check_v_diff_pi_integrator1__out;
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.PI.Sum5
    _diesel_gen2_control_freq_setpoint_control_pi_sum5__out = _diesel_gen2_control_freq_setpoint_control_pi_kp__out + _diesel_gen2_control_freq_setpoint_control_pi_integrator1__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.offset_phase
    _diesel_gen3_sync_check_check_phase_diff_offset_phase__phase = _diesel_gen3_sync_check_check_phase_diff_confine_phase__dtheta_confined;
    _diesel_gen3_sync_check_check_phase_diff_offset_phase__phase_out = _diesel_gen3_sync_check_check_phase_diff_offset_phase__phase - _diesel_gen3_sync_check_check_phase_diff_offset_phase__off1 + _diesel_gen3_sync_check_check_phase_diff_offset_phase__off2;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.Comparator1
    if (_diesel_gen3_sync_check_check_v_diff_volt_diff__out < _diesel_gen3_sync_check_check_v_diff_abs3__out) {
        _diesel_gen3_sync_check_check_v_diff_comparator1__out = 0;
    } else if (_diesel_gen3_sync_check_check_v_diff_volt_diff__out > _diesel_gen3_sync_check_check_v_diff_abs3__out) {
        _diesel_gen3_sync_check_check_v_diff_comparator1__out = 1;
    } else {
        _diesel_gen3_sync_check_check_v_diff_comparator1__out = _diesel_gen3_sync_check_check_v_diff_comparator1__state;
    }
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.PI.Sum5
    _diesel_gen3_sync_check_check_v_diff_pi_sum5__out = _diesel_gen3_sync_check_check_v_diff_pi_kp__out + _diesel_gen3_sync_check_check_v_diff_pi_integrator1__out;
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.PI.Sum5
    _diesel_gen3_control_freq_setpoint_control_pi_sum5__out = _diesel_gen3_control_freq_setpoint_control_pi_kp__out + _diesel_gen3_control_freq_setpoint_control_pi_integrator1__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.offset_phase
    _diesel_gen4_sync_check_check_phase_diff_offset_phase__phase = _diesel_gen4_sync_check_check_phase_diff_confine_phase__dtheta_confined;
    _diesel_gen4_sync_check_check_phase_diff_offset_phase__phase_out = _diesel_gen4_sync_check_check_phase_diff_offset_phase__phase - _diesel_gen4_sync_check_check_phase_diff_offset_phase__off1 + _diesel_gen4_sync_check_check_phase_diff_offset_phase__off2;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.Comparator1
    if (_diesel_gen4_sync_check_check_v_diff_volt_diff__out < _diesel_gen4_sync_check_check_v_diff_abs3__out) {
        _diesel_gen4_sync_check_check_v_diff_comparator1__out = 0;
    } else if (_diesel_gen4_sync_check_check_v_diff_volt_diff__out > _diesel_gen4_sync_check_check_v_diff_abs3__out) {
        _diesel_gen4_sync_check_check_v_diff_comparator1__out = 1;
    } else {
        _diesel_gen4_sync_check_check_v_diff_comparator1__out = _diesel_gen4_sync_check_check_v_diff_comparator1__state;
    }
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.PI.Sum5
    _diesel_gen4_sync_check_check_v_diff_pi_sum5__out = _diesel_gen4_sync_check_check_v_diff_pi_kp__out + _diesel_gen4_sync_check_check_v_diff_pi_integrator1__out;
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.PI.Sum5
    _diesel_gen4_control_freq_setpoint_control_pi_sum5__out = _diesel_gen4_control_freq_setpoint_control_pi_kp__out + _diesel_gen4_control_freq_setpoint_control_pi_integrator1__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.PI.Kb
    _diesel_gen1_sync_check_check_phase_diff_pi_kb__out = 1.0 * _diesel_gen1_sync_check_check_phase_diff_pi_sum6__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.Calculate_dw_synch.Sum4
    _diesel_gen1_sync_check_calculate_dw_synch_sum4__out = _diesel_gen1_sync_check_check_f_diff_topu__out + _diesel_gen1_sync_check_check_phase_diff_product1__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.dw_phase
    HIL_OutAO(0x401e, (float)_diesel_gen1_sync_check_check_phase_diff_product1__out);
    // Generated from the component: Diesel_Gen1.Control.pf Control.PI.Kb
    _diesel_gen1_control_pf_control_pi_kb__out = 1.0 * _diesel_gen1_control_pf_control_pi_sum6__out;
    // Generated from the component: Diesel_Gen1.Control.pf Control.delta_V
    HIL_OutAO(0x400c, (float)_diesel_gen1_control_pf_control_signal_switch4__out);
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.PI.Kb
    _diesel_gen2_sync_check_check_phase_diff_pi_kb__out = 1.0 * _diesel_gen2_sync_check_check_phase_diff_pi_sum6__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.Calculate_dw_synch.Sum4
    _diesel_gen2_sync_check_calculate_dw_synch_sum4__out = _diesel_gen2_sync_check_check_f_diff_topu__out + _diesel_gen2_sync_check_check_phase_diff_product1__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.dw_phase
    HIL_OutAO(0x403e, (float)_diesel_gen2_sync_check_check_phase_diff_product1__out);
    // Generated from the component: Diesel_Gen2.Control.pf Control.PI.Kb
    _diesel_gen2_control_pf_control_pi_kb__out = 1.0 * _diesel_gen2_control_pf_control_pi_sum6__out;
    // Generated from the component: Diesel_Gen2.Control.pf Control.delta_V
    HIL_OutAO(0x402c, (float)_diesel_gen2_control_pf_control_signal_switch4__out);
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.PI.Kb
    _diesel_gen4_sync_check_check_phase_diff_pi_kb__out = 1.0 * _diesel_gen4_sync_check_check_phase_diff_pi_sum6__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.Calculate_dw_synch.Sum4
    _diesel_gen4_sync_check_calculate_dw_synch_sum4__out = _diesel_gen4_sync_check_check_f_diff_topu__out + _diesel_gen4_sync_check_check_phase_diff_product1__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.dw_phase
    HIL_OutAO(0x407e, (float)_diesel_gen4_sync_check_check_phase_diff_product1__out);
    // Generated from the component: Diesel_Gen4.Control.pf Control.PI.Kb
    _diesel_gen4_control_pf_control_pi_kb__out = 1.0 * _diesel_gen4_control_pf_control_pi_sum6__out;
    // Generated from the component: Diesel_Gen4.Control.pf Control.delta_V
    HIL_OutAO(0x406c, (float)_diesel_gen4_control_pf_control_signal_switch4__out);
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.PI.Kb
    _diesel_gen3_sync_check_check_phase_diff_pi_kb__out = 1.0 * _diesel_gen3_sync_check_check_phase_diff_pi_sum6__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.Calculate_dw_synch.Sum4
    _diesel_gen3_sync_check_calculate_dw_synch_sum4__out = _diesel_gen3_sync_check_check_f_diff_topu__out + _diesel_gen3_sync_check_check_phase_diff_product1__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.dw_phase
    HIL_OutAO(0x405e, (float)_diesel_gen3_sync_check_check_phase_diff_product1__out);
    // Generated from the component: Diesel_Gen3.Control.pf Control.PI.Kb
    _diesel_gen3_control_pf_control_pi_kb__out = 1.0 * _diesel_gen3_control_pf_control_pi_sum6__out;
    // Generated from the component: Diesel_Gen3.Control.pf Control.delta_V
    HIL_OutAO(0x404c, (float)_diesel_gen3_control_pf_control_signal_switch4__out);
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.LPF
    X_UnInt32 _diesel_gen1_sync_check_check_phase_diff_lpf__i;
    _diesel_gen1_sync_check_check_phase_diff_lpf__a_sum = 0.0f;
    _diesel_gen1_sync_check_check_phase_diff_lpf__b_sum = 0.0f;
    _diesel_gen1_sync_check_check_phase_diff_lpf__delay_line_in = 0.0f;
    for (_diesel_gen1_sync_check_check_phase_diff_lpf__i = 0; _diesel_gen1_sync_check_check_phase_diff_lpf__i < 1; _diesel_gen1_sync_check_check_phase_diff_lpf__i++) {
        _diesel_gen1_sync_check_check_phase_diff_lpf__b_sum += _diesel_gen1_sync_check_check_phase_diff_lpf__b_coeff[_diesel_gen1_sync_check_check_phase_diff_lpf__i + 1] * _diesel_gen1_sync_check_check_phase_diff_lpf__states[_diesel_gen1_sync_check_check_phase_diff_lpf__i];
    }
    _diesel_gen1_sync_check_check_phase_diff_lpf__a_sum += _diesel_gen1_sync_check_check_phase_diff_lpf__states[0] * _diesel_gen1_sync_check_check_phase_diff_lpf__a_coeff[1];
    _diesel_gen1_sync_check_check_phase_diff_lpf__delay_line_in = _diesel_gen1_sync_check_check_phase_diff_offset_phase__phase_out - _diesel_gen1_sync_check_check_phase_diff_lpf__a_sum;
    _diesel_gen1_sync_check_check_phase_diff_lpf__b_sum += _diesel_gen1_sync_check_check_phase_diff_lpf__b_coeff[0] * _diesel_gen1_sync_check_check_phase_diff_lpf__delay_line_in;
    _diesel_gen1_sync_check_check_phase_diff_lpf__out = _diesel_gen1_sync_check_check_phase_diff_lpf__b_sum;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.phase_diff
    HIL_OutAO(0x401a, (float)_diesel_gen1_sync_check_check_phase_diff_offset_phase__phase_out);
    // Generated from the component: Diesel_Gen1.Sync_Check.Contactor_Control.and
    _diesel_gen1_sync_check_contactor_control_and__out = _diesel_gen1_sync_check_bus_split1__out4 && _diesel_gen1_sync_check_check_phase_diff_counter_c_function__out && _diesel_gen1_sync_check_contactor_control_wait_to_trip__Trip && _diesel_gen1_sync_check_check_f_diff_comparator1__out && _diesel_gen1_sync_check_check_v_diff_comparator1__out ;
    // Generated from the component: Diesel_Gen1.Sync_Check.V_match
    HIL_OutInt32(0xf0040d, _diesel_gen1_sync_check_check_v_diff_comparator1__out != 0x0);
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.PI.Limit1
    _diesel_gen1_sync_check_check_v_diff_pi_limit1__out = MIN(MAX(_diesel_gen1_sync_check_check_v_diff_pi_sum5__out, -1.0), 1.0);
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.PI.Limit1
    _diesel_gen1_control_freq_setpoint_control_pi_limit1__out = MIN(MAX(_diesel_gen1_control_freq_setpoint_control_pi_sum5__out, -10.0), 10.0);
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.LPF
    X_UnInt32 _diesel_gen2_sync_check_check_phase_diff_lpf__i;
    _diesel_gen2_sync_check_check_phase_diff_lpf__a_sum = 0.0f;
    _diesel_gen2_sync_check_check_phase_diff_lpf__b_sum = 0.0f;
    _diesel_gen2_sync_check_check_phase_diff_lpf__delay_line_in = 0.0f;
    for (_diesel_gen2_sync_check_check_phase_diff_lpf__i = 0; _diesel_gen2_sync_check_check_phase_diff_lpf__i < 1; _diesel_gen2_sync_check_check_phase_diff_lpf__i++) {
        _diesel_gen2_sync_check_check_phase_diff_lpf__b_sum += _diesel_gen2_sync_check_check_phase_diff_lpf__b_coeff[_diesel_gen2_sync_check_check_phase_diff_lpf__i + 1] * _diesel_gen2_sync_check_check_phase_diff_lpf__states[_diesel_gen2_sync_check_check_phase_diff_lpf__i];
    }
    _diesel_gen2_sync_check_check_phase_diff_lpf__a_sum += _diesel_gen2_sync_check_check_phase_diff_lpf__states[0] * _diesel_gen2_sync_check_check_phase_diff_lpf__a_coeff[1];
    _diesel_gen2_sync_check_check_phase_diff_lpf__delay_line_in = _diesel_gen2_sync_check_check_phase_diff_offset_phase__phase_out - _diesel_gen2_sync_check_check_phase_diff_lpf__a_sum;
    _diesel_gen2_sync_check_check_phase_diff_lpf__b_sum += _diesel_gen2_sync_check_check_phase_diff_lpf__b_coeff[0] * _diesel_gen2_sync_check_check_phase_diff_lpf__delay_line_in;
    _diesel_gen2_sync_check_check_phase_diff_lpf__out = _diesel_gen2_sync_check_check_phase_diff_lpf__b_sum;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.phase_diff
    HIL_OutAO(0x403a, (float)_diesel_gen2_sync_check_check_phase_diff_offset_phase__phase_out);
    // Generated from the component: Diesel_Gen2.Sync_Check.Contactor_Control.and
    _diesel_gen2_sync_check_contactor_control_and__out = _diesel_gen2_sync_check_bus_split1__out4 && _diesel_gen2_sync_check_check_phase_diff_counter_c_function__out && _diesel_gen2_sync_check_contactor_control_wait_to_trip__Trip && _diesel_gen2_sync_check_check_f_diff_comparator1__out && _diesel_gen2_sync_check_check_v_diff_comparator1__out ;
    // Generated from the component: Diesel_Gen2.Sync_Check.V_match
    HIL_OutInt32(0xf0041d, _diesel_gen2_sync_check_check_v_diff_comparator1__out != 0x0);
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.PI.Limit1
    _diesel_gen2_sync_check_check_v_diff_pi_limit1__out = MIN(MAX(_diesel_gen2_sync_check_check_v_diff_pi_sum5__out, -1.0), 1.0);
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.PI.Limit1
    _diesel_gen2_control_freq_setpoint_control_pi_limit1__out = MIN(MAX(_diesel_gen2_control_freq_setpoint_control_pi_sum5__out, -10.0), 10.0);
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.LPF
    X_UnInt32 _diesel_gen3_sync_check_check_phase_diff_lpf__i;
    _diesel_gen3_sync_check_check_phase_diff_lpf__a_sum = 0.0f;
    _diesel_gen3_sync_check_check_phase_diff_lpf__b_sum = 0.0f;
    _diesel_gen3_sync_check_check_phase_diff_lpf__delay_line_in = 0.0f;
    for (_diesel_gen3_sync_check_check_phase_diff_lpf__i = 0; _diesel_gen3_sync_check_check_phase_diff_lpf__i < 1; _diesel_gen3_sync_check_check_phase_diff_lpf__i++) {
        _diesel_gen3_sync_check_check_phase_diff_lpf__b_sum += _diesel_gen3_sync_check_check_phase_diff_lpf__b_coeff[_diesel_gen3_sync_check_check_phase_diff_lpf__i + 1] * _diesel_gen3_sync_check_check_phase_diff_lpf__states[_diesel_gen3_sync_check_check_phase_diff_lpf__i];
    }
    _diesel_gen3_sync_check_check_phase_diff_lpf__a_sum += _diesel_gen3_sync_check_check_phase_diff_lpf__states[0] * _diesel_gen3_sync_check_check_phase_diff_lpf__a_coeff[1];
    _diesel_gen3_sync_check_check_phase_diff_lpf__delay_line_in = _diesel_gen3_sync_check_check_phase_diff_offset_phase__phase_out - _diesel_gen3_sync_check_check_phase_diff_lpf__a_sum;
    _diesel_gen3_sync_check_check_phase_diff_lpf__b_sum += _diesel_gen3_sync_check_check_phase_diff_lpf__b_coeff[0] * _diesel_gen3_sync_check_check_phase_diff_lpf__delay_line_in;
    _diesel_gen3_sync_check_check_phase_diff_lpf__out = _diesel_gen3_sync_check_check_phase_diff_lpf__b_sum;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.phase_diff
    HIL_OutAO(0x405a, (float)_diesel_gen3_sync_check_check_phase_diff_offset_phase__phase_out);
    // Generated from the component: Diesel_Gen3.Sync_Check.Contactor_Control.and
    _diesel_gen3_sync_check_contactor_control_and__out = _diesel_gen3_sync_check_bus_split1__out4 && _diesel_gen3_sync_check_check_phase_diff_counter_c_function__out && _diesel_gen3_sync_check_contactor_control_wait_to_trip__Trip && _diesel_gen3_sync_check_check_f_diff_comparator1__out && _diesel_gen3_sync_check_check_v_diff_comparator1__out ;
    // Generated from the component: Diesel_Gen3.Sync_Check.V_match
    HIL_OutInt32(0xf0042d, _diesel_gen3_sync_check_check_v_diff_comparator1__out != 0x0);
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.PI.Limit1
    _diesel_gen3_sync_check_check_v_diff_pi_limit1__out = MIN(MAX(_diesel_gen3_sync_check_check_v_diff_pi_sum5__out, -1.0), 1.0);
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.PI.Limit1
    _diesel_gen3_control_freq_setpoint_control_pi_limit1__out = MIN(MAX(_diesel_gen3_control_freq_setpoint_control_pi_sum5__out, -10.0), 10.0);
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.LPF
    X_UnInt32 _diesel_gen4_sync_check_check_phase_diff_lpf__i;
    _diesel_gen4_sync_check_check_phase_diff_lpf__a_sum = 0.0f;
    _diesel_gen4_sync_check_check_phase_diff_lpf__b_sum = 0.0f;
    _diesel_gen4_sync_check_check_phase_diff_lpf__delay_line_in = 0.0f;
    for (_diesel_gen4_sync_check_check_phase_diff_lpf__i = 0; _diesel_gen4_sync_check_check_phase_diff_lpf__i < 1; _diesel_gen4_sync_check_check_phase_diff_lpf__i++) {
        _diesel_gen4_sync_check_check_phase_diff_lpf__b_sum += _diesel_gen4_sync_check_check_phase_diff_lpf__b_coeff[_diesel_gen4_sync_check_check_phase_diff_lpf__i + 1] * _diesel_gen4_sync_check_check_phase_diff_lpf__states[_diesel_gen4_sync_check_check_phase_diff_lpf__i];
    }
    _diesel_gen4_sync_check_check_phase_diff_lpf__a_sum += _diesel_gen4_sync_check_check_phase_diff_lpf__states[0] * _diesel_gen4_sync_check_check_phase_diff_lpf__a_coeff[1];
    _diesel_gen4_sync_check_check_phase_diff_lpf__delay_line_in = _diesel_gen4_sync_check_check_phase_diff_offset_phase__phase_out - _diesel_gen4_sync_check_check_phase_diff_lpf__a_sum;
    _diesel_gen4_sync_check_check_phase_diff_lpf__b_sum += _diesel_gen4_sync_check_check_phase_diff_lpf__b_coeff[0] * _diesel_gen4_sync_check_check_phase_diff_lpf__delay_line_in;
    _diesel_gen4_sync_check_check_phase_diff_lpf__out = _diesel_gen4_sync_check_check_phase_diff_lpf__b_sum;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.phase_diff
    HIL_OutAO(0x407a, (float)_diesel_gen4_sync_check_check_phase_diff_offset_phase__phase_out);
    // Generated from the component: Diesel_Gen4.Sync_Check.Contactor_Control.and
    _diesel_gen4_sync_check_contactor_control_and__out = _diesel_gen4_sync_check_bus_split1__out4 && _diesel_gen4_sync_check_check_phase_diff_counter_c_function__out && _diesel_gen4_sync_check_contactor_control_wait_to_trip__Trip && _diesel_gen4_sync_check_check_f_diff_comparator1__out && _diesel_gen4_sync_check_check_v_diff_comparator1__out ;
    // Generated from the component: Diesel_Gen4.Sync_Check.V_match
    HIL_OutInt32(0xf0043d, _diesel_gen4_sync_check_check_v_diff_comparator1__out != 0x0);
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.PI.Limit1
    _diesel_gen4_sync_check_check_v_diff_pi_limit1__out = MIN(MAX(_diesel_gen4_sync_check_check_v_diff_pi_sum5__out, -1.0), 1.0);
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.PI.Limit1
    _diesel_gen4_control_freq_setpoint_control_pi_limit1__out = MIN(MAX(_diesel_gen4_control_freq_setpoint_control_pi_sum5__out, -10.0), 10.0);
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.PI.Sum7
    _diesel_gen1_sync_check_check_phase_diff_pi_sum7__out = _diesel_gen1_sync_check_check_phase_diff_pi_ki__out + _diesel_gen1_sync_check_check_phase_diff_pi_kb__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.Calculate_dw_synch.LPF_dw
    X_UnInt32 _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__i;
    _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__a_sum = 0.0f;
    _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__b_sum = 0.0f;
    _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__delay_line_in = 0.0f;
    for (_diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__i = 0; _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__i < 1; _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__i++) {
        _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__b_sum += _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__b_coeff[_diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__i + 1] * _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__states[_diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__i];
    }
    _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__a_sum += _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__states[0] * _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__a_coeff[1];
    _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__delay_line_in = _diesel_gen1_sync_check_calculate_dw_synch_sum4__out - _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__a_sum;
    _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__b_sum += _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__b_coeff[0] * _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__delay_line_in;
    _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__out = _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__b_sum;
    // Generated from the component: Diesel_Gen1.Control.pf Control.PI.Sum7
    _diesel_gen1_control_pf_control_pi_sum7__out = _diesel_gen1_control_pf_control_pi_ki__out + _diesel_gen1_control_pf_control_pi_kb__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.PI.Sum7
    _diesel_gen2_sync_check_check_phase_diff_pi_sum7__out = _diesel_gen2_sync_check_check_phase_diff_pi_ki__out + _diesel_gen2_sync_check_check_phase_diff_pi_kb__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.Calculate_dw_synch.LPF_dw
    X_UnInt32 _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__i;
    _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__a_sum = 0.0f;
    _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__b_sum = 0.0f;
    _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__delay_line_in = 0.0f;
    for (_diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__i = 0; _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__i < 1; _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__i++) {
        _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__b_sum += _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__b_coeff[_diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__i + 1] * _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__states[_diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__i];
    }
    _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__a_sum += _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__states[0] * _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__a_coeff[1];
    _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__delay_line_in = _diesel_gen2_sync_check_calculate_dw_synch_sum4__out - _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__a_sum;
    _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__b_sum += _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__b_coeff[0] * _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__delay_line_in;
    _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__out = _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__b_sum;
    // Generated from the component: Diesel_Gen2.Control.pf Control.PI.Sum7
    _diesel_gen2_control_pf_control_pi_sum7__out = _diesel_gen2_control_pf_control_pi_ki__out + _diesel_gen2_control_pf_control_pi_kb__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.PI.Sum7
    _diesel_gen4_sync_check_check_phase_diff_pi_sum7__out = _diesel_gen4_sync_check_check_phase_diff_pi_ki__out + _diesel_gen4_sync_check_check_phase_diff_pi_kb__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.Calculate_dw_synch.LPF_dw
    X_UnInt32 _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__i;
    _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__a_sum = 0.0f;
    _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__b_sum = 0.0f;
    _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__delay_line_in = 0.0f;
    for (_diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__i = 0; _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__i < 1; _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__i++) {
        _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__b_sum += _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__b_coeff[_diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__i + 1] * _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__states[_diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__i];
    }
    _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__a_sum += _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__states[0] * _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__a_coeff[1];
    _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__delay_line_in = _diesel_gen4_sync_check_calculate_dw_synch_sum4__out - _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__a_sum;
    _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__b_sum += _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__b_coeff[0] * _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__delay_line_in;
    _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__out = _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__b_sum;
    // Generated from the component: Diesel_Gen4.Control.pf Control.PI.Sum7
    _diesel_gen4_control_pf_control_pi_sum7__out = _diesel_gen4_control_pf_control_pi_ki__out + _diesel_gen4_control_pf_control_pi_kb__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.PI.Sum7
    _diesel_gen3_sync_check_check_phase_diff_pi_sum7__out = _diesel_gen3_sync_check_check_phase_diff_pi_ki__out + _diesel_gen3_sync_check_check_phase_diff_pi_kb__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.Calculate_dw_synch.LPF_dw
    X_UnInt32 _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__i;
    _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__a_sum = 0.0f;
    _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__b_sum = 0.0f;
    _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__delay_line_in = 0.0f;
    for (_diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__i = 0; _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__i < 1; _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__i++) {
        _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__b_sum += _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__b_coeff[_diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__i + 1] * _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__states[_diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__i];
    }
    _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__a_sum += _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__states[0] * _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__a_coeff[1];
    _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__delay_line_in = _diesel_gen3_sync_check_calculate_dw_synch_sum4__out - _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__a_sum;
    _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__b_sum += _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__b_coeff[0] * _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__delay_line_in;
    _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__out = _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__b_sum;
    // Generated from the component: Diesel_Gen3.Control.pf Control.PI.Sum7
    _diesel_gen3_control_pf_control_pi_sum7__out = _diesel_gen3_control_pf_control_pi_ki__out + _diesel_gen3_control_pf_control_pi_kb__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.Contactor_Control.GCB_control
    HIL_OutInt32(0xf0040a, _diesel_gen1_sync_check_contactor_control_and__out != 0x0);
    // Generated from the component: Diesel_Gen1.Sync_Check.Contactor_Control.Signal switch1
    _diesel_gen1_sync_check_contactor_control_signal_switch1__out = (_diesel_gen1_sync_check_contactor_control_bus_split1__out1 > 0.5f) ? _diesel_gen1_sync_check_contactor_control_close__out : _diesel_gen1_sync_check_contactor_control_and__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.PI.Sum6
    _diesel_gen1_sync_check_check_v_diff_pi_sum6__out =  - _diesel_gen1_sync_check_check_v_diff_pi_sum5__out + _diesel_gen1_sync_check_check_v_diff_pi_limit1__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.Signal switch1
    _diesel_gen1_sync_check_check_v_diff_signal_switch1__out = (_diesel_gen1_sync_check_check_v_diff_unit_delay1__out > 0.5f) ? _diesel_gen1_sync_check_check_v_diff_pi_limit1__out : _diesel_gen1_sync_check_check_v_diff_zero__out;
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.PI.Sum6
    _diesel_gen1_control_freq_setpoint_control_pi_sum6__out =  - _diesel_gen1_control_freq_setpoint_control_pi_sum5__out + _diesel_gen1_control_freq_setpoint_control_pi_limit1__out;
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.mode_switch1
    _diesel_gen1_control_freq_setpoint_control_mode_switch1__out = (_diesel_gen1_control_read_op_mode__enable > 0.5f) ? _diesel_gen1_control_freq_setpoint_control_pi_limit1__out : _diesel_gen1_control_freq_setpoint_control_zero1__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.Contactor_Control.GCB_control
    HIL_OutInt32(0xf0041a, _diesel_gen2_sync_check_contactor_control_and__out != 0x0);
    // Generated from the component: Diesel_Gen2.Sync_Check.Contactor_Control.Signal switch1
    _diesel_gen2_sync_check_contactor_control_signal_switch1__out = (_diesel_gen2_sync_check_contactor_control_bus_split1__out1 > 0.5f) ? _diesel_gen2_sync_check_contactor_control_close__out : _diesel_gen2_sync_check_contactor_control_and__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.PI.Sum6
    _diesel_gen2_sync_check_check_v_diff_pi_sum6__out =  - _diesel_gen2_sync_check_check_v_diff_pi_sum5__out + _diesel_gen2_sync_check_check_v_diff_pi_limit1__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.Signal switch1
    _diesel_gen2_sync_check_check_v_diff_signal_switch1__out = (_diesel_gen2_sync_check_check_v_diff_unit_delay1__out > 0.5f) ? _diesel_gen2_sync_check_check_v_diff_pi_limit1__out : _diesel_gen2_sync_check_check_v_diff_zero__out;
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.PI.Sum6
    _diesel_gen2_control_freq_setpoint_control_pi_sum6__out =  - _diesel_gen2_control_freq_setpoint_control_pi_sum5__out + _diesel_gen2_control_freq_setpoint_control_pi_limit1__out;
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.mode_switch1
    _diesel_gen2_control_freq_setpoint_control_mode_switch1__out = (_diesel_gen2_control_read_op_mode__enable > 0.5f) ? _diesel_gen2_control_freq_setpoint_control_pi_limit1__out : _diesel_gen2_control_freq_setpoint_control_zero1__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.Contactor_Control.GCB_control
    HIL_OutInt32(0xf0042a, _diesel_gen3_sync_check_contactor_control_and__out != 0x0);
    // Generated from the component: Diesel_Gen3.Sync_Check.Contactor_Control.Signal switch1
    _diesel_gen3_sync_check_contactor_control_signal_switch1__out = (_diesel_gen3_sync_check_contactor_control_bus_split1__out1 > 0.5f) ? _diesel_gen3_sync_check_contactor_control_close__out : _diesel_gen3_sync_check_contactor_control_and__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.PI.Sum6
    _diesel_gen3_sync_check_check_v_diff_pi_sum6__out =  - _diesel_gen3_sync_check_check_v_diff_pi_sum5__out + _diesel_gen3_sync_check_check_v_diff_pi_limit1__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.Signal switch1
    _diesel_gen3_sync_check_check_v_diff_signal_switch1__out = (_diesel_gen3_sync_check_check_v_diff_unit_delay1__out > 0.5f) ? _diesel_gen3_sync_check_check_v_diff_pi_limit1__out : _diesel_gen3_sync_check_check_v_diff_zero__out;
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.PI.Sum6
    _diesel_gen3_control_freq_setpoint_control_pi_sum6__out =  - _diesel_gen3_control_freq_setpoint_control_pi_sum5__out + _diesel_gen3_control_freq_setpoint_control_pi_limit1__out;
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.mode_switch1
    _diesel_gen3_control_freq_setpoint_control_mode_switch1__out = (_diesel_gen3_control_read_op_mode__enable > 0.5f) ? _diesel_gen3_control_freq_setpoint_control_pi_limit1__out : _diesel_gen3_control_freq_setpoint_control_zero1__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.Contactor_Control.GCB_control
    HIL_OutInt32(0xf0043a, _diesel_gen4_sync_check_contactor_control_and__out != 0x0);
    // Generated from the component: Diesel_Gen4.Sync_Check.Contactor_Control.Signal switch1
    _diesel_gen4_sync_check_contactor_control_signal_switch1__out = (_diesel_gen4_sync_check_contactor_control_bus_split1__out1 > 0.5f) ? _diesel_gen4_sync_check_contactor_control_close__out : _diesel_gen4_sync_check_contactor_control_and__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.PI.Sum6
    _diesel_gen4_sync_check_check_v_diff_pi_sum6__out =  - _diesel_gen4_sync_check_check_v_diff_pi_sum5__out + _diesel_gen4_sync_check_check_v_diff_pi_limit1__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.Signal switch1
    _diesel_gen4_sync_check_check_v_diff_signal_switch1__out = (_diesel_gen4_sync_check_check_v_diff_unit_delay1__out > 0.5f) ? _diesel_gen4_sync_check_check_v_diff_pi_limit1__out : _diesel_gen4_sync_check_check_v_diff_zero__out;
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.PI.Sum6
    _diesel_gen4_control_freq_setpoint_control_pi_sum6__out =  - _diesel_gen4_control_freq_setpoint_control_pi_sum5__out + _diesel_gen4_control_freq_setpoint_control_pi_limit1__out;
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.mode_switch1
    _diesel_gen4_control_freq_setpoint_control_mode_switch1__out = (_diesel_gen4_control_read_op_mode__enable > 0.5f) ? _diesel_gen4_control_freq_setpoint_control_pi_limit1__out : _diesel_gen4_control_freq_setpoint_control_zero1__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.PI.Kb
    _diesel_gen1_sync_check_check_v_diff_pi_kb__out = 1.0 * _diesel_gen1_sync_check_check_v_diff_pi_sum6__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.Bus Join
    _diesel_gen1_sync_check_bus_join__out[0] = _diesel_gen1_sync_check_calculate_dw_synch_signal_switch1__out;
    _diesel_gen1_sync_check_bus_join__out[1] = _diesel_gen1_sync_check_contactor_control_sr_flip_flop1__out;
    _diesel_gen1_sync_check_bus_join__out[2] = _diesel_gen1_sync_check_check_v_diff_signal_switch1__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.dV
    HIL_OutAO(0x401c, (float)_diesel_gen1_sync_check_check_v_diff_signal_switch1__out);
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.PI.Kb
    _diesel_gen1_control_freq_setpoint_control_pi_kb__out = 1.0 * _diesel_gen1_control_freq_setpoint_control_pi_sum6__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.PI.Kb
    _diesel_gen2_sync_check_check_v_diff_pi_kb__out = 1.0 * _diesel_gen2_sync_check_check_v_diff_pi_sum6__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.Bus Join
    _diesel_gen2_sync_check_bus_join__out[0] = _diesel_gen2_sync_check_calculate_dw_synch_signal_switch1__out;
    _diesel_gen2_sync_check_bus_join__out[1] = _diesel_gen2_sync_check_contactor_control_sr_flip_flop1__out;
    _diesel_gen2_sync_check_bus_join__out[2] = _diesel_gen2_sync_check_check_v_diff_signal_switch1__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.dV
    HIL_OutAO(0x403c, (float)_diesel_gen2_sync_check_check_v_diff_signal_switch1__out);
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.PI.Kb
    _diesel_gen2_control_freq_setpoint_control_pi_kb__out = 1.0 * _diesel_gen2_control_freq_setpoint_control_pi_sum6__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.PI.Kb
    _diesel_gen3_sync_check_check_v_diff_pi_kb__out = 1.0 * _diesel_gen3_sync_check_check_v_diff_pi_sum6__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.Bus Join
    _diesel_gen3_sync_check_bus_join__out[0] = _diesel_gen3_sync_check_calculate_dw_synch_signal_switch1__out;
    _diesel_gen3_sync_check_bus_join__out[1] = _diesel_gen3_sync_check_contactor_control_sr_flip_flop1__out;
    _diesel_gen3_sync_check_bus_join__out[2] = _diesel_gen3_sync_check_check_v_diff_signal_switch1__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.dV
    HIL_OutAO(0x405c, (float)_diesel_gen3_sync_check_check_v_diff_signal_switch1__out);
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.PI.Kb
    _diesel_gen3_control_freq_setpoint_control_pi_kb__out = 1.0 * _diesel_gen3_control_freq_setpoint_control_pi_sum6__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.PI.Kb
    _diesel_gen4_sync_check_check_v_diff_pi_kb__out = 1.0 * _diesel_gen4_sync_check_check_v_diff_pi_sum6__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.Bus Join
    _diesel_gen4_sync_check_bus_join__out[0] = _diesel_gen4_sync_check_calculate_dw_synch_signal_switch1__out;
    _diesel_gen4_sync_check_bus_join__out[1] = _diesel_gen4_sync_check_contactor_control_sr_flip_flop1__out;
    _diesel_gen4_sync_check_bus_join__out[2] = _diesel_gen4_sync_check_check_v_diff_signal_switch1__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.dV
    HIL_OutAO(0x407c, (float)_diesel_gen4_sync_check_check_v_diff_signal_switch1__out);
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.PI.Kb
    _diesel_gen4_control_freq_setpoint_control_pi_kb__out = 1.0 * _diesel_gen4_control_freq_setpoint_control_pi_sum6__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.PI.Sum7
    _diesel_gen1_sync_check_check_v_diff_pi_sum7__out = _diesel_gen1_sync_check_check_v_diff_pi_ki__out + _diesel_gen1_sync_check_check_v_diff_pi_kb__out;
    // Generated from the component: Diesel_Gen1.Control.Bus Split2
    _diesel_gen1_control_bus_split2__out = _diesel_gen1_sync_check_bus_join__out[0];
    _diesel_gen1_control_bus_split2__out1 = _diesel_gen1_sync_check_bus_join__out[1];
    _diesel_gen1_control_bus_split2__out2 = _diesel_gen1_sync_check_bus_join__out[2];
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.PI.Sum7
    _diesel_gen1_control_freq_setpoint_control_pi_sum7__out = _diesel_gen1_control_freq_setpoint_control_pi_ki__out + _diesel_gen1_control_freq_setpoint_control_pi_kb__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.PI.Sum7
    _diesel_gen2_sync_check_check_v_diff_pi_sum7__out = _diesel_gen2_sync_check_check_v_diff_pi_ki__out + _diesel_gen2_sync_check_check_v_diff_pi_kb__out;
    // Generated from the component: Diesel_Gen2.Control.Bus Split2
    _diesel_gen2_control_bus_split2__out = _diesel_gen2_sync_check_bus_join__out[0];
    _diesel_gen2_control_bus_split2__out1 = _diesel_gen2_sync_check_bus_join__out[1];
    _diesel_gen2_control_bus_split2__out2 = _diesel_gen2_sync_check_bus_join__out[2];
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.PI.Sum7
    _diesel_gen2_control_freq_setpoint_control_pi_sum7__out = _diesel_gen2_control_freq_setpoint_control_pi_ki__out + _diesel_gen2_control_freq_setpoint_control_pi_kb__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.PI.Sum7
    _diesel_gen3_sync_check_check_v_diff_pi_sum7__out = _diesel_gen3_sync_check_check_v_diff_pi_ki__out + _diesel_gen3_sync_check_check_v_diff_pi_kb__out;
    // Generated from the component: Diesel_Gen3.Control.Bus Split2
    _diesel_gen3_control_bus_split2__out = _diesel_gen3_sync_check_bus_join__out[0];
    _diesel_gen3_control_bus_split2__out1 = _diesel_gen3_sync_check_bus_join__out[1];
    _diesel_gen3_control_bus_split2__out2 = _diesel_gen3_sync_check_bus_join__out[2];
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.PI.Sum7
    _diesel_gen3_control_freq_setpoint_control_pi_sum7__out = _diesel_gen3_control_freq_setpoint_control_pi_ki__out + _diesel_gen3_control_freq_setpoint_control_pi_kb__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.PI.Sum7
    _diesel_gen4_sync_check_check_v_diff_pi_sum7__out = _diesel_gen4_sync_check_check_v_diff_pi_ki__out + _diesel_gen4_sync_check_check_v_diff_pi_kb__out;
    // Generated from the component: Diesel_Gen4.Control.Bus Split2
    _diesel_gen4_control_bus_split2__out = _diesel_gen4_sync_check_bus_join__out[0];
    _diesel_gen4_control_bus_split2__out1 = _diesel_gen4_sync_check_bus_join__out[1];
    _diesel_gen4_control_bus_split2__out2 = _diesel_gen4_sync_check_bus_join__out[2];
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.PI.Sum7
    _diesel_gen4_control_freq_setpoint_control_pi_sum7__out = _diesel_gen4_control_freq_setpoint_control_pi_ki__out + _diesel_gen4_control_freq_setpoint_control_pi_kb__out;
    // Generated from the component: Diesel_Gen1.Control.Exciter.Sum
    _diesel_gen1_control_exciter_sum__out = _diesel_gen1_control_exciter_rate_limit__out + _diesel_gen1_control_pf_control_signal_switch4__out + _diesel_gen1_control_bus_split2__out2;
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.Sum5
    _diesel_gen1_control_governor_and_engine_sum5__out = _diesel_gen1_control_governor_and_engine_w_ramp__out + _diesel_gen1_control_freq_setpoint_control_mode_switch1__out + _diesel_gen1_control_bus_split2__out;
    // Generated from the component: Diesel_Gen2.Control.Exciter.Sum
    _diesel_gen2_control_exciter_sum__out = _diesel_gen2_control_exciter_rate_limit__out + _diesel_gen2_control_pf_control_signal_switch4__out + _diesel_gen2_control_bus_split2__out2;
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.Sum5
    _diesel_gen2_control_governor_and_engine_sum5__out = _diesel_gen2_control_governor_and_engine_w_ramp__out + _diesel_gen2_control_freq_setpoint_control_mode_switch1__out + _diesel_gen2_control_bus_split2__out;
    // Generated from the component: Diesel_Gen3.Control.Exciter.Sum
    _diesel_gen3_control_exciter_sum__out = _diesel_gen3_control_exciter_rate_limit__out + _diesel_gen3_control_pf_control_signal_switch4__out + _diesel_gen3_control_bus_split2__out2;
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.Sum5
    _diesel_gen3_control_governor_and_engine_sum5__out = _diesel_gen3_control_governor_and_engine_w_ramp__out + _diesel_gen3_control_freq_setpoint_control_mode_switch1__out + _diesel_gen3_control_bus_split2__out;
    // Generated from the component: Diesel_Gen4.Control.Exciter.Sum
    _diesel_gen4_control_exciter_sum__out = _diesel_gen4_control_exciter_rate_limit__out + _diesel_gen4_control_pf_control_signal_switch4__out + _diesel_gen4_control_bus_split2__out2;
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.Sum5
    _diesel_gen4_control_governor_and_engine_sum5__out = _diesel_gen4_control_governor_and_engine_w_ramp__out + _diesel_gen4_control_freq_setpoint_control_mode_switch1__out + _diesel_gen4_control_bus_split2__out;
    // Generated from the component: Diesel_Gen1.Control.Exciter.Sum2
    _diesel_gen1_control_exciter_sum2__out = _diesel_gen1_control_exciter_sum__out - _diesel_gen1_control_exciter_product2__out;
    // Generated from the component: Diesel_Gen1.Control.Exciter.V_ref
    HIL_OutAO(0x4001, (float)_diesel_gen1_control_exciter_sum__out);
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.Sum4
    _diesel_gen1_control_governor_and_engine_sum4__out = _diesel_gen1_control_governor_and_engine_sum5__out - _diesel_gen1_control_governor_and_engine_w_to_wpu__out - _diesel_gen1_control_governor_and_engine_w_switch1__out;
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.wref
    HIL_OutAO(0x4009, (float)_diesel_gen1_control_governor_and_engine_sum5__out);
    // Generated from the component: Diesel_Gen2.Control.Exciter.Sum2
    _diesel_gen2_control_exciter_sum2__out = _diesel_gen2_control_exciter_sum__out - _diesel_gen2_control_exciter_product2__out;
    // Generated from the component: Diesel_Gen2.Control.Exciter.V_ref
    HIL_OutAO(0x4021, (float)_diesel_gen2_control_exciter_sum__out);
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.Sum4
    _diesel_gen2_control_governor_and_engine_sum4__out = _diesel_gen2_control_governor_and_engine_sum5__out - _diesel_gen2_control_governor_and_engine_w_to_wpu__out - _diesel_gen2_control_governor_and_engine_w_switch1__out;
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.wref
    HIL_OutAO(0x4029, (float)_diesel_gen2_control_governor_and_engine_sum5__out);
    // Generated from the component: Diesel_Gen3.Control.Exciter.Sum2
    _diesel_gen3_control_exciter_sum2__out = _diesel_gen3_control_exciter_sum__out - _diesel_gen3_control_exciter_product2__out;
    // Generated from the component: Diesel_Gen3.Control.Exciter.V_ref
    HIL_OutAO(0x4041, (float)_diesel_gen3_control_exciter_sum__out);
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.Sum4
    _diesel_gen3_control_governor_and_engine_sum4__out = _diesel_gen3_control_governor_and_engine_sum5__out - _diesel_gen3_control_governor_and_engine_w_to_wpu__out - _diesel_gen3_control_governor_and_engine_w_switch1__out;
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.wref
    HIL_OutAO(0x4049, (float)_diesel_gen3_control_governor_and_engine_sum5__out);
    // Generated from the component: Diesel_Gen4.Control.Exciter.Sum2
    _diesel_gen4_control_exciter_sum2__out = _diesel_gen4_control_exciter_sum__out - _diesel_gen4_control_exciter_product2__out;
    // Generated from the component: Diesel_Gen4.Control.Exciter.V_ref
    HIL_OutAO(0x4061, (float)_diesel_gen4_control_exciter_sum__out);
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.Sum4
    _diesel_gen4_control_governor_and_engine_sum4__out = _diesel_gen4_control_governor_and_engine_sum5__out - _diesel_gen4_control_governor_and_engine_w_to_wpu__out - _diesel_gen4_control_governor_and_engine_w_switch1__out;
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.wref
    HIL_OutAO(0x4069, (float)_diesel_gen4_control_governor_and_engine_sum5__out);
    // Generated from the component: Diesel_Gen1.Control.Exciter.DC4B.Sum1
    _diesel_gen1_control_exciter_dc4b_sum1__out = _diesel_gen1_control_exciter_sum1__out + _diesel_gen1_control_exciter_sum2__out - _diesel_gen1_control_exciter_dc4b_tf1__out;
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.DEGOV.TF1
    X_UnInt32 _diesel_gen1_control_governor_and_engine_degov_tf1__i;
    _diesel_gen1_control_governor_and_engine_degov_tf1__a_sum = 0.0f;
    _diesel_gen1_control_governor_and_engine_degov_tf1__b_sum = 0.0f;
    _diesel_gen1_control_governor_and_engine_degov_tf1__delay_line_in = 0.0f;
    for (_diesel_gen1_control_governor_and_engine_degov_tf1__i = 0; _diesel_gen1_control_governor_and_engine_degov_tf1__i < 2; _diesel_gen1_control_governor_and_engine_degov_tf1__i++) {
        _diesel_gen1_control_governor_and_engine_degov_tf1__b_sum += _diesel_gen1_control_governor_and_engine_degov_tf1__b_coeff[_diesel_gen1_control_governor_and_engine_degov_tf1__i + 1] * _diesel_gen1_control_governor_and_engine_degov_tf1__states[_diesel_gen1_control_governor_and_engine_degov_tf1__i];
    }
    for (_diesel_gen1_control_governor_and_engine_degov_tf1__i = 1; _diesel_gen1_control_governor_and_engine_degov_tf1__i > 0; _diesel_gen1_control_governor_and_engine_degov_tf1__i--) {
        _diesel_gen1_control_governor_and_engine_degov_tf1__a_sum += _diesel_gen1_control_governor_and_engine_degov_tf1__a_coeff[_diesel_gen1_control_governor_and_engine_degov_tf1__i + 1] * _diesel_gen1_control_governor_and_engine_degov_tf1__states[_diesel_gen1_control_governor_and_engine_degov_tf1__i];
    }
    _diesel_gen1_control_governor_and_engine_degov_tf1__a_sum += _diesel_gen1_control_governor_and_engine_degov_tf1__states[0] * _diesel_gen1_control_governor_and_engine_degov_tf1__a_coeff[1];
    _diesel_gen1_control_governor_and_engine_degov_tf1__delay_line_in = _diesel_gen1_control_governor_and_engine_sum4__out - _diesel_gen1_control_governor_and_engine_degov_tf1__a_sum;
    _diesel_gen1_control_governor_and_engine_degov_tf1__b_sum += _diesel_gen1_control_governor_and_engine_degov_tf1__b_coeff[0] * _diesel_gen1_control_governor_and_engine_degov_tf1__delay_line_in;
    _diesel_gen1_control_governor_and_engine_degov_tf1__out = _diesel_gen1_control_governor_and_engine_degov_tf1__b_sum;
    // Generated from the component: Diesel_Gen2.Control.Exciter.DC4B.Sum1
    _diesel_gen2_control_exciter_dc4b_sum1__out = _diesel_gen2_control_exciter_sum1__out + _diesel_gen2_control_exciter_sum2__out - _diesel_gen2_control_exciter_dc4b_tf1__out;
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.DEGOV.TF1
    X_UnInt32 _diesel_gen2_control_governor_and_engine_degov_tf1__i;
    _diesel_gen2_control_governor_and_engine_degov_tf1__a_sum = 0.0f;
    _diesel_gen2_control_governor_and_engine_degov_tf1__b_sum = 0.0f;
    _diesel_gen2_control_governor_and_engine_degov_tf1__delay_line_in = 0.0f;
    for (_diesel_gen2_control_governor_and_engine_degov_tf1__i = 0; _diesel_gen2_control_governor_and_engine_degov_tf1__i < 2; _diesel_gen2_control_governor_and_engine_degov_tf1__i++) {
        _diesel_gen2_control_governor_and_engine_degov_tf1__b_sum += _diesel_gen2_control_governor_and_engine_degov_tf1__b_coeff[_diesel_gen2_control_governor_and_engine_degov_tf1__i + 1] * _diesel_gen2_control_governor_and_engine_degov_tf1__states[_diesel_gen2_control_governor_and_engine_degov_tf1__i];
    }
    for (_diesel_gen2_control_governor_and_engine_degov_tf1__i = 1; _diesel_gen2_control_governor_and_engine_degov_tf1__i > 0; _diesel_gen2_control_governor_and_engine_degov_tf1__i--) {
        _diesel_gen2_control_governor_and_engine_degov_tf1__a_sum += _diesel_gen2_control_governor_and_engine_degov_tf1__a_coeff[_diesel_gen2_control_governor_and_engine_degov_tf1__i + 1] * _diesel_gen2_control_governor_and_engine_degov_tf1__states[_diesel_gen2_control_governor_and_engine_degov_tf1__i];
    }
    _diesel_gen2_control_governor_and_engine_degov_tf1__a_sum += _diesel_gen2_control_governor_and_engine_degov_tf1__states[0] * _diesel_gen2_control_governor_and_engine_degov_tf1__a_coeff[1];
    _diesel_gen2_control_governor_and_engine_degov_tf1__delay_line_in = _diesel_gen2_control_governor_and_engine_sum4__out - _diesel_gen2_control_governor_and_engine_degov_tf1__a_sum;
    _diesel_gen2_control_governor_and_engine_degov_tf1__b_sum += _diesel_gen2_control_governor_and_engine_degov_tf1__b_coeff[0] * _diesel_gen2_control_governor_and_engine_degov_tf1__delay_line_in;
    _diesel_gen2_control_governor_and_engine_degov_tf1__out = _diesel_gen2_control_governor_and_engine_degov_tf1__b_sum;
    // Generated from the component: Diesel_Gen3.Control.Exciter.DC4B.Sum1
    _diesel_gen3_control_exciter_dc4b_sum1__out = _diesel_gen3_control_exciter_sum1__out + _diesel_gen3_control_exciter_sum2__out - _diesel_gen3_control_exciter_dc4b_tf1__out;
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.DEGOV.TF1
    X_UnInt32 _diesel_gen3_control_governor_and_engine_degov_tf1__i;
    _diesel_gen3_control_governor_and_engine_degov_tf1__a_sum = 0.0f;
    _diesel_gen3_control_governor_and_engine_degov_tf1__b_sum = 0.0f;
    _diesel_gen3_control_governor_and_engine_degov_tf1__delay_line_in = 0.0f;
    for (_diesel_gen3_control_governor_and_engine_degov_tf1__i = 0; _diesel_gen3_control_governor_and_engine_degov_tf1__i < 2; _diesel_gen3_control_governor_and_engine_degov_tf1__i++) {
        _diesel_gen3_control_governor_and_engine_degov_tf1__b_sum += _diesel_gen3_control_governor_and_engine_degov_tf1__b_coeff[_diesel_gen3_control_governor_and_engine_degov_tf1__i + 1] * _diesel_gen3_control_governor_and_engine_degov_tf1__states[_diesel_gen3_control_governor_and_engine_degov_tf1__i];
    }
    for (_diesel_gen3_control_governor_and_engine_degov_tf1__i = 1; _diesel_gen3_control_governor_and_engine_degov_tf1__i > 0; _diesel_gen3_control_governor_and_engine_degov_tf1__i--) {
        _diesel_gen3_control_governor_and_engine_degov_tf1__a_sum += _diesel_gen3_control_governor_and_engine_degov_tf1__a_coeff[_diesel_gen3_control_governor_and_engine_degov_tf1__i + 1] * _diesel_gen3_control_governor_and_engine_degov_tf1__states[_diesel_gen3_control_governor_and_engine_degov_tf1__i];
    }
    _diesel_gen3_control_governor_and_engine_degov_tf1__a_sum += _diesel_gen3_control_governor_and_engine_degov_tf1__states[0] * _diesel_gen3_control_governor_and_engine_degov_tf1__a_coeff[1];
    _diesel_gen3_control_governor_and_engine_degov_tf1__delay_line_in = _diesel_gen3_control_governor_and_engine_sum4__out - _diesel_gen3_control_governor_and_engine_degov_tf1__a_sum;
    _diesel_gen3_control_governor_and_engine_degov_tf1__b_sum += _diesel_gen3_control_governor_and_engine_degov_tf1__b_coeff[0] * _diesel_gen3_control_governor_and_engine_degov_tf1__delay_line_in;
    _diesel_gen3_control_governor_and_engine_degov_tf1__out = _diesel_gen3_control_governor_and_engine_degov_tf1__b_sum;
    // Generated from the component: Diesel_Gen4.Control.Exciter.DC4B.Sum1
    _diesel_gen4_control_exciter_dc4b_sum1__out = _diesel_gen4_control_exciter_sum1__out + _diesel_gen4_control_exciter_sum2__out - _diesel_gen4_control_exciter_dc4b_tf1__out;
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.DEGOV.TF1
    X_UnInt32 _diesel_gen4_control_governor_and_engine_degov_tf1__i;
    _diesel_gen4_control_governor_and_engine_degov_tf1__a_sum = 0.0f;
    _diesel_gen4_control_governor_and_engine_degov_tf1__b_sum = 0.0f;
    _diesel_gen4_control_governor_and_engine_degov_tf1__delay_line_in = 0.0f;
    for (_diesel_gen4_control_governor_and_engine_degov_tf1__i = 0; _diesel_gen4_control_governor_and_engine_degov_tf1__i < 2; _diesel_gen4_control_governor_and_engine_degov_tf1__i++) {
        _diesel_gen4_control_governor_and_engine_degov_tf1__b_sum += _diesel_gen4_control_governor_and_engine_degov_tf1__b_coeff[_diesel_gen4_control_governor_and_engine_degov_tf1__i + 1] * _diesel_gen4_control_governor_and_engine_degov_tf1__states[_diesel_gen4_control_governor_and_engine_degov_tf1__i];
    }
    for (_diesel_gen4_control_governor_and_engine_degov_tf1__i = 1; _diesel_gen4_control_governor_and_engine_degov_tf1__i > 0; _diesel_gen4_control_governor_and_engine_degov_tf1__i--) {
        _diesel_gen4_control_governor_and_engine_degov_tf1__a_sum += _diesel_gen4_control_governor_and_engine_degov_tf1__a_coeff[_diesel_gen4_control_governor_and_engine_degov_tf1__i + 1] * _diesel_gen4_control_governor_and_engine_degov_tf1__states[_diesel_gen4_control_governor_and_engine_degov_tf1__i];
    }
    _diesel_gen4_control_governor_and_engine_degov_tf1__a_sum += _diesel_gen4_control_governor_and_engine_degov_tf1__states[0] * _diesel_gen4_control_governor_and_engine_degov_tf1__a_coeff[1];
    _diesel_gen4_control_governor_and_engine_degov_tf1__delay_line_in = _diesel_gen4_control_governor_and_engine_sum4__out - _diesel_gen4_control_governor_and_engine_degov_tf1__a_sum;
    _diesel_gen4_control_governor_and_engine_degov_tf1__b_sum += _diesel_gen4_control_governor_and_engine_degov_tf1__b_coeff[0] * _diesel_gen4_control_governor_and_engine_degov_tf1__delay_line_in;
    _diesel_gen4_control_governor_and_engine_degov_tf1__out = _diesel_gen4_control_governor_and_engine_degov_tf1__b_sum;
    // Generated from the component: Diesel_Gen1.Control.Exciter.DC4B.Sum2
    _diesel_gen1_control_exciter_dc4b_sum2__out =  - _diesel_gen1_control_exciter_dc4b_tf4__out + _diesel_gen1_control_exciter_dc4b_sum1__out;
    // Generated from the component: Diesel_Gen2.Control.Exciter.DC4B.Sum2
    _diesel_gen2_control_exciter_dc4b_sum2__out =  - _diesel_gen2_control_exciter_dc4b_tf4__out + _diesel_gen2_control_exciter_dc4b_sum1__out;
    // Generated from the component: Diesel_Gen3.Control.Exciter.DC4B.Sum2
    _diesel_gen3_control_exciter_dc4b_sum2__out =  - _diesel_gen3_control_exciter_dc4b_tf4__out + _diesel_gen3_control_exciter_dc4b_sum1__out;
    // Generated from the component: Diesel_Gen4.Control.Exciter.DC4B.Sum2
    _diesel_gen4_control_exciter_dc4b_sum2__out =  - _diesel_gen4_control_exciter_dc4b_tf4__out + _diesel_gen4_control_exciter_dc4b_sum1__out;
    // Generated from the component: Diesel_Gen1.Control.Exciter.DC4B.PI.Ki
    _diesel_gen1_control_exciter_dc4b_pi_ki__out = 0.007 * _diesel_gen1_control_exciter_dc4b_sum2__out;
    // Generated from the component: Diesel_Gen1.Control.Exciter.DC4B.PI.Kp
    _diesel_gen1_control_exciter_dc4b_pi_kp__out = 0.025 * _diesel_gen1_control_exciter_dc4b_sum2__out;
    // Generated from the component: Diesel_Gen2.Control.Exciter.DC4B.PI.Ki
    _diesel_gen2_control_exciter_dc4b_pi_ki__out = 0.007 * _diesel_gen2_control_exciter_dc4b_sum2__out;
    // Generated from the component: Diesel_Gen2.Control.Exciter.DC4B.PI.Kp
    _diesel_gen2_control_exciter_dc4b_pi_kp__out = 0.025 * _diesel_gen2_control_exciter_dc4b_sum2__out;
    // Generated from the component: Diesel_Gen3.Control.Exciter.DC4B.PI.Ki
    _diesel_gen3_control_exciter_dc4b_pi_ki__out = 0.007 * _diesel_gen3_control_exciter_dc4b_sum2__out;
    // Generated from the component: Diesel_Gen3.Control.Exciter.DC4B.PI.Kp
    _diesel_gen3_control_exciter_dc4b_pi_kp__out = 0.025 * _diesel_gen3_control_exciter_dc4b_sum2__out;
    // Generated from the component: Diesel_Gen4.Control.Exciter.DC4B.PI.Ki
    _diesel_gen4_control_exciter_dc4b_pi_ki__out = 0.007 * _diesel_gen4_control_exciter_dc4b_sum2__out;
    // Generated from the component: Diesel_Gen4.Control.Exciter.DC4B.PI.Kp
    _diesel_gen4_control_exciter_dc4b_pi_kp__out = 0.025 * _diesel_gen4_control_exciter_dc4b_sum2__out;
    // Generated from the component: Diesel_Gen1.Control.Exciter.DC4B.PI.Sum5
    _diesel_gen1_control_exciter_dc4b_pi_sum5__out = _diesel_gen1_control_exciter_dc4b_pi_kp__out + _diesel_gen1_control_exciter_dc4b_pi_integrator1__out;
    // Generated from the component: Diesel_Gen2.Control.Exciter.DC4B.PI.Sum5
    _diesel_gen2_control_exciter_dc4b_pi_sum5__out = _diesel_gen2_control_exciter_dc4b_pi_kp__out + _diesel_gen2_control_exciter_dc4b_pi_integrator1__out;
    // Generated from the component: Diesel_Gen3.Control.Exciter.DC4B.PI.Sum5
    _diesel_gen3_control_exciter_dc4b_pi_sum5__out = _diesel_gen3_control_exciter_dc4b_pi_kp__out + _diesel_gen3_control_exciter_dc4b_pi_integrator1__out;
    // Generated from the component: Diesel_Gen4.Control.Exciter.DC4B.PI.Sum5
    _diesel_gen4_control_exciter_dc4b_pi_sum5__out = _diesel_gen4_control_exciter_dc4b_pi_kp__out + _diesel_gen4_control_exciter_dc4b_pi_integrator1__out;
    // Generated from the component: Diesel_Gen1.Control.Exciter.DC4B.PI.Limit1
    _diesel_gen1_control_exciter_dc4b_pi_limit1__out = MIN(MAX(_diesel_gen1_control_exciter_dc4b_pi_sum5__out, -10.0), 10.0);
    // Generated from the component: Diesel_Gen2.Control.Exciter.DC4B.PI.Limit1
    _diesel_gen2_control_exciter_dc4b_pi_limit1__out = MIN(MAX(_diesel_gen2_control_exciter_dc4b_pi_sum5__out, -10.0), 10.0);
    // Generated from the component: Diesel_Gen3.Control.Exciter.DC4B.PI.Limit1
    _diesel_gen3_control_exciter_dc4b_pi_limit1__out = MIN(MAX(_diesel_gen3_control_exciter_dc4b_pi_sum5__out, -10.0), 10.0);
    // Generated from the component: Diesel_Gen4.Control.Exciter.DC4B.PI.Limit1
    _diesel_gen4_control_exciter_dc4b_pi_limit1__out = MIN(MAX(_diesel_gen4_control_exciter_dc4b_pi_sum5__out, -10.0), 10.0);
    // Generated from the component: Diesel_Gen1.Control.Exciter.DC4B.PI.Sum6
    _diesel_gen1_control_exciter_dc4b_pi_sum6__out =  - _diesel_gen1_control_exciter_dc4b_pi_sum5__out + _diesel_gen1_control_exciter_dc4b_pi_limit1__out;
    // Generated from the component: Diesel_Gen1.Control.Exciter.DC4B.Product1
    _diesel_gen1_control_exciter_dc4b_product1__out = (_diesel_gen1_control_exciter_dc4b_pi_limit1__out * _diesel_gen1_control_exciter_dc4b_switch__out);
    // Generated from the component: Diesel_Gen2.Control.Exciter.DC4B.PI.Sum6
    _diesel_gen2_control_exciter_dc4b_pi_sum6__out =  - _diesel_gen2_control_exciter_dc4b_pi_sum5__out + _diesel_gen2_control_exciter_dc4b_pi_limit1__out;
    // Generated from the component: Diesel_Gen2.Control.Exciter.DC4B.Product1
    _diesel_gen2_control_exciter_dc4b_product1__out = (_diesel_gen2_control_exciter_dc4b_pi_limit1__out * _diesel_gen2_control_exciter_dc4b_switch__out);
    // Generated from the component: Diesel_Gen3.Control.Exciter.DC4B.PI.Sum6
    _diesel_gen3_control_exciter_dc4b_pi_sum6__out =  - _diesel_gen3_control_exciter_dc4b_pi_sum5__out + _diesel_gen3_control_exciter_dc4b_pi_limit1__out;
    // Generated from the component: Diesel_Gen3.Control.Exciter.DC4B.Product1
    _diesel_gen3_control_exciter_dc4b_product1__out = (_diesel_gen3_control_exciter_dc4b_pi_limit1__out * _diesel_gen3_control_exciter_dc4b_switch__out);
    // Generated from the component: Diesel_Gen4.Control.Exciter.DC4B.PI.Sum6
    _diesel_gen4_control_exciter_dc4b_pi_sum6__out =  - _diesel_gen4_control_exciter_dc4b_pi_sum5__out + _diesel_gen4_control_exciter_dc4b_pi_limit1__out;
    // Generated from the component: Diesel_Gen4.Control.Exciter.DC4B.Product1
    _diesel_gen4_control_exciter_dc4b_product1__out = (_diesel_gen4_control_exciter_dc4b_pi_limit1__out * _diesel_gen4_control_exciter_dc4b_switch__out);
    // Generated from the component: Diesel_Gen1.Control.Exciter.DC4B.PI.Kb
    _diesel_gen1_control_exciter_dc4b_pi_kb__out = 1.0 * _diesel_gen1_control_exciter_dc4b_pi_sum6__out;
    // Generated from the component: Diesel_Gen1.Control.Exciter.DC4B.KA
    _diesel_gen1_control_exciter_dc4b_ka__out = 1.0 * _diesel_gen1_control_exciter_dc4b_product1__out;
    // Generated from the component: Diesel_Gen1.Control.Exciter.DC4B.Va
    HIL_OutAO(0x4000, (float)_diesel_gen1_control_exciter_dc4b_product1__out);
    // Generated from the component: Diesel_Gen2.Control.Exciter.DC4B.PI.Kb
    _diesel_gen2_control_exciter_dc4b_pi_kb__out = 1.0 * _diesel_gen2_control_exciter_dc4b_pi_sum6__out;
    // Generated from the component: Diesel_Gen2.Control.Exciter.DC4B.KA
    _diesel_gen2_control_exciter_dc4b_ka__out = 1.0 * _diesel_gen2_control_exciter_dc4b_product1__out;
    // Generated from the component: Diesel_Gen2.Control.Exciter.DC4B.Va
    HIL_OutAO(0x4020, (float)_diesel_gen2_control_exciter_dc4b_product1__out);
    // Generated from the component: Diesel_Gen3.Control.Exciter.DC4B.PI.Kb
    _diesel_gen3_control_exciter_dc4b_pi_kb__out = 1.0 * _diesel_gen3_control_exciter_dc4b_pi_sum6__out;
    // Generated from the component: Diesel_Gen3.Control.Exciter.DC4B.KA
    _diesel_gen3_control_exciter_dc4b_ka__out = 1.0 * _diesel_gen3_control_exciter_dc4b_product1__out;
    // Generated from the component: Diesel_Gen3.Control.Exciter.DC4B.Va
    HIL_OutAO(0x4040, (float)_diesel_gen3_control_exciter_dc4b_product1__out);
    // Generated from the component: Diesel_Gen4.Control.Exciter.DC4B.PI.Kb
    _diesel_gen4_control_exciter_dc4b_pi_kb__out = 1.0 * _diesel_gen4_control_exciter_dc4b_pi_sum6__out;
    // Generated from the component: Diesel_Gen4.Control.Exciter.DC4B.KA
    _diesel_gen4_control_exciter_dc4b_ka__out = 1.0 * _diesel_gen4_control_exciter_dc4b_product1__out;
    // Generated from the component: Diesel_Gen4.Control.Exciter.DC4B.Va
    HIL_OutAO(0x4060, (float)_diesel_gen4_control_exciter_dc4b_product1__out);
    // Generated from the component: Diesel_Gen1.Control.Exciter.DC4B.PI.Sum7
    _diesel_gen1_control_exciter_dc4b_pi_sum7__out = _diesel_gen1_control_exciter_dc4b_pi_ki__out + _diesel_gen1_control_exciter_dc4b_pi_kb__out;
    // Generated from the component: Diesel_Gen1.Control.Exciter.DC4B.TF2
    X_UnInt32 _diesel_gen1_control_exciter_dc4b_tf2__i;
    _diesel_gen1_control_exciter_dc4b_tf2__a_sum = 0.0f;
    _diesel_gen1_control_exciter_dc4b_tf2__b_sum = 0.0f;
    _diesel_gen1_control_exciter_dc4b_tf2__delay_line_in = 0.0f;
    for (_diesel_gen1_control_exciter_dc4b_tf2__i = 0; _diesel_gen1_control_exciter_dc4b_tf2__i < 1; _diesel_gen1_control_exciter_dc4b_tf2__i++) {
        _diesel_gen1_control_exciter_dc4b_tf2__b_sum += _diesel_gen1_control_exciter_dc4b_tf2__b_coeff[_diesel_gen1_control_exciter_dc4b_tf2__i + 1] * _diesel_gen1_control_exciter_dc4b_tf2__states[_diesel_gen1_control_exciter_dc4b_tf2__i];
    }
    _diesel_gen1_control_exciter_dc4b_tf2__a_sum += _diesel_gen1_control_exciter_dc4b_tf2__states[0] * _diesel_gen1_control_exciter_dc4b_tf2__a_coeff[1];
    _diesel_gen1_control_exciter_dc4b_tf2__delay_line_in = _diesel_gen1_control_exciter_dc4b_ka__out - _diesel_gen1_control_exciter_dc4b_tf2__a_sum;
    _diesel_gen1_control_exciter_dc4b_tf2__b_sum += _diesel_gen1_control_exciter_dc4b_tf2__b_coeff[0] * _diesel_gen1_control_exciter_dc4b_tf2__delay_line_in;
    _diesel_gen1_control_exciter_dc4b_tf2__out = _diesel_gen1_control_exciter_dc4b_tf2__b_sum;
    // Generated from the component: Diesel_Gen2.Control.Exciter.DC4B.PI.Sum7
    _diesel_gen2_control_exciter_dc4b_pi_sum7__out = _diesel_gen2_control_exciter_dc4b_pi_ki__out + _diesel_gen2_control_exciter_dc4b_pi_kb__out;
    // Generated from the component: Diesel_Gen2.Control.Exciter.DC4B.TF2
    X_UnInt32 _diesel_gen2_control_exciter_dc4b_tf2__i;
    _diesel_gen2_control_exciter_dc4b_tf2__a_sum = 0.0f;
    _diesel_gen2_control_exciter_dc4b_tf2__b_sum = 0.0f;
    _diesel_gen2_control_exciter_dc4b_tf2__delay_line_in = 0.0f;
    for (_diesel_gen2_control_exciter_dc4b_tf2__i = 0; _diesel_gen2_control_exciter_dc4b_tf2__i < 1; _diesel_gen2_control_exciter_dc4b_tf2__i++) {
        _diesel_gen2_control_exciter_dc4b_tf2__b_sum += _diesel_gen2_control_exciter_dc4b_tf2__b_coeff[_diesel_gen2_control_exciter_dc4b_tf2__i + 1] * _diesel_gen2_control_exciter_dc4b_tf2__states[_diesel_gen2_control_exciter_dc4b_tf2__i];
    }
    _diesel_gen2_control_exciter_dc4b_tf2__a_sum += _diesel_gen2_control_exciter_dc4b_tf2__states[0] * _diesel_gen2_control_exciter_dc4b_tf2__a_coeff[1];
    _diesel_gen2_control_exciter_dc4b_tf2__delay_line_in = _diesel_gen2_control_exciter_dc4b_ka__out - _diesel_gen2_control_exciter_dc4b_tf2__a_sum;
    _diesel_gen2_control_exciter_dc4b_tf2__b_sum += _diesel_gen2_control_exciter_dc4b_tf2__b_coeff[0] * _diesel_gen2_control_exciter_dc4b_tf2__delay_line_in;
    _diesel_gen2_control_exciter_dc4b_tf2__out = _diesel_gen2_control_exciter_dc4b_tf2__b_sum;
    // Generated from the component: Diesel_Gen3.Control.Exciter.DC4B.PI.Sum7
    _diesel_gen3_control_exciter_dc4b_pi_sum7__out = _diesel_gen3_control_exciter_dc4b_pi_ki__out + _diesel_gen3_control_exciter_dc4b_pi_kb__out;
    // Generated from the component: Diesel_Gen3.Control.Exciter.DC4B.TF2
    X_UnInt32 _diesel_gen3_control_exciter_dc4b_tf2__i;
    _diesel_gen3_control_exciter_dc4b_tf2__a_sum = 0.0f;
    _diesel_gen3_control_exciter_dc4b_tf2__b_sum = 0.0f;
    _diesel_gen3_control_exciter_dc4b_tf2__delay_line_in = 0.0f;
    for (_diesel_gen3_control_exciter_dc4b_tf2__i = 0; _diesel_gen3_control_exciter_dc4b_tf2__i < 1; _diesel_gen3_control_exciter_dc4b_tf2__i++) {
        _diesel_gen3_control_exciter_dc4b_tf2__b_sum += _diesel_gen3_control_exciter_dc4b_tf2__b_coeff[_diesel_gen3_control_exciter_dc4b_tf2__i + 1] * _diesel_gen3_control_exciter_dc4b_tf2__states[_diesel_gen3_control_exciter_dc4b_tf2__i];
    }
    _diesel_gen3_control_exciter_dc4b_tf2__a_sum += _diesel_gen3_control_exciter_dc4b_tf2__states[0] * _diesel_gen3_control_exciter_dc4b_tf2__a_coeff[1];
    _diesel_gen3_control_exciter_dc4b_tf2__delay_line_in = _diesel_gen3_control_exciter_dc4b_ka__out - _diesel_gen3_control_exciter_dc4b_tf2__a_sum;
    _diesel_gen3_control_exciter_dc4b_tf2__b_sum += _diesel_gen3_control_exciter_dc4b_tf2__b_coeff[0] * _diesel_gen3_control_exciter_dc4b_tf2__delay_line_in;
    _diesel_gen3_control_exciter_dc4b_tf2__out = _diesel_gen3_control_exciter_dc4b_tf2__b_sum;
    // Generated from the component: Diesel_Gen4.Control.Exciter.DC4B.PI.Sum7
    _diesel_gen4_control_exciter_dc4b_pi_sum7__out = _diesel_gen4_control_exciter_dc4b_pi_ki__out + _diesel_gen4_control_exciter_dc4b_pi_kb__out;
    // Generated from the component: Diesel_Gen4.Control.Exciter.DC4B.TF2
    X_UnInt32 _diesel_gen4_control_exciter_dc4b_tf2__i;
    _diesel_gen4_control_exciter_dc4b_tf2__a_sum = 0.0f;
    _diesel_gen4_control_exciter_dc4b_tf2__b_sum = 0.0f;
    _diesel_gen4_control_exciter_dc4b_tf2__delay_line_in = 0.0f;
    for (_diesel_gen4_control_exciter_dc4b_tf2__i = 0; _diesel_gen4_control_exciter_dc4b_tf2__i < 1; _diesel_gen4_control_exciter_dc4b_tf2__i++) {
        _diesel_gen4_control_exciter_dc4b_tf2__b_sum += _diesel_gen4_control_exciter_dc4b_tf2__b_coeff[_diesel_gen4_control_exciter_dc4b_tf2__i + 1] * _diesel_gen4_control_exciter_dc4b_tf2__states[_diesel_gen4_control_exciter_dc4b_tf2__i];
    }
    _diesel_gen4_control_exciter_dc4b_tf2__a_sum += _diesel_gen4_control_exciter_dc4b_tf2__states[0] * _diesel_gen4_control_exciter_dc4b_tf2__a_coeff[1];
    _diesel_gen4_control_exciter_dc4b_tf2__delay_line_in = _diesel_gen4_control_exciter_dc4b_ka__out - _diesel_gen4_control_exciter_dc4b_tf2__a_sum;
    _diesel_gen4_control_exciter_dc4b_tf2__b_sum += _diesel_gen4_control_exciter_dc4b_tf2__b_coeff[0] * _diesel_gen4_control_exciter_dc4b_tf2__delay_line_in;
    _diesel_gen4_control_exciter_dc4b_tf2__out = _diesel_gen4_control_exciter_dc4b_tf2__b_sum;
//@cmp.out.block.end
    //////////////////////////////////////////////////////////////////////////
    // Update block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.update.block.start
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.DEGOV.Transport Delay1
    _diesel_gen1_control_governor_and_engine_degov_transport_delay1__state[_diesel_gen1_control_governor_and_engine_degov_transport_delay1__cbi] = _diesel_gen1_control_governor_and_engine_degov_integrator_limit1__out;
    if (_diesel_gen1_control_governor_and_engine_degov_transport_delay1__cbi < 119)
        _diesel_gen1_control_governor_and_engine_degov_transport_delay1__cbi++;
    else
        _diesel_gen1_control_governor_and_engine_degov_transport_delay1__cbi = 0;
    // Generated from the component: Diesel_Gen1.Control.Unit Delay1
    _diesel_gen1_control_unit_delay1__state = _diesel_gen1_control_bus_split2__out1;
    // Generated from the component: Diesel_Gen1.Control.Unit Delay2
    _diesel_gen1_control_unit_delay2__state = _diesel_gen1_control_read_op_mode__enable;
    // Generated from the component: Diesel_Gen1.Control.Unit Delay3
    _diesel_gen1_control_unit_delay3__state = _diesel_gen1_control_read_op_mode__enable;
    // Generated from the component: Diesel_Gen1.Gen.Machine Wrapper1
    _diesel_gen1_gen_machine_wrapper1__model_load = _diesel_gen1_control_governor_and_engine_tpu_to_t__out;
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.Normalize.V_terminal
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.PI.Integrator1
    _diesel_gen1_measurements_3ph_pll_gen_pll_pi_integrator1__state += _diesel_gen1_measurements_3ph_pll_gen_pll_pi_sum7__out * 0.0002;
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.PI.Integrator2
    _diesel_gen1_measurements_3ph_pll_gen_pll_pi_integrator2__state += _diesel_gen1_measurements_3ph_pll_gen_pll_pi_gain1__out * 0.0002;
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.Unit Delay1
    _diesel_gen1_measurements_3ph_pll_gen_pll_unit_delay1__state = _diesel_gen1_measurements_3ph_pll_gen_pll_integrator__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.Calculate_dw_synch.Unit Delay1
    _diesel_gen1_sync_check_calculate_dw_synch_unit_delay1__state = _diesel_gen1_sync_check_and2__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.Contactor_Control.Edge Detection1.Unit Delay1
    _diesel_gen1_sync_check_contactor_control_edge_detection1_unit_delay1__state = _diesel_gen1_sync_check_contactor_control_bus_split1__out2;
    // Generated from the component: Diesel_Gen1.Sync_Check.Contactor_Control.SR Flip Flop1
    if ((_diesel_gen1_sync_check_contactor_control_signal_switch1__out != 0x0) && (_diesel_gen1_sync_check_contactor_control_or__out == 0x0))
        _diesel_gen1_sync_check_contactor_control_sr_flip_flop1__state = 1;
    else if ((_diesel_gen1_sync_check_contactor_control_signal_switch1__out == 0x0) && (_diesel_gen1_sync_check_contactor_control_or__out != 0x0))
        _diesel_gen1_sync_check_contactor_control_sr_flip_flop1__state = 0;
    else if ((_diesel_gen1_sync_check_contactor_control_signal_switch1__out != 0x0) && (_diesel_gen1_sync_check_contactor_control_or__out != 0x0))
        _diesel_gen1_sync_check_contactor_control_sr_flip_flop1__state = -1;
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.PLL_Grid.PLL.PI.Integrator1
    _diesel_gen1_sync_check_plls_pll_grid_pll_pi_integrator1__state += _diesel_gen1_sync_check_plls_pll_grid_pll_pi_sum7__out * 0.0002;
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.PLL_Grid.PLL.Unit Delay1
    _diesel_gen1_sync_check_plls_pll_grid_pll_unit_delay1__state = _diesel_gen1_sync_check_plls_pll_grid_pll_integrator__output;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.Unit Delay1
    _diesel_gen1_sync_check_check_v_diff_unit_delay1__state = _diesel_gen1_sync_check_and2__out;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.Counter.Counter1.Accumulator1
    if ((_diesel_gen1_sync_check_check_phase_diff_counter_not__out != 0.0) || (_diesel_gen1_sync_check_check_phase_diff_counter_counter1_accumulator1__reset_state != 0)) {
        _diesel_gen1_sync_check_check_phase_diff_counter_counter1_accumulator1__state = 0.0;
    } else
        _diesel_gen1_sync_check_check_phase_diff_counter_counter1_accumulator1__state = (_diesel_gen1_sync_check_check_phase_diff_counter_not__out == 0) ? _diesel_gen1_sync_check_check_phase_diff_counter_counter1_accumulator1__state + _diesel_gen1_sync_check_check_phase_diff_counter_counter1_en_switch__out : 0.0;
    if (_diesel_gen1_sync_check_check_phase_diff_counter_not__out > 0)
        _diesel_gen1_sync_check_check_phase_diff_counter_counter1_accumulator1__reset_state = 1;
    else if (_diesel_gen1_sync_check_check_phase_diff_counter_not__out < 0)
        _diesel_gen1_sync_check_check_phase_diff_counter_counter1_accumulator1__reset_state = -1;
    else
        _diesel_gen1_sync_check_check_phase_diff_counter_counter1_accumulator1__reset_state = 0;
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.DEGOV.Transport Delay1
    _diesel_gen2_control_governor_and_engine_degov_transport_delay1__state[_diesel_gen2_control_governor_and_engine_degov_transport_delay1__cbi] = _diesel_gen2_control_governor_and_engine_degov_integrator_limit1__out;
    if (_diesel_gen2_control_governor_and_engine_degov_transport_delay1__cbi < 119)
        _diesel_gen2_control_governor_and_engine_degov_transport_delay1__cbi++;
    else
        _diesel_gen2_control_governor_and_engine_degov_transport_delay1__cbi = 0;
    // Generated from the component: Diesel_Gen2.Control.Unit Delay1
    _diesel_gen2_control_unit_delay1__state = _diesel_gen2_control_bus_split2__out1;
    // Generated from the component: Diesel_Gen2.Control.Unit Delay2
    _diesel_gen2_control_unit_delay2__state = _diesel_gen2_control_read_op_mode__enable;
    // Generated from the component: Diesel_Gen2.Control.Unit Delay3
    _diesel_gen2_control_unit_delay3__state = _diesel_gen2_control_read_op_mode__enable;
    // Generated from the component: Diesel_Gen2.Gen.Machine Wrapper1
    _diesel_gen2_gen_machine_wrapper1__model_load = _diesel_gen2_control_governor_and_engine_tpu_to_t__out;
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.Normalize.V_terminal
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.PI.Integrator1
    _diesel_gen2_measurements_3ph_pll_gen_pll_pi_integrator1__state += _diesel_gen2_measurements_3ph_pll_gen_pll_pi_sum7__out * 0.0002;
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.PI.Integrator2
    _diesel_gen2_measurements_3ph_pll_gen_pll_pi_integrator2__state += _diesel_gen2_measurements_3ph_pll_gen_pll_pi_gain1__out * 0.0002;
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.Unit Delay1
    _diesel_gen2_measurements_3ph_pll_gen_pll_unit_delay1__state = _diesel_gen2_measurements_3ph_pll_gen_pll_integrator__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.Calculate_dw_synch.Unit Delay1
    _diesel_gen2_sync_check_calculate_dw_synch_unit_delay1__state = _diesel_gen2_sync_check_and2__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.Contactor_Control.Edge Detection1.Unit Delay1
    _diesel_gen2_sync_check_contactor_control_edge_detection1_unit_delay1__state = _diesel_gen2_sync_check_contactor_control_bus_split1__out2;
    // Generated from the component: Diesel_Gen2.Sync_Check.Contactor_Control.SR Flip Flop1
    if ((_diesel_gen2_sync_check_contactor_control_signal_switch1__out != 0x0) && (_diesel_gen2_sync_check_contactor_control_or__out == 0x0))
        _diesel_gen2_sync_check_contactor_control_sr_flip_flop1__state = 1;
    else if ((_diesel_gen2_sync_check_contactor_control_signal_switch1__out == 0x0) && (_diesel_gen2_sync_check_contactor_control_or__out != 0x0))
        _diesel_gen2_sync_check_contactor_control_sr_flip_flop1__state = 0;
    else if ((_diesel_gen2_sync_check_contactor_control_signal_switch1__out != 0x0) && (_diesel_gen2_sync_check_contactor_control_or__out != 0x0))
        _diesel_gen2_sync_check_contactor_control_sr_flip_flop1__state = -1;
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.PLL_Grid.PLL.PI.Integrator1
    _diesel_gen2_sync_check_plls_pll_grid_pll_pi_integrator1__state += _diesel_gen2_sync_check_plls_pll_grid_pll_pi_sum7__out * 0.0002;
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.PLL_Grid.PLL.Unit Delay1
    _diesel_gen2_sync_check_plls_pll_grid_pll_unit_delay1__state = _diesel_gen2_sync_check_plls_pll_grid_pll_integrator__output;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.Unit Delay1
    _diesel_gen2_sync_check_check_v_diff_unit_delay1__state = _diesel_gen2_sync_check_and2__out;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.Counter.Counter1.Accumulator1
    if ((_diesel_gen2_sync_check_check_phase_diff_counter_not__out != 0.0) || (_diesel_gen2_sync_check_check_phase_diff_counter_counter1_accumulator1__reset_state != 0)) {
        _diesel_gen2_sync_check_check_phase_diff_counter_counter1_accumulator1__state = 0.0;
    } else
        _diesel_gen2_sync_check_check_phase_diff_counter_counter1_accumulator1__state = (_diesel_gen2_sync_check_check_phase_diff_counter_not__out == 0) ? _diesel_gen2_sync_check_check_phase_diff_counter_counter1_accumulator1__state + _diesel_gen2_sync_check_check_phase_diff_counter_counter1_en_switch__out : 0.0;
    if (_diesel_gen2_sync_check_check_phase_diff_counter_not__out > 0)
        _diesel_gen2_sync_check_check_phase_diff_counter_counter1_accumulator1__reset_state = 1;
    else if (_diesel_gen2_sync_check_check_phase_diff_counter_not__out < 0)
        _diesel_gen2_sync_check_check_phase_diff_counter_counter1_accumulator1__reset_state = -1;
    else
        _diesel_gen2_sync_check_check_phase_diff_counter_counter1_accumulator1__reset_state = 0;
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.DEGOV.Transport Delay1
    _diesel_gen3_control_governor_and_engine_degov_transport_delay1__state[_diesel_gen3_control_governor_and_engine_degov_transport_delay1__cbi] = _diesel_gen3_control_governor_and_engine_degov_integrator_limit1__out;
    if (_diesel_gen3_control_governor_and_engine_degov_transport_delay1__cbi < 119)
        _diesel_gen3_control_governor_and_engine_degov_transport_delay1__cbi++;
    else
        _diesel_gen3_control_governor_and_engine_degov_transport_delay1__cbi = 0;
    // Generated from the component: Diesel_Gen3.Control.Unit Delay1
    _diesel_gen3_control_unit_delay1__state = _diesel_gen3_control_bus_split2__out1;
    // Generated from the component: Diesel_Gen3.Control.Unit Delay2
    _diesel_gen3_control_unit_delay2__state = _diesel_gen3_control_read_op_mode__enable;
    // Generated from the component: Diesel_Gen3.Control.Unit Delay3
    _diesel_gen3_control_unit_delay3__state = _diesel_gen3_control_read_op_mode__enable;
    // Generated from the component: Diesel_Gen3.Gen.Machine Wrapper1
    _diesel_gen3_gen_machine_wrapper1__model_load = _diesel_gen3_control_governor_and_engine_tpu_to_t__out;
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.Normalize.V_terminal
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.PI.Integrator1
    _diesel_gen3_measurements_3ph_pll_gen_pll_pi_integrator1__state += _diesel_gen3_measurements_3ph_pll_gen_pll_pi_sum7__out * 0.0002;
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.PI.Integrator2
    _diesel_gen3_measurements_3ph_pll_gen_pll_pi_integrator2__state += _diesel_gen3_measurements_3ph_pll_gen_pll_pi_gain1__out * 0.0002;
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.Unit Delay1
    _diesel_gen3_measurements_3ph_pll_gen_pll_unit_delay1__state = _diesel_gen3_measurements_3ph_pll_gen_pll_integrator__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.Calculate_dw_synch.Unit Delay1
    _diesel_gen3_sync_check_calculate_dw_synch_unit_delay1__state = _diesel_gen3_sync_check_and2__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.Contactor_Control.Edge Detection1.Unit Delay1
    _diesel_gen3_sync_check_contactor_control_edge_detection1_unit_delay1__state = _diesel_gen3_sync_check_contactor_control_bus_split1__out2;
    // Generated from the component: Diesel_Gen3.Sync_Check.Contactor_Control.SR Flip Flop1
    if ((_diesel_gen3_sync_check_contactor_control_signal_switch1__out != 0x0) && (_diesel_gen3_sync_check_contactor_control_or__out == 0x0))
        _diesel_gen3_sync_check_contactor_control_sr_flip_flop1__state = 1;
    else if ((_diesel_gen3_sync_check_contactor_control_signal_switch1__out == 0x0) && (_diesel_gen3_sync_check_contactor_control_or__out != 0x0))
        _diesel_gen3_sync_check_contactor_control_sr_flip_flop1__state = 0;
    else if ((_diesel_gen3_sync_check_contactor_control_signal_switch1__out != 0x0) && (_diesel_gen3_sync_check_contactor_control_or__out != 0x0))
        _diesel_gen3_sync_check_contactor_control_sr_flip_flop1__state = -1;
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.PLL_Grid.PLL.PI.Integrator1
    _diesel_gen3_sync_check_plls_pll_grid_pll_pi_integrator1__state += _diesel_gen3_sync_check_plls_pll_grid_pll_pi_sum7__out * 0.0002;
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.PLL_Grid.PLL.Unit Delay1
    _diesel_gen3_sync_check_plls_pll_grid_pll_unit_delay1__state = _diesel_gen3_sync_check_plls_pll_grid_pll_integrator__output;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.Unit Delay1
    _diesel_gen3_sync_check_check_v_diff_unit_delay1__state = _diesel_gen3_sync_check_and2__out;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.Counter.Counter1.Accumulator1
    if ((_diesel_gen3_sync_check_check_phase_diff_counter_not__out != 0.0) || (_diesel_gen3_sync_check_check_phase_diff_counter_counter1_accumulator1__reset_state != 0)) {
        _diesel_gen3_sync_check_check_phase_diff_counter_counter1_accumulator1__state = 0.0;
    } else
        _diesel_gen3_sync_check_check_phase_diff_counter_counter1_accumulator1__state = (_diesel_gen3_sync_check_check_phase_diff_counter_not__out == 0) ? _diesel_gen3_sync_check_check_phase_diff_counter_counter1_accumulator1__state + _diesel_gen3_sync_check_check_phase_diff_counter_counter1_en_switch__out : 0.0;
    if (_diesel_gen3_sync_check_check_phase_diff_counter_not__out > 0)
        _diesel_gen3_sync_check_check_phase_diff_counter_counter1_accumulator1__reset_state = 1;
    else if (_diesel_gen3_sync_check_check_phase_diff_counter_not__out < 0)
        _diesel_gen3_sync_check_check_phase_diff_counter_counter1_accumulator1__reset_state = -1;
    else
        _diesel_gen3_sync_check_check_phase_diff_counter_counter1_accumulator1__reset_state = 0;
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.DEGOV.Transport Delay1
    _diesel_gen4_control_governor_and_engine_degov_transport_delay1__state[_diesel_gen4_control_governor_and_engine_degov_transport_delay1__cbi] = _diesel_gen4_control_governor_and_engine_degov_integrator_limit1__out;
    if (_diesel_gen4_control_governor_and_engine_degov_transport_delay1__cbi < 119)
        _diesel_gen4_control_governor_and_engine_degov_transport_delay1__cbi++;
    else
        _diesel_gen4_control_governor_and_engine_degov_transport_delay1__cbi = 0;
    // Generated from the component: Diesel_Gen4.Control.Unit Delay1
    _diesel_gen4_control_unit_delay1__state = _diesel_gen4_control_bus_split2__out1;
    // Generated from the component: Diesel_Gen4.Control.Unit Delay2
    _diesel_gen4_control_unit_delay2__state = _diesel_gen4_control_read_op_mode__enable;
    // Generated from the component: Diesel_Gen4.Control.Unit Delay3
    _diesel_gen4_control_unit_delay3__state = _diesel_gen4_control_read_op_mode__enable;
    // Generated from the component: Diesel_Gen4.Gen.Machine Wrapper1
    _diesel_gen4_gen_machine_wrapper1__model_load = _diesel_gen4_control_governor_and_engine_tpu_to_t__out;
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.Normalize.V_terminal
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.PI.Integrator1
    _diesel_gen4_measurements_3ph_pll_gen_pll_pi_integrator1__state += _diesel_gen4_measurements_3ph_pll_gen_pll_pi_sum7__out * 0.0002;
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.PI.Integrator2
    _diesel_gen4_measurements_3ph_pll_gen_pll_pi_integrator2__state += _diesel_gen4_measurements_3ph_pll_gen_pll_pi_gain1__out * 0.0002;
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.Unit Delay1
    _diesel_gen4_measurements_3ph_pll_gen_pll_unit_delay1__state = _diesel_gen4_measurements_3ph_pll_gen_pll_integrator__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.Calculate_dw_synch.Unit Delay1
    _diesel_gen4_sync_check_calculate_dw_synch_unit_delay1__state = _diesel_gen4_sync_check_and2__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.Contactor_Control.Edge Detection1.Unit Delay1
    _diesel_gen4_sync_check_contactor_control_edge_detection1_unit_delay1__state = _diesel_gen4_sync_check_contactor_control_bus_split1__out2;
    // Generated from the component: Diesel_Gen4.Sync_Check.Contactor_Control.SR Flip Flop1
    if ((_diesel_gen4_sync_check_contactor_control_signal_switch1__out != 0x0) && (_diesel_gen4_sync_check_contactor_control_or__out == 0x0))
        _diesel_gen4_sync_check_contactor_control_sr_flip_flop1__state = 1;
    else if ((_diesel_gen4_sync_check_contactor_control_signal_switch1__out == 0x0) && (_diesel_gen4_sync_check_contactor_control_or__out != 0x0))
        _diesel_gen4_sync_check_contactor_control_sr_flip_flop1__state = 0;
    else if ((_diesel_gen4_sync_check_contactor_control_signal_switch1__out != 0x0) && (_diesel_gen4_sync_check_contactor_control_or__out != 0x0))
        _diesel_gen4_sync_check_contactor_control_sr_flip_flop1__state = -1;
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.PLL_Grid.PLL.PI.Integrator1
    _diesel_gen4_sync_check_plls_pll_grid_pll_pi_integrator1__state += _diesel_gen4_sync_check_plls_pll_grid_pll_pi_sum7__out * 0.0002;
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.PLL_Grid.PLL.Unit Delay1
    _diesel_gen4_sync_check_plls_pll_grid_pll_unit_delay1__state = _diesel_gen4_sync_check_plls_pll_grid_pll_integrator__output;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.Unit Delay1
    _diesel_gen4_sync_check_check_v_diff_unit_delay1__state = _diesel_gen4_sync_check_and2__out;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.Counter.Counter1.Accumulator1
    if ((_diesel_gen4_sync_check_check_phase_diff_counter_not__out != 0.0) || (_diesel_gen4_sync_check_check_phase_diff_counter_counter1_accumulator1__reset_state != 0)) {
        _diesel_gen4_sync_check_check_phase_diff_counter_counter1_accumulator1__state = 0.0;
    } else
        _diesel_gen4_sync_check_check_phase_diff_counter_counter1_accumulator1__state = (_diesel_gen4_sync_check_check_phase_diff_counter_not__out == 0) ? _diesel_gen4_sync_check_check_phase_diff_counter_counter1_accumulator1__state + _diesel_gen4_sync_check_check_phase_diff_counter_counter1_en_switch__out : 0.0;
    if (_diesel_gen4_sync_check_check_phase_diff_counter_not__out > 0)
        _diesel_gen4_sync_check_check_phase_diff_counter_counter1_accumulator1__reset_state = 1;
    else if (_diesel_gen4_sync_check_check_phase_diff_counter_not__out < 0)
        _diesel_gen4_sync_check_check_phase_diff_counter_counter1_accumulator1__reset_state = -1;
    else
        _diesel_gen4_sync_check_check_phase_diff_counter_counter1_accumulator1__reset_state = 0;
    // Generated from the component: Diesel_Gen1.Control.Exciter.DC4B.TF4
    _diesel_gen1_control_exciter_dc4b_tf4__states[0] = _diesel_gen1_control_exciter_dc4b_tf4__delay_line_in;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.PI.Integrator1
    _diesel_gen1_sync_check_check_v_diff_pi_integrator1__state += _diesel_gen1_sync_check_check_v_diff_pi_sum7__out * 0.0002;
    if (_diesel_gen1_sync_check_check_v_diff_unit_delay1__out > 0)
        _diesel_gen1_sync_check_check_v_diff_pi_integrator1__reset_state = 1;
    else if (_diesel_gen1_sync_check_check_v_diff_unit_delay1__out < 0)
        _diesel_gen1_sync_check_check_v_diff_pi_integrator1__reset_state = -1;
    else
        _diesel_gen1_sync_check_check_v_diff_pi_integrator1__reset_state = 0;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.Counter.c_function
    // Generated from the component: Diesel_Gen2.Control.Exciter.DC4B.TF4
    _diesel_gen2_control_exciter_dc4b_tf4__states[0] = _diesel_gen2_control_exciter_dc4b_tf4__delay_line_in;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.PI.Integrator1
    _diesel_gen2_sync_check_check_v_diff_pi_integrator1__state += _diesel_gen2_sync_check_check_v_diff_pi_sum7__out * 0.0002;
    if (_diesel_gen2_sync_check_check_v_diff_unit_delay1__out > 0)
        _diesel_gen2_sync_check_check_v_diff_pi_integrator1__reset_state = 1;
    else if (_diesel_gen2_sync_check_check_v_diff_unit_delay1__out < 0)
        _diesel_gen2_sync_check_check_v_diff_pi_integrator1__reset_state = -1;
    else
        _diesel_gen2_sync_check_check_v_diff_pi_integrator1__reset_state = 0;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.Counter.c_function
    // Generated from the component: Diesel_Gen3.Control.Exciter.DC4B.TF4
    _diesel_gen3_control_exciter_dc4b_tf4__states[0] = _diesel_gen3_control_exciter_dc4b_tf4__delay_line_in;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.PI.Integrator1
    _diesel_gen3_sync_check_check_v_diff_pi_integrator1__state += _diesel_gen3_sync_check_check_v_diff_pi_sum7__out * 0.0002;
    if (_diesel_gen3_sync_check_check_v_diff_unit_delay1__out > 0)
        _diesel_gen3_sync_check_check_v_diff_pi_integrator1__reset_state = 1;
    else if (_diesel_gen3_sync_check_check_v_diff_unit_delay1__out < 0)
        _diesel_gen3_sync_check_check_v_diff_pi_integrator1__reset_state = -1;
    else
        _diesel_gen3_sync_check_check_v_diff_pi_integrator1__reset_state = 0;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.Counter.c_function
    // Generated from the component: Diesel_Gen4.Control.Exciter.DC4B.TF4
    _diesel_gen4_control_exciter_dc4b_tf4__states[0] = _diesel_gen4_control_exciter_dc4b_tf4__delay_line_in;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.PI.Integrator1
    _diesel_gen4_sync_check_check_v_diff_pi_integrator1__state += _diesel_gen4_sync_check_check_v_diff_pi_sum7__out * 0.0002;
    if (_diesel_gen4_sync_check_check_v_diff_unit_delay1__out > 0)
        _diesel_gen4_sync_check_check_v_diff_pi_integrator1__reset_state = 1;
    else if (_diesel_gen4_sync_check_check_v_diff_unit_delay1__out < 0)
        _diesel_gen4_sync_check_check_v_diff_pi_integrator1__reset_state = -1;
    else
        _diesel_gen4_sync_check_check_v_diff_pi_integrator1__reset_state = 0;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.Counter.c_function
    // Generated from the component: Diesel_Gen1.Control.Exciter.DC4B.Variable Limit
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.DEGOV.TF2
    for (_diesel_gen1_control_governor_and_engine_degov_tf2__i = 1; _diesel_gen1_control_governor_and_engine_degov_tf2__i > 0; _diesel_gen1_control_governor_and_engine_degov_tf2__i--) {
        _diesel_gen1_control_governor_and_engine_degov_tf2__states[_diesel_gen1_control_governor_and_engine_degov_tf2__i] = _diesel_gen1_control_governor_and_engine_degov_tf2__states[_diesel_gen1_control_governor_and_engine_degov_tf2__i - 1];
    }
    _diesel_gen1_control_governor_and_engine_degov_tf2__states[0] = _diesel_gen1_control_governor_and_engine_degov_tf2__delay_line_in;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_f_diff.Comparator1
    if (_diesel_gen1_sync_check_check_f_diff_freq_diff__out < _diesel_gen1_sync_check_check_f_diff_abs3__out) {
        _diesel_gen1_sync_check_check_f_diff_comparator1__state = 0;
    } else if (_diesel_gen1_sync_check_check_f_diff_freq_diff__out > _diesel_gen1_sync_check_check_f_diff_abs3__out) {
        _diesel_gen1_sync_check_check_f_diff_comparator1__state = 1;
    }
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.Comparator2
    if (_diesel_gen1_sync_check_check_phase_diff_phase_diff__out < _diesel_gen1_sync_check_check_phase_diff_abs2__out) {
        _diesel_gen1_sync_check_check_phase_diff_comparator2__state = 0;
    } else if (_diesel_gen1_sync_check_check_phase_diff_phase_diff__out > _diesel_gen1_sync_check_check_phase_diff_abs2__out) {
        _diesel_gen1_sync_check_check_phase_diff_comparator2__state = 1;
    }
    // Generated from the component: Diesel_Gen1.Control.Start_Exciter.Comparator1
    if (_diesel_gen1_control_start_exciter_w_to_wpu__out < _diesel_gen1_control_start_exciter_exciter_start_speed__out) {
        _diesel_gen1_control_start_exciter_comparator1__state = 0;
    } else if (_diesel_gen1_control_start_exciter_w_to_wpu__out > _diesel_gen1_control_start_exciter_exciter_start_speed__out) {
        _diesel_gen1_control_start_exciter_comparator1__state = 1;
    }
    // Generated from the component: Diesel_Gen2.Control.Exciter.DC4B.Variable Limit
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.DEGOV.TF2
    for (_diesel_gen2_control_governor_and_engine_degov_tf2__i = 1; _diesel_gen2_control_governor_and_engine_degov_tf2__i > 0; _diesel_gen2_control_governor_and_engine_degov_tf2__i--) {
        _diesel_gen2_control_governor_and_engine_degov_tf2__states[_diesel_gen2_control_governor_and_engine_degov_tf2__i] = _diesel_gen2_control_governor_and_engine_degov_tf2__states[_diesel_gen2_control_governor_and_engine_degov_tf2__i - 1];
    }
    _diesel_gen2_control_governor_and_engine_degov_tf2__states[0] = _diesel_gen2_control_governor_and_engine_degov_tf2__delay_line_in;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_f_diff.Comparator1
    if (_diesel_gen2_sync_check_check_f_diff_freq_diff__out < _diesel_gen2_sync_check_check_f_diff_abs3__out) {
        _diesel_gen2_sync_check_check_f_diff_comparator1__state = 0;
    } else if (_diesel_gen2_sync_check_check_f_diff_freq_diff__out > _diesel_gen2_sync_check_check_f_diff_abs3__out) {
        _diesel_gen2_sync_check_check_f_diff_comparator1__state = 1;
    }
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.Comparator2
    if (_diesel_gen2_sync_check_check_phase_diff_phase_diff__out < _diesel_gen2_sync_check_check_phase_diff_abs2__out) {
        _diesel_gen2_sync_check_check_phase_diff_comparator2__state = 0;
    } else if (_diesel_gen2_sync_check_check_phase_diff_phase_diff__out > _diesel_gen2_sync_check_check_phase_diff_abs2__out) {
        _diesel_gen2_sync_check_check_phase_diff_comparator2__state = 1;
    }
    // Generated from the component: Diesel_Gen2.Control.Start_Exciter.Comparator1
    if (_diesel_gen2_control_start_exciter_w_to_wpu__out < _diesel_gen2_control_start_exciter_exciter_start_speed__out) {
        _diesel_gen2_control_start_exciter_comparator1__state = 0;
    } else if (_diesel_gen2_control_start_exciter_w_to_wpu__out > _diesel_gen2_control_start_exciter_exciter_start_speed__out) {
        _diesel_gen2_control_start_exciter_comparator1__state = 1;
    }
    // Generated from the component: Diesel_Gen3.Control.Exciter.DC4B.Variable Limit
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.DEGOV.TF2
    for (_diesel_gen3_control_governor_and_engine_degov_tf2__i = 1; _diesel_gen3_control_governor_and_engine_degov_tf2__i > 0; _diesel_gen3_control_governor_and_engine_degov_tf2__i--) {
        _diesel_gen3_control_governor_and_engine_degov_tf2__states[_diesel_gen3_control_governor_and_engine_degov_tf2__i] = _diesel_gen3_control_governor_and_engine_degov_tf2__states[_diesel_gen3_control_governor_and_engine_degov_tf2__i - 1];
    }
    _diesel_gen3_control_governor_and_engine_degov_tf2__states[0] = _diesel_gen3_control_governor_and_engine_degov_tf2__delay_line_in;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_f_diff.Comparator1
    if (_diesel_gen3_sync_check_check_f_diff_freq_diff__out < _diesel_gen3_sync_check_check_f_diff_abs3__out) {
        _diesel_gen3_sync_check_check_f_diff_comparator1__state = 0;
    } else if (_diesel_gen3_sync_check_check_f_diff_freq_diff__out > _diesel_gen3_sync_check_check_f_diff_abs3__out) {
        _diesel_gen3_sync_check_check_f_diff_comparator1__state = 1;
    }
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.Comparator2
    if (_diesel_gen3_sync_check_check_phase_diff_phase_diff__out < _diesel_gen3_sync_check_check_phase_diff_abs2__out) {
        _diesel_gen3_sync_check_check_phase_diff_comparator2__state = 0;
    } else if (_diesel_gen3_sync_check_check_phase_diff_phase_diff__out > _diesel_gen3_sync_check_check_phase_diff_abs2__out) {
        _diesel_gen3_sync_check_check_phase_diff_comparator2__state = 1;
    }
    // Generated from the component: Diesel_Gen3.Control.Start_Exciter.Comparator1
    if (_diesel_gen3_control_start_exciter_w_to_wpu__out < _diesel_gen3_control_start_exciter_exciter_start_speed__out) {
        _diesel_gen3_control_start_exciter_comparator1__state = 0;
    } else if (_diesel_gen3_control_start_exciter_w_to_wpu__out > _diesel_gen3_control_start_exciter_exciter_start_speed__out) {
        _diesel_gen3_control_start_exciter_comparator1__state = 1;
    }
    // Generated from the component: Diesel_Gen4.Control.Exciter.DC4B.Variable Limit
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.DEGOV.TF2
    for (_diesel_gen4_control_governor_and_engine_degov_tf2__i = 1; _diesel_gen4_control_governor_and_engine_degov_tf2__i > 0; _diesel_gen4_control_governor_and_engine_degov_tf2__i--) {
        _diesel_gen4_control_governor_and_engine_degov_tf2__states[_diesel_gen4_control_governor_and_engine_degov_tf2__i] = _diesel_gen4_control_governor_and_engine_degov_tf2__states[_diesel_gen4_control_governor_and_engine_degov_tf2__i - 1];
    }
    _diesel_gen4_control_governor_and_engine_degov_tf2__states[0] = _diesel_gen4_control_governor_and_engine_degov_tf2__delay_line_in;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_f_diff.Comparator1
    if (_diesel_gen4_sync_check_check_f_diff_freq_diff__out < _diesel_gen4_sync_check_check_f_diff_abs3__out) {
        _diesel_gen4_sync_check_check_f_diff_comparator1__state = 0;
    } else if (_diesel_gen4_sync_check_check_f_diff_freq_diff__out > _diesel_gen4_sync_check_check_f_diff_abs3__out) {
        _diesel_gen4_sync_check_check_f_diff_comparator1__state = 1;
    }
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.Comparator2
    if (_diesel_gen4_sync_check_check_phase_diff_phase_diff__out < _diesel_gen4_sync_check_check_phase_diff_abs2__out) {
        _diesel_gen4_sync_check_check_phase_diff_comparator2__state = 0;
    } else if (_diesel_gen4_sync_check_check_phase_diff_phase_diff__out > _diesel_gen4_sync_check_check_phase_diff_abs2__out) {
        _diesel_gen4_sync_check_check_phase_diff_comparator2__state = 1;
    }
    // Generated from the component: Diesel_Gen4.Control.Start_Exciter.Comparator1
    if (_diesel_gen4_control_start_exciter_w_to_wpu__out < _diesel_gen4_control_start_exciter_exciter_start_speed__out) {
        _diesel_gen4_control_start_exciter_comparator1__state = 0;
    } else if (_diesel_gen4_control_start_exciter_w_to_wpu__out > _diesel_gen4_control_start_exciter_exciter_start_speed__out) {
        _diesel_gen4_control_start_exciter_comparator1__state = 1;
    }
    // Generated from the component: Diesel_Gen1.Control.Define_control_mode.Control_mode
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.DEGOV.Integrator.Integrator1
    _diesel_gen1_control_governor_and_engine_degov_integrator_integrator1__state += _diesel_gen1_control_governor_and_engine_degov_integrator_sum7__out * 0.0002;
    if (_diesel_gen1_control_bus_split3__out > 0)
        _diesel_gen1_control_governor_and_engine_degov_integrator_integrator1__reset_state = 1;
    else if (_diesel_gen1_control_bus_split3__out < 0)
        _diesel_gen1_control_governor_and_engine_degov_integrator_integrator1__reset_state = -1;
    else
        _diesel_gen1_control_governor_and_engine_degov_integrator_integrator1__reset_state = 0;
    // Generated from the component: Diesel_Gen2.Control.Define_control_mode.Control_mode
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.DEGOV.Integrator.Integrator1
    _diesel_gen2_control_governor_and_engine_degov_integrator_integrator1__state += _diesel_gen2_control_governor_and_engine_degov_integrator_sum7__out * 0.0002;
    if (_diesel_gen2_control_bus_split3__out > 0)
        _diesel_gen2_control_governor_and_engine_degov_integrator_integrator1__reset_state = 1;
    else if (_diesel_gen2_control_bus_split3__out < 0)
        _diesel_gen2_control_governor_and_engine_degov_integrator_integrator1__reset_state = -1;
    else
        _diesel_gen2_control_governor_and_engine_degov_integrator_integrator1__reset_state = 0;
    // Generated from the component: Diesel_Gen4.Control.Define_control_mode.Control_mode
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.DEGOV.Integrator.Integrator1
    _diesel_gen4_control_governor_and_engine_degov_integrator_integrator1__state += _diesel_gen4_control_governor_and_engine_degov_integrator_sum7__out * 0.0002;
    if (_diesel_gen4_control_bus_split3__out > 0)
        _diesel_gen4_control_governor_and_engine_degov_integrator_integrator1__reset_state = 1;
    else if (_diesel_gen4_control_bus_split3__out < 0)
        _diesel_gen4_control_governor_and_engine_degov_integrator_integrator1__reset_state = -1;
    else
        _diesel_gen4_control_governor_and_engine_degov_integrator_integrator1__reset_state = 0;
    // Generated from the component: Diesel_Gen3.Control.Define_control_mode.Control_mode
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.DEGOV.Integrator.Integrator1
    _diesel_gen3_control_governor_and_engine_degov_integrator_integrator1__state += _diesel_gen3_control_governor_and_engine_degov_integrator_sum7__out * 0.0002;
    if (_diesel_gen3_control_bus_split3__out > 0)
        _diesel_gen3_control_governor_and_engine_degov_integrator_integrator1__reset_state = 1;
    else if (_diesel_gen3_control_bus_split3__out < 0)
        _diesel_gen3_control_governor_and_engine_degov_integrator_integrator1__reset_state = -1;
    else
        _diesel_gen3_control_governor_and_engine_degov_integrator_integrator1__reset_state = 0;
    // Generated from the component: Diesel_Gen1.Control.Exciter.DC4B.TF3
    _diesel_gen1_control_exciter_dc4b_tf3__states[0] = _diesel_gen1_control_exciter_dc4b_tf3__delay_line_in;
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.LPF_d
    _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__states[0] = _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_d__delay_line_in;
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.LPF_q
    _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__states[0] = _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q__delay_line_in;
    // Generated from the component: Diesel_Gen1.Control.check_steady_state_w.Comparator3
    if (_diesel_gen1_control_check_steady_state_w_speed_diff__out < _diesel_gen1_control_check_steady_state_w_abs1__out) {
        _diesel_gen1_control_check_steady_state_w_comparator3__state = 0;
    } else if (_diesel_gen1_control_check_steady_state_w_speed_diff__out > _diesel_gen1_control_check_steady_state_w_abs1__out) {
        _diesel_gen1_control_check_steady_state_w_comparator3__state = 1;
    }
    // Generated from the component: Diesel_Gen2.Control.Exciter.DC4B.TF3
    _diesel_gen2_control_exciter_dc4b_tf3__states[0] = _diesel_gen2_control_exciter_dc4b_tf3__delay_line_in;
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.LPF_d
    _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__states[0] = _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_d__delay_line_in;
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.LPF_q
    _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__states[0] = _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q__delay_line_in;
    // Generated from the component: Diesel_Gen2.Control.check_steady_state_w.Comparator3
    if (_diesel_gen2_control_check_steady_state_w_speed_diff__out < _diesel_gen2_control_check_steady_state_w_abs1__out) {
        _diesel_gen2_control_check_steady_state_w_comparator3__state = 0;
    } else if (_diesel_gen2_control_check_steady_state_w_speed_diff__out > _diesel_gen2_control_check_steady_state_w_abs1__out) {
        _diesel_gen2_control_check_steady_state_w_comparator3__state = 1;
    }
    // Generated from the component: Diesel_Gen3.Control.Exciter.DC4B.TF3
    _diesel_gen3_control_exciter_dc4b_tf3__states[0] = _diesel_gen3_control_exciter_dc4b_tf3__delay_line_in;
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.LPF_d
    _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__states[0] = _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_d__delay_line_in;
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.LPF_q
    _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__states[0] = _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q__delay_line_in;
    // Generated from the component: Diesel_Gen3.Control.check_steady_state_w.Comparator3
    if (_diesel_gen3_control_check_steady_state_w_speed_diff__out < _diesel_gen3_control_check_steady_state_w_abs1__out) {
        _diesel_gen3_control_check_steady_state_w_comparator3__state = 0;
    } else if (_diesel_gen3_control_check_steady_state_w_speed_diff__out > _diesel_gen3_control_check_steady_state_w_abs1__out) {
        _diesel_gen3_control_check_steady_state_w_comparator3__state = 1;
    }
    // Generated from the component: Diesel_Gen4.Control.Exciter.DC4B.TF3
    _diesel_gen4_control_exciter_dc4b_tf3__states[0] = _diesel_gen4_control_exciter_dc4b_tf3__delay_line_in;
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.LPF_d
    _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__states[0] = _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_d__delay_line_in;
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.LPF_q
    _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__states[0] = _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q__delay_line_in;
    // Generated from the component: Diesel_Gen4.Control.check_steady_state_w.Comparator3
    if (_diesel_gen4_control_check_steady_state_w_speed_diff__out < _diesel_gen4_control_check_steady_state_w_abs1__out) {
        _diesel_gen4_control_check_steady_state_w_comparator3__state = 0;
    } else if (_diesel_gen4_control_check_steady_state_w_speed_diff__out > _diesel_gen4_control_check_steady_state_w_abs1__out) {
        _diesel_gen4_control_check_steady_state_w_comparator3__state = 1;
    }
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.P_ramp
    if (_diesel_gen1_control_freq_setpoint_control_p_limit__out - _diesel_gen1_control_freq_setpoint_control_p_ramp__state > 0.002)
        _diesel_gen1_control_freq_setpoint_control_p_ramp__state += (0.002);
    else  if (_diesel_gen1_control_freq_setpoint_control_p_limit__out - _diesel_gen1_control_freq_setpoint_control_p_ramp__state < -0.002)
        _diesel_gen1_control_freq_setpoint_control_p_ramp__state += (-0.002);
    else
        _diesel_gen1_control_freq_setpoint_control_p_ramp__state = _diesel_gen1_control_freq_setpoint_control_p_limit__out;
    _diesel_gen1_control_freq_setpoint_control_p_ramp__first_step = 0;
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.w_ramp
    if (_diesel_gen1_control_governor_and_engine_w_switch__out - _diesel_gen1_control_governor_and_engine_w_ramp__state > 0.002)
        _diesel_gen1_control_governor_and_engine_w_ramp__state += (0.002);
    else  if (_diesel_gen1_control_governor_and_engine_w_switch__out - _diesel_gen1_control_governor_and_engine_w_ramp__state < -0.002)
        _diesel_gen1_control_governor_and_engine_w_ramp__state += (-0.002);
    else
        _diesel_gen1_control_governor_and_engine_w_ramp__state = _diesel_gen1_control_governor_and_engine_w_switch__out;
    _diesel_gen1_control_governor_and_engine_w_ramp__first_step = 0;
    // Generated from the component: Diesel_Gen1.Control.read_OP_mode
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.P_ramp
    if (_diesel_gen2_control_freq_setpoint_control_p_limit__out - _diesel_gen2_control_freq_setpoint_control_p_ramp__state > 0.002)
        _diesel_gen2_control_freq_setpoint_control_p_ramp__state += (0.002);
    else  if (_diesel_gen2_control_freq_setpoint_control_p_limit__out - _diesel_gen2_control_freq_setpoint_control_p_ramp__state < -0.002)
        _diesel_gen2_control_freq_setpoint_control_p_ramp__state += (-0.002);
    else
        _diesel_gen2_control_freq_setpoint_control_p_ramp__state = _diesel_gen2_control_freq_setpoint_control_p_limit__out;
    _diesel_gen2_control_freq_setpoint_control_p_ramp__first_step = 0;
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.w_ramp
    if (_diesel_gen2_control_governor_and_engine_w_switch__out - _diesel_gen2_control_governor_and_engine_w_ramp__state > 0.002)
        _diesel_gen2_control_governor_and_engine_w_ramp__state += (0.002);
    else  if (_diesel_gen2_control_governor_and_engine_w_switch__out - _diesel_gen2_control_governor_and_engine_w_ramp__state < -0.002)
        _diesel_gen2_control_governor_and_engine_w_ramp__state += (-0.002);
    else
        _diesel_gen2_control_governor_and_engine_w_ramp__state = _diesel_gen2_control_governor_and_engine_w_switch__out;
    _diesel_gen2_control_governor_and_engine_w_ramp__first_step = 0;
    // Generated from the component: Diesel_Gen2.Control.read_OP_mode
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.P_ramp
    if (_diesel_gen4_control_freq_setpoint_control_p_limit__out - _diesel_gen4_control_freq_setpoint_control_p_ramp__state > 0.002)
        _diesel_gen4_control_freq_setpoint_control_p_ramp__state += (0.002);
    else  if (_diesel_gen4_control_freq_setpoint_control_p_limit__out - _diesel_gen4_control_freq_setpoint_control_p_ramp__state < -0.002)
        _diesel_gen4_control_freq_setpoint_control_p_ramp__state += (-0.002);
    else
        _diesel_gen4_control_freq_setpoint_control_p_ramp__state = _diesel_gen4_control_freq_setpoint_control_p_limit__out;
    _diesel_gen4_control_freq_setpoint_control_p_ramp__first_step = 0;
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.w_ramp
    if (_diesel_gen4_control_governor_and_engine_w_switch__out - _diesel_gen4_control_governor_and_engine_w_ramp__state > 0.002)
        _diesel_gen4_control_governor_and_engine_w_ramp__state += (0.002);
    else  if (_diesel_gen4_control_governor_and_engine_w_switch__out - _diesel_gen4_control_governor_and_engine_w_ramp__state < -0.002)
        _diesel_gen4_control_governor_and_engine_w_ramp__state += (-0.002);
    else
        _diesel_gen4_control_governor_and_engine_w_ramp__state = _diesel_gen4_control_governor_and_engine_w_switch__out;
    _diesel_gen4_control_governor_and_engine_w_ramp__first_step = 0;
    // Generated from the component: Diesel_Gen4.Control.read_OP_mode
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.P_ramp
    if (_diesel_gen3_control_freq_setpoint_control_p_limit__out - _diesel_gen3_control_freq_setpoint_control_p_ramp__state > 0.002)
        _diesel_gen3_control_freq_setpoint_control_p_ramp__state += (0.002);
    else  if (_diesel_gen3_control_freq_setpoint_control_p_limit__out - _diesel_gen3_control_freq_setpoint_control_p_ramp__state < -0.002)
        _diesel_gen3_control_freq_setpoint_control_p_ramp__state += (-0.002);
    else
        _diesel_gen3_control_freq_setpoint_control_p_ramp__state = _diesel_gen3_control_freq_setpoint_control_p_limit__out;
    _diesel_gen3_control_freq_setpoint_control_p_ramp__first_step = 0;
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.w_ramp
    if (_diesel_gen3_control_governor_and_engine_w_switch__out - _diesel_gen3_control_governor_and_engine_w_ramp__state > 0.002)
        _diesel_gen3_control_governor_and_engine_w_ramp__state += (0.002);
    else  if (_diesel_gen3_control_governor_and_engine_w_switch__out - _diesel_gen3_control_governor_and_engine_w_ramp__state < -0.002)
        _diesel_gen3_control_governor_and_engine_w_ramp__state += (-0.002);
    else
        _diesel_gen3_control_governor_and_engine_w_ramp__state = _diesel_gen3_control_governor_and_engine_w_switch__out;
    _diesel_gen3_control_governor_and_engine_w_ramp__first_step = 0;
    // Generated from the component: Diesel_Gen3.Control.read_OP_mode
    // Generated from the component: Diesel_Gen1.Control.pf Control.norm_pf_meas
    // Generated from the component: Diesel_Gen1.Control.pf Control.norm_pf_ref
    // Generated from the component: Diesel_Gen1.Control.Exciter.DC4B.PI.Integrator1
    _diesel_gen1_control_exciter_dc4b_pi_integrator1__state += _diesel_gen1_control_exciter_dc4b_pi_sum7__out * 0.0002;
    if (_diesel_gen1_control_start_exciter_and__out > 0)
        _diesel_gen1_control_exciter_dc4b_pi_integrator1__reset_state = 1;
    else if (_diesel_gen1_control_start_exciter_and__out < 0)
        _diesel_gen1_control_exciter_dc4b_pi_integrator1__reset_state = -1;
    else
        _diesel_gen1_control_exciter_dc4b_pi_integrator1__reset_state = 0;
    // Generated from the component: Diesel_Gen2.Control.pf Control.norm_pf_meas
    // Generated from the component: Diesel_Gen2.Control.pf Control.norm_pf_ref
    // Generated from the component: Diesel_Gen2.Control.Exciter.DC4B.PI.Integrator1
    _diesel_gen2_control_exciter_dc4b_pi_integrator1__state += _diesel_gen2_control_exciter_dc4b_pi_sum7__out * 0.0002;
    if (_diesel_gen2_control_start_exciter_and__out > 0)
        _diesel_gen2_control_exciter_dc4b_pi_integrator1__reset_state = 1;
    else if (_diesel_gen2_control_start_exciter_and__out < 0)
        _diesel_gen2_control_exciter_dc4b_pi_integrator1__reset_state = -1;
    else
        _diesel_gen2_control_exciter_dc4b_pi_integrator1__reset_state = 0;
    // Generated from the component: Diesel_Gen3.Control.pf Control.norm_pf_meas
    // Generated from the component: Diesel_Gen3.Control.pf Control.norm_pf_ref
    // Generated from the component: Diesel_Gen3.Control.Exciter.DC4B.PI.Integrator1
    _diesel_gen3_control_exciter_dc4b_pi_integrator1__state += _diesel_gen3_control_exciter_dc4b_pi_sum7__out * 0.0002;
    if (_diesel_gen3_control_start_exciter_and__out > 0)
        _diesel_gen3_control_exciter_dc4b_pi_integrator1__reset_state = 1;
    else if (_diesel_gen3_control_start_exciter_and__out < 0)
        _diesel_gen3_control_exciter_dc4b_pi_integrator1__reset_state = -1;
    else
        _diesel_gen3_control_exciter_dc4b_pi_integrator1__reset_state = 0;
    // Generated from the component: Diesel_Gen4.Control.pf Control.norm_pf_meas
    // Generated from the component: Diesel_Gen4.Control.pf Control.norm_pf_ref
    // Generated from the component: Diesel_Gen4.Control.Exciter.DC4B.PI.Integrator1
    _diesel_gen4_control_exciter_dc4b_pi_integrator1__state += _diesel_gen4_control_exciter_dc4b_pi_sum7__out * 0.0002;
    if (_diesel_gen4_control_start_exciter_and__out > 0)
        _diesel_gen4_control_exciter_dc4b_pi_integrator1__reset_state = 1;
    else if (_diesel_gen4_control_start_exciter_and__out < 0)
        _diesel_gen4_control_exciter_dc4b_pi_integrator1__reset_state = -1;
    else
        _diesel_gen4_control_exciter_dc4b_pi_integrator1__reset_state = 0;
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.PI.Integrator1
    _diesel_gen1_control_freq_setpoint_control_pi_integrator1__state += _diesel_gen1_control_freq_setpoint_control_pi_sum7__out * 0.0002;
    if (_diesel_gen1_control_read_op_mode__enable > 0)
        _diesel_gen1_control_freq_setpoint_control_pi_integrator1__reset_state = 1;
    else if (_diesel_gen1_control_read_op_mode__enable < 0)
        _diesel_gen1_control_freq_setpoint_control_pi_integrator1__reset_state = -1;
    else
        _diesel_gen1_control_freq_setpoint_control_pi_integrator1__reset_state = 0;
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.PI.Integrator1
    _diesel_gen2_control_freq_setpoint_control_pi_integrator1__state += _diesel_gen2_control_freq_setpoint_control_pi_sum7__out * 0.0002;
    if (_diesel_gen2_control_read_op_mode__enable > 0)
        _diesel_gen2_control_freq_setpoint_control_pi_integrator1__reset_state = 1;
    else if (_diesel_gen2_control_read_op_mode__enable < 0)
        _diesel_gen2_control_freq_setpoint_control_pi_integrator1__reset_state = -1;
    else
        _diesel_gen2_control_freq_setpoint_control_pi_integrator1__reset_state = 0;
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.PI.Integrator1
    _diesel_gen4_control_freq_setpoint_control_pi_integrator1__state += _diesel_gen4_control_freq_setpoint_control_pi_sum7__out * 0.0002;
    if (_diesel_gen4_control_read_op_mode__enable > 0)
        _diesel_gen4_control_freq_setpoint_control_pi_integrator1__reset_state = 1;
    else if (_diesel_gen4_control_read_op_mode__enable < 0)
        _diesel_gen4_control_freq_setpoint_control_pi_integrator1__reset_state = -1;
    else
        _diesel_gen4_control_freq_setpoint_control_pi_integrator1__reset_state = 0;
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.PI.Integrator1
    _diesel_gen3_control_freq_setpoint_control_pi_integrator1__state += _diesel_gen3_control_freq_setpoint_control_pi_sum7__out * 0.0002;
    if (_diesel_gen3_control_read_op_mode__enable > 0)
        _diesel_gen3_control_freq_setpoint_control_pi_integrator1__reset_state = 1;
    else if (_diesel_gen3_control_read_op_mode__enable < 0)
        _diesel_gen3_control_freq_setpoint_control_pi_integrator1__reset_state = -1;
    else
        _diesel_gen3_control_freq_setpoint_control_pi_integrator1__reset_state = 0;
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.PLL_Grid.PLL.Normalize.V_terminal
    // Generated from the component: Diesel_Gen1.Control.Exciter.DC4B.TF1
    _diesel_gen1_control_exciter_dc4b_tf1__states[0] = _diesel_gen1_control_exciter_dc4b_tf1__delay_line_in;
    // Generated from the component: Diesel_Gen1.Control.Exciter.Rate Limit
    if (_diesel_gen1_control_exciter_switch__out - _diesel_gen1_control_exciter_rate_limit__state > 0.002)
        _diesel_gen1_control_exciter_rate_limit__state += (0.002);
    else  if (_diesel_gen1_control_exciter_switch__out - _diesel_gen1_control_exciter_rate_limit__state < -0.002)
        _diesel_gen1_control_exciter_rate_limit__state += (-0.002);
    else
        _diesel_gen1_control_exciter_rate_limit__state = _diesel_gen1_control_exciter_switch__out;
    _diesel_gen1_control_exciter_rate_limit__first_step = 0;
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.PLL_Grid.PLL.Normalize.V_terminal
    // Generated from the component: Diesel_Gen2.Control.Exciter.DC4B.TF1
    _diesel_gen2_control_exciter_dc4b_tf1__states[0] = _diesel_gen2_control_exciter_dc4b_tf1__delay_line_in;
    // Generated from the component: Diesel_Gen2.Control.Exciter.Rate Limit
    if (_diesel_gen2_control_exciter_switch__out - _diesel_gen2_control_exciter_rate_limit__state > 0.002)
        _diesel_gen2_control_exciter_rate_limit__state += (0.002);
    else  if (_diesel_gen2_control_exciter_switch__out - _diesel_gen2_control_exciter_rate_limit__state < -0.002)
        _diesel_gen2_control_exciter_rate_limit__state += (-0.002);
    else
        _diesel_gen2_control_exciter_rate_limit__state = _diesel_gen2_control_exciter_switch__out;
    _diesel_gen2_control_exciter_rate_limit__first_step = 0;
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.PLL_Grid.PLL.Normalize.V_terminal
    // Generated from the component: Diesel_Gen3.Control.Exciter.DC4B.TF1
    _diesel_gen3_control_exciter_dc4b_tf1__states[0] = _diesel_gen3_control_exciter_dc4b_tf1__delay_line_in;
    // Generated from the component: Diesel_Gen3.Control.Exciter.Rate Limit
    if (_diesel_gen3_control_exciter_switch__out - _diesel_gen3_control_exciter_rate_limit__state > 0.002)
        _diesel_gen3_control_exciter_rate_limit__state += (0.002);
    else  if (_diesel_gen3_control_exciter_switch__out - _diesel_gen3_control_exciter_rate_limit__state < -0.002)
        _diesel_gen3_control_exciter_rate_limit__state += (-0.002);
    else
        _diesel_gen3_control_exciter_rate_limit__state = _diesel_gen3_control_exciter_switch__out;
    _diesel_gen3_control_exciter_rate_limit__first_step = 0;
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.PLL_Grid.PLL.Normalize.V_terminal
    // Generated from the component: Diesel_Gen4.Control.Exciter.DC4B.TF1
    _diesel_gen4_control_exciter_dc4b_tf1__states[0] = _diesel_gen4_control_exciter_dc4b_tf1__delay_line_in;
    // Generated from the component: Diesel_Gen4.Control.Exciter.Rate Limit
    if (_diesel_gen4_control_exciter_switch__out - _diesel_gen4_control_exciter_rate_limit__state > 0.002)
        _diesel_gen4_control_exciter_rate_limit__state += (0.002);
    else  if (_diesel_gen4_control_exciter_switch__out - _diesel_gen4_control_exciter_rate_limit__state < -0.002)
        _diesel_gen4_control_exciter_rate_limit__state += (-0.002);
    else
        _diesel_gen4_control_exciter_rate_limit__state = _diesel_gen4_control_exciter_switch__out;
    _diesel_gen4_control_exciter_rate_limit__first_step = 0;
    // Generated from the component: Diesel_Gen1.Control.Freq_setpoint_control.w_ramp
    if (_diesel_gen1_control_freq_setpoint_control_w_switch__out - _diesel_gen1_control_freq_setpoint_control_w_ramp__state > 0.002)
        _diesel_gen1_control_freq_setpoint_control_w_ramp__state += (0.002);
    else  if (_diesel_gen1_control_freq_setpoint_control_w_switch__out - _diesel_gen1_control_freq_setpoint_control_w_ramp__state < -0.002)
        _diesel_gen1_control_freq_setpoint_control_w_ramp__state += (-0.002);
    else
        _diesel_gen1_control_freq_setpoint_control_w_ramp__state = _diesel_gen1_control_freq_setpoint_control_w_switch__out;
    _diesel_gen1_control_freq_setpoint_control_w_ramp__first_step = 0;
    // Generated from the component: Diesel_Gen1.Control.Read_Control_mode.State
    // Generated from the component: Diesel_Gen1.Control.pf Control.PI.Integrator1
    _diesel_gen1_control_pf_control_pi_integrator1__state += _diesel_gen1_control_pf_control_pi_sum7__out * 0.0002;
    if (_diesel_gen1_control_pf_control_logical_operator5__out > 0)
        _diesel_gen1_control_pf_control_pi_integrator1__reset_state = 1;
    else if (_diesel_gen1_control_pf_control_logical_operator5__out < 0)
        _diesel_gen1_control_pf_control_pi_integrator1__reset_state = -1;
    else
        _diesel_gen1_control_pf_control_pi_integrator1__reset_state = 0;
    // Generated from the component: Diesel_Gen2.Control.Freq_setpoint_control.w_ramp
    if (_diesel_gen2_control_freq_setpoint_control_w_switch__out - _diesel_gen2_control_freq_setpoint_control_w_ramp__state > 0.002)
        _diesel_gen2_control_freq_setpoint_control_w_ramp__state += (0.002);
    else  if (_diesel_gen2_control_freq_setpoint_control_w_switch__out - _diesel_gen2_control_freq_setpoint_control_w_ramp__state < -0.002)
        _diesel_gen2_control_freq_setpoint_control_w_ramp__state += (-0.002);
    else
        _diesel_gen2_control_freq_setpoint_control_w_ramp__state = _diesel_gen2_control_freq_setpoint_control_w_switch__out;
    _diesel_gen2_control_freq_setpoint_control_w_ramp__first_step = 0;
    // Generated from the component: Diesel_Gen2.Control.Read_Control_mode.State
    // Generated from the component: Diesel_Gen2.Control.pf Control.PI.Integrator1
    _diesel_gen2_control_pf_control_pi_integrator1__state += _diesel_gen2_control_pf_control_pi_sum7__out * 0.0002;
    if (_diesel_gen2_control_pf_control_logical_operator5__out > 0)
        _diesel_gen2_control_pf_control_pi_integrator1__reset_state = 1;
    else if (_diesel_gen2_control_pf_control_logical_operator5__out < 0)
        _diesel_gen2_control_pf_control_pi_integrator1__reset_state = -1;
    else
        _diesel_gen2_control_pf_control_pi_integrator1__reset_state = 0;
    // Generated from the component: Diesel_Gen4.Control.Freq_setpoint_control.w_ramp
    if (_diesel_gen4_control_freq_setpoint_control_w_switch__out - _diesel_gen4_control_freq_setpoint_control_w_ramp__state > 0.002)
        _diesel_gen4_control_freq_setpoint_control_w_ramp__state += (0.002);
    else  if (_diesel_gen4_control_freq_setpoint_control_w_switch__out - _diesel_gen4_control_freq_setpoint_control_w_ramp__state < -0.002)
        _diesel_gen4_control_freq_setpoint_control_w_ramp__state += (-0.002);
    else
        _diesel_gen4_control_freq_setpoint_control_w_ramp__state = _diesel_gen4_control_freq_setpoint_control_w_switch__out;
    _diesel_gen4_control_freq_setpoint_control_w_ramp__first_step = 0;
    // Generated from the component: Diesel_Gen4.Control.Read_Control_mode.State
    // Generated from the component: Diesel_Gen4.Control.pf Control.PI.Integrator1
    _diesel_gen4_control_pf_control_pi_integrator1__state += _diesel_gen4_control_pf_control_pi_sum7__out * 0.0002;
    if (_diesel_gen4_control_pf_control_logical_operator5__out > 0)
        _diesel_gen4_control_pf_control_pi_integrator1__reset_state = 1;
    else if (_diesel_gen4_control_pf_control_logical_operator5__out < 0)
        _diesel_gen4_control_pf_control_pi_integrator1__reset_state = -1;
    else
        _diesel_gen4_control_pf_control_pi_integrator1__reset_state = 0;
    // Generated from the component: Diesel_Gen3.Control.Freq_setpoint_control.w_ramp
    if (_diesel_gen3_control_freq_setpoint_control_w_switch__out - _diesel_gen3_control_freq_setpoint_control_w_ramp__state > 0.002)
        _diesel_gen3_control_freq_setpoint_control_w_ramp__state += (0.002);
    else  if (_diesel_gen3_control_freq_setpoint_control_w_switch__out - _diesel_gen3_control_freq_setpoint_control_w_ramp__state < -0.002)
        _diesel_gen3_control_freq_setpoint_control_w_ramp__state += (-0.002);
    else
        _diesel_gen3_control_freq_setpoint_control_w_ramp__state = _diesel_gen3_control_freq_setpoint_control_w_switch__out;
    _diesel_gen3_control_freq_setpoint_control_w_ramp__first_step = 0;
    // Generated from the component: Diesel_Gen3.Control.Read_Control_mode.State
    // Generated from the component: Diesel_Gen3.Control.pf Control.PI.Integrator1
    _diesel_gen3_control_pf_control_pi_integrator1__state += _diesel_gen3_control_pf_control_pi_sum7__out * 0.0002;
    if (_diesel_gen3_control_pf_control_logical_operator5__out > 0)
        _diesel_gen3_control_pf_control_pi_integrator1__reset_state = 1;
    else if (_diesel_gen3_control_pf_control_logical_operator5__out < 0)
        _diesel_gen3_control_pf_control_pi_integrator1__reset_state = -1;
    else
        _diesel_gen3_control_pf_control_pi_integrator1__reset_state = 0;
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.PLL_Grid.LPF_Vt
    _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__states[0] = _diesel_gen1_sync_check_plls_pll_grid_lpf_vt__delay_line_in;
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.Rate Limiter1
    if (_diesel_gen1_measurements_3ph_pll_gen_pll_pi_limit1__out - _diesel_gen1_measurements_3ph_pll_gen_pll_rate_limiter1__state > 0.015079644737231007)
        _diesel_gen1_measurements_3ph_pll_gen_pll_rate_limiter1__state += (0.015079644737231007);
    else  if (_diesel_gen1_measurements_3ph_pll_gen_pll_pi_limit1__out - _diesel_gen1_measurements_3ph_pll_gen_pll_rate_limiter1__state < -0.015079644737231007)
        _diesel_gen1_measurements_3ph_pll_gen_pll_rate_limiter1__state += (-0.015079644737231007);
    else
        _diesel_gen1_measurements_3ph_pll_gen_pll_rate_limiter1__state = _diesel_gen1_measurements_3ph_pll_gen_pll_pi_limit1__out;
    _diesel_gen1_measurements_3ph_pll_gen_pll_rate_limiter1__first_step = 0;
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.integrator
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.PLL_Grid.LPF_Vt
    _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__states[0] = _diesel_gen2_sync_check_plls_pll_grid_lpf_vt__delay_line_in;
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.Rate Limiter1
    if (_diesel_gen2_measurements_3ph_pll_gen_pll_pi_limit1__out - _diesel_gen2_measurements_3ph_pll_gen_pll_rate_limiter1__state > 0.015079644737231007)
        _diesel_gen2_measurements_3ph_pll_gen_pll_rate_limiter1__state += (0.015079644737231007);
    else  if (_diesel_gen2_measurements_3ph_pll_gen_pll_pi_limit1__out - _diesel_gen2_measurements_3ph_pll_gen_pll_rate_limiter1__state < -0.015079644737231007)
        _diesel_gen2_measurements_3ph_pll_gen_pll_rate_limiter1__state += (-0.015079644737231007);
    else
        _diesel_gen2_measurements_3ph_pll_gen_pll_rate_limiter1__state = _diesel_gen2_measurements_3ph_pll_gen_pll_pi_limit1__out;
    _diesel_gen2_measurements_3ph_pll_gen_pll_rate_limiter1__first_step = 0;
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.integrator
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.PLL_Grid.LPF_Vt
    _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__states[0] = _diesel_gen3_sync_check_plls_pll_grid_lpf_vt__delay_line_in;
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.Rate Limiter1
    if (_diesel_gen3_measurements_3ph_pll_gen_pll_pi_limit1__out - _diesel_gen3_measurements_3ph_pll_gen_pll_rate_limiter1__state > 0.015079644737231007)
        _diesel_gen3_measurements_3ph_pll_gen_pll_rate_limiter1__state += (0.015079644737231007);
    else  if (_diesel_gen3_measurements_3ph_pll_gen_pll_pi_limit1__out - _diesel_gen3_measurements_3ph_pll_gen_pll_rate_limiter1__state < -0.015079644737231007)
        _diesel_gen3_measurements_3ph_pll_gen_pll_rate_limiter1__state += (-0.015079644737231007);
    else
        _diesel_gen3_measurements_3ph_pll_gen_pll_rate_limiter1__state = _diesel_gen3_measurements_3ph_pll_gen_pll_pi_limit1__out;
    _diesel_gen3_measurements_3ph_pll_gen_pll_rate_limiter1__first_step = 0;
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.integrator
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.PLL_Grid.LPF_Vt
    _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__states[0] = _diesel_gen4_sync_check_plls_pll_grid_lpf_vt__delay_line_in;
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.Rate Limiter1
    if (_diesel_gen4_measurements_3ph_pll_gen_pll_pi_limit1__out - _diesel_gen4_measurements_3ph_pll_gen_pll_rate_limiter1__state > 0.015079644737231007)
        _diesel_gen4_measurements_3ph_pll_gen_pll_rate_limiter1__state += (0.015079644737231007);
    else  if (_diesel_gen4_measurements_3ph_pll_gen_pll_pi_limit1__out - _diesel_gen4_measurements_3ph_pll_gen_pll_rate_limiter1__state < -0.015079644737231007)
        _diesel_gen4_measurements_3ph_pll_gen_pll_rate_limiter1__state += (-0.015079644737231007);
    else
        _diesel_gen4_measurements_3ph_pll_gen_pll_rate_limiter1__state = _diesel_gen4_measurements_3ph_pll_gen_pll_pi_limit1__out;
    _diesel_gen4_measurements_3ph_pll_gen_pll_rate_limiter1__first_step = 0;
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.integrator
    // Generated from the component: Diesel_Gen1.Control.pf Control.Rate Limiter1
    if (_diesel_gen1_control_pf_control_signal_switch2__out - _diesel_gen1_control_pf_control_rate_limiter1__state > 0.002)
        _diesel_gen1_control_pf_control_rate_limiter1__state += (0.002);
    else  if (_diesel_gen1_control_pf_control_signal_switch2__out - _diesel_gen1_control_pf_control_rate_limiter1__state < -0.002)
        _diesel_gen1_control_pf_control_rate_limiter1__state += (-0.002);
    else
        _diesel_gen1_control_pf_control_rate_limiter1__state = _diesel_gen1_control_pf_control_signal_switch2__out;
    _diesel_gen1_control_pf_control_rate_limiter1__first_step = 0;
    // Generated from the component: Diesel_Gen2.Control.pf Control.Rate Limiter1
    if (_diesel_gen2_control_pf_control_signal_switch2__out - _diesel_gen2_control_pf_control_rate_limiter1__state > 0.002)
        _diesel_gen2_control_pf_control_rate_limiter1__state += (0.002);
    else  if (_diesel_gen2_control_pf_control_signal_switch2__out - _diesel_gen2_control_pf_control_rate_limiter1__state < -0.002)
        _diesel_gen2_control_pf_control_rate_limiter1__state += (-0.002);
    else
        _diesel_gen2_control_pf_control_rate_limiter1__state = _diesel_gen2_control_pf_control_signal_switch2__out;
    _diesel_gen2_control_pf_control_rate_limiter1__first_step = 0;
    // Generated from the component: Diesel_Gen4.Control.pf Control.Rate Limiter1
    if (_diesel_gen4_control_pf_control_signal_switch2__out - _diesel_gen4_control_pf_control_rate_limiter1__state > 0.002)
        _diesel_gen4_control_pf_control_rate_limiter1__state += (0.002);
    else  if (_diesel_gen4_control_pf_control_signal_switch2__out - _diesel_gen4_control_pf_control_rate_limiter1__state < -0.002)
        _diesel_gen4_control_pf_control_rate_limiter1__state += (-0.002);
    else
        _diesel_gen4_control_pf_control_rate_limiter1__state = _diesel_gen4_control_pf_control_signal_switch2__out;
    _diesel_gen4_control_pf_control_rate_limiter1__first_step = 0;
    // Generated from the component: Diesel_Gen3.Control.pf Control.Rate Limiter1
    if (_diesel_gen3_control_pf_control_signal_switch2__out - _diesel_gen3_control_pf_control_rate_limiter1__state > 0.002)
        _diesel_gen3_control_pf_control_rate_limiter1__state += (0.002);
    else  if (_diesel_gen3_control_pf_control_signal_switch2__out - _diesel_gen3_control_pf_control_rate_limiter1__state < -0.002)
        _diesel_gen3_control_pf_control_rate_limiter1__state += (-0.002);
    else
        _diesel_gen3_control_pf_control_rate_limiter1__state = _diesel_gen3_control_pf_control_signal_switch2__out;
    _diesel_gen3_control_pf_control_rate_limiter1__first_step = 0;
    // Generated from the component: Diesel_Gen1.Measurements.3ph_PLL_Gen.PLL.LPF_q1
    for (_diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__i = 1; _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__i > 0; _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__i--) {
        _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__states[_diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__i] = _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__states[_diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__i - 1];
    }
    _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__states[0] = _diesel_gen1_measurements_3ph_pll_gen_pll_lpf_q1__delay_line_in;
    // Generated from the component: Diesel_Gen2.Measurements.3ph_PLL_Gen.PLL.LPF_q1
    for (_diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__i = 1; _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__i > 0; _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__i--) {
        _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__states[_diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__i] = _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__states[_diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__i - 1];
    }
    _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__states[0] = _diesel_gen2_measurements_3ph_pll_gen_pll_lpf_q1__delay_line_in;
    // Generated from the component: Diesel_Gen3.Measurements.3ph_PLL_Gen.PLL.LPF_q1
    for (_diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__i = 1; _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__i > 0; _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__i--) {
        _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__states[_diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__i] = _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__states[_diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__i - 1];
    }
    _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__states[0] = _diesel_gen3_measurements_3ph_pll_gen_pll_lpf_q1__delay_line_in;
    // Generated from the component: Diesel_Gen4.Measurements.3ph_PLL_Gen.PLL.LPF_q1
    for (_diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__i = 1; _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__i > 0; _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__i--) {
        _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__states[_diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__i] = _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__states[_diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__i - 1];
    }
    _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__states[0] = _diesel_gen4_measurements_3ph_pll_gen_pll_lpf_q1__delay_line_in;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.PI.Integrator1
    _diesel_gen1_sync_check_check_phase_diff_pi_integrator1__state += _diesel_gen1_sync_check_check_phase_diff_pi_sum7__out * 0.0002;
    if (_diesel_gen1_sync_check_and1__out > 0)
        _diesel_gen1_sync_check_check_phase_diff_pi_integrator1__reset_state = 1;
    else if (_diesel_gen1_sync_check_and1__out < 0)
        _diesel_gen1_sync_check_check_phase_diff_pi_integrator1__reset_state = -1;
    else
        _diesel_gen1_sync_check_check_phase_diff_pi_integrator1__reset_state = 0;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.PI.Integrator1
    _diesel_gen2_sync_check_check_phase_diff_pi_integrator1__state += _diesel_gen2_sync_check_check_phase_diff_pi_sum7__out * 0.0002;
    if (_diesel_gen2_sync_check_and1__out > 0)
        _diesel_gen2_sync_check_check_phase_diff_pi_integrator1__reset_state = 1;
    else if (_diesel_gen2_sync_check_and1__out < 0)
        _diesel_gen2_sync_check_check_phase_diff_pi_integrator1__reset_state = -1;
    else
        _diesel_gen2_sync_check_check_phase_diff_pi_integrator1__reset_state = 0;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.PI.Integrator1
    _diesel_gen4_sync_check_check_phase_diff_pi_integrator1__state += _diesel_gen4_sync_check_check_phase_diff_pi_sum7__out * 0.0002;
    if (_diesel_gen4_sync_check_and1__out > 0)
        _diesel_gen4_sync_check_check_phase_diff_pi_integrator1__reset_state = 1;
    else if (_diesel_gen4_sync_check_and1__out < 0)
        _diesel_gen4_sync_check_check_phase_diff_pi_integrator1__reset_state = -1;
    else
        _diesel_gen4_sync_check_check_phase_diff_pi_integrator1__reset_state = 0;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.PI.Integrator1
    _diesel_gen3_sync_check_check_phase_diff_pi_integrator1__state += _diesel_gen3_sync_check_check_phase_diff_pi_sum7__out * 0.0002;
    if (_diesel_gen3_sync_check_and1__out > 0)
        _diesel_gen3_sync_check_check_phase_diff_pi_integrator1__reset_state = 1;
    else if (_diesel_gen3_sync_check_and1__out < 0)
        _diesel_gen3_sync_check_check_phase_diff_pi_integrator1__reset_state = -1;
    else
        _diesel_gen3_sync_check_check_phase_diff_pi_integrator1__reset_state = 0;
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.PLL_Grid.PLL.integrator
    _diesel_gen1_sync_check_plls_pll_grid_pll_integrator__out += 0.0002 * _diesel_gen1_sync_check_plls_pll_grid_pll_integrator__in;
    if (_diesel_gen1_sync_check_plls_pll_grid_pll_integrator__in >= 0.0) {
        if (_diesel_gen1_sync_check_plls_pll_grid_pll_integrator__out >= 6.283185307179586) {
            _diesel_gen1_sync_check_plls_pll_grid_pll_integrator__out -= 6.283185307179586;
        }
    }
    else {
        if (_diesel_gen1_sync_check_plls_pll_grid_pll_integrator__out <= -6.283185307179586) {
            _diesel_gen1_sync_check_plls_pll_grid_pll_integrator__out += 6.283185307179586;
        }
    }
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.PLL_Grid.PLL.integrator
    _diesel_gen2_sync_check_plls_pll_grid_pll_integrator__out += 0.0002 * _diesel_gen2_sync_check_plls_pll_grid_pll_integrator__in;
    if (_diesel_gen2_sync_check_plls_pll_grid_pll_integrator__in >= 0.0) {
        if (_diesel_gen2_sync_check_plls_pll_grid_pll_integrator__out >= 6.283185307179586) {
            _diesel_gen2_sync_check_plls_pll_grid_pll_integrator__out -= 6.283185307179586;
        }
    }
    else {
        if (_diesel_gen2_sync_check_plls_pll_grid_pll_integrator__out <= -6.283185307179586) {
            _diesel_gen2_sync_check_plls_pll_grid_pll_integrator__out += 6.283185307179586;
        }
    }
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.PLL_Grid.PLL.integrator
    _diesel_gen3_sync_check_plls_pll_grid_pll_integrator__out += 0.0002 * _diesel_gen3_sync_check_plls_pll_grid_pll_integrator__in;
    if (_diesel_gen3_sync_check_plls_pll_grid_pll_integrator__in >= 0.0) {
        if (_diesel_gen3_sync_check_plls_pll_grid_pll_integrator__out >= 6.283185307179586) {
            _diesel_gen3_sync_check_plls_pll_grid_pll_integrator__out -= 6.283185307179586;
        }
    }
    else {
        if (_diesel_gen3_sync_check_plls_pll_grid_pll_integrator__out <= -6.283185307179586) {
            _diesel_gen3_sync_check_plls_pll_grid_pll_integrator__out += 6.283185307179586;
        }
    }
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.PLL_Grid.PLL.integrator
    _diesel_gen4_sync_check_plls_pll_grid_pll_integrator__out += 0.0002 * _diesel_gen4_sync_check_plls_pll_grid_pll_integrator__in;
    if (_diesel_gen4_sync_check_plls_pll_grid_pll_integrator__in >= 0.0) {
        if (_diesel_gen4_sync_check_plls_pll_grid_pll_integrator__out >= 6.283185307179586) {
            _diesel_gen4_sync_check_plls_pll_grid_pll_integrator__out -= 6.283185307179586;
        }
    }
    else {
        if (_diesel_gen4_sync_check_plls_pll_grid_pll_integrator__out <= -6.283185307179586) {
            _diesel_gen4_sync_check_plls_pll_grid_pll_integrator__out += 6.283185307179586;
        }
    }
    // Generated from the component: Diesel_Gen1.Sync_Check.Contactor_Control.wait_to_trip
    // Generated from the component: Diesel_Gen2.Sync_Check.Contactor_Control.wait_to_trip
    // Generated from the component: Diesel_Gen4.Sync_Check.Contactor_Control.wait_to_trip
    // Generated from the component: Diesel_Gen3.Sync_Check.Contactor_Control.wait_to_trip
    // Generated from the component: Diesel_Gen1.Sync_Check.PLLs.PLL_Grid.LPF_f
    _diesel_gen1_sync_check_plls_pll_grid_lpf_f__states[0] = _diesel_gen1_sync_check_plls_pll_grid_lpf_f__delay_line_in;
    // Generated from the component: Diesel_Gen2.Sync_Check.PLLs.PLL_Grid.LPF_f
    _diesel_gen2_sync_check_plls_pll_grid_lpf_f__states[0] = _diesel_gen2_sync_check_plls_pll_grid_lpf_f__delay_line_in;
    // Generated from the component: Diesel_Gen3.Sync_Check.PLLs.PLL_Grid.LPF_f
    _diesel_gen3_sync_check_plls_pll_grid_lpf_f__states[0] = _diesel_gen3_sync_check_plls_pll_grid_lpf_f__delay_line_in;
    // Generated from the component: Diesel_Gen4.Sync_Check.PLLs.PLL_Grid.LPF_f
    _diesel_gen4_sync_check_plls_pll_grid_lpf_f__states[0] = _diesel_gen4_sync_check_plls_pll_grid_lpf_f__delay_line_in;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.confine_phase
    // Generated from the component: Diesel_Gen1.Sync_Check.check_f_diff.LPF_dwf
    _diesel_gen1_sync_check_check_f_diff_lpf_dwf__states[0] = _diesel_gen1_sync_check_check_f_diff_lpf_dwf__delay_line_in;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.confine_phase
    // Generated from the component: Diesel_Gen2.Sync_Check.check_f_diff.LPF_dwf
    _diesel_gen2_sync_check_check_f_diff_lpf_dwf__states[0] = _diesel_gen2_sync_check_check_f_diff_lpf_dwf__delay_line_in;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.confine_phase
    // Generated from the component: Diesel_Gen3.Sync_Check.check_f_diff.LPF_dwf
    _diesel_gen3_sync_check_check_f_diff_lpf_dwf__states[0] = _diesel_gen3_sync_check_check_f_diff_lpf_dwf__delay_line_in;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.confine_phase
    // Generated from the component: Diesel_Gen4.Sync_Check.check_f_diff.LPF_dwf
    _diesel_gen4_sync_check_check_f_diff_lpf_dwf__states[0] = _diesel_gen4_sync_check_check_f_diff_lpf_dwf__delay_line_in;
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.offset_phase
    // Generated from the component: Diesel_Gen1.Sync_Check.check_V_diff.Comparator1
    if (_diesel_gen1_sync_check_check_v_diff_volt_diff__out < _diesel_gen1_sync_check_check_v_diff_abs3__out) {
        _diesel_gen1_sync_check_check_v_diff_comparator1__state = 0;
    } else if (_diesel_gen1_sync_check_check_v_diff_volt_diff__out > _diesel_gen1_sync_check_check_v_diff_abs3__out) {
        _diesel_gen1_sync_check_check_v_diff_comparator1__state = 1;
    }
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.offset_phase
    // Generated from the component: Diesel_Gen2.Sync_Check.check_V_diff.Comparator1
    if (_diesel_gen2_sync_check_check_v_diff_volt_diff__out < _diesel_gen2_sync_check_check_v_diff_abs3__out) {
        _diesel_gen2_sync_check_check_v_diff_comparator1__state = 0;
    } else if (_diesel_gen2_sync_check_check_v_diff_volt_diff__out > _diesel_gen2_sync_check_check_v_diff_abs3__out) {
        _diesel_gen2_sync_check_check_v_diff_comparator1__state = 1;
    }
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.offset_phase
    // Generated from the component: Diesel_Gen3.Sync_Check.check_V_diff.Comparator1
    if (_diesel_gen3_sync_check_check_v_diff_volt_diff__out < _diesel_gen3_sync_check_check_v_diff_abs3__out) {
        _diesel_gen3_sync_check_check_v_diff_comparator1__state = 0;
    } else if (_diesel_gen3_sync_check_check_v_diff_volt_diff__out > _diesel_gen3_sync_check_check_v_diff_abs3__out) {
        _diesel_gen3_sync_check_check_v_diff_comparator1__state = 1;
    }
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.offset_phase
    // Generated from the component: Diesel_Gen4.Sync_Check.check_V_diff.Comparator1
    if (_diesel_gen4_sync_check_check_v_diff_volt_diff__out < _diesel_gen4_sync_check_check_v_diff_abs3__out) {
        _diesel_gen4_sync_check_check_v_diff_comparator1__state = 0;
    } else if (_diesel_gen4_sync_check_check_v_diff_volt_diff__out > _diesel_gen4_sync_check_check_v_diff_abs3__out) {
        _diesel_gen4_sync_check_check_v_diff_comparator1__state = 1;
    }
    // Generated from the component: Diesel_Gen1.Sync_Check.check_phase_diff.LPF
    _diesel_gen1_sync_check_check_phase_diff_lpf__states[0] = _diesel_gen1_sync_check_check_phase_diff_lpf__delay_line_in;
    // Generated from the component: Diesel_Gen2.Sync_Check.check_phase_diff.LPF
    _diesel_gen2_sync_check_check_phase_diff_lpf__states[0] = _diesel_gen2_sync_check_check_phase_diff_lpf__delay_line_in;
    // Generated from the component: Diesel_Gen3.Sync_Check.check_phase_diff.LPF
    _diesel_gen3_sync_check_check_phase_diff_lpf__states[0] = _diesel_gen3_sync_check_check_phase_diff_lpf__delay_line_in;
    // Generated from the component: Diesel_Gen4.Sync_Check.check_phase_diff.LPF
    _diesel_gen4_sync_check_check_phase_diff_lpf__states[0] = _diesel_gen4_sync_check_check_phase_diff_lpf__delay_line_in;
    // Generated from the component: Diesel_Gen1.Sync_Check.Calculate_dw_synch.LPF_dw
    _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__states[0] = _diesel_gen1_sync_check_calculate_dw_synch_lpf_dw__delay_line_in;
    // Generated from the component: Diesel_Gen2.Sync_Check.Calculate_dw_synch.LPF_dw
    _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__states[0] = _diesel_gen2_sync_check_calculate_dw_synch_lpf_dw__delay_line_in;
    // Generated from the component: Diesel_Gen4.Sync_Check.Calculate_dw_synch.LPF_dw
    _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__states[0] = _diesel_gen4_sync_check_calculate_dw_synch_lpf_dw__delay_line_in;
    // Generated from the component: Diesel_Gen3.Sync_Check.Calculate_dw_synch.LPF_dw
    _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__states[0] = _diesel_gen3_sync_check_calculate_dw_synch_lpf_dw__delay_line_in;
    // Generated from the component: Diesel_Gen1.Control.Governor_and_Engine.DEGOV.TF1
    for (_diesel_gen1_control_governor_and_engine_degov_tf1__i = 1; _diesel_gen1_control_governor_and_engine_degov_tf1__i > 0; _diesel_gen1_control_governor_and_engine_degov_tf1__i--) {
        _diesel_gen1_control_governor_and_engine_degov_tf1__states[_diesel_gen1_control_governor_and_engine_degov_tf1__i] = _diesel_gen1_control_governor_and_engine_degov_tf1__states[_diesel_gen1_control_governor_and_engine_degov_tf1__i - 1];
    }
    _diesel_gen1_control_governor_and_engine_degov_tf1__states[0] = _diesel_gen1_control_governor_and_engine_degov_tf1__delay_line_in;
    // Generated from the component: Diesel_Gen2.Control.Governor_and_Engine.DEGOV.TF1
    for (_diesel_gen2_control_governor_and_engine_degov_tf1__i = 1; _diesel_gen2_control_governor_and_engine_degov_tf1__i > 0; _diesel_gen2_control_governor_and_engine_degov_tf1__i--) {
        _diesel_gen2_control_governor_and_engine_degov_tf1__states[_diesel_gen2_control_governor_and_engine_degov_tf1__i] = _diesel_gen2_control_governor_and_engine_degov_tf1__states[_diesel_gen2_control_governor_and_engine_degov_tf1__i - 1];
    }
    _diesel_gen2_control_governor_and_engine_degov_tf1__states[0] = _diesel_gen2_control_governor_and_engine_degov_tf1__delay_line_in;
    // Generated from the component: Diesel_Gen3.Control.Governor_and_Engine.DEGOV.TF1
    for (_diesel_gen3_control_governor_and_engine_degov_tf1__i = 1; _diesel_gen3_control_governor_and_engine_degov_tf1__i > 0; _diesel_gen3_control_governor_and_engine_degov_tf1__i--) {
        _diesel_gen3_control_governor_and_engine_degov_tf1__states[_diesel_gen3_control_governor_and_engine_degov_tf1__i] = _diesel_gen3_control_governor_and_engine_degov_tf1__states[_diesel_gen3_control_governor_and_engine_degov_tf1__i - 1];
    }
    _diesel_gen3_control_governor_and_engine_degov_tf1__states[0] = _diesel_gen3_control_governor_and_engine_degov_tf1__delay_line_in;
    // Generated from the component: Diesel_Gen4.Control.Governor_and_Engine.DEGOV.TF1
    for (_diesel_gen4_control_governor_and_engine_degov_tf1__i = 1; _diesel_gen4_control_governor_and_engine_degov_tf1__i > 0; _diesel_gen4_control_governor_and_engine_degov_tf1__i--) {
        _diesel_gen4_control_governor_and_engine_degov_tf1__states[_diesel_gen4_control_governor_and_engine_degov_tf1__i] = _diesel_gen4_control_governor_and_engine_degov_tf1__states[_diesel_gen4_control_governor_and_engine_degov_tf1__i - 1];
    }
    _diesel_gen4_control_governor_and_engine_degov_tf1__states[0] = _diesel_gen4_control_governor_and_engine_degov_tf1__delay_line_in;
    // Generated from the component: Diesel_Gen1.Control.Exciter.DC4B.TF2
    _diesel_gen1_control_exciter_dc4b_tf2__states[0] = _diesel_gen1_control_exciter_dc4b_tf2__delay_line_in;
    // Generated from the component: Diesel_Gen2.Control.Exciter.DC4B.TF2
    _diesel_gen2_control_exciter_dc4b_tf2__states[0] = _diesel_gen2_control_exciter_dc4b_tf2__delay_line_in;
    // Generated from the component: Diesel_Gen3.Control.Exciter.DC4B.TF2
    _diesel_gen3_control_exciter_dc4b_tf2__states[0] = _diesel_gen3_control_exciter_dc4b_tf2__delay_line_in;
    // Generated from the component: Diesel_Gen4.Control.Exciter.DC4B.TF2
    _diesel_gen4_control_exciter_dc4b_tf2__states[0] = _diesel_gen4_control_exciter_dc4b_tf2__delay_line_in;
    //@cmp.update.block.end
}
// ----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------